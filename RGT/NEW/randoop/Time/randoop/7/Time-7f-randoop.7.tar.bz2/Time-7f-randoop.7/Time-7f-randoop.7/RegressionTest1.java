import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.addMonths((-1));
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.secondOfDay();
        mutableDateTime4.addYears((int) '#');
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology11);
        mutableDateTime14.addMonths((-1));
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime14.secondOfDay();
        boolean boolean18 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        try {
            mutableDateTime14.setTime((-18059), 19677, 19686, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -18059 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.yearOfCentury();
        java.lang.String str6 = property5.getName();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "yearOfCentury" + "'", str6.equals("yearOfCentury"));
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
//        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
//        int int19 = mutableDateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
//        org.joda.time.DurationField durationField27 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
//        int int50 = offsetDateTimeField48.getLeapAmount((long) (short) 10);
//        long long52 = offsetDateTimeField48.roundHalfCeiling((long) 19676);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19700 + "'", int19 == 19700);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 20000L + "'", long52 == 20000L);
//    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
//        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
//        int int19 = mutableDateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
//        org.joda.time.DurationField durationField27 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology50.yearOfCentury();
//        java.util.Locale locale53 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology50, locale53, (java.lang.Integer) (-2), 19675);
//        java.lang.Object obj57 = dateTimeParserBucket56.saveState();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder58.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField62 = gJChronology61.weekyears();
//        org.joda.time.DurationField durationField63 = gJChronology61.millis();
//        org.joda.time.DateTimeField dateTimeField64 = gJChronology61.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime65 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property66 = mutableDateTime65.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property66.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField71 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField64, dateTimeFieldType67);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException77 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder58.appendFixedDecimal(dateTimeFieldType67, (int) (short) 100);
//        dateTimeParserBucket56.saveField(dateTimeFieldType67, 0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType67, 19683);
//        try {
//            long long86 = dividedDateTimeField83.addWrapField(365300444L, 20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19700 + "'", int19 == 19700);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(obj57);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
//        org.junit.Assert.assertNotNull(gJChronology61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(durationField63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(property66);
//        org.junit.Assert.assertNotNull(dateTimeFieldType67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (byte) 100);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.weekyear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        long long6 = cachedDateTimeZone3.previousTransition((long) 4);
        long long8 = cachedDateTimeZone3.nextTransition(1613L);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 4L + "'", long6 == 4L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1613L + "'", long8 == 1613L);
        org.junit.Assert.assertNotNull(julianChronology9);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        int int5 = mutableDateTime4.getRoundingMode();
        boolean boolean7 = mutableDateTime4.isAfter((long) 19670);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        int int6 = cachedDateTimeZone3.getStandardOffset((long) 12);
        long long8 = cachedDateTimeZone3.previousTransition(19684L);
        boolean boolean9 = cachedDateTimeZone3.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 19684L + "'", long8 == 19684L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
//        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendClockhourOfDay(19667);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendClockhourOfHalfday((int) (short) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder23.appendYear(0, (int) (short) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property31 = dateTime30.minuteOfDay();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime30.minus(readablePeriod32);
//        java.lang.String str34 = dateTimeFormatter29.print((org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.format.DateTimePrinter dateTimePrinter35 = dateTimeFormatter29.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder36.appendMinuteOfDay(19);
//        org.joda.time.format.DateTimePrinter dateTimePrinter39 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter40.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser42 = dateTimeFormatter41.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter43.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser45 = dateTimeFormatter44.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = dateTimeFormatter46.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser48 = dateTimeFormatter47.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = dateTimeFormatter49.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser51 = dateTimeFormatter50.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = dateTimeFormatter52.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser54 = dateTimeFormatter53.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray55 = new org.joda.time.format.DateTimeParser[] { dateTimeParser42, dateTimeParser45, dateTimeParser48, dateTimeParser51, dateTimeParser54 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder36.append(dateTimePrinter39, dateTimeParserArray55);
//        boolean boolean57 = dateTimeFormatterBuilder36.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder36.appendClockhourOfDay(19667);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder59.appendSecondOfMinute(27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder61.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter63 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property65 = dateTime64.minuteOfDay();
//        org.joda.time.ReadablePeriod readablePeriod66 = null;
//        org.joda.time.DateTime dateTime67 = dateTime64.minus(readablePeriod66);
//        java.lang.String str68 = dateTimeFormatter63.print((org.joda.time.ReadableInstant) dateTime64);
//        org.joda.time.format.DateTimePrinter dateTimePrinter69 = dateTimeFormatter63.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter71 = dateTimeFormatter70.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser72 = dateTimeFormatter71.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter73 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter74 = dateTimeFormatter73.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser75 = dateTimeFormatter74.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter76 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter77 = dateTimeFormatter76.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser78 = dateTimeFormatter77.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray79 = new org.joda.time.format.DateTimeParser[] { dateTimeParser72, dateTimeParser75, dateTimeParser78 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder80 = dateTimeFormatterBuilder62.append(dateTimePrinter69, dateTimeParserArray79);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder28.append(dateTimePrinter35, dateTimeParserArray79);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeParser6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeParser9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeParser12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeParser15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeParser18);
//        org.junit.Assert.assertNotNull(dateTimeParserArray19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019-07-12T05" + "'", str34.equals("2019-07-12T05"));
//        org.junit.Assert.assertNotNull(dateTimePrinter35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(dateTimeParser42);
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(dateTimeParser45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(dateTimeFormatter47);
//        org.junit.Assert.assertNotNull(dateTimeParser48);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter50);
//        org.junit.Assert.assertNotNull(dateTimeParser51);
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertNotNull(dateTimeParser54);
//        org.junit.Assert.assertNotNull(dateTimeParserArray55);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
//        org.junit.Assert.assertNotNull(dateTimeFormatter63);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "2019-07-12T05" + "'", str68.equals("2019-07-12T05"));
//        org.junit.Assert.assertNotNull(dateTimePrinter69);
//        org.junit.Assert.assertNotNull(dateTimeFormatter70);
//        org.junit.Assert.assertNotNull(dateTimeFormatter71);
//        org.junit.Assert.assertNotNull(dateTimeParser72);
//        org.junit.Assert.assertNotNull(dateTimeFormatter73);
//        org.junit.Assert.assertNotNull(dateTimeFormatter74);
//        org.junit.Assert.assertNotNull(dateTimeParser75);
//        org.junit.Assert.assertNotNull(dateTimeFormatter76);
//        org.junit.Assert.assertNotNull(dateTimeFormatter77);
//        org.junit.Assert.assertNotNull(dateTimeParser78);
//        org.junit.Assert.assertNotNull(dateTimeParserArray79);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder80);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay(19676);
        org.joda.time.DateTime dateTime7 = dateTime3.plusSeconds(19679);
        org.joda.time.DateTime.Property property8 = dateTime7.centuryOfEra();
        boolean boolean9 = property8.isLeap();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology1, locale3);
        java.util.Locale locale5 = dateTimeParserBucket4.getLocale();
        dateTimeParserBucket4.setPivotYear((java.lang.Integer) 163);
        long long10 = dateTimeParserBucket4.computeMillis(false, "2019-07-12T05");
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology12.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField(chronology11, dateTimeField14);
        org.joda.time.DateTimeField dateTimeField16 = skipUndoDateTimeField15.getWrappedField();
        long long19 = skipUndoDateTimeField15.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial20 = null;
        int[] intArray28 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray30 = skipUndoDateTimeField15.add(readablePartial20, 19670, intArray28, 0);
        int int32 = skipUndoDateTimeField15.getMaximumValue((long) (short) 100);
        dateTimeParserBucket4.saveField((org.joda.time.DateTimeField) skipUndoDateTimeField15, (int) (short) 1);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(locale5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 49L + "'", long19 == 49L);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 19);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 19 + "'", int1 == 19);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.add(19674);
        java.lang.String str10 = property7.toString();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[dayOfMonth]" + "'", str10.equals("Property[dayOfMonth]"));
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
//        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
//        int int19 = mutableDateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
//        org.joda.time.DurationField durationField27 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
//        long long51 = zeroIsMaxDateTimeField10.set((long) 19673, 12);
//        long long53 = zeroIsMaxDateTimeField10.roundHalfCeiling(1613L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19700 + "'", int19 == 19700);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 12673L + "'", long51 == 12673L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 2000L + "'", long53 == 2000L);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        boolean boolean21 = dateTimeFormatterBuilder20.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 19670, (java.lang.Number) 192483574L, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology3);
//        mutableDateTime6.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        mutableDateTime6.setZoneRetainFields(dateTimeZone9);
//        int int11 = mutableDateTime6.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = mutableDateTime6.getZone();
//        long long15 = dateTimeZone12.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField19 = gregorianChronology18.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone23 = dateTimeZoneBuilder20.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology24 = gregorianChronology18.withZone(dateTimeZone23);
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.hourOfHalfday();
//        java.util.Locale locale28 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology26, locale28);
//        java.util.Locale locale30 = dateTimeParserBucket29.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket32 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology24, locale30, (java.lang.Integer) 19671);
//        java.lang.String str33 = dateTimeZone12.getShortName((long) 2000, locale30);
//        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField35 = zonedChronology34.minuteOfDay();
//        try {
//            long long41 = zonedChronology34.getDateTimeMillis((long) 27, 19702, 19, 19, 19676);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19702 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 19684L + "'", long15 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(locale30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PST" + "'", str33.equals("PST"));
//        org.junit.Assert.assertNotNull(zonedChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        java.lang.String str17 = illegalFieldValueException16.getIllegalStringValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readablePeriod5);
        org.joda.time.DateTime.Property property7 = dateTime4.weekOfWeekyear();
        boolean boolean8 = gJChronology0.equals((java.lang.Object) dateTime4);
        org.joda.time.DurationField durationField9 = gJChronology0.halfdays();
        long long12 = durationField9.subtract((long) 19691, 0);
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField15 = new org.joda.time.field.ScaledDurationField(durationField9, durationFieldType13, 163);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 19691L + "'", long12 == 19691L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray17 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray19 = skipUndoDateTimeField4.add(readablePartial9, 19670, intArray17, 0);
        java.lang.String str20 = skipUndoDateTimeField4.toString();
        long long22 = skipUndoDateTimeField4.roundHalfFloor(0L);
        org.joda.time.DateTimeField dateTimeField23 = skipUndoDateTimeField4.getWrappedField();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[yearOfCentury]" + "'", str20.equals("DateTimeField[yearOfCentury]"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28800000L + "'", long22 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) 0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone3);
//        java.lang.String str6 = cachedDateTimeZone3.getNameKey((long) (byte) 10);
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
//        java.lang.String str9 = property8.getName();
//        org.joda.time.MutableDateTime mutableDateTime11 = property8.add((long) 'a');
//        org.joda.time.Interval interval12 = property8.toInterval();
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval12);
//        boolean boolean14 = cachedDateTimeZone3.equals((java.lang.Object) chronology13);
//        java.lang.String str16 = cachedDateTimeZone3.getShortName((long) (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(interval12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.add(19674);
        mutableDateTime9.addMillis((-28800000));
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.dayOfWeek();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.addMonths((-1));
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.secondOfDay();
        mutableDateTime4.addYears((int) '#');
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology11);
        mutableDateTime14.addMonths((-1));
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime14.secondOfDay();
        boolean boolean18 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime14.secondOfMinute();
        org.joda.time.DurationFieldType durationFieldType20 = null;
        try {
            mutableDateTime14.add(durationFieldType20, 328);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType9, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendHourOfHalfday(19681);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendYear(1296, (-18059));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong((long) 19670, (-1L));
        long long10 = skipUndoDateTimeField4.roundHalfEven(0L);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4);
        long long14 = skipUndoDateTimeField4.add((long) 19691, (long) (byte) 0);
        long long16 = skipUndoDateTimeField4.remainder((long) 35);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 19691L + "'", long14 == 19691L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 31507200035L + "'", long16 == 31507200035L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType9, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendMillisOfDay(19677);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendTwoDigitYear((-19666));
        org.joda.time.format.DateTimePrinter dateTimePrinter26 = dateTimeFormatterBuilder25.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendTwoDigitWeekyear(10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimePrinter26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 12885, (java.lang.Number) 19669, (java.lang.Number) 19049L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        boolean boolean5 = cachedDateTimeZone3.isStandardOffset((long) 19148);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) 0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone3);
//        boolean boolean5 = cachedDateTimeZone3.isFixed();
//        java.lang.String str7 = cachedDateTimeZone3.getShortName((long) 19678);
//        org.joda.time.LocalDateTime localDateTime8 = null;
//        boolean boolean9 = cachedDateTimeZone3.isLocalDateTimeGap(localDateTime8);
//        int int11 = cachedDateTimeZone3.getOffsetFromLocal((long) 'a');
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("monthOfYear", false);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("19", (int) '4', 19666, 19702, 'a', (int) (byte) 1, 66, 19673, false, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 69);
        boolean boolean2 = mutableDateTime1.isEqualNow();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
//        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
//        int int19 = mutableDateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
//        org.joda.time.DurationField durationField27 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology50.yearOfCentury();
//        java.util.Locale locale53 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology50, locale53, (java.lang.Integer) (-2), 19675);
//        java.lang.Object obj57 = dateTimeParserBucket56.saveState();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder58.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField62 = gJChronology61.weekyears();
//        org.joda.time.DurationField durationField63 = gJChronology61.millis();
//        org.joda.time.DateTimeField dateTimeField64 = gJChronology61.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime65 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property66 = mutableDateTime65.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property66.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField71 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField64, dateTimeFieldType67);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException77 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder58.appendFixedDecimal(dateTimeFieldType67, (int) (short) 100);
//        dateTimeParserBucket56.saveField(dateTimeFieldType67, 0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType67, 19683);
//        long long86 = dividedDateTimeField83.getDifferenceAsLong(0L, (long) (short) 0);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19700 + "'", int19 == 19700);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(obj57);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
//        org.junit.Assert.assertNotNull(gJChronology61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(durationField63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(property66);
//        org.junit.Assert.assertNotNull(dateTimeFieldType67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 0L + "'", long86 == 0L);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.weekOfWeekyear();
        java.lang.String str3 = buddhistChronology0.toString();
        java.lang.String str4 = buddhistChronology0.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[UTC]" + "'", str3.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "BuddhistChronology[UTC]" + "'", str4.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 19672L, (java.lang.Number) 192467526L, (java.lang.Number) 59052L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gJChronology0.add(readablePeriod5, (long) 12, (-2));
        org.joda.time.DurationField durationField9 = gJChronology0.weekyears();
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        int int11 = mutableDateTime10.getRoundingMode();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime10.dayOfYear();
        org.joda.time.ReadablePartial readablePartial13 = null;
        try {
            int int14 = property12.compareTo(readablePartial13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology2);
        mutableDateTime5.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        mutableDateTime5.setZoneRetainFields(dateTimeZone8);
        int int10 = mutableDateTime5.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = mutableDateTime5.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withZone(dateTimeZone11);
        org.joda.time.Chronology chronology13 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNull(chronology13);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType9, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendHourOfHalfday((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatterBuilder21.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder21.appendFractionOfHour(19699, 19679);
        boolean boolean28 = dateTimeFormatterBuilder27.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
        org.joda.time.DateTime dateTime3 = dateTime0.plusMinutes((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime0.plusWeeks(19676);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        try {
            long long13 = gregorianChronology0.getDateTimeMillis(163, 19694, 19678, 19, 1, (-1), 19690);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, "hi!");
        org.joda.time.DurationFieldType durationFieldType13 = illegalFieldValueException12.getDurationFieldType();
        java.lang.String str14 = illegalFieldValueException12.getIllegalValueAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = illegalFieldValueException12.getDateTimeFieldType();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(durationFieldType13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long13 = zeroIsMaxDateTimeField10.set((long) 52, "59");
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = zeroIsMaxDateTimeField10.getType();
        int int16 = zeroIsMaxDateTimeField10.getMaximumValue((long) (-1));
        org.joda.time.DurationField durationField17 = zeroIsMaxDateTimeField10.getRangeDurationField();
        long long20 = zeroIsMaxDateTimeField10.add(2440587L, 19697);
        int int22 = zeroIsMaxDateTimeField10.getMinimumValue((long) (short) 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 59052L + "'", long13 == 59052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 60 + "'", int16 == 60);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 22137587L + "'", long20 == 22137587L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (-19));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(19690, 328);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6458320 + "'", int2 == 6458320);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        long long13 = zeroIsMaxDateTimeField10.set((long) 52, "59");
//        int int14 = zeroIsMaxDateTimeField10.getMinimumValue();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField16 = gJChronology15.weekyears();
//        org.joda.time.DurationField durationField17 = gJChronology15.millis();
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology15.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField18, dateTimeFieldType21);
//        long long27 = zeroIsMaxDateTimeField25.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.monthOfYear();
//        int int30 = mutableDateTime28.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTime dateTime32 = mutableDateTime28.toDateTime(dateTimeZone31);
//        org.joda.time.DateTime dateTime33 = dateTime32.toDateTime();
//        org.joda.time.LocalTime localTime34 = dateTime33.toLocalTime();
//        int int35 = zeroIsMaxDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) localTime34);
//        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property37 = mutableDateTime36.monthOfYear();
//        int int38 = mutableDateTime36.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.DateTime dateTime40 = mutableDateTime36.toDateTime(dateTimeZone39);
//        org.joda.time.DateTime dateTime41 = dateTime40.toDateTime();
//        org.joda.time.LocalTime localTime42 = dateTime41.toLocalTime();
//        org.joda.time.Chronology chronology43 = null;
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField45 = gJChronology44.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField46 = gJChronology44.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField47 = new org.joda.time.field.SkipUndoDateTimeField(chronology43, dateTimeField46);
//        org.joda.time.DateTimeField dateTimeField48 = skipUndoDateTimeField47.getWrappedField();
//        long long51 = skipUndoDateTimeField47.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial52 = null;
//        int[] intArray60 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray62 = skipUndoDateTimeField47.add(readablePartial52, 19670, intArray60, 0);
//        int int63 = zeroIsMaxDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) localTime42, intArray62);
//        int[] intArray64 = null;
//        int int65 = zeroIsMaxDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localTime42, intArray64);
//        long long67 = zeroIsMaxDateTimeField10.roundHalfCeiling(1562934500444L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 59052L + "'", long13 == 59052L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 19700 + "'", int30 == 19700);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(localTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 60 + "'", int35 == 60);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 19700 + "'", int38 == 19700);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(localTime42);
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 49L + "'", long51 == 49L);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 60 + "'", int63 == 60);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1562934500000L + "'", long67 == 1562934500000L);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 69);
        mutableDateTime1.addDays(2019);
        org.joda.time.Chronology chronology4 = mutableDateTime1.getChronology();
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("12", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"12\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long13 = zeroIsMaxDateTimeField10.set((long) 52, "59");
        int int14 = zeroIsMaxDateTimeField10.getMinimumValue();
        org.joda.time.DurationField durationField15 = zeroIsMaxDateTimeField10.getLeapDurationField();
        int int16 = zeroIsMaxDateTimeField10.getMinimumValue();
        int int19 = zeroIsMaxDateTimeField10.getDifference((long) 19671, (long) (-28800000));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 59052L + "'", long13 == 59052L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 28819 + "'", int19 == 28819);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) (-2), 19675);
        java.lang.Integer int8 = dateTimeParserBucket7.getPivotYear();
        java.lang.Integer int9 = dateTimeParserBucket7.getPivotYear();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-2) + "'", int8.equals((-2)));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-2) + "'", int9.equals((-2)));
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField5);
//        org.joda.time.DateTimeField dateTimeField7 = skipUndoDateTimeField6.getWrappedField();
//        long long10 = skipUndoDateTimeField6.getDifferenceAsLong(1560342467589L, (long) ' ');
//        long long12 = skipUndoDateTimeField6.roundFloor((long) (short) 1);
//        int int13 = skipUndoDateTimeField6.getMaximumValue();
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.monthOfYear();
//        int int16 = mutableDateTime14.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = mutableDateTime14.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime18.toDateTime();
//        org.joda.time.LocalTime localTime20 = dateTime19.toLocalTime();
//        int int21 = skipUndoDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) localTime20);
//        java.util.Locale locale22 = null;
//        int int23 = skipUndoDateTimeField6.getMaximumTextLength(locale22);
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology26.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology26);
//        mutableDateTime29.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        mutableDateTime29.setZoneRetainFields(dateTimeZone32);
//        int int34 = mutableDateTime29.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone35 = mutableDateTime29.getZone();
//        long long38 = dateTimeZone35.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField42 = gregorianChronology41.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder43 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone46 = dateTimeZoneBuilder43.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology47 = gregorianChronology41.withZone(dateTimeZone46);
//        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField50 = gJChronology49.hourOfHalfday();
//        java.util.Locale locale51 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket52 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology49, locale51);
//        java.util.Locale locale53 = dateTimeParserBucket52.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket55 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology47, locale53, (java.lang.Integer) 19671);
//        java.lang.String str56 = dateTimeZone35.getShortName((long) 2000, locale53);
//        java.lang.String str57 = skipUndoDateTimeField6.getAsText(19680, locale53);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket60 = new org.joda.time.format.DateTimeParserBucket((-210866673600000L), chronology1, locale53, (java.lang.Integer) 1, 19700);
//        dateTimeParserBucket60.setOffset((java.lang.Integer) 19683);
//        dateTimeParserBucket60.setOffset((java.lang.Integer) 19684);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 49L + "'", long10 == 49L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31507200000L) + "'", long12 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 19700 + "'", int16 == 19700);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 19684L + "'", long38 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(chronology47);
//        org.junit.Assert.assertNotNull(gJChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(locale53);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "PST" + "'", str56.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "19680" + "'", str57.equals("19680"));
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gJChronology0.add(readablePeriod5, (long) 12, (-2));
        org.joda.time.DurationField durationField9 = gJChronology0.weekyears();
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.minuteOfDay();
        org.joda.time.Instant instant12 = mutableDateTime10.toInstant();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(instant12);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) (short) 100, "monthOfYear");
        java.lang.String str14 = illegalFieldValueException13.getIllegalStringValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray17 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray19 = skipUndoDateTimeField4.add(readablePartial9, 19670, intArray17, 0);
        java.lang.String str20 = skipUndoDateTimeField4.toString();
        int int22 = skipUndoDateTimeField4.getMinimumValue((long) 19672);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[yearOfCentury]" + "'", str20.equals("DateTimeField[yearOfCentury]"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.addMonths((-1));
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime8 = mutableDateTime4.copy();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime4.yearOfCentury();
        mutableDateTime4.setMonthOfYear(10);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
//        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
//        long long10 = skipUndoDateTimeField4.roundFloor((long) (short) 1);
//        int int11 = skipUndoDateTimeField4.getMaximumValue();
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.monthOfYear();
//        int int14 = mutableDateTime12.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = mutableDateTime12.toDateTime(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = dateTime16.toDateTime();
//        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
//        int int19 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime18);
//        java.util.Locale locale20 = null;
//        int int21 = skipUndoDateTimeField4.getMaximumTextLength(locale20);
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField26 = gJChronology24.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology24);
//        mutableDateTime27.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        mutableDateTime27.setZoneRetainFields(dateTimeZone30);
//        int int32 = mutableDateTime27.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone33 = mutableDateTime27.getZone();
//        long long36 = dateTimeZone33.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField40 = gregorianChronology39.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder41 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone44 = dateTimeZoneBuilder41.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology45 = gregorianChronology39.withZone(dateTimeZone44);
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField48 = gJChronology47.hourOfHalfday();
//        java.util.Locale locale49 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket50 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology47, locale49);
//        java.util.Locale locale51 = dateTimeParserBucket50.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket53 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology45, locale51, (java.lang.Integer) 19671);
//        java.lang.String str54 = dateTimeZone33.getShortName((long) 2000, locale51);
//        java.lang.String str55 = skipUndoDateTimeField4.getAsText(19680, locale51);
//        java.lang.String str56 = skipUndoDateTimeField4.toString();
//        try {
//            long long59 = skipUndoDateTimeField4.set(12L, 19673);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19673 for yearOfCentury must be in the range [0,100]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19700 + "'", int14 == 19700);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 19684L + "'", long36 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(locale51);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "PST" + "'", str54.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "19680" + "'", str55.equals("19680"));
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "DateTimeField[yearOfCentury]" + "'", str56.equals("DateTimeField[yearOfCentury]"));
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        boolean boolean2 = dateTimeFormatter1.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfCentury(52);
        org.joda.time.DateTime dateTime8 = dateTime1.plusHours(19689901);
        org.joda.time.DateTime dateTime10 = dateTime1.plus((long) 19692);
        org.joda.time.DateTime dateTime12 = dateTime10.plusMillis(19674);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.minus(readablePeriod3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfDay(19676);
//        org.joda.time.DateTime dateTime8 = dateTime4.plusSeconds(19679);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField12);
//        org.joda.time.DateTimeField dateTimeField14 = skipUndoDateTimeField13.getWrappedField();
//        long long17 = skipUndoDateTimeField13.getDifferenceAsLong((long) 19670, (-1L));
//        long long19 = skipUndoDateTimeField13.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.monthOfYear();
//        int int22 = mutableDateTime20.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = mutableDateTime20.toDateTime(dateTimeZone23);
//        org.joda.time.DateTime dateTime25 = dateTime24.toDateTime();
//        org.joda.time.LocalTime localTime26 = dateTime25.toLocalTime();
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = skipUndoDateTimeField13.getAsText((org.joda.time.ReadablePartial) localTime26, 19, locale28);
//        boolean boolean30 = dateTime8.equals((java.lang.Object) 19);
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime8);
//        boolean boolean32 = dateTime8.isEqualNow();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800000L + "'", long19 == 28800000L);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 19700 + "'", int22 == 19700);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localTime26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "19" + "'", str29.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekOfWeekyear();
        org.joda.time.Chronology chronology4 = gJChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
        int int9 = mutableDateTime4.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = mutableDateTime4.getZone();
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now(dateTimeZone10);
        try {
            mutableDateTime11.setTime((int) ' ', (int) (short) 100, 19669, 328);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 19667);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusMinutes((int) '4');
//        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField7 = gJChronology6.weekyears();
//        org.joda.time.DurationField durationField8 = gJChronology6.millis();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime10.minus(readablePeriod11);
//        org.joda.time.DateTime.Property property13 = dateTime10.weekOfWeekyear();
//        boolean boolean14 = gJChronology6.equals((java.lang.Object) dateTime10);
//        org.joda.time.DateTime dateTime15 = dateTime5.toDateTime((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.DateTime.Property property16 = dateTime15.hourOfDay();
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField21 = gJChronology19.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField21);
//        org.joda.time.DateTimeField dateTimeField23 = skipUndoDateTimeField22.getWrappedField();
//        long long26 = skipUndoDateTimeField22.getDifferenceAsLong(1560342467589L, (long) ' ');
//        long long28 = skipUndoDateTimeField22.roundFloor((long) (short) 1);
//        int int29 = skipUndoDateTimeField22.getMaximumValue();
//        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.monthOfYear();
//        int int32 = mutableDateTime30.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = mutableDateTime30.toDateTime(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = dateTime34.toDateTime();
//        org.joda.time.LocalTime localTime36 = dateTime35.toLocalTime();
//        int int37 = skipUndoDateTimeField22.getMinimumValue((org.joda.time.ReadablePartial) localTime36);
//        java.util.Locale locale38 = null;
//        int int39 = skipUndoDateTimeField22.getMaximumTextLength(locale38);
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = gJChronology42.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField44 = gJChronology42.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime45 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology42);
//        mutableDateTime45.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        mutableDateTime45.setZoneRetainFields(dateTimeZone48);
//        int int50 = mutableDateTime45.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone51 = mutableDateTime45.getZone();
//        long long54 = dateTimeZone51.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField58 = gregorianChronology57.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder59 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone62 = dateTimeZoneBuilder59.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology63 = gregorianChronology57.withZone(dateTimeZone62);
//        org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField66 = gJChronology65.hourOfHalfday();
//        java.util.Locale locale67 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket68 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology65, locale67);
//        java.util.Locale locale69 = dateTimeParserBucket68.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket71 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology63, locale69, (java.lang.Integer) 19671);
//        java.lang.String str72 = dateTimeZone51.getShortName((long) 2000, locale69);
//        java.lang.String str73 = skipUndoDateTimeField22.getAsText(19680, locale69);
//        try {
//            org.joda.time.DateTime dateTime74 = property16.setCopy("America/Los_Angeles", locale69);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for hourOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 49L + "'", long26 == 49L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-31507200000L) + "'", long28 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 57619 + "'", int32 == 57619);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(localTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 3 + "'", int39 == 3);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 19684L + "'", long54 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology57);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(chronology63);
//        org.junit.Assert.assertNotNull(gJChronology65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertNotNull(locale69);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "PST" + "'", str72.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "19680" + "'", str73.equals("19680"));
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) 'a');
        org.joda.time.DateTime.Property property6 = dateTime3.weekyear();
        boolean boolean7 = property6.isLeap();
        org.joda.time.DateTime dateTime8 = property6.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.weekOfWeekyear();
        org.joda.time.Chronology chronology5 = gJChronology1.withUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 19677, (org.joda.time.Chronology) gJChronology1);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths(1);
        org.joda.time.DateTime.Property property4 = dateTime1.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long10 = skipUndoDateTimeField4.roundFloor((long) (short) 1);
        boolean boolean12 = skipUndoDateTimeField4.isLeap((long) 2019);
        long long15 = skipUndoDateTimeField4.add(19674L, 0L);
        int int17 = skipUndoDateTimeField4.getMaximumValue(19672L);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 19674L + "'", long15 == 19674L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear(19670);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendPattern("");
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField11 = gJChronology10.weekyears();
        org.joda.time.DurationField durationField12 = gJChronology10.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField20 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField13, dateTimeFieldType16);
        org.joda.time.DurationField durationField21 = zeroIsMaxDateTimeField20.getDurationField();
        java.util.Locale locale23 = null;
        java.lang.String str24 = zeroIsMaxDateTimeField20.getAsText((long) (short) -1, locale23);
        long long26 = zeroIsMaxDateTimeField20.roundCeiling((-31507200000L));
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.monthOfYear();
        int int29 = mutableDateTime27.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = mutableDateTime27.toDateTime(dateTimeZone30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField36 = gJChronology35.weekyears();
        org.joda.time.DurationField durationField37 = gJChronology35.millis();
        org.joda.time.DateTimeField dateTimeField38 = gJChronology35.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property40.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType41, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField45 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField38, dateTimeFieldType41);
        org.joda.time.IllegalFieldValueException illegalFieldValueException47 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType41, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException51 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType41, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder32.appendFixedDecimal(dateTimeFieldType41, (int) (short) 100);
        org.joda.time.MutableDateTime.Property property54 = mutableDateTime27.property(dateTimeFieldType41);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField20, dateTimeFieldType41, 4, (int) ' ', 19666);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder5.appendText(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder60.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField64 = gJChronology63.weekyears();
        org.joda.time.DurationField durationField65 = gJChronology63.millis();
        org.joda.time.DateTimeField dateTimeField66 = gJChronology63.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime67 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property68 = mutableDateTime67.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = property68.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException72 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType69, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField73 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField66, dateTimeFieldType69);
        org.joda.time.IllegalFieldValueException illegalFieldValueException75 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType69, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException79 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType69, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder60.appendFixedDecimal(dateTimeFieldType69, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType69);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType69);
        org.joda.time.format.DateTimePrinter dateTimePrinter84 = dateTimeFormatterBuilder4.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "59" + "'", str24.equals("59"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-31507200000L) + "'", long26 == (-31507200000L));
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 57619 + "'", int29 == 57619);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(gJChronology63);
        org.junit.Assert.assertNotNull(durationField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(property68);
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
        org.junit.Assert.assertNotNull(dateTimePrinter84);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone1);
        java.lang.StringBuffer stringBuffer6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField10);
        org.joda.time.DateTimeField dateTimeField12 = skipUndoDateTimeField11.getWrappedField();
        long long15 = skipUndoDateTimeField11.getDifferenceAsLong((long) 19670, (-1L));
        long long17 = skipUndoDateTimeField11.roundHalfEven(0L);
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime18.monthOfYear();
        int int20 = mutableDateTime18.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = mutableDateTime18.toDateTime(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = dateTime22.toDateTime();
        org.joda.time.LocalTime localTime24 = dateTime23.toLocalTime();
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localTime24, 19, locale26);
        try {
            dateTimeFormatter0.printTo(stringBuffer6, (org.joda.time.ReadablePartial) localTime24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 57619 + "'", int20 == 57619);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localTime24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "19" + "'", str27.equals("19"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 1);
        int int3 = dateTime0.getSecondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.hours();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology7);
        mutableDateTime10.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        mutableDateTime10.setZoneRetainFields(dateTimeZone13);
        int int15 = mutableDateTime10.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = mutableDateTime10.getZone();
        org.joda.time.Chronology chronology17 = gJChronology4.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = dateTime0.withZoneRetainFields(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        long long6 = cachedDateTimeZone3.previousTransition((long) 4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        int int10 = dateTimeZone8.getOffsetFromLocal((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone11);
        boolean boolean13 = cachedDateTimeZone11.isFixed();
        boolean boolean14 = cachedDateTimeZone3.equals((java.lang.Object) cachedDateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 4L + "'", long6 == 4L);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        long long7 = dateTimeZone3.convertLocalToUTC(19L, false);
        long long9 = dateTimeZone3.convertUTCToLocal((long) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 19L + "'", long7 == 19L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long13 = zeroIsMaxDateTimeField10.set((long) 52, "59");
        java.lang.String str15 = zeroIsMaxDateTimeField10.getAsShortText((long) 19675);
        int int17 = zeroIsMaxDateTimeField10.get((-37899509L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 59052L + "'", long13 == 59052L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "19" + "'", str15.equals("19"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 20 + "'", int17 == 20);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay(19676);
        org.joda.time.DateTime dateTime7 = dateTime3.plusSeconds(19679);
        org.joda.time.DateTime.Property property8 = dateTime7.centuryOfEra();
        try {
            org.joda.time.DateTime dateTime10 = dateTime7.withEra((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.addMonths((-1));
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.addWrapField(69);
        org.joda.time.MutableDateTime mutableDateTime10 = property7.roundHalfEven();
        mutableDateTime10.addDays(20);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(19669);
        boolean boolean23 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
//        mutableDateTime4.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
//        int int9 = mutableDateTime4.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = mutableDateTime4.getZone();
//        long long13 = dateTimeZone10.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField17 = gregorianChronology16.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone21 = dateTimeZoneBuilder18.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology22 = gregorianChronology16.withZone(dateTimeZone21);
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.hourOfHalfday();
//        java.util.Locale locale26 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology24, locale26);
//        java.util.Locale locale28 = dateTimeParserBucket27.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket30 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology22, locale28, (java.lang.Integer) 19671);
//        java.lang.String str31 = dateTimeZone10.getShortName((long) 2000, locale28);
//        java.text.DateFormatSymbols dateFormatSymbols32 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale28);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 19684L + "'", long13 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(locale28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "PST" + "'", str31.equals("PST"));
//        org.junit.Assert.assertNotNull(dateFormatSymbols32);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
//        mutableDateTime4.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
//        int int9 = mutableDateTime4.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = mutableDateTime4.getZone();
//        long long13 = dateTimeZone10.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField17 = gregorianChronology16.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone21 = dateTimeZoneBuilder18.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology22 = gregorianChronology16.withZone(dateTimeZone21);
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.hourOfHalfday();
//        java.util.Locale locale26 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology24, locale26);
//        java.util.Locale locale28 = dateTimeParserBucket27.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket30 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology22, locale28, (java.lang.Integer) 19671);
//        java.lang.String str31 = dateTimeZone10.getShortName((long) 2000, locale28);
//        java.util.TimeZone timeZone32 = dateTimeZone10.toTimeZone();
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 19684L + "'", long13 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(locale28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "PST" + "'", str31.equals("PST"));
//        org.junit.Assert.assertNotNull(timeZone32);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology6 = gregorianChronology2.withZone(dateTimeZone5);
        java.lang.String str7 = gregorianChronology2.toString();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, dateTimeField11);
        org.joda.time.DateTimeField dateTimeField13 = skipUndoDateTimeField12.getWrappedField();
        long long16 = skipUndoDateTimeField12.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long18 = skipUndoDateTimeField12.roundFloor((long) (short) 1);
        int int19 = skipUndoDateTimeField12.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.monthOfYear();
        int int22 = mutableDateTime20.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = mutableDateTime20.toDateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = dateTime24.toDateTime();
        org.joda.time.LocalTime localTime26 = dateTime25.toLocalTime();
        int int27 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localTime26);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology30.hourOfHalfday();
        java.util.Locale locale32 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology30, locale32);
        java.util.Locale locale34 = dateTimeParserBucket33.getLocale();
        java.lang.String str35 = skipUndoDateTimeField12.getAsText((-18059), locale34);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket38 = new org.joda.time.format.DateTimeParserBucket((long) 12885, (org.joda.time.Chronology) gregorianChronology2, locale34, (java.lang.Integer) 19683, 19);
        try {
            java.lang.String str39 = org.joda.time.format.DateTimeFormat.patternForStyle("DateTimeField[monthOfYear]", locale34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: DateTimeField[monthOfYear]");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str7.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 49L + "'", long16 == 49L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31507200000L) + "'", long18 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 57619 + "'", int22 == 57619);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(locale34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "-18059" + "'", str35.equals("-18059"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.addMonths((-1));
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.secondOfDay();
        mutableDateTime4.addYears((int) '#');
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology11);
        mutableDateTime14.addMonths((-1));
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime14.secondOfDay();
        boolean boolean18 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime14.secondOfMinute();
        try {
            mutableDateTime14.setDate(0, 3, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((-1));
        boolean boolean4 = dateTimeFormatter0.isPrinter();
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(dateTimeZone5);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) 'a');
        org.joda.time.DateTime.Property property6 = dateTime3.weekyear();
        org.joda.time.DateTime.Property property7 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime9 = dateTime3.plusMillis(2019);
        org.joda.time.Instant instant10 = dateTime3.toInstant();
        org.joda.time.MutableDateTime mutableDateTime11 = instant10.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.minus(readablePeriod3);
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime7 = dateTime1.withMillis((long) 69);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-31T16" + "'", str5.equals("1969-12-31T16"));
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.weekyears();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("monthOfYear", false);
        org.joda.time.Chronology chronology7 = gregorianChronology1.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.hourOfHalfday();
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology9, locale11);
        java.util.Locale locale13 = dateTimeParserBucket12.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology7, locale13, (java.lang.Integer) 19671);
        java.lang.Integer int16 = dateTimeParserBucket15.getOffsetInteger();
        long long17 = dateTimeParserBucket15.computeMillis();
        long long20 = dateTimeParserBucket15.computeMillis(true, "");
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(locale13);
        org.junit.Assert.assertNull(int16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560342467589L + "'", long17 == 1560342467589L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560342467589L + "'", long20 == 1560342467589L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
        int int9 = mutableDateTime4.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = mutableDateTime4.getZone();
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now(dateTimeZone10);
        mutableDateTime11.addHours(0);
        boolean boolean14 = mutableDateTime11.isEqualNow();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long10 = skipUndoDateTimeField4.roundFloor((long) (short) 1);
        int int12 = skipUndoDateTimeField4.get(0L);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder20.appendHalfdayOfDayText();
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField23 = gJChronology22.weekyears();
        org.joda.time.DurationField durationField24 = gJChronology22.millis();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology22.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime26.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType28);
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) (short) 100, "monthOfYear");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder21.appendDecimal(dateTimeFieldType28, 19696, 19671);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder21.appendMinuteOfHour(19683);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder21.appendYearOfCentury(69, 19698);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder21.appendMillisOfDay(1296);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        java.util.GregorianCalendar gregorianCalendar4 = dateTime1.toGregorianCalendar();
        java.lang.String str5 = dateTime1.toString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gregorianCalendar4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-31T16:00:19.667-08:00" + "'", str5.equals("1969-12-31T16:00:19.667-08:00"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong((long) 19670, (-1L));
        boolean boolean9 = skipUndoDateTimeField4.isLenient();
        try {
            long long12 = skipUndoDateTimeField4.set((long) 2000, 6458320);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 6458320 for yearOfCentury must be in the range [0,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendClockhourOfDay(19667);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendClockhourOfHalfday((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder25.appendEraText();
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder26.appendSignedDecimal(dateTimeFieldType29, (-19695), (-18059));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) 'a');
        org.joda.time.DateTime.Property property6 = dateTime3.weekyear();
        org.joda.time.DateTime.Property property7 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime9 = dateTime3.plusMillis(2019);
        org.joda.time.LocalDate localDate10 = dateTime3.toLocalDate();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate10);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
        long long5 = property4.remainder();
        org.joda.time.DateTime dateTime7 = property4.addWrapFieldToCopy(19670);
        org.joda.time.DateTime dateTime8 = property4.roundCeilingCopy();
        org.joda.time.DateTime dateTime10 = property4.addToCopy((long) (short) 100);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 230419667L + "'", long5 == 230419667L);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology7);
        mutableDateTime10.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        mutableDateTime10.setZoneRetainFields(dateTimeZone13);
        int int15 = mutableDateTime10.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = mutableDateTime10.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter5.withZone(dateTimeZone16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder0.append(dateTimeFormatter17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter22 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter23.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser25 = dateTimeFormatter24.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter26.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser28 = dateTimeFormatter27.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter29.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser31 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter32.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser34 = dateTimeFormatter33.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter35.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatter36.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray38 = new org.joda.time.format.DateTimeParser[] { dateTimeParser25, dateTimeParser28, dateTimeParser31, dateTimeParser34, dateTimeParser37 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder19.append(dateTimePrinter22, dateTimeParserArray38);
        boolean boolean40 = dateTimeFormatterBuilder19.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder19.appendClockhourOfDay(19667);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendClockhourOfHalfday((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder42.appendYear(0, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder48.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter51 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = dateTimeFormatter52.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser54 = dateTimeFormatter53.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = dateTimeFormatter55.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser57 = dateTimeFormatter56.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = dateTimeFormatter58.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser60 = dateTimeFormatter59.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = dateTimeFormatter61.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser63 = dateTimeFormatter62.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter64 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter65 = dateTimeFormatter64.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser66 = dateTimeFormatter65.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray67 = new org.joda.time.format.DateTimeParser[] { dateTimeParser54, dateTimeParser57, dateTimeParser60, dateTimeParser63, dateTimeParser66 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder48.append(dateTimePrinter51, dateTimeParserArray67);
        boolean boolean69 = dateTimeFormatterBuilder48.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder48.appendClockhourOfDay(19667);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder71.appendSecondOfMinute(27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder73.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter75 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property77 = dateTime76.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod78 = null;
        org.joda.time.DateTime dateTime79 = dateTime76.minus(readablePeriod78);
        java.lang.String str80 = dateTimeFormatter75.print((org.joda.time.ReadableInstant) dateTime76);
        org.joda.time.format.DateTimePrinter dateTimePrinter81 = dateTimeFormatter75.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter82 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter83 = dateTimeFormatter82.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser84 = dateTimeFormatter83.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter85 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter86 = dateTimeFormatter85.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser87 = dateTimeFormatter86.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter88 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter89 = dateTimeFormatter88.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser90 = dateTimeFormatter89.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray91 = new org.joda.time.format.DateTimeParser[] { dateTimeParser84, dateTimeParser87, dateTimeParser90 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder92 = dateTimeFormatterBuilder74.append(dateTimePrinter81, dateTimeParserArray91);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder93 = dateTimeFormatterBuilder42.append(dateTimePrinter81);
        org.joda.time.format.DateTimeParser dateTimeParser94 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder95 = dateTimeFormatterBuilder18.append(dateTimePrinter81, dateTimeParser94);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimeParser28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeParser31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeParser34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeParser37);
        org.junit.Assert.assertNotNull(dateTimeParserArray38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatter52);
        org.junit.Assert.assertNotNull(dateTimeFormatter53);
        org.junit.Assert.assertNotNull(dateTimeParser54);
        org.junit.Assert.assertNotNull(dateTimeFormatter55);
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertNotNull(dateTimeParser57);
        org.junit.Assert.assertNotNull(dateTimeFormatter58);
        org.junit.Assert.assertNotNull(dateTimeFormatter59);
        org.junit.Assert.assertNotNull(dateTimeParser60);
        org.junit.Assert.assertNotNull(dateTimeFormatter61);
        org.junit.Assert.assertNotNull(dateTimeFormatter62);
        org.junit.Assert.assertNotNull(dateTimeParser63);
        org.junit.Assert.assertNotNull(dateTimeFormatter64);
        org.junit.Assert.assertNotNull(dateTimeFormatter65);
        org.junit.Assert.assertNotNull(dateTimeParser66);
        org.junit.Assert.assertNotNull(dateTimeParserArray67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
        org.junit.Assert.assertNotNull(dateTimeFormatter75);
        org.junit.Assert.assertNotNull(property77);
        org.junit.Assert.assertNotNull(dateTime79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "1969-12-31T16" + "'", str80.equals("1969-12-31T16"));
        org.junit.Assert.assertNotNull(dateTimePrinter81);
        org.junit.Assert.assertNotNull(dateTimeFormatter82);
        org.junit.Assert.assertNotNull(dateTimeFormatter83);
        org.junit.Assert.assertNotNull(dateTimeParser84);
        org.junit.Assert.assertNotNull(dateTimeFormatter85);
        org.junit.Assert.assertNotNull(dateTimeFormatter86);
        org.junit.Assert.assertNotNull(dateTimeParser87);
        org.junit.Assert.assertNotNull(dateTimeFormatter88);
        org.junit.Assert.assertNotNull(dateTimeFormatter89);
        org.junit.Assert.assertNotNull(dateTimeParser90);
        org.junit.Assert.assertNotNull(dateTimeParserArray91);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder92);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder93);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 2000);
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str3 = julianChronology2.toString();
        org.joda.time.Chronology chronology4 = julianChronology2.withUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime1, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.millisOfDay();
        mutableDateTime5.setMinuteOfHour(12);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.dayOfYear();
        try {
            mutableDateTime5.setMinuteOfHour(19697);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19697 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "hi!", "52");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.hourOfHalfday();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology7, locale9);
        java.util.Locale locale11 = dateTimeParserBucket10.getLocale();
        java.lang.String str14 = defaultNameProvider0.getShortName(locale11, "UTC", "JulianChronology[America/Los_Angeles]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(locale11);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 19697);
        java.lang.String str2 = mutableDateTime1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31T16:00:19.697-08:00" + "'", str2.equals("1969-12-31T16:00:19.697-08:00"));
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.plusYears((int) (short) 0);
//        org.joda.time.DateTime.Property property7 = dateTime4.weekOfWeekyear();
//        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.lang.String str10 = julianChronology9.toString();
//        int int11 = julianChronology9.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField12 = julianChronology9.centuries();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property14 = dateTime13.millisOfDay();
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology17.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology16, dateTimeField19);
//        org.joda.time.DateTimeField dateTimeField21 = skipUndoDateTimeField20.getWrappedField();
//        long long24 = skipUndoDateTimeField20.getDifferenceAsLong((long) 19670, (-1L));
//        int int27 = skipUndoDateTimeField20.getDifference((long) (-1), (long) (byte) -1);
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField31 = gJChronology30.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField32 = gJChronology30.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime33 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology30);
//        mutableDateTime33.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        mutableDateTime33.setZoneRetainFields(dateTimeZone36);
//        int int38 = mutableDateTime33.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone39 = mutableDateTime33.getZone();
//        long long42 = dateTimeZone39.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField46 = gregorianChronology45.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder47 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone50 = dateTimeZoneBuilder47.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology51 = gregorianChronology45.withZone(dateTimeZone50);
//        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField54 = gJChronology53.hourOfHalfday();
//        java.util.Locale locale55 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology53, locale55);
//        java.util.Locale locale57 = dateTimeParserBucket56.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket59 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology51, locale57, (java.lang.Integer) 19671);
//        java.lang.String str60 = dateTimeZone39.getShortName((long) 2000, locale57);
//        java.lang.String str61 = skipUndoDateTimeField20.getAsShortText(0, locale57);
//        org.joda.time.DateTime dateTime62 = property14.setCopy("0", locale57);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket64 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) julianChronology9, locale57, (java.lang.Integer) 19696);
//        int int65 = property7.getMaximumTextLength(locale57);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57619 + "'", int2 == 57619);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(julianChronology9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str10.equals("JulianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 19684L + "'", long42 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(chronology51);
//        org.junit.Assert.assertNotNull(gJChronology53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(locale57);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "PST" + "'", str60.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "0" + "'", str61.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2 + "'", int65 == 2);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("DateTimeField[monthOfYear]", "12", 19700, (int) (short) 1);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(1560342498872L);
        int int8 = fixedDateTimeZone4.getStandardOffset((long) 19669);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19700 + "'", int6 == 19700);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, "hi!");
        org.joda.time.DurationFieldType durationFieldType13 = illegalFieldValueException12.getDurationFieldType();
        java.lang.Throwable[] throwableArray14 = illegalFieldValueException12.getSuppressed();
        java.lang.Number number15 = illegalFieldValueException12.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(durationFieldType13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNull(number15);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology3);
        mutableDateTime6.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        mutableDateTime6.setZoneRetainFields(dateTimeZone9);
        int int11 = mutableDateTime6.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = mutableDateTime6.getZone();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.minus(readablePeriod16);
        org.joda.time.DateTime.Property property18 = dateTime15.weekOfWeekyear();
        long long19 = property18.remainder();
        org.joda.time.DateTime dateTime21 = property18.addWrapFieldToCopy(19670);
        org.joda.time.DateTime dateTime22 = property18.roundCeilingCopy();
        boolean boolean23 = mutableDateTime13.isAfter((org.joda.time.ReadableInstant) dateTime22);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 230419667L + "'", long19 == 230419667L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
        int int19 = mutableDateTime17.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
        org.joda.time.DurationField durationField27 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField52 = gJChronology50.yearOfCentury();
        java.util.Locale locale53 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology50, locale53, (java.lang.Integer) (-2), 19675);
        java.lang.Object obj57 = dateTimeParserBucket56.saveState();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder58.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField62 = gJChronology61.weekyears();
        org.joda.time.DurationField durationField63 = gJChronology61.millis();
        org.joda.time.DateTimeField dateTimeField64 = gJChronology61.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime65 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property66 = mutableDateTime65.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property66.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField71 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField64, dateTimeFieldType67);
        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException77 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder58.appendFixedDecimal(dateTimeFieldType67, (int) (short) 100);
        dateTimeParserBucket56.saveField(dateTimeFieldType67, 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType67, 19683);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField84 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField83);
        long long86 = remainderDateTimeField84.roundFloor(192483574L);
        org.joda.time.chrono.GJChronology gJChronology87 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField88 = gJChronology87.weekyears();
        org.joda.time.DurationField durationField89 = gJChronology87.millis();
        org.joda.time.DateTimeField dateTimeField90 = gJChronology87.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime91 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property92 = mutableDateTime91.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType93 = property92.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException96 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType93, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField97 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField90, dateTimeFieldType93);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField98 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField84, dateTimeFieldType93);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57619 + "'", int19 == 57619);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 192483000L + "'", long86 == 192483000L);
        org.junit.Assert.assertNotNull(gJChronology87);
        org.junit.Assert.assertNotNull(durationField88);
        org.junit.Assert.assertNotNull(durationField89);
        org.junit.Assert.assertNotNull(dateTimeField90);
        org.junit.Assert.assertNotNull(property92);
        org.junit.Assert.assertNotNull(dateTimeFieldType93);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
        try {
            org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((java.lang.Object) zeroIsMaxDateTimeField10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.ZeroIsMaxDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType9, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendSecondOfDay(19676);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendClockhourOfDay(12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
        long long15 = zeroIsMaxDateTimeField10.add(12L, 2000);
        long long18 = zeroIsMaxDateTimeField10.getDifferenceAsLong((long) 19687, 192477915L);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10);
        long long22 = delegatedDateTimeField19.add(0L, 0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2000012L + "'", long15 == 2000012L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-192458L) + "'", long18 == (-192458L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        java.lang.String str2 = property1.getName();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.add((long) 'a');
        java.lang.String str5 = property1.toString();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "monthOfYear" + "'", str2.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[monthOfYear]" + "'", str5.equals("Property[monthOfYear]"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("monthOfYear", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (short) 1, 'a', 0, 2, 19671, true, 60);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.setStandardOffset((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = mutableDateTime0.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField10);
        org.joda.time.DateTimeField dateTimeField12 = skipUndoDateTimeField11.getWrappedField();
        long long15 = skipUndoDateTimeField11.getDifferenceAsLong((long) 19670, (-1L));
        long long17 = skipUndoDateTimeField11.roundHalfEven(0L);
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime18.monthOfYear();
        int int20 = mutableDateTime18.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = mutableDateTime18.toDateTime(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = dateTime22.toDateTime();
        org.joda.time.LocalTime localTime24 = dateTime23.toLocalTime();
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localTime24, 19, locale26);
        org.joda.time.DateTime dateTime28 = dateTime5.withFields((org.joda.time.ReadablePartial) localTime24);
        boolean boolean29 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime24);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57619 + "'", int2 == 57619);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localTime6);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 57619 + "'", int20 == 57619);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localTime24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "19" + "'", str27.equals("19"));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder20.appendHalfdayOfDayText();
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField23 = gJChronology22.weekyears();
        org.joda.time.DurationField durationField24 = gJChronology22.millis();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology22.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime26.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType28);
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) (short) 100, "monthOfYear");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder21.appendDecimal(dateTimeFieldType28, 19696, 19671);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder21.appendMonthOfYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
//        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
//        long long10 = skipUndoDateTimeField4.roundFloor((long) (short) 1);
//        int int11 = skipUndoDateTimeField4.getMaximumValue();
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.monthOfYear();
//        int int14 = mutableDateTime12.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = mutableDateTime12.toDateTime(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = dateTime16.toDateTime();
//        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
//        int int19 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime18);
//        java.util.Locale locale20 = null;
//        int int21 = skipUndoDateTimeField4.getMaximumTextLength(locale20);
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField26 = gJChronology24.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology24);
//        mutableDateTime27.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        mutableDateTime27.setZoneRetainFields(dateTimeZone30);
//        int int32 = mutableDateTime27.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone33 = mutableDateTime27.getZone();
//        long long36 = dateTimeZone33.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField40 = gregorianChronology39.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder41 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone44 = dateTimeZoneBuilder41.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology45 = gregorianChronology39.withZone(dateTimeZone44);
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField48 = gJChronology47.hourOfHalfday();
//        java.util.Locale locale49 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket50 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology47, locale49);
//        java.util.Locale locale51 = dateTimeParserBucket50.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket53 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology45, locale51, (java.lang.Integer) 19671);
//        java.lang.String str54 = dateTimeZone33.getShortName((long) 2000, locale51);
//        java.lang.String str55 = skipUndoDateTimeField4.getAsText(19680, locale51);
//        try {
//            long long58 = skipUndoDateTimeField4.set((long) 19696, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfCentury must be in the range [1,100]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 57619 + "'", int14 == 57619);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 19684L + "'", long36 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(locale51);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "PST" + "'", str54.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "19680" + "'", str55.equals("19680"));
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str1 = julianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        int int3 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology4 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str1.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        int int12 = zeroIsMaxDateTimeField10.getMaximumValue((long) 0);
        int int14 = zeroIsMaxDateTimeField10.getLeapAmount((-209167272000000L));
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField16 = gJChronology15.weekyears();
        org.joda.time.DurationField durationField17 = gJChronology15.millis();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology15.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField18, dateTimeFieldType21);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) (short) 100, "monthOfYear");
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType21);
        java.lang.String str31 = delegatedDateTimeField29.getAsText((long) 328);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 60 + "'", int12 == 60);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "60" + "'", str31.equals("60"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
        int int9 = mutableDateTime4.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = mutableDateTime4.getZone();
        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime4.toMutableDateTimeISO();
        try {
            mutableDateTime11.setSecondOfMinute(19670);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19670 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 2000);
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str3 = julianChronology2.toString();
        org.joda.time.Chronology chronology4 = julianChronology2.withUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime1, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.millisOfDay();
        mutableDateTime5.addMillis(8);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.dayOfWeek();
        try {
            mutableDateTime5.setMonthOfYear(19695);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19695 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gJChronology0.add(readablePeriod5, (long) 12, (-2));
        long long13 = gJChronology0.getDateTimeMillis(19, 1, (int) (byte) 1, 52);
        try {
            long long18 = gJChronology0.getDateTimeMillis(19673, 19693, 19695, 19685);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19693 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61567747621948L) + "'", long13 == (-61567747621948L));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendWeekOfWeekyear(30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = gJChronology1.get(readablePeriod3, 19049L, (long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime dateTime11 = dateTime9.withYear((int) 'a');
        mutableDateTime4.setMillis((org.joda.time.ReadableInstant) dateTime11);
        try {
            mutableDateTime4.setDateTime(100, (int) (short) 1, 19696, (-25200000), 52, 5, 19685);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray17 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray19 = skipUndoDateTimeField4.add(readablePartial9, 19670, intArray17, 0);
        java.lang.String str20 = skipUndoDateTimeField4.toString();
        long long22 = skipUndoDateTimeField4.roundHalfFloor(0L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField4.getAsShortText(4038000, locale24);
        int int27 = skipUndoDateTimeField4.get((long) 'a');
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[yearOfCentury]" + "'", str20.equals("DateTimeField[yearOfCentury]"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28800000L + "'", long22 == 28800000L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "4038000" + "'", str25.equals("4038000"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 69 + "'", int27 == 69);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        java.lang.String str2 = property1.getName();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.add((long) 'a');
        int int5 = property1.getMaximumValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "monthOfYear" + "'", str2.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology3);
//        mutableDateTime6.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        mutableDateTime6.setZoneRetainFields(dateTimeZone9);
//        int int11 = mutableDateTime6.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = mutableDateTime6.getZone();
//        long long15 = dateTimeZone12.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField19 = gregorianChronology18.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone23 = dateTimeZoneBuilder20.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology24 = gregorianChronology18.withZone(dateTimeZone23);
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.hourOfHalfday();
//        java.util.Locale locale28 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology26, locale28);
//        java.util.Locale locale30 = dateTimeParserBucket29.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket32 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology24, locale30, (java.lang.Integer) 19671);
//        java.lang.String str33 = dateTimeZone12.getShortName((long) 2000, locale30);
//        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField35 = zonedChronology34.minuteOfDay();
//        try {
//            long long43 = zonedChronology34.getDateTimeMillis(19688, 12, 0, (int) (byte) 100, (-19), 19701, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 19684L + "'", long15 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(locale30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PST" + "'", str33.equals("PST"));
//        org.junit.Assert.assertNotNull(zonedChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis(6458320, 19675, (int) (short) -1, (-25200000), (int) (short) -1, 0, 19687);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("52");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.hours();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology3);
        mutableDateTime6.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        mutableDateTime6.setZoneRetainFields(dateTimeZone9);
        int int11 = mutableDateTime6.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = mutableDateTime6.getZone();
        org.joda.time.Chronology chronology13 = gJChronology0.withZone(dateTimeZone12);
        java.lang.String str14 = dateTimeZone12.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "America/Los_Angeles" + "'", str14.equals("America/Los_Angeles"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = mutableDateTime0.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField7 = gJChronology6.weekyears();
        org.joda.time.DurationField durationField8 = gJChronology6.millis();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField16 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType12);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) (short) 100, "monthOfYear");
        org.joda.time.DateTime.Property property20 = dateTime4.property(dateTimeFieldType12);
        org.joda.time.DateTime dateTime21 = property20.roundCeilingCopy();
        org.joda.time.LocalDate localDate22 = dateTime21.toLocalDate();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57619 + "'", int2 == 57619);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localDate22);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("monthOfYear", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (short) 1, 'a', 0, 2, 19671, true, 60);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder0.toDateTimeZone("2019163T000008.699-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear(19670);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendWeekyear(19669, 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("UTC", 19683, 30, 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19683 for UTC must be in the range [30,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider5 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider5.getShortName(locale6, "hi!", "52");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology13.getZone();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology17 = gregorianChronology13.withZone(dateTimeZone16);
        java.lang.String str18 = gregorianChronology13.toString();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = gJChronology20.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology20.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology19, dateTimeField22);
        org.joda.time.DateTimeField dateTimeField24 = skipUndoDateTimeField23.getWrappedField();
        long long27 = skipUndoDateTimeField23.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long29 = skipUndoDateTimeField23.roundFloor((long) (short) 1);
        int int30 = skipUndoDateTimeField23.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime31.monthOfYear();
        int int33 = mutableDateTime31.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = mutableDateTime31.toDateTime(dateTimeZone34);
        org.joda.time.DateTime dateTime36 = dateTime35.toDateTime();
        org.joda.time.LocalTime localTime37 = dateTime36.toLocalTime();
        int int38 = skipUndoDateTimeField23.getMinimumValue((org.joda.time.ReadablePartial) localTime37);
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.hourOfHalfday();
        java.util.Locale locale43 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket44 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology41, locale43);
        java.util.Locale locale45 = dateTimeParserBucket44.getLocale();
        java.lang.String str46 = skipUndoDateTimeField23.getAsText((-18059), locale45);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket49 = new org.joda.time.format.DateTimeParserBucket((long) 12885, (org.joda.time.Chronology) gregorianChronology13, locale45, (java.lang.Integer) 19683, 19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = dateTimeFormatter10.withLocale(locale45);
        java.lang.String str53 = defaultNameProvider5.getShortName(locale45, "monthOfYear", "2019-W28");
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket55 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 100, (org.joda.time.Chronology) gJChronology1, locale45, (java.lang.Integer) 19677);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str18.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 49L + "'", long27 == 49L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-31507200000L) + "'", long29 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 57619 + "'", int33 == 57619);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(locale45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "-18059" + "'", str46.equals("-18059"));
        org.junit.Assert.assertNotNull(dateTimeFormatter50);
        org.junit.Assert.assertNull(str53);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.monthOfYear();
        int int15 = mutableDateTime13.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = mutableDateTime13.toDateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        int int20 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime19);
        long long22 = zeroIsMaxDateTimeField10.roundHalfFloor(100L);
        long long24 = zeroIsMaxDateTimeField10.roundHalfFloor((long) (short) -1);
        boolean boolean26 = zeroIsMaxDateTimeField10.isLeap((long) 19702);
        org.joda.time.DateTimeField dateTimeField27 = zeroIsMaxDateTimeField10.getWrappedField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 57619 + "'", int15 == 57619);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 60 + "'", int20 == 60);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
        int int9 = mutableDateTime4.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = mutableDateTime4.getZone();
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now(dateTimeZone10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        mutableDateTime11.add(readablePeriod12, 19687);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology3 = buddhistChronology0.withZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.hours();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology3);
        mutableDateTime6.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        mutableDateTime6.setZoneRetainFields(dateTimeZone9);
        int int11 = mutableDateTime6.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = mutableDateTime6.getZone();
        org.joda.time.Chronology chronology13 = gJChronology0.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = gJChronology0.hours();
        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField16 = gJChronology0.eras();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType9, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendHourOfHalfday((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder21.appendWeekyear(12, 19672);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.Chronology chronology28 = dateTimeFormatter27.getChronolgy();
        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter27.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder26.appendOptional(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.monthOfYear();
        int int4 = mutableDateTime2.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.plusMonths(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("monthOfYear", false);
        org.joda.time.DateTime dateTime13 = dateTime8.withZone(dateTimeZone12);
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) mutableDateTime2, (org.joda.time.ReadableDateTime) dateTime13);
        org.joda.time.TimeOfDay timeOfDay15 = dateTime13.toTimeOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57619 + "'", int4 == 57619);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(limitChronology14);
        org.junit.Assert.assertNotNull(timeOfDay15);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
        java.util.Locale locale2 = null;
        int int3 = property1.getMaximumShortTextLength(locale2);
        org.joda.time.DateTime dateTime5 = property1.setCopy((int) (byte) 0);
        org.joda.time.DateTime.Property property6 = dateTime5.hourOfDay();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withDayOfYear((int) (short) 100);
//        org.joda.time.DateTime.Property property4 = dateTime1.era();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology7);
//        mutableDateTime10.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        mutableDateTime10.setZoneRetainFields(dateTimeZone13);
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime10.dayOfWeek();
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime10.weekOfWeekyear();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfDay();
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology20, dateTimeField23);
//        org.joda.time.DateTimeField dateTimeField25 = skipUndoDateTimeField24.getWrappedField();
//        long long28 = skipUndoDateTimeField24.getDifferenceAsLong((long) 19670, (-1L));
//        int int31 = skipUndoDateTimeField24.getDifference((long) (-1), (long) (byte) -1);
//        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField35 = gJChronology34.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField36 = gJChronology34.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology34);
//        mutableDateTime37.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        mutableDateTime37.setZoneRetainFields(dateTimeZone40);
//        int int42 = mutableDateTime37.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone43 = mutableDateTime37.getZone();
//        long long46 = dateTimeZone43.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField50 = gregorianChronology49.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder51 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone54 = dateTimeZoneBuilder51.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology55 = gregorianChronology49.withZone(dateTimeZone54);
//        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField58 = gJChronology57.hourOfHalfday();
//        java.util.Locale locale59 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket60 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology57, locale59);
//        java.util.Locale locale61 = dateTimeParserBucket60.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket63 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology55, locale61, (java.lang.Integer) 19671);
//        java.lang.String str64 = dateTimeZone43.getShortName((long) 2000, locale61);
//        java.lang.String str65 = skipUndoDateTimeField24.getAsShortText(0, locale61);
//        org.joda.time.DateTime dateTime66 = property18.setCopy("0", locale61);
//        int int67 = property16.getMaximumShortTextLength(locale61);
//        try {
//            org.joda.time.DateTime dateTime68 = property4.setCopy("2019-W24", locale61);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-W24\" for era is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(gJChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 19684L + "'", long46 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(gJChronology57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(locale61);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "PST" + "'", str64.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "0" + "'", str65.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2 + "'", int67 == 2);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        int int8 = dateTimeZone6.getOffsetFromLocal((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        long long12 = cachedDateTimeZone9.previousTransition((long) 4);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        mutableDateTime4.setZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 4L + "'", long12 == 4L);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str1 = julianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        int int3 = julianChronology0.getMinimumDaysInFirstWeek();
        long long7 = julianChronology0.add((long) (short) 1, (long) 4, 1);
        org.joda.time.DateTimeField dateTimeField8 = julianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str1.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 5L + "'", long7 == 5L);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
        int int19 = mutableDateTime17.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
        org.joda.time.DurationField durationField27 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField52 = gJChronology50.yearOfCentury();
        java.util.Locale locale53 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology50, locale53, (java.lang.Integer) (-2), 19675);
        java.lang.Object obj57 = dateTimeParserBucket56.saveState();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder58.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField62 = gJChronology61.weekyears();
        org.joda.time.DurationField durationField63 = gJChronology61.millis();
        org.joda.time.DateTimeField dateTimeField64 = gJChronology61.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime65 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property66 = mutableDateTime65.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property66.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField71 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField64, dateTimeFieldType67);
        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException77 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder58.appendFixedDecimal(dateTimeFieldType67, (int) (short) 100);
        dateTimeParserBucket56.saveField(dateTimeFieldType67, 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType67, 19683);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField84 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField83);
        int int85 = remainderDateTimeField84.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57619 + "'", int19 == 57619);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology5 = gregorianChronology1.withZone(dateTimeZone4);
        java.lang.String str6 = gregorianChronology1.toString();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField10);
        org.joda.time.DateTimeField dateTimeField12 = skipUndoDateTimeField11.getWrappedField();
        long long15 = skipUndoDateTimeField11.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long17 = skipUndoDateTimeField11.roundFloor((long) (short) 1);
        int int18 = skipUndoDateTimeField11.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.monthOfYear();
        int int21 = mutableDateTime19.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = mutableDateTime19.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = dateTime23.toDateTime();
        org.joda.time.LocalTime localTime25 = dateTime24.toLocalTime();
        int int26 = skipUndoDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) localTime25);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.hourOfHalfday();
        java.util.Locale locale31 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket32 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology29, locale31);
        java.util.Locale locale33 = dateTimeParserBucket32.getLocale();
        java.lang.String str34 = skipUndoDateTimeField11.getAsText((-18059), locale33);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket37 = new org.joda.time.format.DateTimeParserBucket((long) 12885, (org.joda.time.Chronology) gregorianChronology1, locale33, (java.lang.Integer) 19683, 19);
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int39 = gregorianChronology38.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField40 = gregorianChronology38.days();
        org.joda.time.DateTimeZone dateTimeZone41 = gregorianChronology38.getZone();
        try {
            org.joda.time.MutableDateTime mutableDateTime42 = new org.joda.time.MutableDateTime((java.lang.Object) gregorianChronology1, dateTimeZone41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 49L + "'", long15 == 49L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-31507200000L) + "'", long17 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 57619 + "'", int21 == 57619);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "-18059" + "'", str34.equals("-18059"));
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
        int int19 = mutableDateTime17.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
        org.joda.time.DurationField durationField27 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField52 = gJChronology50.yearOfCentury();
        java.util.Locale locale53 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology50, locale53, (java.lang.Integer) (-2), 19675);
        java.lang.Object obj57 = dateTimeParserBucket56.saveState();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder58.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField62 = gJChronology61.weekyears();
        org.joda.time.DurationField durationField63 = gJChronology61.millis();
        org.joda.time.DateTimeField dateTimeField64 = gJChronology61.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime65 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property66 = mutableDateTime65.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property66.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField71 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField64, dateTimeFieldType67);
        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException77 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder58.appendFixedDecimal(dateTimeFieldType67, (int) (short) 100);
        dateTimeParserBucket56.saveField(dateTimeFieldType67, 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType67, 19683);
        long long86 = dividedDateTimeField83.getDifferenceAsLong(19678L, 31507199999L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57619 + "'", int19 == 57619);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + (-1600L) + "'", long86 == (-1600L));
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = gJChronology6.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8);
//        org.joda.time.DateTimeField dateTimeField10 = skipUndoDateTimeField9.getWrappedField();
//        long long13 = skipUndoDateTimeField9.getDifferenceAsLong((long) 19670, (-1L));
//        int int16 = skipUndoDateTimeField9.getDifference((long) (-1), (long) (byte) -1);
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField21 = gJChronology19.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology19);
//        mutableDateTime22.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        mutableDateTime22.setZoneRetainFields(dateTimeZone25);
//        int int27 = mutableDateTime22.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone28 = mutableDateTime22.getZone();
//        long long31 = dateTimeZone28.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField35 = gregorianChronology34.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder36 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone39 = dateTimeZoneBuilder36.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology40 = gregorianChronology34.withZone(dateTimeZone39);
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = gJChronology42.hourOfHalfday();
//        java.util.Locale locale44 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket45 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology42, locale44);
//        java.util.Locale locale46 = dateTimeParserBucket45.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket48 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology40, locale46, (java.lang.Integer) 19671);
//        java.lang.String str49 = dateTimeZone28.getShortName((long) 2000, locale46);
//        java.lang.String str50 = skipUndoDateTimeField9.getAsShortText(0, locale46);
//        org.joda.time.DateTime dateTime51 = property3.setCopy("0", locale46);
//        java.lang.String str52 = property1.getAsText(locale46);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 19684L + "'", long31 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(locale46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "PST" + "'", str49.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "0" + "'", str50.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "57619667" + "'", str52.equals("57619667"));
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long13 = zeroIsMaxDateTimeField10.set((long) 52, "59");
        java.lang.String str15 = zeroIsMaxDateTimeField10.getAsShortText((long) 19675);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField17 = gJChronology16.weekyears();
        org.joda.time.DurationField durationField18 = gJChronology16.millis();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology16.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType22);
        long long29 = zeroIsMaxDateTimeField26.set((long) 52, "59");
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = zeroIsMaxDateTimeField26.getType();
        int int32 = zeroIsMaxDateTimeField26.getMaximumValue((long) (-1));
        org.joda.time.DurationField durationField33 = zeroIsMaxDateTimeField26.getRangeDurationField();
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.monthOfYear();
        int int36 = mutableDateTime34.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.DateTime dateTime38 = mutableDateTime34.toDateTime(dateTimeZone37);
        org.joda.time.LocalTime localTime39 = dateTime38.toLocalTime();
        int int40 = zeroIsMaxDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime39);
        java.util.Locale locale41 = null;
        try {
            java.lang.String str42 = zeroIsMaxDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localTime39, locale41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'monthOfYear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 59052L + "'", long13 == 59052L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "19" + "'", str15.equals("19"));
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 59052L + "'", long29 == 59052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 60 + "'", int32 == 60);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 57619 + "'", int36 == 57619);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(localTime39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.monthOfYear();
        int int7 = mutableDateTime5.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime5.toDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime5.secondOfDay();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime5);
        java.lang.String str12 = dateTimeZone3.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57619 + "'", int7 == 57619);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        org.joda.time.DurationField durationField2 = property1.getRangeDurationField();
        int int3 = property1.getMinimumValueOverall();
        org.joda.time.DateTime dateTime5 = property1.setCopy("57600");
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong((long) 19670, (-1L));
        long long10 = skipUndoDateTimeField4.roundHalfEven(0L);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField11, (int) 'a');
        try {
            long long16 = offsetDateTimeField13.add(0L, 31507199999L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 31507199999");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        long long6 = dateTimeZone3.convertLocalToUTC((long) 19684, false);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28819684L + "'", long6 == 28819684L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology5 = gregorianChronology1.withZone(dateTimeZone4);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider6 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale7 = null;
        java.lang.String str10 = defaultNameProvider6.getShortName(locale7, "hi!", "52");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter11.withZoneUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int15 = gregorianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology14.getZone();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology18 = gregorianChronology14.withZone(dateTimeZone17);
        java.lang.String str19 = gregorianChronology14.toString();
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology20, dateTimeField23);
        org.joda.time.DateTimeField dateTimeField25 = skipUndoDateTimeField24.getWrappedField();
        long long28 = skipUndoDateTimeField24.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long30 = skipUndoDateTimeField24.roundFloor((long) (short) 1);
        int int31 = skipUndoDateTimeField24.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property33 = mutableDateTime32.monthOfYear();
        int int34 = mutableDateTime32.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.DateTime dateTime36 = mutableDateTime32.toDateTime(dateTimeZone35);
        org.joda.time.DateTime dateTime37 = dateTime36.toDateTime();
        org.joda.time.LocalTime localTime38 = dateTime37.toLocalTime();
        int int39 = skipUndoDateTimeField24.getMinimumValue((org.joda.time.ReadablePartial) localTime38);
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = gJChronology42.hourOfHalfday();
        java.util.Locale locale44 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket45 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology42, locale44);
        java.util.Locale locale46 = dateTimeParserBucket45.getLocale();
        java.lang.String str47 = skipUndoDateTimeField24.getAsText((-18059), locale46);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket50 = new org.joda.time.format.DateTimeParserBucket((long) 12885, (org.joda.time.Chronology) gregorianChronology14, locale46, (java.lang.Integer) 19683, 19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter11.withLocale(locale46);
        java.lang.String str54 = defaultNameProvider6.getShortName(locale46, "monthOfYear", "2019-W28");
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket57 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gregorianChronology1, locale46, (java.lang.Integer) 29645, 19700);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str19.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 49L + "'", long28 == 49L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-31507200000L) + "'", long30 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 57619 + "'", int34 == 57619);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(localTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(locale46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "-18059" + "'", str47.equals("-18059"));
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNull(str54);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        int int5 = mutableDateTime4.getRoundingMode();
        java.lang.String str6 = mutableDateTime4.toString();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T15:59:59.999-08:00" + "'", str6.equals("1969-12-31T15:59:59.999-08:00"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.minus(readablePeriod3);
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology7);
        mutableDateTime10.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        mutableDateTime10.setZoneRetainFields(dateTimeZone13);
        int int15 = mutableDateTime10.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = mutableDateTime10.getZone();
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime1.toMutableDateTime(dateTimeZone16);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.millisOfSecond();
        boolean boolean19 = property18.isLeap();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-31T16" + "'", str5.equals("1969-12-31T16"));
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField7 = gregorianChronology6.weekyears();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology9);
        mutableDateTime12.addMonths((-1));
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime12.secondOfDay();
        boolean boolean16 = gregorianChronology6.equals((java.lang.Object) property15);
        java.lang.Class<?> wildcardClass17 = gregorianChronology6.getClass();
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(2000, (int) (short) 1, 19702, 0, 19692, (int) 'a', (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19692 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 19678, "19666");
        java.lang.Throwable throwable3 = null;
        try {
            illegalInstantException2.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder20.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendCenturyOfEra(19689901, 19686);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.monthOfYear();
        int int4 = mutableDateTime2.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.plusMonths(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("monthOfYear", false);
        org.joda.time.DateTime dateTime13 = dateTime8.withZone(dateTimeZone12);
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) mutableDateTime2, (org.joda.time.ReadableDateTime) dateTime13);
        try {
            long long22 = limitChronology14.getDateTimeMillis(0, 0, 163, (int) (short) 1, 60, (int) '#', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 60 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57619 + "'", int4 == 57619);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(limitChronology14);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = mutableDateTime0.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
        org.joda.time.DateTime dateTime7 = dateTime4.minus((long) 5);
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(19677);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField14 = gregorianChronology13.weekyears();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone18 = dateTimeZoneBuilder15.toDateTimeZone("monthOfYear", false);
        org.joda.time.Chronology chronology19 = gregorianChronology13.withZone(dateTimeZone18);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.hourOfHalfday();
        java.util.Locale locale23 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket24 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology21, locale23);
        java.util.Locale locale25 = dateTimeParserBucket24.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology19, locale25, (java.lang.Integer) 19671);
        org.joda.time.Chronology chronology28 = dateTimeParserBucket27.getChronology();
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology30.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology30.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime33 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology30);
        mutableDateTime33.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime33.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder37 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone40 = dateTimeZoneBuilder37.toDateTimeZone("monthOfYear", false);
        java.lang.String str42 = dateTimeZone40.getShortName(0L);
        mutableDateTime33.setZoneRetainFields(dateTimeZone40);
        dateTimeParserBucket27.setZone(dateTimeZone40);
        org.joda.time.DateTime dateTime45 = dateTime9.withZoneRetainFields(dateTimeZone40);
        long long49 = dateTimeZone40.convertLocalToUTC((long) 95, true, 0L);
        org.joda.time.DateTime dateTime50 = dateTime7.withZoneRetainFields(dateTimeZone40);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57619 + "'", int2 == 57619);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57619662 + "'", int8 == 57619662);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(locale25);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "+00:00" + "'", str42.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 95L + "'", long49 == 95L);
        org.junit.Assert.assertNotNull(dateTime50);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField18 = gJChronology17.weekyears();
        org.joda.time.DurationField durationField19 = gJChronology17.millis();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology17.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField20, dateTimeFieldType23);
        int int29 = zeroIsMaxDateTimeField27.getMaximumValue((long) 2);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.monthOfYear();
        int int32 = mutableDateTime30.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = mutableDateTime30.toDateTime(dateTimeZone33);
        org.joda.time.DateTime dateTime35 = dateTime34.toDateTime();
        org.joda.time.LocalTime localTime36 = dateTime35.toLocalTime();
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = gJChronology38.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField40 = gJChronology38.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField(chronology37, dateTimeField40);
        org.joda.time.DateTimeField dateTimeField42 = skipUndoDateTimeField41.getWrappedField();
        long long45 = skipUndoDateTimeField41.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial46 = null;
        int[] intArray54 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray56 = skipUndoDateTimeField41.add(readablePartial46, 19670, intArray54, 0);
        int int57 = zeroIsMaxDateTimeField27.getMaximumValue((org.joda.time.ReadablePartial) localTime36, intArray54);
        org.joda.time.Chronology chronology59 = null;
        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField61 = gJChronology60.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField62 = gJChronology60.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField63 = new org.joda.time.field.SkipUndoDateTimeField(chronology59, dateTimeField62);
        org.joda.time.DateTimeField dateTimeField64 = skipUndoDateTimeField63.getWrappedField();
        long long67 = skipUndoDateTimeField63.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial68 = null;
        int[] intArray76 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray78 = skipUndoDateTimeField63.add(readablePartial68, 19670, intArray76, 0);
        try {
            int[] intArray80 = zeroIsMaxDateTimeField10.addWrapField((org.joda.time.ReadablePartial) localTime36, 19697, intArray78, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19697");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 60 + "'", int29 == 60);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 57619 + "'", int32 == 57619);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(localTime36);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 49L + "'", long45 == 49L);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 60 + "'", int57 == 60);
        org.junit.Assert.assertNotNull(gJChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 49L + "'", long67 == 49L);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray78);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField5 = gregorianChronology3.days();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology3.getZone();
        org.joda.time.DateTime dateTime7 = dateTime0.withZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long13 = zeroIsMaxDateTimeField10.set((long) 52, "59");
        int int14 = zeroIsMaxDateTimeField10.getMinimumValue();
        long long16 = zeroIsMaxDateTimeField10.remainder(49L);
        java.util.Locale locale18 = null;
        java.lang.String str19 = zeroIsMaxDateTimeField10.getAsText(192467526L, locale18);
        long long22 = zeroIsMaxDateTimeField10.getDifferenceAsLong(0L, (-37916381L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 59052L + "'", long13 == 59052L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 49L + "'", long16 == 49L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "47" + "'", str19.equals("47"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 37916L + "'", long22 == 37916L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("16:00", "57600");
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.dayOfMonth();
        org.joda.time.DurationField durationField3 = gJChronology0.seconds();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
        int int19 = mutableDateTime17.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
        org.joda.time.DurationField durationField27 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
        long long51 = offsetDateTimeField48.add((long) 19681, 19689);
        int int52 = offsetDateTimeField48.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57619 + "'", int19 == 57619);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 19708681L + "'", long51 == 19708681L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 32 + "'", int52 == 32);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str2 = julianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime dateTime10 = dateTime8.withYear((int) 'a');
        org.joda.time.DateTime dateTime13 = dateTime8.withDurationAdded((long) 60, (int) (byte) 0);
        org.joda.time.DateTime dateTime15 = dateTime13.minusWeeks((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime dateTime21 = dateTime19.withYear((int) 'a');
        org.joda.time.DateTime.Property property22 = dateTime19.weekyear();
        org.joda.time.DateTime.Property property23 = dateTime19.dayOfYear();
        boolean boolean24 = dateTime15.isAfter((org.joda.time.ReadableInstant) dateTime19);
        int int25 = dateTimeZone3.getOffset((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter0.withZone(dateTimeZone3);
        org.joda.time.LocalDateTime localDateTime27 = null;
        try {
            boolean boolean28 = dateTimeZone3.isLocalDateTimeGap(localDateTime27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-28800000) + "'", int25 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(19683, 2052, 59, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        int int2 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        mutableDateTime4.setMillis(readableInstant9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime4.dayOfMonth();
        mutableDateTime4.addMonths((-28800000));
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.addMonths((-1));
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundHalfEven();
        org.joda.time.DurationField durationField9 = property7.getRangeDurationField();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.monthOfYear();
        int int15 = mutableDateTime13.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = mutableDateTime13.toDateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        int int20 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime19);
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.monthOfYear();
        int int23 = mutableDateTime21.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = mutableDateTime21.toDateTime(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTime();
        org.joda.time.LocalTime localTime27 = dateTime26.toLocalTime();
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology29.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField(chronology28, dateTimeField31);
        org.joda.time.DateTimeField dateTimeField33 = skipUndoDateTimeField32.getWrappedField();
        long long36 = skipUndoDateTimeField32.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial37 = null;
        int[] intArray45 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray47 = skipUndoDateTimeField32.add(readablePartial37, 19670, intArray45, 0);
        int int48 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime27, intArray47);
        org.joda.time.DurationField durationField49 = zeroIsMaxDateTimeField10.getLeapDurationField();
        int int51 = zeroIsMaxDateTimeField10.get((-187200000L));
        long long54 = zeroIsMaxDateTimeField10.getDifferenceAsLong((long) 19671, (long) 57619);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 57619 + "'", int15 == 57619);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 60 + "'", int20 == 60);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 57619 + "'", int23 == 57619);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localTime27);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 49L + "'", long36 == 49L);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 60 + "'", int48 == 60);
        org.junit.Assert.assertNull(durationField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 60 + "'", int51 == 60);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-37L) + "'", long54 == (-37L));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        try {
            long long12 = gregorianChronology0.getDateTimeMillis(100, 19686, 2, 20, 19694, (int) (byte) 10, (-18059));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19694 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(5, 0, 2052, (-18059), 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -18059 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.minus(readablePeriod3);
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology7);
        mutableDateTime10.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        mutableDateTime10.setZoneRetainFields(dateTimeZone13);
        int int15 = mutableDateTime10.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = mutableDateTime10.getZone();
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime1.toMutableDateTime(dateTimeZone16);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField19 = gJChronology18.weekyears();
        org.joda.time.DurationField durationField20 = gJChronology18.millis();
        org.joda.time.DateTimeField dateTimeField21 = gJChronology18.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime22.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField28 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField21, dateTimeFieldType24);
        org.joda.time.DurationField durationField29 = zeroIsMaxDateTimeField28.getDurationField();
        java.util.Locale locale31 = null;
        java.lang.String str32 = zeroIsMaxDateTimeField28.getAsText((long) (short) -1, locale31);
        long long34 = zeroIsMaxDateTimeField28.roundCeiling((-31507200000L));
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.monthOfYear();
        int int37 = mutableDateTime35.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = mutableDateTime35.toDateTime(dateTimeZone38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder40.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField44 = gJChronology43.weekyears();
        org.joda.time.DurationField durationField45 = gJChronology43.millis();
        org.joda.time.DateTimeField dateTimeField46 = gJChronology43.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime47 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime47.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property48.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException52 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType49, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField53 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField46, dateTimeFieldType49);
        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType49, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException59 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType49, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder40.appendFixedDecimal(dateTimeFieldType49, (int) (short) 100);
        org.joda.time.MutableDateTime.Property property62 = mutableDateTime35.property(dateTimeFieldType49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField28, dateTimeFieldType49, 4, (int) ' ', 19666);
        mutableDateTime17.setRounding((org.joda.time.DateTimeField) offsetDateTimeField66);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-31T16" + "'", str5.equals("1969-12-31T16"));
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "59" + "'", str32.equals("59"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-31507200000L) + "'", long34 == (-31507200000L));
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 57619 + "'", int37 == 57619);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(property62);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime dateTime13 = dateTime11.withYear((int) 'a');
        int int14 = mutableDateTime4.compareTo((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.dayOfYear();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        long long6 = gJChronology0.add((long) (short) 100, 0L, (int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) mutableDateTime7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        boolean boolean10 = mutableDateTime7.isEqual(readableInstant9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        boolean boolean12 = mutableDateTime7.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime1.minusHours(60);
        org.joda.time.DateTime.Property property6 = dateTime1.monthOfYear();
        boolean boolean8 = dateTime1.isBefore((long) 19671);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long12 = zeroIsMaxDateTimeField10.roundHalfEven((long) 19701);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 20000L + "'", long12 == 20000L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        java.lang.String str2 = property1.getName();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.add((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime4.toMutableDateTime(dateTimeZone5);
        boolean boolean8 = mutableDateTime4.isBefore(192480938L);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "monthOfYear" + "'", str2.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendSecondOfMinute(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay(19676);
        org.joda.time.DateTime dateTime7 = dateTime3.plusSeconds(19679);
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
        org.joda.time.DateTimeZone dateTimeZone9 = mutableDateTime8.getZone();
        org.joda.time.DateTime dateTime10 = dateTime7.withZone(dateTimeZone9);
        java.util.Date date11 = dateTime10.toDate();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(date11);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
//        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
//        long long10 = skipUndoDateTimeField4.roundFloor((long) (short) 1);
//        int int11 = skipUndoDateTimeField4.getMaximumValue();
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.monthOfYear();
//        int int14 = mutableDateTime12.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = mutableDateTime12.toDateTime(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = dateTime16.toDateTime();
//        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
//        int int19 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime18);
//        java.util.Locale locale20 = null;
//        int int21 = skipUndoDateTimeField4.getMaximumTextLength(locale20);
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField26 = gJChronology24.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology24);
//        mutableDateTime27.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        mutableDateTime27.setZoneRetainFields(dateTimeZone30);
//        int int32 = mutableDateTime27.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone33 = mutableDateTime27.getZone();
//        long long36 = dateTimeZone33.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField40 = gregorianChronology39.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder41 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone44 = dateTimeZoneBuilder41.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology45 = gregorianChronology39.withZone(dateTimeZone44);
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField48 = gJChronology47.hourOfHalfday();
//        java.util.Locale locale49 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket50 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology47, locale49);
//        java.util.Locale locale51 = dateTimeParserBucket50.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket53 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology45, locale51, (java.lang.Integer) 19671);
//        java.lang.String str54 = dateTimeZone33.getShortName((long) 2000, locale51);
//        java.lang.String str55 = skipUndoDateTimeField4.getAsText(19680, locale51);
//        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField58 = gJChronology57.hourOfHalfday();
//        java.util.Locale locale59 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket60 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology57, locale59);
//        java.util.Locale locale61 = dateTimeParserBucket60.getLocale();
//        int int62 = skipUndoDateTimeField4.getMaximumTextLength(locale61);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 57619 + "'", int14 == 57619);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 19684L + "'", long36 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(locale51);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "PST" + "'", str54.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "19680" + "'", str55.equals("19680"));
//        org.junit.Assert.assertNotNull(gJChronology57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(locale61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 3 + "'", int62 == 3);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = mutableDateTime0.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
        org.joda.time.DateTime.Property property6 = dateTime5.era();
        java.lang.String str7 = property6.toString();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57619 + "'", int2 == 57619);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[era]" + "'", str7.equals("Property[era]"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        long long6 = gJChronology0.add((long) (short) 100, 0L, (int) (byte) 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField10);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11);
        java.lang.String str14 = skipUndoDateTimeField11.getAsShortText((long) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.monthOfYear();
        int int17 = mutableDateTime15.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = mutableDateTime15.toDateTime(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime19.toDateTime();
        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
        int int22 = skipUndoDateTimeField11.getMaximumValue((org.joda.time.ReadablePartial) localTime21);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 57619 + "'", int17 == 57619);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = mutableDateTime0.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField9 = gJChronology8.weekyears();
        org.joda.time.DurationField durationField10 = gJChronology8.millis();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField18 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField11, dateTimeFieldType14);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder5.appendFixedDecimal(dateTimeFieldType14, (int) (short) 100);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime0.property(dateTimeFieldType14);
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 0.0f, "59");
        java.lang.Number number31 = illegalFieldValueException30.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType32 = illegalFieldValueException30.getDurationFieldType();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57619 + "'", int2 == 57619);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertNull(durationFieldType32);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
        int int13 = zeroIsMaxDateTimeField10.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = zeroIsMaxDateTimeField10.getType();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 60 + "'", int13 == 60);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
        int int19 = mutableDateTime17.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
        org.joda.time.DurationField durationField27 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField52 = gJChronology50.yearOfCentury();
        java.util.Locale locale53 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology50, locale53, (java.lang.Integer) (-2), 19675);
        java.lang.Object obj57 = dateTimeParserBucket56.saveState();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder58.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField62 = gJChronology61.weekyears();
        org.joda.time.DurationField durationField63 = gJChronology61.millis();
        org.joda.time.DateTimeField dateTimeField64 = gJChronology61.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime65 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property66 = mutableDateTime65.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property66.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField71 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField64, dateTimeFieldType67);
        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException77 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder58.appendFixedDecimal(dateTimeFieldType67, (int) (short) 100);
        dateTimeParserBucket56.saveField(dateTimeFieldType67, 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType67, 19683);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField84 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField83);
        boolean boolean86 = dividedDateTimeField83.isLeap((long) 52);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57619 + "'", int19 == 57619);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
//        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
//        long long10 = skipUndoDateTimeField4.roundFloor((long) (short) 1);
//        boolean boolean12 = skipUndoDateTimeField4.isLeap((long) 2019);
//        long long15 = skipUndoDateTimeField4.add(19674L, 0L);
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology18);
//        mutableDateTime21.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        mutableDateTime21.setZoneRetainFields(dateTimeZone24);
//        org.joda.time.MutableDateTime.Property property26 = mutableDateTime21.dayOfWeek();
//        org.joda.time.MutableDateTime.Property property27 = mutableDateTime21.weekOfWeekyear();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property29 = dateTime28.millisOfDay();
//        org.joda.time.Chronology chronology31 = null;
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField33 = gJChronology32.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology32.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField(chronology31, dateTimeField34);
//        org.joda.time.DateTimeField dateTimeField36 = skipUndoDateTimeField35.getWrappedField();
//        long long39 = skipUndoDateTimeField35.getDifferenceAsLong((long) 19670, (-1L));
//        int int42 = skipUndoDateTimeField35.getDifference((long) (-1), (long) (byte) -1);
//        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField46 = gJChronology45.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField47 = gJChronology45.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime48 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology45);
//        mutableDateTime48.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        mutableDateTime48.setZoneRetainFields(dateTimeZone51);
//        int int53 = mutableDateTime48.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone54 = mutableDateTime48.getZone();
//        long long57 = dateTimeZone54.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField61 = gregorianChronology60.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder62 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone65 = dateTimeZoneBuilder62.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology66 = gregorianChronology60.withZone(dateTimeZone65);
//        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField69 = gJChronology68.hourOfHalfday();
//        java.util.Locale locale70 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket71 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology68, locale70);
//        java.util.Locale locale72 = dateTimeParserBucket71.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket74 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology66, locale72, (java.lang.Integer) 19671);
//        java.lang.String str75 = dateTimeZone54.getShortName((long) 2000, locale72);
//        java.lang.String str76 = skipUndoDateTimeField35.getAsShortText(0, locale72);
//        org.joda.time.DateTime dateTime77 = property29.setCopy("0", locale72);
//        int int78 = property27.getMaximumShortTextLength(locale72);
//        try {
//            java.lang.String str79 = skipUndoDateTimeField4.getAsShortText(readablePartial16, locale72);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 19674L + "'", long15 == 19674L);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(gJChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 19684L + "'", long57 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(dateTimeZone65);
//        org.junit.Assert.assertNotNull(chronology66);
//        org.junit.Assert.assertNotNull(gJChronology68);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertNotNull(locale72);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "PST" + "'", str75.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "0" + "'", str76.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2 + "'", int78 == 2);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        org.joda.time.LocalDate localDate2 = dateTime0.toLocalDate();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(localDate2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = mutableDateTime0.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField9 = gJChronology8.weekyears();
        org.joda.time.DurationField durationField10 = gJChronology8.millis();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField18 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField11, dateTimeFieldType14);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder5.appendFixedDecimal(dateTimeFieldType14, (int) (short) 100);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime0.property(dateTimeFieldType14);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType14, 29645, 0, 19696);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 29645 for monthOfYear must be in the range [0,19696]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57619 + "'", int2 == 57619);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(property27);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = mutableDateTime0.getSecondOfDay();
        mutableDateTime0.addWeeks(19669);
        mutableDateTime0.addSeconds(19669);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime0.monthOfYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.monthOfYear();
        int int11 = mutableDateTime9.getSecondOfDay();
        int int14 = dateTimeFormatter8.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "monthOfYear", (int) (short) 1);
        int int15 = mutableDateTime9.getMinuteOfDay();
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime9);
        int int17 = mutableDateTime0.compareTo((org.joda.time.ReadableInstant) mutableDateTime9);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57619 + "'", int2 == 57619);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57619 + "'", int11 == 57619);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-2) + "'", int14 == (-2));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 960 + "'", int15 == 960);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long13 = zeroIsMaxDateTimeField10.add(19689901L, (long) 52);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 19741901L + "'", long13 == 19741901L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("");
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField6 = gJChronology5.weekyears();
        org.joda.time.DurationField durationField7 = gJChronology5.millis();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField15 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType11);
        org.joda.time.DurationField durationField16 = zeroIsMaxDateTimeField15.getDurationField();
        java.util.Locale locale18 = null;
        java.lang.String str19 = zeroIsMaxDateTimeField15.getAsText((long) (short) -1, locale18);
        long long21 = zeroIsMaxDateTimeField15.roundCeiling((-31507200000L));
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime22.monthOfYear();
        int int24 = mutableDateTime22.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = mutableDateTime22.toDateTime(dateTimeZone25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField31 = gJChronology30.weekyears();
        org.joda.time.DurationField durationField32 = gJChronology30.millis();
        org.joda.time.DateTimeField dateTimeField33 = gJChronology30.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField33, dateTimeFieldType36);
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder27.appendFixedDecimal(dateTimeFieldType36, (int) (short) 100);
        org.joda.time.MutableDateTime.Property property49 = mutableDateTime22.property(dateTimeFieldType36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField15, dateTimeFieldType36, 4, (int) ' ', 19666);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType36);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder55.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField59 = gJChronology58.weekyears();
        org.joda.time.DurationField durationField60 = gJChronology58.millis();
        org.joda.time.DateTimeField dateTimeField61 = gJChronology58.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime62 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property63 = mutableDateTime62.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property63.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException67 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField68 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField61, dateTimeFieldType64);
        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException74 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder76 = dateTimeFormatterBuilder55.appendFixedDecimal(dateTimeFieldType64, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType64);
        org.joda.time.IllegalFieldValueException illegalFieldValueException81 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, (java.lang.Number) 28800000L, (java.lang.Number) 2000012L, (java.lang.Number) 19689901L);
        java.lang.Number number82 = illegalFieldValueException81.getLowerBound();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "59" + "'", str19.equals("59"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-31507200000L) + "'", long21 == (-31507200000L));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 57619 + "'", int24 == 57619);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertNotNull(gJChronology58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(durationField60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder76);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
        org.junit.Assert.assertTrue("'" + number82 + "' != '" + 2000012L + "'", number82.equals(2000012L));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((-1));
        java.io.Writer writer4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8);
        org.joda.time.DateTimeField dateTimeField10 = skipUndoDateTimeField9.getWrappedField();
        long long13 = skipUndoDateTimeField9.getDifferenceAsLong((long) 19670, (-1L));
        long long15 = skipUndoDateTimeField9.roundHalfEven(0L);
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.monthOfYear();
        int int18 = mutableDateTime16.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = mutableDateTime16.toDateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTime();
        org.joda.time.LocalTime localTime22 = dateTime21.toLocalTime();
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField9.getAsText((org.joda.time.ReadablePartial) localTime22, 19, locale24);
        try {
            dateTimeFormatter3.printTo(writer4, (org.joda.time.ReadablePartial) localTime22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 57619 + "'", int18 == 57619);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localTime22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "19" + "'", str25.equals("19"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType9, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendSecondOfDay(19676);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.appendClockhourOfDay(19678);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.yearOfCentury();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.centuryOfEra();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology3 = buddhistChronology2.withUTC();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology5.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology5);
//        mutableDateTime8.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        mutableDateTime8.setZoneRetainFields(dateTimeZone11);
//        int int13 = mutableDateTime8.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone14 = mutableDateTime8.getZone();
//        long long17 = dateTimeZone14.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField21 = gregorianChronology20.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone25 = dateTimeZoneBuilder22.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology26 = gregorianChronology20.withZone(dateTimeZone25);
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField29 = gJChronology28.hourOfHalfday();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology28, locale30);
//        java.util.Locale locale32 = dateTimeParserBucket31.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket34 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology26, locale32, (java.lang.Integer) 19671);
//        java.lang.String str35 = dateTimeZone14.getShortName((long) 2000, locale32);
//        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone14);
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology36);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.Chronology chronology39 = dateTimeFormatter38.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property41 = mutableDateTime40.monthOfYear();
//        java.lang.Object obj42 = mutableDateTime40.clone();
//        mutableDateTime40.addMinutes(19669);
//        int int47 = dateTimeFormatter38.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime40, "", 19670);
//        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField50 = gregorianChronology49.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder51 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone54 = dateTimeZoneBuilder51.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology55 = gregorianChronology49.withZone(dateTimeZone54);
//        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField58 = gJChronology57.hourOfHalfday();
//        java.util.Locale locale59 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket60 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology57, locale59);
//        java.util.Locale locale61 = dateTimeParserBucket60.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket63 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology55, locale61, (java.lang.Integer) 19671);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter64 = dateTimeFormatter38.withLocale(locale61);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket65 = new org.joda.time.format.DateTimeParserBucket((long) 19670, (org.joda.time.Chronology) zonedChronology36, locale61);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter66 = dateTimeFormatter0.withLocale(locale61);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 19684L + "'", long17 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(locale32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "PST" + "'", str35.equals("PST"));
//        org.junit.Assert.assertNotNull(zonedChronology36);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNull(chronology39);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(obj42);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-19671) + "'", int47 == (-19671));
//        org.junit.Assert.assertNotNull(gregorianChronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(gJChronology57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(locale61);
//        org.junit.Assert.assertNotNull(dateTimeFormatter64);
//        org.junit.Assert.assertNotNull(dateTimeFormatter66);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType9, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder0.appendYearOfCentury(0, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder0.appendDayOfYear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendTwoDigitWeekyear(19697);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(1560342467589L);
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.property(dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 57, "19");
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long10 = skipUndoDateTimeField4.roundFloor((long) (short) 1);
        int int11 = skipUndoDateTimeField4.getMaximumValue();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField13 = gJChronology12.weekyears();
        org.joda.time.DurationField durationField14 = gJChronology12.millis();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology12.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField15, dateTimeFieldType18);
        int int24 = zeroIsMaxDateTimeField22.getMaximumValue((long) 2);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
        org.joda.time.DurationField durationField27 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
        int int37 = zeroIsMaxDateTimeField35.getMaximumValue((long) 2);
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime38.monthOfYear();
        int int40 = mutableDateTime38.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = mutableDateTime38.toDateTime(dateTimeZone41);
        org.joda.time.DateTime dateTime43 = dateTime42.toDateTime();
        org.joda.time.LocalTime localTime44 = dateTime43.toLocalTime();
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField47 = gJChronology46.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField48 = gJChronology46.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField(chronology45, dateTimeField48);
        org.joda.time.DateTimeField dateTimeField50 = skipUndoDateTimeField49.getWrappedField();
        long long53 = skipUndoDateTimeField49.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial54 = null;
        int[] intArray62 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray64 = skipUndoDateTimeField49.add(readablePartial54, 19670, intArray62, 0);
        int int65 = zeroIsMaxDateTimeField35.getMaximumValue((org.joda.time.ReadablePartial) localTime44, intArray62);
        java.util.Locale locale67 = null;
        java.lang.String str68 = zeroIsMaxDateTimeField22.getAsText((org.joda.time.ReadablePartial) localTime44, 12, locale67);
        int int69 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime44);
        long long71 = skipUndoDateTimeField4.roundHalfFloor((long) 4038000);
        int int72 = skipUndoDateTimeField4.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField73 = skipUndoDateTimeField4.getWrappedField();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 60 + "'", int24 == 60);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 60 + "'", int37 == 60);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 57619 + "'", int40 == 57619);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localTime44);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 49L + "'", long53 == 49L);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 60 + "'", int65 == 60);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "12" + "'", str68.equals("12"));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 28800000L + "'", long71 == 28800000L);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(dateTimeField73);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.minus(readablePeriod3);
        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology7);
        mutableDateTime10.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        mutableDateTime10.setZoneRetainFields(dateTimeZone13);
        int int15 = mutableDateTime10.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = mutableDateTime10.getZone();
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime1.toMutableDateTime(dateTimeZone16);
        int int19 = dateTimeZone16.getOffsetFromLocal(100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-31T16" + "'", str5.equals("1969-12-31T16"));
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
        java.util.Locale locale2 = null;
        int int3 = property1.getMaximumShortTextLength(locale2);
        org.joda.time.DateTime dateTime4 = property1.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-37899509L));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.weekyear();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField7 = gJChronology6.weekyears();
//        org.joda.time.DurationField durationField8 = gJChronology6.millis();
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField16 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType12);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) (short) 100, "monthOfYear");
//        org.joda.time.DateTime.Property property20 = dateTime4.property(dateTimeFieldType12);
//        org.joda.time.DateTime dateTime21 = property20.roundCeilingCopy();
//        int int22 = property20.getMinimumValue();
//        try {
//            org.joda.time.DateTime dateTime24 = property20.addToCopy((-31507200000L));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Magnitude of add amount is too large: -31507200000");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68253 + "'", int2 == 68253);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
//        long long15 = zeroIsMaxDateTimeField10.add(12L, 2000);
//        long long18 = zeroIsMaxDateTimeField10.getDifferenceAsLong((long) 19687, 192477915L);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10);
//        org.joda.time.DurationField durationField20 = delegatedDateTimeField19.getDurationField();
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField22 = gJChronology21.weekyears();
//        org.joda.time.DurationField durationField23 = gJChronology21.millis();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType27, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField31 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField24, dateTimeFieldType27);
//        int int33 = zeroIsMaxDateTimeField31.getMaximumValue((long) 2);
//        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField35 = gJChronology34.weekyears();
//        org.joda.time.DurationField durationField36 = gJChronology34.millis();
//        org.joda.time.DateTimeField dateTimeField37 = gJChronology34.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property39 = mutableDateTime38.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField44 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField37, dateTimeFieldType40);
//        int int46 = zeroIsMaxDateTimeField44.getMaximumValue((long) 2);
//        org.joda.time.MutableDateTime mutableDateTime47 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property48 = mutableDateTime47.monthOfYear();
//        int int49 = mutableDateTime47.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.DateTime dateTime51 = mutableDateTime47.toDateTime(dateTimeZone50);
//        org.joda.time.DateTime dateTime52 = dateTime51.toDateTime();
//        org.joda.time.LocalTime localTime53 = dateTime52.toLocalTime();
//        org.joda.time.Chronology chronology54 = null;
//        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField56 = gJChronology55.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField57 = gJChronology55.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField58 = new org.joda.time.field.SkipUndoDateTimeField(chronology54, dateTimeField57);
//        org.joda.time.DateTimeField dateTimeField59 = skipUndoDateTimeField58.getWrappedField();
//        long long62 = skipUndoDateTimeField58.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial63 = null;
//        int[] intArray71 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray73 = skipUndoDateTimeField58.add(readablePartial63, 19670, intArray71, 0);
//        int int74 = zeroIsMaxDateTimeField44.getMaximumValue((org.joda.time.ReadablePartial) localTime53, intArray71);
//        java.util.Locale locale76 = null;
//        java.lang.String str77 = zeroIsMaxDateTimeField31.getAsText((org.joda.time.ReadablePartial) localTime53, 12, locale76);
//        int int78 = delegatedDateTimeField19.getMaximumValue((org.joda.time.ReadablePartial) localTime53);
//        long long80 = delegatedDateTimeField19.roundHalfFloor((long) 19671);
//        org.joda.time.DurationField durationField81 = delegatedDateTimeField19.getRangeDurationField();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2000012L + "'", long15 == 2000012L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-192458L) + "'", long18 == (-192458L));
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 60 + "'", int33 == 60);
//        org.junit.Assert.assertNotNull(gJChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 60 + "'", int46 == 60);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 68253 + "'", int49 == 68253);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(localTime53);
//        org.junit.Assert.assertNotNull(gJChronology55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 49L + "'", long62 == 49L);
//        org.junit.Assert.assertNotNull(intArray71);
//        org.junit.Assert.assertNotNull(intArray73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 60 + "'", int74 == 60);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "12" + "'", str77.equals("12"));
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 60 + "'", int78 == 60);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 20000L + "'", long80 == 20000L);
//        org.junit.Assert.assertNotNull(durationField81);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        boolean boolean2 = mutableDateTime0.isEqual(0L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis((int) (byte) 10, 19678, (-28800000), 19692, 8, 1296, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19692 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        java.lang.String str5 = gregorianChronology0.toString();
        java.lang.String str6 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str5.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField9 = gJChronology8.weekyears();
//        org.joda.time.DurationField durationField10 = gJChronology8.millis();
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField18 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField11, dateTimeFieldType14);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder5.appendFixedDecimal(dateTimeFieldType14, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property27 = mutableDateTime0.property(dateTimeFieldType14);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 0.0f, "59");
//        java.lang.String str31 = illegalFieldValueException30.toString();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68253 + "'", int2 == 68253);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 0.0 for monthOfYear is not supported: 59" + "'", str31.equals("org.joda.time.IllegalFieldValueException: Value 0.0 for monthOfYear is not supported: 59"));
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        java.lang.String str2 = property1.getName();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.add((long) 'a');
        org.joda.time.Interval interval5 = property1.toInterval();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property1.getAsText(locale6);
        java.lang.String str8 = property1.getAsText();
        int int9 = property1.getLeapAmount();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "monthOfYear" + "'", str2.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "July" + "'", str7.equals("July"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "July" + "'", str8.equals("July"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("DateTimeField[monthOfYear]", "12", 19700, (int) (short) 1);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(1560342498872L);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 100);
        long long10 = fixedDateTimeZone4.nextTransition((long) 19678);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter15.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter18.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter19.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter21.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter22.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter24.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser26 = dateTimeFormatter25.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter27.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter28.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray30 = new org.joda.time.format.DateTimeParser[] { dateTimeParser17, dateTimeParser20, dateTimeParser23, dateTimeParser26, dateTimeParser29 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder11.append(dateTimePrinter14, dateTimeParserArray30);
        boolean boolean32 = dateTimeFormatterBuilder11.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder11.appendClockhourOfDay(19667);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder34.appendHalfdayOfDayText();
        boolean boolean36 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeFormatterBuilder34);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19700 + "'", int6 == 19700);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "12" + "'", str8.equals("12"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 19678L + "'", long10 == 19678L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeParser26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeParserArray30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField2 = gJChronology0.years();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        int int12 = zeroIsMaxDateTimeField10.getMaximumValue((long) 2);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField14 = gJChronology13.weekyears();
//        org.joda.time.DurationField durationField15 = gJChronology13.millis();
//        org.joda.time.DateTimeField dateTimeField16 = gJChronology13.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField16, dateTimeFieldType19);
//        int int25 = zeroIsMaxDateTimeField23.getMaximumValue((long) 2);
//        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property27 = mutableDateTime26.monthOfYear();
//        int int28 = mutableDateTime26.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = mutableDateTime26.toDateTime(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = dateTime30.toDateTime();
//        org.joda.time.LocalTime localTime32 = dateTime31.toLocalTime();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField35 = gJChronology34.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField36 = gJChronology34.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField(chronology33, dateTimeField36);
//        org.joda.time.DateTimeField dateTimeField38 = skipUndoDateTimeField37.getWrappedField();
//        long long41 = skipUndoDateTimeField37.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial42 = null;
//        int[] intArray50 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray52 = skipUndoDateTimeField37.add(readablePartial42, 19670, intArray50, 0);
//        int int53 = zeroIsMaxDateTimeField23.getMaximumValue((org.joda.time.ReadablePartial) localTime32, intArray50);
//        java.util.Locale locale55 = null;
//        java.lang.String str56 = zeroIsMaxDateTimeField10.getAsText((org.joda.time.ReadablePartial) localTime32, 12, locale55);
//        int int58 = zeroIsMaxDateTimeField10.getMinimumValue((-210866673619666L));
//        long long61 = zeroIsMaxDateTimeField10.add((long) ' ', 0);
//        int int63 = zeroIsMaxDateTimeField10.get((long) (byte) 100);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 60 + "'", int12 == 60);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 60 + "'", int25 == 60);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 68253 + "'", int28 == 68253);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localTime32);
//        org.junit.Assert.assertNotNull(gJChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 49L + "'", long41 == 49L);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertNotNull(intArray52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 60 + "'", int53 == 60);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "12" + "'", str56.equals("12"));
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 32L + "'", long61 == 32L);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 60 + "'", int63 == 60);
//    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.monthOfYear();
//        int int15 = mutableDateTime13.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = mutableDateTime13.toDateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
//        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
//        int int20 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime19);
//        long long22 = zeroIsMaxDateTimeField10.roundHalfFloor(100L);
//        long long24 = zeroIsMaxDateTimeField10.roundHalfFloor((long) (short) -1);
//        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.monthOfYear();
//        int int27 = mutableDateTime25.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTime dateTime29 = mutableDateTime25.toDateTime(dateTimeZone28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField34 = gJChronology33.weekyears();
//        org.joda.time.DurationField durationField35 = gJChronology33.millis();
//        org.joda.time.DateTimeField dateTimeField36 = gJChronology33.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property38 = mutableDateTime37.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType39, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField36, dateTimeFieldType39);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException45 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType39, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType39, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder30.appendFixedDecimal(dateTimeFieldType39, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property52 = mutableDateTime25.property(dateTimeFieldType39);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType39, (java.lang.Number) 0.0f, "59");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType39, (int) '#');
//        int int58 = offsetDateTimeField57.getMaximumValue();
//        long long60 = offsetDateTimeField57.roundFloor((long) 19689);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 68253 + "'", int15 == 68253);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 60 + "'", int20 == 60);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 68253 + "'", int27 == 68253);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 95 + "'", int58 == 95);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 19000L + "'", long60 == 19000L);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(19688, (-1), (int) (short) 100, 2000, 4, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.withYear(19666);
//        mutableDateTime1.setDate((org.joda.time.ReadableInstant) dateTime3);
//        java.lang.String str7 = dateTime3.toString();
//        org.joda.time.DateTime.Property property8 = dateTime3.yearOfEra();
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-11T18:57:34.240-07:00" + "'", str7.equals("2019-06-11T18:57:34.240-07:00"));
//        org.junit.Assert.assertNotNull(property8);
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
//        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
//        long long10 = skipUndoDateTimeField4.roundFloor((long) (short) 1);
//        int int11 = skipUndoDateTimeField4.getMaximumValue();
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.monthOfYear();
//        int int14 = mutableDateTime12.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = mutableDateTime12.toDateTime(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = dateTime16.toDateTime();
//        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
//        int int19 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime18);
//        long long21 = skipUndoDateTimeField4.remainder((long) (-1));
//        java.lang.String str22 = skipUndoDateTimeField4.toString();
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 68254 + "'", int14 == 68254);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 31507199999L + "'", long21 == 31507199999L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "DateTimeField[yearOfCentury]" + "'", str22.equals("DateTimeField[yearOfCentury]"));
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 19700);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.add(19674);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime9);
        boolean boolean12 = mutableDateTime9.isAfter(59052L);
        mutableDateTime9.setSecondOfDay((int) ' ');
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime9.millisOfSecond();
        mutableDateTime9.addSeconds(0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property15);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        mutableDateTime0.addWeeks(19669);
//        mutableDateTime0.addSeconds(19669);
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
//        int int9 = mutableDateTime7.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = mutableDateTime7.toDateTime(dateTimeZone10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField16 = gJChronology15.weekyears();
//        org.joda.time.DurationField durationField17 = gJChronology15.millis();
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology15.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField18, dateTimeFieldType21);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder12.appendFixedDecimal(dateTimeFieldType21, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property34 = mutableDateTime7.property(dateTimeFieldType21);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 0.0f, "59");
//        int int38 = mutableDateTime0.get(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68254 + "'", int2 == 68254);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 68254 + "'", int9 == 68254);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 5 + "'", int38 == 5);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths(1);
//        int int4 = dateTime3.getYearOfCentury();
//        org.joda.time.DateTime dateTime6 = dateTime3.minusMillis((int) (short) 1);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, dateTimeField11);
//        org.joda.time.DateTimeField dateTimeField13 = skipUndoDateTimeField12.getWrappedField();
//        long long16 = skipUndoDateTimeField12.getDifferenceAsLong(1560342467589L, (long) ' ');
//        long long18 = skipUndoDateTimeField12.roundFloor((long) (short) 1);
//        int int19 = skipUndoDateTimeField12.getMaximumValue();
//        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.monthOfYear();
//        int int22 = mutableDateTime20.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = mutableDateTime20.toDateTime(dateTimeZone23);
//        org.joda.time.DateTime dateTime25 = dateTime24.toDateTime();
//        org.joda.time.LocalTime localTime26 = dateTime25.toLocalTime();
//        int int27 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localTime26);
//        java.util.Locale locale28 = null;
//        int int29 = skipUndoDateTimeField12.getMaximumTextLength(locale28);
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField33 = gJChronology32.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology32.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology32);
//        mutableDateTime35.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        mutableDateTime35.setZoneRetainFields(dateTimeZone38);
//        int int40 = mutableDateTime35.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone41 = mutableDateTime35.getZone();
//        long long44 = dateTimeZone41.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField48 = gregorianChronology47.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder49 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone52 = dateTimeZoneBuilder49.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology53 = gregorianChronology47.withZone(dateTimeZone52);
//        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField56 = gJChronology55.hourOfHalfday();
//        java.util.Locale locale57 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket58 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology55, locale57);
//        java.util.Locale locale59 = dateTimeParserBucket58.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket61 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology53, locale59, (java.lang.Integer) 19671);
//        java.lang.String str62 = dateTimeZone41.getShortName((long) 2000, locale59);
//        java.lang.String str63 = skipUndoDateTimeField12.getAsText(19680, locale59);
//        try {
//            java.lang.String str64 = dateTime3.toString("org.joda.time.IllegalFieldValueException: Value 0.0 for monthOfYear is not supported: 59", locale59);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 49L + "'", long16 == 49L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31507200000L) + "'", long18 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 68254 + "'", int22 == 68254);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 19684L + "'", long44 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(chronology53);
//        org.junit.Assert.assertNotNull(gJChronology55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(locale59);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "PST" + "'", str62.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "19680" + "'", str63.equals("19680"));
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
//        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int[] intArray17 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray19 = skipUndoDateTimeField4.add(readablePartial9, 19670, intArray17, 0);
//        java.lang.String str20 = skipUndoDateTimeField4.toString();
//        long long22 = skipUndoDateTimeField4.roundHalfFloor(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology26 = buddhistChronology25.withUTC();
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField29 = gJChronology28.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology28.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology28);
//        mutableDateTime31.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        mutableDateTime31.setZoneRetainFields(dateTimeZone34);
//        int int36 = mutableDateTime31.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone37 = mutableDateTime31.getZone();
//        long long40 = dateTimeZone37.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField44 = gregorianChronology43.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder45 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone48 = dateTimeZoneBuilder45.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology49 = gregorianChronology43.withZone(dateTimeZone48);
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.hourOfHalfday();
//        java.util.Locale locale53 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket54 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology51, locale53);
//        java.util.Locale locale55 = dateTimeParserBucket54.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket57 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology49, locale55, (java.lang.Integer) 19671);
//        java.lang.String str58 = dateTimeZone37.getShortName((long) 2000, locale55);
//        org.joda.time.chrono.ZonedChronology zonedChronology59 = org.joda.time.chrono.ZonedChronology.getInstance(chronology26, dateTimeZone37);
//        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology59);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.Chronology chronology62 = dateTimeFormatter61.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property64 = mutableDateTime63.monthOfYear();
//        java.lang.Object obj65 = mutableDateTime63.clone();
//        mutableDateTime63.addMinutes(19669);
//        int int70 = dateTimeFormatter61.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime63, "", 19670);
//        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField73 = gregorianChronology72.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder74 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone77 = dateTimeZoneBuilder74.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology78 = gregorianChronology72.withZone(dateTimeZone77);
//        org.joda.time.chrono.GJChronology gJChronology80 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField81 = gJChronology80.hourOfHalfday();
//        java.util.Locale locale82 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket83 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology80, locale82);
//        java.util.Locale locale84 = dateTimeParserBucket83.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket86 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology78, locale84, (java.lang.Integer) 19671);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter87 = dateTimeFormatter61.withLocale(locale84);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket88 = new org.joda.time.format.DateTimeParserBucket((long) 19670, (org.joda.time.Chronology) zonedChronology59, locale84);
//        java.lang.String str89 = skipUndoDateTimeField4.getAsShortText(1562934500444L, locale84);
//        boolean boolean90 = skipUndoDateTimeField4.isSupported();
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[yearOfCentury]" + "'", str20.equals("DateTimeField[yearOfCentury]"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28800000L + "'", long22 == 28800000L);
//        org.junit.Assert.assertNotNull(buddhistChronology25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 19684L + "'", long40 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(locale55);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "PST" + "'", str58.equals("PST"));
//        org.junit.Assert.assertNotNull(zonedChronology59);
//        org.junit.Assert.assertNotNull(chronology60);
//        org.junit.Assert.assertNotNull(dateTimeFormatter61);
//        org.junit.Assert.assertNull(chronology62);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertNotNull(obj65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-19671) + "'", int70 == (-19671));
//        org.junit.Assert.assertNotNull(gregorianChronology72);
//        org.junit.Assert.assertNotNull(durationField73);
//        org.junit.Assert.assertNotNull(dateTimeZone77);
//        org.junit.Assert.assertNotNull(chronology78);
//        org.junit.Assert.assertNotNull(gJChronology80);
//        org.junit.Assert.assertNotNull(dateTimeField81);
//        org.junit.Assert.assertNotNull(locale84);
//        org.junit.Assert.assertNotNull(dateTimeFormatter87);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "19" + "'", str89.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
//        mutableDateTime4.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
//        int int9 = mutableDateTime4.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = mutableDateTime4.getZone();
//        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime4.toMutableDateTimeISO();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfDay(19);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendPattern("");
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField18 = gJChronology17.weekyears();
//        org.joda.time.DurationField durationField19 = gJChronology17.millis();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology17.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField20, dateTimeFieldType23);
//        org.joda.time.DurationField durationField28 = zeroIsMaxDateTimeField27.getDurationField();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = zeroIsMaxDateTimeField27.getAsText((long) (short) -1, locale30);
//        long long33 = zeroIsMaxDateTimeField27.roundCeiling((-31507200000L));
//        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.monthOfYear();
//        int int36 = mutableDateTime34.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTime dateTime38 = mutableDateTime34.toDateTime(dateTimeZone37);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder39.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField43 = gJChronology42.weekyears();
//        org.joda.time.DurationField durationField44 = gJChronology42.millis();
//        org.joda.time.DateTimeField dateTimeField45 = gJChronology42.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property47 = mutableDateTime46.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = property47.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException51 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType48, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField52 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField45, dateTimeFieldType48);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException54 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType48, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType48, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder39.appendFixedDecimal(dateTimeFieldType48, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property61 = mutableDateTime34.property(dateTimeFieldType48);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField27, dateTimeFieldType48, 4, (int) ' ', 19666);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType48);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder67.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology70 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField71 = gJChronology70.weekyears();
//        org.joda.time.DurationField durationField72 = gJChronology70.millis();
//        org.joda.time.DateTimeField dateTimeField73 = gJChronology70.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime74 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property75 = mutableDateTime74.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = property75.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException79 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType76, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField80 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField73, dateTimeFieldType76);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException82 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType76, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType76, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder88 = dateTimeFormatterBuilder67.appendFixedDecimal(dateTimeFieldType76, (int) (short) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder89 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType76);
//        org.joda.time.MutableDateTime.Property property90 = mutableDateTime4.property(dateTimeFieldType76);
//        mutableDateTime4.addMillis((-28800000));
//        org.joda.time.MutableDateTime.Property property93 = mutableDateTime4.monthOfYear();
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "59" + "'", str31.equals("59"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-31507200000L) + "'", long33 == (-31507200000L));
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 68255 + "'", int36 == 68255);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(dateTimeFieldType48);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//        org.junit.Assert.assertNotNull(gJChronology70);
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertNotNull(durationField72);
//        org.junit.Assert.assertNotNull(dateTimeField73);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNotNull(dateTimeFieldType76);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder88);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder89);
//        org.junit.Assert.assertNotNull(property90);
//        org.junit.Assert.assertNotNull(property93);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gJChronology0.add(readablePeriod4, (long) 100, (-18059));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "2019-07-12T05");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gJChronology0.add(readablePeriod5, (long) 12, (-2));
        org.joda.time.DurationField durationField9 = gJChronology0.weekyears();
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        int int11 = mutableDateTime10.getYear();
        mutableDateTime10.addHours(30);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.plusYears((int) (short) 0);
//        org.joda.time.DateTime.Property property7 = dateTime4.weekOfWeekyear();
//        org.joda.time.Instant instant8 = dateTime4.toInstant();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68255 + "'", int2 == 68255);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(instant8);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
        int int9 = mutableDateTime4.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = mutableDateTime4.getZone();
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now(dateTimeZone10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology2);
//        mutableDateTime5.addMonths((-1));
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.secondOfDay();
//        mutableDateTime5.addYears((int) '#');
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology12.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology12);
//        mutableDateTime15.addMonths((-1));
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime15.secondOfDay();
//        boolean boolean19 = mutableDateTime5.isEqual((org.joda.time.ReadableInstant) mutableDateTime15);
//        org.joda.time.MutableDateTime.Property property20 = mutableDateTime15.minuteOfHour();
//        org.joda.time.ReadableInstant readableInstant21 = null;
//        mutableDateTime15.setDate(readableInstant21);
//        java.lang.String str23 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019162T155959.999-0700" + "'", str23.equals("2019162T155959.999-0700"));
//    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.minus(readablePeriod3);
//        java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology7);
//        mutableDateTime10.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        mutableDateTime10.setZoneRetainFields(dateTimeZone13);
//        int int15 = mutableDateTime10.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = mutableDateTime10.getZone();
//        org.joda.time.MutableDateTime mutableDateTime17 = dateTime1.toMutableDateTime(dateTimeZone16);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.millisOfSecond();
//        org.joda.time.MutableDateTime.Property property19 = mutableDateTime17.millisOfSecond();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-11T18" + "'", str5.equals("2019-06-11T18"));
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.monthOfYear();
//        int int15 = mutableDateTime13.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = mutableDateTime13.toDateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
//        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
//        int int20 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime19);
//        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.monthOfYear();
//        int int23 = mutableDateTime21.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = mutableDateTime21.toDateTime(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = dateTime25.toDateTime();
//        org.joda.time.LocalTime localTime27 = dateTime26.toLocalTime();
//        org.joda.time.Chronology chronology28 = null;
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField31 = gJChronology29.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField(chronology28, dateTimeField31);
//        org.joda.time.DateTimeField dateTimeField33 = skipUndoDateTimeField32.getWrappedField();
//        long long36 = skipUndoDateTimeField32.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        int[] intArray45 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray47 = skipUndoDateTimeField32.add(readablePartial37, 19670, intArray45, 0);
//        int int48 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime27, intArray47);
//        org.joda.time.DurationField durationField49 = zeroIsMaxDateTimeField10.getLeapDurationField();
//        long long52 = zeroIsMaxDateTimeField10.getDifferenceAsLong((long) 19670, 100L);
//        int int53 = zeroIsMaxDateTimeField10.getMinimumValue();
//        boolean boolean55 = zeroIsMaxDateTimeField10.isLeap((long) 19679);
//        int int58 = zeroIsMaxDateTimeField10.getDifference((long) 0, 19691L);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField59 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10);
//        int int60 = zeroIsMaxDateTimeField10.getMaximumValue();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 68256 + "'", int15 == 68256);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 60 + "'", int20 == 60);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 68256 + "'", int23 == 68256);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(localTime27);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 49L + "'", long36 == 49L);
//        org.junit.Assert.assertNotNull(intArray45);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 60 + "'", int48 == 60);
//        org.junit.Assert.assertNull(durationField49);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 19L + "'", long52 == 19L);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-19) + "'", int58 == (-19));
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 60 + "'", int60 == 60);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology3);
//        mutableDateTime6.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        mutableDateTime6.setZoneRetainFields(dateTimeZone9);
//        int int11 = mutableDateTime6.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = mutableDateTime6.getZone();
//        long long15 = dateTimeZone12.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField19 = gregorianChronology18.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone23 = dateTimeZoneBuilder20.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology24 = gregorianChronology18.withZone(dateTimeZone23);
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.hourOfHalfday();
//        java.util.Locale locale28 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology26, locale28);
//        java.util.Locale locale30 = dateTimeParserBucket29.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket32 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology24, locale30, (java.lang.Integer) 19671);
//        java.lang.String str33 = dateTimeZone12.getShortName((long) 2000, locale30);
//        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField35 = zonedChronology34.minuteOfDay();
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField38 = gJChronology37.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField39 = gJChronology37.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology37);
//        mutableDateTime40.addMonths((-1));
//        org.joda.time.MutableDateTime.Property property43 = mutableDateTime40.secondOfDay();
//        mutableDateTime40.addYears((int) '#');
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField48 = gJChronology47.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField49 = gJChronology47.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime50 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology47);
//        mutableDateTime50.addMonths((-1));
//        org.joda.time.MutableDateTime.Property property53 = mutableDateTime50.secondOfDay();
//        boolean boolean54 = mutableDateTime40.isEqual((org.joda.time.ReadableInstant) mutableDateTime50);
//        org.joda.time.MutableDateTime.Property property55 = mutableDateTime50.minuteOfHour();
//        boolean boolean56 = zonedChronology34.equals((java.lang.Object) property55);
//        try {
//            long long64 = zonedChronology34.getDateTimeMillis(66, 19148, 12, 5929, (int) (short) 1, 19700, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19148 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 19684L + "'", long15 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(locale30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PST" + "'", str33.equals("PST"));
//        org.junit.Assert.assertNotNull(zonedChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendClockhourOfDay(19667);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendSecondOfMinute(27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder25.appendMonthOfYearShortText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap27 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendTimeZoneName(strMap27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatterBuilder26.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(strMap27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray17 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray19 = skipUndoDateTimeField4.add(readablePartial9, 19670, intArray17, 0);
        java.lang.String str20 = skipUndoDateTimeField4.toString();
        long long22 = skipUndoDateTimeField4.roundHalfFloor(0L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, 52);
        long long27 = skipUndoDateTimeField4.addWrapField(192467687L, 59);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[yearOfCentury]" + "'", str20.equals("DateTimeField[yearOfCentury]"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28800000L + "'", long22 == 28800000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1293647532313L) + "'", long27 == (-1293647532313L));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology2);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) 100, (org.joda.time.Chronology) gJChronology2);
        boolean boolean7 = mutableDateTime6.isEqualNow();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime6.dayOfYear();
        boolean boolean10 = mutableDateTime6.isEqual((long) 19675);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime6.minuteOfHour();
        java.lang.String str12 = property11.getAsText();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
//        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
//        int int19 = mutableDateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
//        org.joda.time.DurationField durationField27 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
//        long long51 = zeroIsMaxDateTimeField10.set((long) 19673, 12);
//        java.util.Locale locale53 = null;
//        java.lang.String str54 = zeroIsMaxDateTimeField10.getAsText((-1), locale53);
//        long long56 = zeroIsMaxDateTimeField10.roundHalfFloor((long) 19);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 68256 + "'", int19 == 68256);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 12673L + "'", long51 == 12673L);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "-1" + "'", str54.equals("-1"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 2000);
        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField5 = gJChronology4.weekyears();
        org.joda.time.DurationField durationField6 = gJChronology4.millis();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField14 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, "hi!");
        boolean boolean17 = mutableDateTime2.isSupported(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "16:00" + "'", str3.equals("16:00"));
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.monthOfYear();
//        int int15 = mutableDateTime13.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = mutableDateTime13.toDateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
//        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
//        int int20 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime19);
//        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.monthOfYear();
//        int int23 = mutableDateTime21.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = mutableDateTime21.toDateTime(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = dateTime25.toDateTime();
//        org.joda.time.LocalTime localTime27 = dateTime26.toLocalTime();
//        org.joda.time.Chronology chronology28 = null;
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField31 = gJChronology29.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField(chronology28, dateTimeField31);
//        org.joda.time.DateTimeField dateTimeField33 = skipUndoDateTimeField32.getWrappedField();
//        long long36 = skipUndoDateTimeField32.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        int[] intArray45 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray47 = skipUndoDateTimeField32.add(readablePartial37, 19670, intArray45, 0);
//        int int48 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime27, intArray47);
//        org.joda.time.DurationField durationField49 = zeroIsMaxDateTimeField10.getLeapDurationField();
//        long long52 = zeroIsMaxDateTimeField10.getDifferenceAsLong((long) 19670, 100L);
//        long long54 = zeroIsMaxDateTimeField10.roundFloor(12L);
//        long long57 = zeroIsMaxDateTimeField10.addWrapField(63052141542L, (int) (byte) 10);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 68257 + "'", int15 == 68257);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 60 + "'", int20 == 60);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 68257 + "'", int23 == 68257);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(localTime27);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 49L + "'", long36 == 49L);
//        org.junit.Assert.assertNotNull(intArray45);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 60 + "'", int48 == 60);
//        org.junit.Assert.assertNull(durationField49);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 19L + "'", long52 == 19L);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 63052151542L + "'", long57 == 63052151542L);
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
//        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
//        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendClockhourOfDay(19667);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendClockhourOfHalfday((int) (short) 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder23.appendYear(0, (int) (short) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendMinuteOfDay(19);
//        org.joda.time.format.DateTimePrinter dateTimePrinter32 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter33.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser35 = dateTimeFormatter34.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter36.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser38 = dateTimeFormatter37.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter39.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser41 = dateTimeFormatter40.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter42.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser44 = dateTimeFormatter43.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter45.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser47 = dateTimeFormatter46.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray48 = new org.joda.time.format.DateTimeParser[] { dateTimeParser35, dateTimeParser38, dateTimeParser41, dateTimeParser44, dateTimeParser47 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder29.append(dateTimePrinter32, dateTimeParserArray48);
//        boolean boolean50 = dateTimeFormatterBuilder29.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder29.appendClockhourOfDay(19667);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.appendSecondOfMinute(27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder54.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property58 = dateTime57.minuteOfDay();
//        org.joda.time.ReadablePeriod readablePeriod59 = null;
//        org.joda.time.DateTime dateTime60 = dateTime57.minus(readablePeriod59);
//        java.lang.String str61 = dateTimeFormatter56.print((org.joda.time.ReadableInstant) dateTime57);
//        org.joda.time.format.DateTimePrinter dateTimePrinter62 = dateTimeFormatter56.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter63 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter64 = dateTimeFormatter63.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser65 = dateTimeFormatter64.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter66 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter67 = dateTimeFormatter66.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser68 = dateTimeFormatter67.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter69 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = dateTimeFormatter69.withZoneUTC();
//        org.joda.time.format.DateTimeParser dateTimeParser71 = dateTimeFormatter70.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray72 = new org.joda.time.format.DateTimeParser[] { dateTimeParser65, dateTimeParser68, dateTimeParser71 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder55.append(dateTimePrinter62, dateTimeParserArray72);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder23.append(dateTimePrinter62);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder74.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder74.appendWeekOfWeekyear((int) (byte) 100);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeParser6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeParser9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeParser12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeParser15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeParser18);
//        org.junit.Assert.assertNotNull(dateTimeParserArray19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(dateTimeParser35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertNotNull(dateTimeParser38);
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertNotNull(dateTimeParser41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertNotNull(dateTimeFormatter43);
//        org.junit.Assert.assertNotNull(dateTimeParser44);
//        org.junit.Assert.assertNotNull(dateTimeFormatter45);
//        org.junit.Assert.assertNotNull(dateTimeFormatter46);
//        org.junit.Assert.assertNotNull(dateTimeParser47);
//        org.junit.Assert.assertNotNull(dateTimeParserArray48);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
//        org.junit.Assert.assertNotNull(dateTimeFormatter56);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "2019-06-11T18" + "'", str61.equals("2019-06-11T18"));
//        org.junit.Assert.assertNotNull(dateTimePrinter62);
//        org.junit.Assert.assertNotNull(dateTimeFormatter63);
//        org.junit.Assert.assertNotNull(dateTimeFormatter64);
//        org.junit.Assert.assertNotNull(dateTimeParser65);
//        org.junit.Assert.assertNotNull(dateTimeFormatter66);
//        org.junit.Assert.assertNotNull(dateTimeFormatter67);
//        org.junit.Assert.assertNotNull(dateTimeParser68);
//        org.junit.Assert.assertNotNull(dateTimeFormatter69);
//        org.junit.Assert.assertNotNull(dateTimeFormatter70);
//        org.junit.Assert.assertNotNull(dateTimeParser71);
//        org.junit.Assert.assertNotNull(dateTimeParserArray72);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray17 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray19 = skipUndoDateTimeField4.add(readablePartial9, 19670, intArray17, 0);
        java.lang.String str20 = skipUndoDateTimeField4.toString();
        long long22 = skipUndoDateTimeField4.roundHalfFloor(0L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField4.getAsShortText(4038000, locale24);
        int int26 = skipUndoDateTimeField4.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[yearOfCentury]" + "'", str20.equals("DateTimeField[yearOfCentury]"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28800000L + "'", long22 == 28800000L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "4038000" + "'", str25.equals("4038000"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField5);
//        org.joda.time.DateTimeField dateTimeField7 = skipUndoDateTimeField6.getWrappedField();
//        long long10 = skipUndoDateTimeField6.getDifferenceAsLong(1560342467589L, (long) ' ');
//        long long12 = skipUndoDateTimeField6.roundFloor((long) (short) 1);
//        int int13 = skipUndoDateTimeField6.getMaximumValue();
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.monthOfYear();
//        int int16 = mutableDateTime14.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = mutableDateTime14.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime18.toDateTime();
//        org.joda.time.LocalTime localTime20 = dateTime19.toLocalTime();
//        int int21 = skipUndoDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) localTime20);
//        java.util.Locale locale22 = null;
//        int int23 = skipUndoDateTimeField6.getMaximumTextLength(locale22);
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology26.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology26);
//        mutableDateTime29.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        mutableDateTime29.setZoneRetainFields(dateTimeZone32);
//        int int34 = mutableDateTime29.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone35 = mutableDateTime29.getZone();
//        long long38 = dateTimeZone35.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField42 = gregorianChronology41.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder43 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone46 = dateTimeZoneBuilder43.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology47 = gregorianChronology41.withZone(dateTimeZone46);
//        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField50 = gJChronology49.hourOfHalfday();
//        java.util.Locale locale51 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket52 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology49, locale51);
//        java.util.Locale locale53 = dateTimeParserBucket52.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket55 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology47, locale53, (java.lang.Integer) 19671);
//        java.lang.String str56 = dateTimeZone35.getShortName((long) 2000, locale53);
//        java.lang.String str57 = skipUndoDateTimeField6.getAsText(19680, locale53);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket60 = new org.joda.time.format.DateTimeParserBucket((-210866673600000L), chronology1, locale53, (java.lang.Integer) 1, 19700);
//        dateTimeParserBucket60.setOffset((java.lang.Integer) 19683);
//        long long64 = dateTimeParserBucket60.computeMillis(false);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 49L + "'", long10 == 49L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31507200000L) + "'", long12 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 68257 + "'", int16 == 68257);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 19684L + "'", long38 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(chronology47);
//        org.junit.Assert.assertNotNull(gJChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(locale53);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "PST" + "'", str56.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "19680" + "'", str57.equals("19680"));
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-210866673619683L) + "'", long64 == (-210866673619683L));
//    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.monthOfYear();
//        int int4 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusMonths(1);
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("monthOfYear", false);
//        org.joda.time.DateTime dateTime13 = dateTime8.withZone(dateTimeZone12);
//        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) mutableDateTime2, (org.joda.time.ReadableDateTime) dateTime13);
//        try {
//            long long20 = limitChronology14.getDateTimeMillis((long) 19700, 19670, (-28800000), 19680, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 2019-06-11T18:57:37.769-07:00 (GJChronology[America/Los_Angeles])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 68257 + "'", int4 == 68257);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(limitChronology14);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology1, locale3);
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField6 = gJChronology1.months();
        org.joda.time.DurationField durationField7 = gJChronology1.hours();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.era();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test259");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
//        org.joda.time.DurationField durationField4 = gJChronology1.eras();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.monthOfYear();
//        int int7 = mutableDateTime5.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = mutableDateTime5.toDateTime(dateTimeZone8);
//        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
//        long long12 = gJChronology1.set((org.joda.time.ReadablePartial) localTime10, (long) 19690);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 19681, (org.joda.time.Chronology) gJChronology1);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 68257 + "'", int7 == 68257);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localTime10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10657842L + "'", long12 == 10657842L);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.add(19674);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime9);
        boolean boolean12 = mutableDateTime9.isAfter(59052L);
        mutableDateTime9.setSecondOfDay((int) ' ');
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime9.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            org.joda.time.MutableDateTime.Property property17 = mutableDateTime9.property(dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((-19666), 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-19635) + "'", int2 == (-19635));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder20.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
//        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int[] intArray17 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray19 = skipUndoDateTimeField4.add(readablePartial9, 19670, intArray17, 0);
//        java.lang.String str20 = skipUndoDateTimeField4.toString();
//        long long22 = skipUndoDateTimeField4.roundHalfFloor(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology26 = buddhistChronology25.withUTC();
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField29 = gJChronology28.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology28.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology28);
//        mutableDateTime31.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        mutableDateTime31.setZoneRetainFields(dateTimeZone34);
//        int int36 = mutableDateTime31.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone37 = mutableDateTime31.getZone();
//        long long40 = dateTimeZone37.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField44 = gregorianChronology43.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder45 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone48 = dateTimeZoneBuilder45.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology49 = gregorianChronology43.withZone(dateTimeZone48);
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.hourOfHalfday();
//        java.util.Locale locale53 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket54 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology51, locale53);
//        java.util.Locale locale55 = dateTimeParserBucket54.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket57 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology49, locale55, (java.lang.Integer) 19671);
//        java.lang.String str58 = dateTimeZone37.getShortName((long) 2000, locale55);
//        org.joda.time.chrono.ZonedChronology zonedChronology59 = org.joda.time.chrono.ZonedChronology.getInstance(chronology26, dateTimeZone37);
//        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology59);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.Chronology chronology62 = dateTimeFormatter61.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property64 = mutableDateTime63.monthOfYear();
//        java.lang.Object obj65 = mutableDateTime63.clone();
//        mutableDateTime63.addMinutes(19669);
//        int int70 = dateTimeFormatter61.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime63, "", 19670);
//        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField73 = gregorianChronology72.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder74 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone77 = dateTimeZoneBuilder74.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology78 = gregorianChronology72.withZone(dateTimeZone77);
//        org.joda.time.chrono.GJChronology gJChronology80 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField81 = gJChronology80.hourOfHalfday();
//        java.util.Locale locale82 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket83 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology80, locale82);
//        java.util.Locale locale84 = dateTimeParserBucket83.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket86 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology78, locale84, (java.lang.Integer) 19671);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter87 = dateTimeFormatter61.withLocale(locale84);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket88 = new org.joda.time.format.DateTimeParserBucket((long) 19670, (org.joda.time.Chronology) zonedChronology59, locale84);
//        java.lang.String str89 = skipUndoDateTimeField4.getAsShortText(1562934500444L, locale84);
//        java.lang.Class<?> wildcardClass90 = skipUndoDateTimeField4.getClass();
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[yearOfCentury]" + "'", str20.equals("DateTimeField[yearOfCentury]"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28800000L + "'", long22 == 28800000L);
//        org.junit.Assert.assertNotNull(buddhistChronology25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 19684L + "'", long40 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(locale55);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "PST" + "'", str58.equals("PST"));
//        org.junit.Assert.assertNotNull(zonedChronology59);
//        org.junit.Assert.assertNotNull(chronology60);
//        org.junit.Assert.assertNotNull(dateTimeFormatter61);
//        org.junit.Assert.assertNull(chronology62);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertNotNull(obj65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-19671) + "'", int70 == (-19671));
//        org.junit.Assert.assertNotNull(gregorianChronology72);
//        org.junit.Assert.assertNotNull(durationField73);
//        org.junit.Assert.assertNotNull(dateTimeZone77);
//        org.junit.Assert.assertNotNull(chronology78);
//        org.junit.Assert.assertNotNull(gJChronology80);
//        org.junit.Assert.assertNotNull(dateTimeField81);
//        org.junit.Assert.assertNotNull(locale84);
//        org.junit.Assert.assertNotNull(dateTimeFormatter87);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "19" + "'", str89.equals("19"));
//        org.junit.Assert.assertNotNull(wildcardClass90);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime4.dayOfWeek();
        org.joda.time.ReadableDuration readableDuration10 = null;
        mutableDateTime4.add(readableDuration10, 0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
//        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
//        int int19 = mutableDateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
//        org.joda.time.DurationField durationField27 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology50.yearOfCentury();
//        java.util.Locale locale53 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology50, locale53, (java.lang.Integer) (-2), 19675);
//        java.lang.Object obj57 = dateTimeParserBucket56.saveState();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder58.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField62 = gJChronology61.weekyears();
//        org.joda.time.DurationField durationField63 = gJChronology61.millis();
//        org.joda.time.DateTimeField dateTimeField64 = gJChronology61.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime65 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property66 = mutableDateTime65.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property66.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField71 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField64, dateTimeFieldType67);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException77 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder58.appendFixedDecimal(dateTimeFieldType67, (int) (short) 100);
//        dateTimeParserBucket56.saveField(dateTimeFieldType67, 0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType67, 19683);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField84 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField83);
//        long long86 = remainderDateTimeField84.roundFloor(192483574L);
//        long long88 = remainderDateTimeField84.roundHalfCeiling(620599017602000L);
//        long long91 = remainderDateTimeField84.addWrapField((long) 19693, 10);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 68259 + "'", int19 == 68259);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(obj57);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
//        org.junit.Assert.assertNotNull(gJChronology61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(durationField63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(property66);
//        org.junit.Assert.assertNotNull(dateTimeFieldType67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 192483000L + "'", long86 == 192483000L);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 620599017602000L + "'", long88 == 620599017602000L);
//        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 29693L + "'", long91 == 29693L);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        java.lang.String str2 = property1.getName();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.add((long) 'a');
        org.joda.time.Interval interval5 = property1.toInterval();
        org.joda.time.MutableDateTime mutableDateTime6 = property1.roundHalfEven();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "monthOfYear" + "'", str2.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
        java.util.Locale locale2 = null;
        int int3 = property1.getMaximumShortTextLength(locale2);
        org.joda.time.DateTime dateTime5 = property1.setCopy((int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTime5.getZone();
        boolean boolean8 = dateTimeZone6.isStandardOffset(1562934500000L);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (-192461));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology1, locale3);
        java.util.Locale locale5 = dateTimeParserBucket4.getLocale();
        dateTimeParserBucket4.setPivotYear((java.lang.Integer) 163);
        long long10 = dateTimeParserBucket4.computeMillis(false, "2019-07-12T05");
        java.lang.Object obj11 = dateTimeParserBucket4.saveState();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(locale5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertNotNull(obj11);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
//        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
//        int int19 = mutableDateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
//        org.joda.time.DurationField durationField27 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology50.yearOfCentury();
//        java.util.Locale locale53 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology50, locale53, (java.lang.Integer) (-2), 19675);
//        java.lang.Object obj57 = dateTimeParserBucket56.saveState();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder58.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField62 = gJChronology61.weekyears();
//        org.joda.time.DurationField durationField63 = gJChronology61.millis();
//        org.joda.time.DateTimeField dateTimeField64 = gJChronology61.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime65 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property66 = mutableDateTime65.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property66.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField71 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField64, dateTimeFieldType67);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException77 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder58.appendFixedDecimal(dateTimeFieldType67, (int) (short) 100);
//        dateTimeParserBucket56.saveField(dateTimeFieldType67, 0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType67, 19683);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField84 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField83);
//        long long86 = remainderDateTimeField84.roundFloor(192483574L);
//        long long88 = remainderDateTimeField84.roundFloor((long) 19686);
//        int int89 = remainderDateTimeField84.getDivisor();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 68259 + "'", int19 == 68259);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(obj57);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
//        org.junit.Assert.assertNotNull(gJChronology61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(durationField63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(property66);
//        org.junit.Assert.assertNotNull(dateTimeFieldType67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 192483000L + "'", long86 == 192483000L);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 19000L + "'", long88 == 19000L);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 19683 + "'", int89 == 19683);
//    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField3 = gregorianChronology2.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeZoneBuilder4.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone7);
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.hourOfHalfday();
//        java.util.Locale locale12 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology10, locale12);
//        java.util.Locale locale14 = dateTimeParserBucket13.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology8, locale14, (java.lang.Integer) 19671);
//        java.lang.String str19 = defaultNameProvider0.getShortName(locale14, "2019-06-12T05", "2019-06-12T05");
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology21);
//        mutableDateTime24.setSecondOfDay((int) (short) 100);
//        org.joda.time.MutableDateTime.Property property27 = mutableDateTime24.dayOfMonth();
//        org.joda.time.MutableDateTime mutableDateTime29 = property27.add(19674);
//        org.joda.time.MutableDateTime mutableDateTime30 = property27.roundHalfFloor();
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField33 = gregorianChronology32.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder34 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone37 = dateTimeZoneBuilder34.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology38 = gregorianChronology32.withZone(dateTimeZone37);
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.hourOfHalfday();
//        java.util.Locale locale42 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket43 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology40, locale42);
//        java.util.Locale locale44 = dateTimeParserBucket43.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket46 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology38, locale44, (java.lang.Integer) 19671);
//        java.lang.String str47 = property27.getAsText(locale44);
//        java.lang.String str50 = defaultNameProvider0.getName(locale44, "1969-12-18T16:12:02.000-08:00", "DateTimeField[monthOfYear]");
//        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int53 = gregorianChronology52.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone54 = gregorianChronology52.getZone();
//        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology56 = gregorianChronology52.withZone(dateTimeZone55);
//        java.lang.String str57 = gregorianChronology52.toString();
//        org.joda.time.Chronology chronology58 = null;
//        org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField60 = gJChronology59.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField61 = gJChronology59.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField62 = new org.joda.time.field.SkipUndoDateTimeField(chronology58, dateTimeField61);
//        org.joda.time.DateTimeField dateTimeField63 = skipUndoDateTimeField62.getWrappedField();
//        long long66 = skipUndoDateTimeField62.getDifferenceAsLong(1560342467589L, (long) ' ');
//        long long68 = skipUndoDateTimeField62.roundFloor((long) (short) 1);
//        int int69 = skipUndoDateTimeField62.getMaximumValue();
//        org.joda.time.MutableDateTime mutableDateTime70 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property71 = mutableDateTime70.monthOfYear();
//        int int72 = mutableDateTime70.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone73 = null;
//        org.joda.time.DateTime dateTime74 = mutableDateTime70.toDateTime(dateTimeZone73);
//        org.joda.time.DateTime dateTime75 = dateTime74.toDateTime();
//        org.joda.time.LocalTime localTime76 = dateTime75.toLocalTime();
//        int int77 = skipUndoDateTimeField62.getMinimumValue((org.joda.time.ReadablePartial) localTime76);
//        org.joda.time.chrono.GJChronology gJChronology80 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField81 = gJChronology80.hourOfHalfday();
//        java.util.Locale locale82 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket83 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology80, locale82);
//        java.util.Locale locale84 = dateTimeParserBucket83.getLocale();
//        java.lang.String str85 = skipUndoDateTimeField62.getAsText((-18059), locale84);
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket88 = new org.joda.time.format.DateTimeParserBucket((long) 12885, (org.joda.time.Chronology) gregorianChronology52, locale84, (java.lang.Integer) 19683, 19);
//        java.lang.String str91 = defaultNameProvider0.getName(locale84, "2019-W28", "Pacific Standard Time");
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(locale14);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(locale44);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "12" + "'", str47.equals("12"));
//        org.junit.Assert.assertNull(str50);
//        org.junit.Assert.assertNotNull(gregorianChronology52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 4 + "'", int53 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(chronology56);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str57.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(gJChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 49L + "'", long66 == 49L);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-31507200000L) + "'", long68 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 100 + "'", int69 == 100);
//        org.junit.Assert.assertNotNull(property71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 68259 + "'", int72 == 68259);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(localTime76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
//        org.junit.Assert.assertNotNull(gJChronology80);
//        org.junit.Assert.assertNotNull(dateTimeField81);
//        org.junit.Assert.assertNotNull(locale84);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "-18059" + "'", str85.equals("-18059"));
//        org.junit.Assert.assertNull(str91);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        java.lang.String str5 = gregorianChronology0.toString();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis(68254, 0, 0, 19690);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str5.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("DateTimeField[monthOfYear]", "12", 19700, (int) (short) 1);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(1560342498872L);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 100);
        long long10 = fixedDateTimeZone4.nextTransition((long) 19678);
        int int12 = fixedDateTimeZone4.getOffsetFromLocal((long) 19687);
        int int14 = fixedDateTimeZone4.getStandardOffset((long) 19684);
        long long16 = fixedDateTimeZone4.nextTransition(192483000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19700 + "'", int6 == 19700);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "12" + "'", str8.equals("12"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 19678L + "'", long10 == 19678L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19700 + "'", int12 == 19700);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 192483000L + "'", long16 == 192483000L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfCentury(52);
        org.joda.time.DateTime dateTime8 = dateTime1.plusHours(19689901);
        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfCentury(1);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.plus(readableDuration11);
        org.joda.time.DateTime.Property property13 = dateTime12.era();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withYear(19666);
        try {
            org.joda.time.DateTime dateTime5 = dateTime3.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.monthOfYear();
//        int int8 = mutableDateTime6.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = mutableDateTime6.toDateTime(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = dateTime10.toDateTime();
//        org.joda.time.DateTime dateTime13 = dateTime10.minusMinutes((-18059));
//        boolean boolean14 = gregorianChronology0.equals((java.lang.Object) dateTime13);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 68260 + "'", int8 == 68260);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear(19670);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMinuteOfDay(19685);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("monthOfYear", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("monthOfYear", 19690, 2019, 52, '#', 0, (int) '4', 0, false, (int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder25 = dateTimeZoneBuilder14.addRecurringSavings("2019-06-12T05:28:03.598-07:00", 19693, 19690, 19678, '4', 68253, 19692, 1, false, 19673);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder25);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        int int6 = skipUndoDateTimeField4.get(0L);
        long long9 = skipUndoDateTimeField4.addWrapField((-192458L), 2);
        int int10 = skipUndoDateTimeField4.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 63071807542L + "'", long9 == 63071807542L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfCentury(52);
        org.joda.time.DateTime dateTime8 = dateTime1.plusHours(19689901);
        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfCentury(1);
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(57, 19690);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19747 + "'", int2 == 19747);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear(19670);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMinuteOfDay(19685);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfSecond((int) (byte) 100, 19676);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendTwoDigitWeekyear((-19666));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendHourOfHalfday(163);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str1 = julianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField3 = julianChronology0.minutes();
        try {
            long long8 = julianChronology0.getDateTimeMillis(19686, 100, 19700, 19674);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str1.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyear();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        long long8 = gJChronology0.add(readablePeriod5, (long) 12, (-2));
//        org.joda.time.DurationField durationField9 = gJChronology0.weekyears();
//        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.minuteOfDay();
//        org.joda.time.MutableDateTime mutableDateTime12 = property11.roundHalfCeiling();
//        org.joda.time.MutableDateTime mutableDateTime14 = property11.addWrapField(19688);
//        int int15 = mutableDateTime14.getMinuteOfDay();
//        mutableDateTime14.addMonths(19681);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 666 + "'", int15 == 666);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.weekyears();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("monthOfYear", false);
        org.joda.time.Chronology chronology7 = gregorianChronology1.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.hourOfHalfday();
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology9, locale11);
        java.util.Locale locale13 = dateTimeParserBucket12.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology7, locale13, (java.lang.Integer) 19671);
        org.joda.time.Chronology chronology16 = dateTimeParserBucket15.getChronology();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology18);
        mutableDateTime21.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime21.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder25 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone28 = dateTimeZoneBuilder25.toDateTimeZone("monthOfYear", false);
        java.lang.String str30 = dateTimeZone28.getShortName(0L);
        mutableDateTime21.setZoneRetainFields(dateTimeZone28);
        dateTimeParserBucket15.setZone(dateTimeZone28);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(locale13);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+00:00" + "'", str30.equals("+00:00"));
        org.junit.Assert.assertNotNull(gJChronology33);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        java.lang.String str2 = property1.getName();
//        org.joda.time.MutableDateTime mutableDateTime4 = property1.add((long) 'a');
//        org.joda.time.Interval interval5 = property1.toInterval();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property1.getAsText(locale6);
//        java.lang.String str8 = property1.getAsText();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property12 = dateTime11.minuteOfDay();
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.minus(readablePeriod13);
//        java.lang.String str15 = dateTimeFormatter10.print((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology17.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology17);
//        mutableDateTime20.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        mutableDateTime20.setZoneRetainFields(dateTimeZone23);
//        int int25 = mutableDateTime20.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone26 = mutableDateTime20.getZone();
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime11.toMutableDateTime(dateTimeZone26);
//        org.joda.time.Chronology chronology28 = iSOChronology9.withZone(dateTimeZone26);
//        boolean boolean29 = property1.equals((java.lang.Object) dateTimeZone26);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "monthOfYear" + "'", str2.equals("monthOfYear"));
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(interval5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "July" + "'", str7.equals("July"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "July" + "'", str8.equals("July"));
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019-06-11T18" + "'", str15.equals("2019-06-11T18"));
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test288");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.plusYears((int) (short) 0);
//        org.joda.time.DateTime.Property property7 = dateTime4.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = property7.addToCopy(19000L);
//        org.joda.time.DateTime dateTime10 = property7.withMaximumValue();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68261 + "'", int2 == 68261);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("69");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-25200000), 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: -25200000");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
//        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
//        int int19 = mutableDateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
//        org.joda.time.DurationField durationField27 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
//        long long50 = offsetDateTimeField48.roundHalfFloor(0L);
//        long long53 = offsetDateTimeField48.add(19708681L, 30);
//        int int55 = offsetDateTimeField48.get((-209167272000000L));
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 68261 + "'", int19 == 68261);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 19738681L + "'", long53 == 19738681L);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.hours();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology3);
        mutableDateTime6.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        mutableDateTime6.setZoneRetainFields(dateTimeZone9);
        int int11 = mutableDateTime6.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = mutableDateTime6.getZone();
        org.joda.time.Chronology chronology13 = gJChronology0.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = gJChronology0.hours();
        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Instant instant16 = gJChronology0.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Instant instant18 = instant16.plus(readableDuration17);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Instant instant20 = instant18.minus(readableDuration19);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.Instant instant23 = instant20.withDurationAdded(readableDuration21, (int) (byte) 100);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(instant23);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
//        java.util.Locale locale2 = null;
//        int int3 = property1.getMaximumShortTextLength(locale2);
//        org.joda.time.DateTime dateTime5 = property1.setCopy((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        java.lang.String str7 = dateTime5.toString(dateTimeFormatter6);
//        java.io.Writer writer8 = null;
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) 2000);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.lang.String str12 = julianChronology11.toString();
//        org.joda.time.Chronology chronology13 = julianChronology11.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime10, (org.joda.time.Chronology) julianChronology11);
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.millisOfDay();
//        mutableDateTime14.setMinuteOfHour(12);
//        java.lang.String str18 = mutableDateTime14.toString();
//        try {
//            dateTimeFormatter6.printTo(writer8, (org.joda.time.ReadableInstant) mutableDateTime14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019162T000041.392-0700" + "'", str7.equals("2019162T000041.392-0700"));
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str12.equals("JulianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-18T16:12:02.000-08:00" + "'", str18.equals("1969-12-18T16:12:02.000-08:00"));
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test294");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.monthOfYear();
//        int int15 = mutableDateTime13.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = mutableDateTime13.toDateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
//        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
//        int int20 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime19);
//        long long22 = zeroIsMaxDateTimeField10.roundHalfFloor(100L);
//        long long24 = zeroIsMaxDateTimeField10.roundHalfFloor((long) (short) -1);
//        long long27 = zeroIsMaxDateTimeField10.add((-210866673619683L), 2);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 68261 + "'", int15 == 68261);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 60 + "'", int20 == 60);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-210866673617683L) + "'", long27 == (-210866673617683L));
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("monthOfYear", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(69);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addCutover((int) ' ', '4', 2019, 35, 59, true, 68257);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear(19666);
        mutableDateTime1.setDate((org.joda.time.ReadableInstant) dateTime3);
        int int7 = mutableDateTime1.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test297");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks(100);
//        org.joda.time.DateTime dateTime8 = dateTime4.plusDays((int) (short) -1);
//        int int9 = dateTime8.getSecondOfDay();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68261 + "'", int2 == 68261);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 68261 + "'", int9 == 68261);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendDayOfWeek(19148);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("America/Los_Angeles");
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.hours();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
//        org.joda.time.DurationField durationField5 = gJChronology3.millis();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType9);
//        long long15 = zeroIsMaxDateTimeField13.roundHalfEven(0L);
//        long long18 = zeroIsMaxDateTimeField13.add(12L, 2000);
//        long long21 = zeroIsMaxDateTimeField13.getDifferenceAsLong((long) 19687, 192477915L);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField13);
//        org.joda.time.DurationField durationField23 = delegatedDateTimeField22.getDurationField();
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField25 = gJChronology24.weekyears();
//        org.joda.time.DurationField durationField26 = gJChronology24.millis();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology24.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField27, dateTimeFieldType30);
//        int int36 = zeroIsMaxDateTimeField34.getMaximumValue((long) 2);
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField38 = gJChronology37.weekyears();
//        org.joda.time.DurationField durationField39 = gJChronology37.millis();
//        org.joda.time.DateTimeField dateTimeField40 = gJChronology37.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property42 = mutableDateTime41.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField40, dateTimeFieldType43);
//        int int49 = zeroIsMaxDateTimeField47.getMaximumValue((long) 2);
//        org.joda.time.MutableDateTime mutableDateTime50 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property51 = mutableDateTime50.monthOfYear();
//        int int52 = mutableDateTime50.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTime dateTime54 = mutableDateTime50.toDateTime(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = dateTime54.toDateTime();
//        org.joda.time.LocalTime localTime56 = dateTime55.toLocalTime();
//        org.joda.time.Chronology chronology57 = null;
//        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField59 = gJChronology58.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField60 = gJChronology58.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField61 = new org.joda.time.field.SkipUndoDateTimeField(chronology57, dateTimeField60);
//        org.joda.time.DateTimeField dateTimeField62 = skipUndoDateTimeField61.getWrappedField();
//        long long65 = skipUndoDateTimeField61.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial66 = null;
//        int[] intArray74 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray76 = skipUndoDateTimeField61.add(readablePartial66, 19670, intArray74, 0);
//        int int77 = zeroIsMaxDateTimeField47.getMaximumValue((org.joda.time.ReadablePartial) localTime56, intArray74);
//        java.util.Locale locale79 = null;
//        java.lang.String str80 = zeroIsMaxDateTimeField34.getAsText((org.joda.time.ReadablePartial) localTime56, 12, locale79);
//        int int81 = delegatedDateTimeField22.getMaximumValue((org.joda.time.ReadablePartial) localTime56);
//        int[] intArray83 = gJChronology0.get((org.joda.time.ReadablePartial) localTime56, (long) 29645);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2000012L + "'", long18 == 2000012L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-192458L) + "'", long21 == (-192458L));
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 60 + "'", int36 == 60);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 60 + "'", int49 == 60);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 68261 + "'", int52 == 68261);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(localTime56);
//        org.junit.Assert.assertNotNull(gJChronology58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 49L + "'", long65 == 49L);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertNotNull(intArray76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 60 + "'", int77 == 60);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "12" + "'", str80.equals("12"));
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 60 + "'", int81 == 60);
//        org.junit.Assert.assertNotNull(intArray83);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology1, locale3);
        java.lang.Integer int5 = dateTimeParserBucket4.getOffsetInteger();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(int5);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
//        long long6 = gJChronology0.add((long) (short) 100, 0L, (int) (byte) 0);
//        org.joda.time.DurationField durationField7 = gJChronology0.weekyears();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField12);
//        org.joda.time.DateTimeField dateTimeField14 = skipUndoDateTimeField13.getWrappedField();
//        long long17 = skipUndoDateTimeField13.getDifferenceAsLong(1560342467589L, (long) ' ');
//        long long19 = skipUndoDateTimeField13.roundFloor((long) (short) 1);
//        int int20 = skipUndoDateTimeField13.getMaximumValue();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology8, (org.joda.time.DateTimeField) skipUndoDateTimeField13);
//        int int23 = skipDateTimeField21.get(558445966400012L);
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField25 = gJChronology24.weekyears();
//        org.joda.time.DurationField durationField26 = gJChronology24.millis();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology24.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField34 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField27, dateTimeFieldType30);
//        long long37 = zeroIsMaxDateTimeField34.set((long) 52, "59");
//        int int38 = zeroIsMaxDateTimeField34.getMinimumValue();
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField40 = gJChronology39.weekyears();
//        org.joda.time.DurationField durationField41 = gJChronology39.millis();
//        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime43.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property44.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField49 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField42, dateTimeFieldType45);
//        long long51 = zeroIsMaxDateTimeField49.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime52 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property53 = mutableDateTime52.monthOfYear();
//        int int54 = mutableDateTime52.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.DateTime dateTime56 = mutableDateTime52.toDateTime(dateTimeZone55);
//        org.joda.time.DateTime dateTime57 = dateTime56.toDateTime();
//        org.joda.time.LocalTime localTime58 = dateTime57.toLocalTime();
//        int int59 = zeroIsMaxDateTimeField49.getMaximumValue((org.joda.time.ReadablePartial) localTime58);
//        org.joda.time.MutableDateTime mutableDateTime60 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property61 = mutableDateTime60.monthOfYear();
//        int int62 = mutableDateTime60.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone63 = null;
//        org.joda.time.DateTime dateTime64 = mutableDateTime60.toDateTime(dateTimeZone63);
//        org.joda.time.DateTime dateTime65 = dateTime64.toDateTime();
//        org.joda.time.LocalTime localTime66 = dateTime65.toLocalTime();
//        org.joda.time.Chronology chronology67 = null;
//        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField69 = gJChronology68.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField70 = gJChronology68.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField71 = new org.joda.time.field.SkipUndoDateTimeField(chronology67, dateTimeField70);
//        org.joda.time.DateTimeField dateTimeField72 = skipUndoDateTimeField71.getWrappedField();
//        long long75 = skipUndoDateTimeField71.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial76 = null;
//        int[] intArray84 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray86 = skipUndoDateTimeField71.add(readablePartial76, 19670, intArray84, 0);
//        int int87 = zeroIsMaxDateTimeField49.getMaximumValue((org.joda.time.ReadablePartial) localTime66, intArray86);
//        int[] intArray88 = null;
//        int int89 = zeroIsMaxDateTimeField34.getMinimumValue((org.joda.time.ReadablePartial) localTime66, intArray88);
//        int[] intArray94 = new int[] { 19683, 19681, 19700, (byte) 0 };
//        int int95 = skipDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localTime66, intArray94);
//        int[] intArray97 = gJChronology0.get((org.joda.time.ReadablePartial) localTime66, 1562934500000L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 49L + "'", long17 == 49L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-31507200000L) + "'", long19 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 66 + "'", int23 == 66);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 59052L + "'", long37 == 59052L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 68262 + "'", int54 == 68262);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(localTime58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 60 + "'", int59 == 60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 68262 + "'", int62 == 68262);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(localTime66);
//        org.junit.Assert.assertNotNull(gJChronology68);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 49L + "'", long75 == 49L);
//        org.junit.Assert.assertNotNull(intArray84);
//        org.junit.Assert.assertNotNull(intArray86);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 60 + "'", int87 == 60);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
//        org.junit.Assert.assertNotNull(intArray94);
//        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 100 + "'", int95 == 100);
//        org.junit.Assert.assertNotNull(intArray97);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology2);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) 100, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology2.millisOfDay();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology2);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.add(19674);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime9);
        boolean boolean12 = mutableDateTime9.isAfter(59052L);
        mutableDateTime9.setSecondOfDay((int) ' ');
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime9.millisOfSecond();
        int int16 = mutableDateTime9.getCenturyOfEra();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 21 + "'", int16 == 21);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology2);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) 100, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology2.millisOfDay();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField9 = gJChronology8.weekyears();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.dayOfMonth();
        boolean boolean11 = gJChronology2.equals((java.lang.Object) gJChronology8);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology2.clockhourOfHalfday();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField14 = gJChronology13.weekyears();
        org.joda.time.DurationField durationField15 = gJChronology13.millis();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology13.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField16, dateTimeFieldType19);
        org.joda.time.DurationField durationField24 = zeroIsMaxDateTimeField23.getDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField23);
        int int27 = skipDateTimeField25.getLeapAmount((long) 19697);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
//        long long8 = skipUndoDateTimeField4.getDifferenceAsLong((long) 19670, (-1L));
//        int int11 = skipUndoDateTimeField4.getDifference((long) (-1), (long) (byte) -1);
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.monthOfYear();
//        int int14 = mutableDateTime12.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = mutableDateTime12.toDateTime(dateTimeZone15);
//        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField20 = gJChronology19.weekyears();
//        org.joda.time.DurationField durationField21 = gJChronology19.millis();
//        org.joda.time.DateTimeField dateTimeField22 = gJChronology19.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property24 = mutableDateTime23.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField29 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField22, dateTimeFieldType25);
//        int int31 = zeroIsMaxDateTimeField29.getMaximumValue((long) 2);
//        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property33 = mutableDateTime32.monthOfYear();
//        int int34 = mutableDateTime32.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = mutableDateTime32.toDateTime(dateTimeZone35);
//        org.joda.time.DateTime dateTime37 = dateTime36.toDateTime();
//        org.joda.time.LocalTime localTime38 = dateTime37.toLocalTime();
//        org.joda.time.Chronology chronology39 = null;
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField42 = gJChronology40.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField43 = new org.joda.time.field.SkipUndoDateTimeField(chronology39, dateTimeField42);
//        org.joda.time.DateTimeField dateTimeField44 = skipUndoDateTimeField43.getWrappedField();
//        long long47 = skipUndoDateTimeField43.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial48 = null;
//        int[] intArray56 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray58 = skipUndoDateTimeField43.add(readablePartial48, 19670, intArray56, 0);
//        int int59 = zeroIsMaxDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localTime38, intArray56);
//        try {
//            int[] intArray61 = skipUndoDateTimeField4.add((org.joda.time.ReadablePartial) localTime17, 0, intArray56, 4038000);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 68263 + "'", int14 == 68263);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localTime17);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 60 + "'", int31 == 60);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 68263 + "'", int34 == 68263);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(localTime38);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 49L + "'", long47 == 49L);
//        org.junit.Assert.assertNotNull(intArray56);
//        org.junit.Assert.assertNotNull(intArray58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 60 + "'", int59 == 60);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) (-2), 19675);
        long long8 = dateTimeParserBucket7.computeMillis();
        java.lang.Integer int9 = dateTimeParserBucket7.getPivotYear();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 30800012L + "'", long8 == 30800012L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-2) + "'", int9.equals((-2)));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(19689901, 19675, (-19635), 328, 68253);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 328 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology3);
//        mutableDateTime6.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        mutableDateTime6.setZoneRetainFields(dateTimeZone9);
//        int int11 = mutableDateTime6.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = mutableDateTime6.getZone();
//        long long15 = dateTimeZone12.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField19 = gregorianChronology18.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone23 = dateTimeZoneBuilder20.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology24 = gregorianChronology18.withZone(dateTimeZone23);
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.hourOfHalfday();
//        java.util.Locale locale28 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology26, locale28);
//        java.util.Locale locale30 = dateTimeParserBucket29.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket32 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology24, locale30, (java.lang.Integer) 19671);
//        java.lang.String str33 = dateTimeZone12.getShortName((long) 2000, locale30);
//        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField35 = zonedChronology34.minuteOfDay();
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField38 = gJChronology37.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField39 = gJChronology37.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology37);
//        mutableDateTime40.addMonths((-1));
//        org.joda.time.MutableDateTime.Property property43 = mutableDateTime40.secondOfDay();
//        mutableDateTime40.addYears((int) '#');
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField48 = gJChronology47.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField49 = gJChronology47.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime50 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology47);
//        mutableDateTime50.addMonths((-1));
//        org.joda.time.MutableDateTime.Property property53 = mutableDateTime50.secondOfDay();
//        boolean boolean54 = mutableDateTime40.isEqual((org.joda.time.ReadableInstant) mutableDateTime50);
//        org.joda.time.MutableDateTime.Property property55 = mutableDateTime50.minuteOfHour();
//        boolean boolean56 = zonedChronology34.equals((java.lang.Object) property55);
//        org.joda.time.MutableDateTime mutableDateTime57 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) zonedChronology34);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 19684L + "'", long15 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(locale30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PST" + "'", str33.equals("PST"));
//        org.junit.Assert.assertNotNull(zonedChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        java.lang.String str2 = property1.getName();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.add((long) 'a');
        org.joda.time.Interval interval5 = property1.toInterval();
        org.joda.time.DurationField durationField6 = property1.getRangeDurationField();
        int int7 = property1.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "monthOfYear" + "'", str2.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.plus((-210866673619683L));
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, dateTimeField6);
        org.joda.time.DateTimeField dateTimeField8 = skipUndoDateTimeField7.getWrappedField();
        long long11 = skipUndoDateTimeField7.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long14 = skipUndoDateTimeField7.getDifferenceAsLong((long) 0, (long) (short) 10);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField7, 30);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 49L + "'", long11 == 49L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        int int12 = zeroIsMaxDateTimeField10.getMaximumValue((long) 0);
        int int14 = zeroIsMaxDateTimeField10.getLeapAmount((-209167272000000L));
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField16 = gJChronology15.weekyears();
        org.joda.time.DurationField durationField17 = gJChronology15.millis();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology15.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField18, dateTimeFieldType21);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) (short) 100, "monthOfYear");
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType21);
        int int32 = zeroIsMaxDateTimeField10.getDifference(19738681L, (long) 19697);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 60 + "'", int12 == 60);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 19718 + "'", int32 == 19718);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 19670);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) 0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone3);
//        boolean boolean5 = cachedDateTimeZone3.isFixed();
//        java.lang.String str7 = cachedDateTimeZone3.getShortName((long) 19678);
//        org.joda.time.LocalDateTime localDateTime8 = null;
//        boolean boolean9 = cachedDateTimeZone3.isLocalDateTimeGap(localDateTime8);
//        java.lang.String str11 = cachedDateTimeZone3.getNameKey(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test318");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology3);
//        mutableDateTime6.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        mutableDateTime6.setZoneRetainFields(dateTimeZone9);
//        int int11 = mutableDateTime6.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = mutableDateTime6.getZone();
//        long long15 = dateTimeZone12.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField19 = gregorianChronology18.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone23 = dateTimeZoneBuilder20.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology24 = gregorianChronology18.withZone(dateTimeZone23);
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.hourOfHalfday();
//        java.util.Locale locale28 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology26, locale28);
//        java.util.Locale locale30 = dateTimeParserBucket29.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket32 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology24, locale30, (java.lang.Integer) 19671);
//        java.lang.String str33 = dateTimeZone12.getShortName((long) 2000, locale30);
//        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone12);
//        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology34);
//        org.joda.time.DateTimeZone dateTimeZone36 = zonedChronology34.getZone();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 19684L + "'", long15 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(locale30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PST" + "'", str33.equals("PST"));
//        org.junit.Assert.assertNotNull(zonedChronology34);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        int int3 = dateTimeZone1.getOffsetFromLocal((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone1);
        java.lang.Appendable appendable6 = null;
        try {
            dateTimeFormatter0.printTo(appendable6, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
        boolean boolean14 = zeroIsMaxDateTimeField10.isLeap((-1L));
        long long16 = zeroIsMaxDateTimeField10.roundHalfCeiling((long) (-19));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 328);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfSecond((-19666), 57619662);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        org.joda.time.Chronology chronology3 = gJChronology0.withUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
//        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
//        long long5 = property4.remainder();
//        org.joda.time.DateTime dateTime6 = property4.withMaximumValue();
//        org.joda.time.DateTimeField dateTimeField7 = property4.getField();
//        int int8 = property4.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 154664691L + "'", long5 == 154664691L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test326");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        java.lang.StringBuffer stringBuffer3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        int int6 = mutableDateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = mutableDateTime4.toDateTime(dateTimeZone7);
//        org.joda.time.LocalTime localTime9 = dateTime8.toLocalTime();
//        org.joda.time.DateTime dateTime11 = dateTime8.withMillisOfSecond((int) (short) 1);
//        try {
//            dateTimeFormatter2.printTo(stringBuffer3, (org.joda.time.ReadableInstant) dateTime8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 68264 + "'", int6 == 68264);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology2);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) 100, (org.joda.time.Chronology) gJChronology2);
        boolean boolean7 = mutableDateTime6.isEqualNow();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime6.dayOfYear();
        boolean boolean10 = mutableDateTime6.isEqual((long) 19675);
        mutableDateTime6.setMillisOfDay((int) ' ');
        mutableDateTime6.add((long) 19675);
        int int15 = mutableDateTime6.getCenturyOfEra();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 20 + "'", int15 == 20);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.monthOfYear();
//        int int15 = mutableDateTime13.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = mutableDateTime13.toDateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
//        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
//        int int20 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime19);
//        long long22 = zeroIsMaxDateTimeField10.roundHalfFloor(100L);
//        long long24 = zeroIsMaxDateTimeField10.roundHalfFloor((long) (short) -1);
//        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.monthOfYear();
//        int int27 = mutableDateTime25.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTime dateTime29 = mutableDateTime25.toDateTime(dateTimeZone28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField34 = gJChronology33.weekyears();
//        org.joda.time.DurationField durationField35 = gJChronology33.millis();
//        org.joda.time.DateTimeField dateTimeField36 = gJChronology33.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property38 = mutableDateTime37.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType39, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField36, dateTimeFieldType39);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException45 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType39, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType39, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder30.appendFixedDecimal(dateTimeFieldType39, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property52 = mutableDateTime25.property(dateTimeFieldType39);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType39, (java.lang.Number) 0.0f, "59");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType39, (int) '#');
//        org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField60 = gJChronology59.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField61 = gJChronology59.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime62 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology59);
//        mutableDateTime62.addMonths((-1));
//        org.joda.time.MutableDateTime.Property property65 = mutableDateTime62.secondOfDay();
//        mutableDateTime62.addYears((int) '#');
//        org.joda.time.MutableDateTime.Property property68 = mutableDateTime62.minuteOfDay();
//        org.joda.time.DurationField durationField69 = property68.getRangeDurationField();
//        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField72 = gJChronology71.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField73 = gJChronology71.yearOfCentury();
//        java.util.Locale locale74 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket77 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology71, locale74, (java.lang.Integer) (-2), 19675);
//        org.joda.time.DurationField durationField78 = gJChronology71.seconds();
//        org.joda.time.DurationField durationField79 = gJChronology71.weekyears();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField80 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType39, durationField69, durationField79);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 68264 + "'", int15 == 68264);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 60 + "'", int20 == 60);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 68264 + "'", int27 == 68264);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(gJChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(durationField69);
//        org.junit.Assert.assertNotNull(gJChronology71);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertNotNull(dateTimeField73);
//        org.junit.Assert.assertNotNull(durationField78);
//        org.junit.Assert.assertNotNull(durationField79);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        try {
            long long5 = dateTimeFormatter3.parseMillis("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test330");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        int int12 = zeroIsMaxDateTimeField10.getMaximumValue((long) 2);
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.monthOfYear();
//        int int15 = mutableDateTime13.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = mutableDateTime13.toDateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
//        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology20, dateTimeField23);
//        org.joda.time.DateTimeField dateTimeField25 = skipUndoDateTimeField24.getWrappedField();
//        long long28 = skipUndoDateTimeField24.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial29 = null;
//        int[] intArray37 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray39 = skipUndoDateTimeField24.add(readablePartial29, 19670, intArray37, 0);
//        int int40 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime19, intArray37);
//        long long43 = zeroIsMaxDateTimeField10.add((long) (-1), 12673L);
//        int int45 = zeroIsMaxDateTimeField10.getMinimumValue((long) 68257);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 60 + "'", int12 == 60);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 68264 + "'", int15 == 68264);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 49L + "'", long28 == 49L);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 60 + "'", int40 == 60);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 12672999L + "'", long43 == 12672999L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
//        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
//        int int19 = mutableDateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
//        org.joda.time.DurationField durationField27 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
//        long long51 = offsetDateTimeField48.add((long) 19681, 19689);
//        long long53 = offsetDateTimeField48.roundCeiling(2440588L);
//        long long56 = offsetDateTimeField48.add((long) (byte) 10, 0L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 68264 + "'", int19 == 68264);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 19708681L + "'", long51 == 19708681L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 2441000L + "'", long53 == 2441000L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Property[era]");
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("monthOfYear", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (short) 1, 'a', 0, 2, 19671, true, 60);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder0.toDateTimeZone("2019163T000008.699-0700", false);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test334");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
//        int int16 = zeroIsMaxDateTimeField10.get(192477915L);
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField(chronology17, dateTimeField20);
//        org.joda.time.DateTimeField dateTimeField22 = skipUndoDateTimeField21.getWrappedField();
//        long long25 = skipUndoDateTimeField21.getDifferenceAsLong(1560342467589L, (long) ' ');
//        long long27 = skipUndoDateTimeField21.roundFloor((long) (short) 1);
//        int int28 = skipUndoDateTimeField21.getMaximumValue();
//        org.joda.time.DurationField durationField29 = skipUndoDateTimeField21.getLeapDurationField();
//        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.monthOfYear();
//        int int32 = mutableDateTime30.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = mutableDateTime30.toDateTime(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = dateTime34.toDateTime();
//        org.joda.time.LocalTime localTime36 = dateTime35.toLocalTime();
//        int int37 = skipUndoDateTimeField21.getMinimumValue((org.joda.time.ReadablePartial) localTime36);
//        int[] intArray43 = new int[] { (-19671), (byte) 1, 19676, 32 };
//        try {
//            int[] intArray45 = zeroIsMaxDateTimeField10.addWrapPartial((org.joda.time.ReadablePartial) localTime36, 12885, intArray43, 19679);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -19671 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 57 + "'", int16 == 57);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 49L + "'", long25 == 49L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-31507200000L) + "'", long27 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
//        org.junit.Assert.assertNull(durationField29);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 68265 + "'", int32 == 68265);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(localTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(intArray43);
//    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
//        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
//        int int19 = mutableDateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
//        org.joda.time.DurationField durationField27 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology50.yearOfCentury();
//        java.util.Locale locale53 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology50, locale53, (java.lang.Integer) (-2), 19675);
//        java.lang.Object obj57 = dateTimeParserBucket56.saveState();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder58.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField62 = gJChronology61.weekyears();
//        org.joda.time.DurationField durationField63 = gJChronology61.millis();
//        org.joda.time.DateTimeField dateTimeField64 = gJChronology61.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime65 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property66 = mutableDateTime65.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property66.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField71 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField64, dateTimeFieldType67);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException77 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder58.appendFixedDecimal(dateTimeFieldType67, (int) (short) 100);
//        dateTimeParserBucket56.saveField(dateTimeFieldType67, 0);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType67, 19683);
//        org.joda.time.DurationField durationField84 = dividedDateTimeField83.getDurationField();
//        long long87 = dividedDateTimeField83.add((long) 19695, 19672L);
//        org.joda.time.DateTimeField dateTimeField88 = dividedDateTimeField83.getWrappedField();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 68265 + "'", int19 == 68265);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(obj57);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
//        org.junit.Assert.assertNotNull(gJChronology61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(durationField63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(property66);
//        org.junit.Assert.assertNotNull(dateTimeFieldType67);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
//        org.junit.Assert.assertNotNull(durationField84);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 387203995695L + "'", long87 == 387203995695L);
//        org.junit.Assert.assertNotNull(dateTimeField88);
//    }
//}

