import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("monthOfYear", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"monthOfYear/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            long long8 = gJChronology0.getDateTimeMillis((int) (byte) 0, 10, (int) (byte) -1, (int) 'a', (int) (byte) 100, 19666, 19666);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) 1.0f, (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Positive hours must not have negative minutes: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        try {
            mutableDateTime4.setWeekyear((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property4.getFieldType();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = property2.getFieldType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField4 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeFieldType3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withPivotYear((-1));
        try {
            org.joda.time.Instant instant5 = org.joda.time.Instant.parse("", dateTimeFormatter4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test026");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560342467589L + "'", long0 == 1560342467589L);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(1.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866673600000L) + "'", long1 == (-210866673600000L));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        try {
            long long4 = dateTimeFormatter2.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        int int6 = skipUndoDateTimeField4.get(0L);
        try {
            long long9 = skipUndoDateTimeField4.set((long) 10, "monthOfYear");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"monthOfYear\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test034");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
//        int int3 = mutableDateTime1.getSecondOfDay();
//        int int6 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime1, "monthOfYear", (int) (short) 1);
//        int int7 = mutableDateTime1.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19667 + "'", int3 == 19667);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2) + "'", int6 == (-2));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 27 + "'", int7 == 27);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1560342467589L, 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6241369870356L + "'", long2 == 6241369870356L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        try {
            org.joda.time.DateTime dateTime5 = dateTime1.withDayOfWeek((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
        org.joda.time.ReadablePartial readablePartial12 = null;
        int[] intArray13 = new int[] {};
        try {
            int int14 = zeroIsMaxDateTimeField10.getMaximumValue(readablePartial12, intArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-2), 10, (int) (short) 100, (int) '#', (int) (short) 10, (-2), dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.dayOfMonth();
//        java.lang.String str4 = property3.getAsText();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19669 + "'", int2 == 19669);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "12" + "'", str4.equals("12"));
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setDayOfMonth((int) (byte) 10);
        try {
            mutableDateTime4.setHourOfDay((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.io.Writer writer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 0);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.parse("59", dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(19666);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-19666) + "'", int1 == (-19666));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        java.lang.Object obj2 = null;
        boolean boolean3 = gregorianChronology0.equals(obj2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths(1);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.DateTime dateTime6 = dateTime1.withFieldAdded(durationFieldType4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeZoneBuilder4.toDateTimeZone("monthOfYear", false);
        org.joda.time.DateTime dateTime8 = dateTime3.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime3.minusYears(19666);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology2);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) 100, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        try {
            int[] intArray9 = gJChronology2.get(readablePeriod7, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime3);
//        try {
//            org.joda.time.DateTime dateTime11 = dateTime3.withTime((int) (short) 100, 10, (int) (short) 10, 2000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019-W24" + "'", str6.equals("2019-W24"));
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int[] intArray12 = new int[] { 12, (byte) 100, 'a', (short) 1, 1, (short) 10 };
        try {
            int int13 = skipUndoDateTimeField4.getMaximumValue(readablePartial5, intArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray12);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime0.secondOfDay();
//        java.util.Locale locale7 = null;
//        try {
//            org.joda.time.MutableDateTime mutableDateTime8 = property5.set("", locale7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for secondOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19671 + "'", int2 == 19671);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((-19666), (-2), (int) (byte) 10, (int) (short) -1, 19669, 2, 100, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.monthOfYear();
//        int int13 = mutableDateTime11.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime11.dayOfMonth();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField17 = gregorianChronology16.weekyears();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField18 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType6, durationField15, durationField17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 19671 + "'", int13 == 19671);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.lang.Appendable appendable2 = null;
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeZoneBuilder4.toDateTimeZone("monthOfYear", false);
        org.joda.time.DateTime dateTime8 = dateTime3.withZone(dateTimeZone7);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime0.secondOfDay();
//        org.joda.time.DurationFieldType durationFieldType6 = null;
//        try {
//            mutableDateTime0.add(durationFieldType6, 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19672 + "'", int2 == 19672);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.monthOfYear();
//        int int4 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusMonths(1);
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("monthOfYear", false);
//        org.joda.time.DateTime dateTime13 = dateTime8.withZone(dateTimeZone12);
//        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) mutableDateTime2, (org.joda.time.ReadableDateTime) dateTime13);
//        try {
//            long long19 = limitChronology14.getDateTimeMillis((int) (short) 10, 27, 4, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 27 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19672 + "'", int4 == 19672);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(limitChronology14);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(69, 19, 19666, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
        java.util.Locale locale12 = null;
        int int13 = zeroIsMaxDateTimeField10.getMaximumTextLength(locale12);
        try {
            long long16 = zeroIsMaxDateTimeField10.set((long) '4', "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(19666, (int) (byte) -1, 19667, (int) (byte) 0, (int) (byte) 10, 0, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray3 = julianChronology0.get(readablePeriod1, (long) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, 192467526L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(69);
        java.lang.Appendable appendable3 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology5.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology5);
        mutableDateTime8.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.dayOfMonth();
        try {
            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadableInstant) mutableDateTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property11);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
//        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
//        long long10 = skipUndoDateTimeField4.roundFloor((long) (short) 1);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField12 = gJChronology11.weekyears();
//        org.joda.time.DurationField durationField13 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology11.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property16.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField21 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField14, dateTimeFieldType17);
//        long long23 = zeroIsMaxDateTimeField21.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property25 = mutableDateTime24.monthOfYear();
//        int int26 = mutableDateTime24.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = mutableDateTime24.toDateTime(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = dateTime28.toDateTime();
//        org.joda.time.LocalTime localTime30 = dateTime29.toLocalTime();
//        int int31 = zeroIsMaxDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localTime30);
//        java.util.Locale locale32 = null;
//        try {
//            java.lang.String str33 = skipUndoDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localTime30, locale32);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfCentury' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19673 + "'", int26 == 19673);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 60 + "'", int31 == 60);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (-19666), (-210866673600000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-210866673619666L) + "'", long2 == (-210866673619666L));
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.plusYears((int) (short) 0);
//        org.joda.time.DateTime dateTime8 = dateTime4.minus((long) 4);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19674 + "'", int2 == 19674);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusMonths(1);
//        int int9 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        try {
//            org.joda.time.DateTime dateTime11 = dateTime6.withYearOfCentury(19666);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19666 for yearOfCentury must be in the range [0,99]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19674 + "'", int2 == 19674);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeZoneBuilder4.toDateTimeZone("monthOfYear", false);
        org.joda.time.DateTime dateTime8 = dateTime3.withZone(dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime3.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 19666, "");
        try {
            org.joda.time.DateTime dateTime17 = dateTime3.withField(dateTimeFieldType12, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long8 = julianChronology0.getDateTimeMillis(2, 19670, 4, 1, 0, 69, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
        int int9 = mutableDateTime4.getMinuteOfDay();
        boolean boolean10 = mutableDateTime4.isAfterNow();
        try {
            mutableDateTime4.setDate(19667, 19669, 19666);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19669 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        try {
//            org.joda.time.DateTime dateTime8 = dateTime5.withWeekOfWeekyear(19672);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19672 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19674 + "'", int2 == 19674);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localTime6);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.addMonths((-1));
        boolean boolean8 = mutableDateTime4.isBefore(1560342467589L);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.withYear((int) 'a');
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long12 = zeroIsMaxDateTimeField10.roundCeiling((long) 19);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1000L + "'", long12 == 1000L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        java.lang.String str2 = property1.getName();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.add((long) 'a');
        org.joda.time.MutableDateTime mutableDateTime6 = property1.addWrapField(19671);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "monthOfYear" + "'", str2.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1000L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "+00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.monthOfYear();
//        int int15 = mutableDateTime13.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = mutableDateTime13.toDateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
//        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
//        int int20 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime19);
//        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.monthOfYear();
//        int int23 = mutableDateTime21.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = mutableDateTime21.toDateTime(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = dateTime25.toDateTime();
//        org.joda.time.LocalTime localTime27 = dateTime26.toLocalTime();
//        org.joda.time.Chronology chronology28 = null;
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField31 = gJChronology29.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField(chronology28, dateTimeField31);
//        org.joda.time.DateTimeField dateTimeField33 = skipUndoDateTimeField32.getWrappedField();
//        long long36 = skipUndoDateTimeField32.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        int[] intArray45 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray47 = skipUndoDateTimeField32.add(readablePartial37, 19670, intArray45, 0);
//        int int48 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime27, intArray47);
//        org.joda.time.DurationField durationField49 = zeroIsMaxDateTimeField10.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = null;
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField52 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType50, 19666);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19675 + "'", int15 == 19675);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 60 + "'", int20 == 60);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19675 + "'", int23 == 19675);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(localTime27);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 49L + "'", long36 == 49L);
//        org.junit.Assert.assertNotNull(intArray45);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 60 + "'", int48 == 60);
//        org.junit.Assert.assertNull(durationField49);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readablePeriod5);
        org.joda.time.DateTime.Property property7 = dateTime4.weekOfWeekyear();
        boolean boolean8 = gJChronology0.equals((java.lang.Object) dateTime4);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime4.toMutableDateTime(dateTimeZone9);
        try {
            mutableDateTime10.setHourOfDay(19671);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19671 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis(10, (int) (byte) -1, 3, 60);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray17 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray19 = skipUndoDateTimeField4.add(readablePartial9, 19670, intArray17, 0);
        long long22 = skipUndoDateTimeField4.set(0L, (int) (short) 10);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1861920000000L) + "'", long22 == (-1861920000000L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withYear(19666);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.DateTime dateTime6 = dateTime1.withFieldAdded(durationFieldType4, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        java.lang.Object obj7 = mutableDateTime4.clone();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeZoneBuilder4.toDateTimeZone("monthOfYear", false);
        org.joda.time.DateTime dateTime8 = dateTime3.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour(0);
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withDayOfYear(19671);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19671 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.addMonths((-1));
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.secondOfDay();
        mutableDateTime4.addYears((int) '#');
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology11);
        mutableDateTime14.addMonths((-1));
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime14.secondOfDay();
        boolean boolean18 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime14.minuteOfHour();
        java.lang.Object obj20 = null;
        boolean boolean21 = property19.equals(obj20);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("monthOfYear", false);
        java.lang.String str5 = dateTimeZone3.getShortName(0L);
        try {
            org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, 12L, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("+00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong((long) 19670, (-1L));
        long long10 = skipUndoDateTimeField4.roundHalfEven(0L);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4);
        long long14 = skipUndoDateTimeField4.add((long) 2000, 19666);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 620599017602000L + "'", long14 == 620599017602000L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(19666, (int) '#', 52, 19670, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19670 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        org.joda.time.DurationField durationField3 = gJChronology0.centuries();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
//        int int3 = mutableDateTime1.getSecondOfDay();
//        int int6 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime1, "monthOfYear", (int) (short) 1);
//        try {
//            org.joda.time.LocalDateTime localDateTime8 = dateTimeFormatter0.parseLocalDateTime("");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19677 + "'", int3 == 19677);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2) + "'", int6 == (-2));
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gJChronology0.add(readablePeriod5, (long) 12, (-2));
        org.joda.time.DurationField durationField9 = gJChronology0.weekyears();
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        int int11 = mutableDateTime10.getRoundingMode();
        int int12 = mutableDateTime10.getRoundingMode();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.hours();
        long long5 = durationField2.subtract(0L, (long) 52);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-187200000L) + "'", long5 == (-187200000L));
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        int int12 = zeroIsMaxDateTimeField10.getMaximumValue((long) 2);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField14 = gJChronology13.weekyears();
//        org.joda.time.DurationField durationField15 = gJChronology13.millis();
//        org.joda.time.DateTimeField dateTimeField16 = gJChronology13.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField16, dateTimeFieldType19);
//        int int25 = zeroIsMaxDateTimeField23.getMaximumValue((long) 2);
//        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property27 = mutableDateTime26.monthOfYear();
//        int int28 = mutableDateTime26.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = mutableDateTime26.toDateTime(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = dateTime30.toDateTime();
//        org.joda.time.LocalTime localTime32 = dateTime31.toLocalTime();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField35 = gJChronology34.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField36 = gJChronology34.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField(chronology33, dateTimeField36);
//        org.joda.time.DateTimeField dateTimeField38 = skipUndoDateTimeField37.getWrappedField();
//        long long41 = skipUndoDateTimeField37.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial42 = null;
//        int[] intArray50 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray52 = skipUndoDateTimeField37.add(readablePartial42, 19670, intArray50, 0);
//        int int53 = zeroIsMaxDateTimeField23.getMaximumValue((org.joda.time.ReadablePartial) localTime32, intArray50);
//        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField56 = gJChronology55.weekyears();
//        org.joda.time.DurationField durationField57 = gJChronology55.millis();
//        org.joda.time.DateTimeField dateTimeField58 = gJChronology55.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime59 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property60 = mutableDateTime59.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType61 = property60.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType61, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField65 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField58, dateTimeFieldType61);
//        int int67 = zeroIsMaxDateTimeField65.getMaximumValue((long) 2);
//        org.joda.time.MutableDateTime mutableDateTime68 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property69 = mutableDateTime68.monthOfYear();
//        int int70 = mutableDateTime68.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone71 = null;
//        org.joda.time.DateTime dateTime72 = mutableDateTime68.toDateTime(dateTimeZone71);
//        org.joda.time.DateTime dateTime73 = dateTime72.toDateTime();
//        org.joda.time.LocalTime localTime74 = dateTime73.toLocalTime();
//        org.joda.time.Chronology chronology75 = null;
//        org.joda.time.chrono.GJChronology gJChronology76 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField77 = gJChronology76.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField78 = gJChronology76.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField79 = new org.joda.time.field.SkipUndoDateTimeField(chronology75, dateTimeField78);
//        org.joda.time.DateTimeField dateTimeField80 = skipUndoDateTimeField79.getWrappedField();
//        long long83 = skipUndoDateTimeField79.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial84 = null;
//        int[] intArray92 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray94 = skipUndoDateTimeField79.add(readablePartial84, 19670, intArray92, 0);
//        int int95 = zeroIsMaxDateTimeField65.getMaximumValue((org.joda.time.ReadablePartial) localTime74, intArray92);
//        try {
//            int[] intArray97 = zeroIsMaxDateTimeField10.addWrapField((org.joda.time.ReadablePartial) localTime32, 19669, intArray92, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19669");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 60 + "'", int12 == 60);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 60 + "'", int25 == 60);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 19677 + "'", int28 == 19677);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localTime32);
//        org.junit.Assert.assertNotNull(gJChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 49L + "'", long41 == 49L);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertNotNull(intArray52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 60 + "'", int53 == 60);
//        org.junit.Assert.assertNotNull(gJChronology55);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(dateTimeFieldType61);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 60 + "'", int67 == 60);
//        org.junit.Assert.assertNotNull(property69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 19677 + "'", int70 == 19677);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(localTime74);
//        org.junit.Assert.assertNotNull(gJChronology76);
//        org.junit.Assert.assertNotNull(dateTimeField77);
//        org.junit.Assert.assertNotNull(dateTimeField78);
//        org.junit.Assert.assertNotNull(dateTimeField80);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 49L + "'", long83 == 49L);
//        org.junit.Assert.assertNotNull(intArray92);
//        org.junit.Assert.assertNotNull(intArray94);
//        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 60 + "'", int95 == 60);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths(1);
        int int4 = dateTime3.getYearOfCentury();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMillis((int) (short) 1);
        boolean boolean7 = dateTime6.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
        try {
            long long19 = zeroIsMaxDateTimeField10.set((long) 100, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
//        int int13 = zeroIsMaxDateTimeField10.getMaximumValue();
//        java.lang.String str14 = zeroIsMaxDateTimeField10.toString();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField16 = gJChronology15.weekyears();
//        org.joda.time.DurationField durationField17 = gJChronology15.millis();
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology15.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField25 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField18, dateTimeFieldType21);
//        int int27 = zeroIsMaxDateTimeField25.getMaximumValue((long) 2);
//        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.monthOfYear();
//        int int30 = mutableDateTime28.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTime dateTime32 = mutableDateTime28.toDateTime(dateTimeZone31);
//        org.joda.time.DateTime dateTime33 = dateTime32.toDateTime();
//        org.joda.time.LocalTime localTime34 = dateTime33.toLocalTime();
//        org.joda.time.Chronology chronology35 = null;
//        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField38 = gJChronology36.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField(chronology35, dateTimeField38);
//        org.joda.time.DateTimeField dateTimeField40 = skipUndoDateTimeField39.getWrappedField();
//        long long43 = skipUndoDateTimeField39.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial44 = null;
//        int[] intArray52 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray54 = skipUndoDateTimeField39.add(readablePartial44, 19670, intArray52, 0);
//        int int55 = zeroIsMaxDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) localTime34, intArray52);
//        org.joda.time.Chronology chronology57 = null;
//        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField59 = gJChronology58.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField60 = gJChronology58.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField61 = new org.joda.time.field.SkipUndoDateTimeField(chronology57, dateTimeField60);
//        org.joda.time.DateTimeField dateTimeField62 = skipUndoDateTimeField61.getWrappedField();
//        long long65 = skipUndoDateTimeField61.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial66 = null;
//        int[] intArray74 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray76 = skipUndoDateTimeField61.add(readablePartial66, 19670, intArray74, 0);
//        try {
//            int[] intArray78 = zeroIsMaxDateTimeField10.set((org.joda.time.ReadablePartial) localTime34, (int) '4', intArray76, 19678);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19678 for monthOfYear must be in the range [1,60]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 60 + "'", int13 == 60);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[monthOfYear]" + "'", str14.equals("DateTimeField[monthOfYear]"));
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 60 + "'", int27 == 60);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 19679 + "'", int30 == 19679);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(localTime34);
//        org.junit.Assert.assertNotNull(gJChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 49L + "'", long43 == 49L);
//        org.junit.Assert.assertNotNull(intArray52);
//        org.junit.Assert.assertNotNull(intArray54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 60 + "'", int55 == 60);
//        org.junit.Assert.assertNotNull(gJChronology58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 49L + "'", long65 == 49L);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertNotNull(intArray76);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(192467526L, "monthOfYear");
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("12");
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime4.dayOfWeek();
        try {
            org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((java.lang.Object) property9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.MutableDateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("DateTimeField[yearOfCentury]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[yearOfCentury]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.addMonths((-1));
        try {
            mutableDateTime4.setTime((int) (short) 100, (int) '#', (int) '#', 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int0 = org.joda.time.MutableDateTime.ROUND_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.dayOfWeek();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField3, 19673, 10, (-2));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19673 for dayOfWeek must be in the range [10,-2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("2019-W24");
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime.Property property4 = dateTime1.era();
        try {
            org.joda.time.DateTime dateTime6 = property4.setCopy((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(19669, 10, 3, 19678, 100, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19678 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "DateTimeField[yearOfCentury]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("monthOfYear");
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField3 = gJChronology2.weekyears();
        org.joda.time.DurationField durationField4 = gJChronology2.millis();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType8);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (short) 100, "monthOfYear");
        java.lang.Number number16 = illegalFieldValueException15.getIllegalNumberValue();
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalFieldValueException15);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (short) 100 + "'", number16.equals((short) 100));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long13 = zeroIsMaxDateTimeField10.set((long) 52, "59");
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology17.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology16, dateTimeField19);
        org.joda.time.DateTimeField dateTimeField21 = skipUndoDateTimeField20.getWrappedField();
        long long24 = skipUndoDateTimeField20.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial25 = null;
        int[] intArray33 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray35 = skipUndoDateTimeField20.add(readablePartial25, 19670, intArray33, 0);
        java.util.Locale locale37 = null;
        try {
            int[] intArray38 = zeroIsMaxDateTimeField10.set(readablePartial14, (-1), intArray33, "DateTimeField[monthOfYear]", locale37);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[monthOfYear]\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 59052L + "'", long13 == 59052L);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 49L + "'", long24 == 49L);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray35);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = property1.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType2, (java.lang.Number) 19666, "");
        java.lang.String str6 = illegalFieldValueException5.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeFieldType2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19666" + "'", str6.equals("19666"));
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        mutableDateTime0.addWeeks(19669);
//        mutableDateTime0.addSeconds(19669);
//        try {
//            mutableDateTime0.setSecondOfMinute(19670);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19670 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19680 + "'", int2 == 19680);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(19677, 4, 4, (int) (short) 0, 10, 69, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder20.appendHalfdayOfDayText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendPattern("July");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        java.lang.String str2 = property1.getName();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.add((long) 'a');
        try {
            org.joda.time.MutableDateTime mutableDateTime6 = property1.set("JulianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"JulianChronology[America/Los_Angeles]\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "monthOfYear" + "'", str2.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology2);
        mutableDateTime5.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        mutableDateTime5.setZoneRetainFields(dateTimeZone8);
        int int10 = mutableDateTime5.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = mutableDateTime5.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withZone(dateTimeZone11);
        try {
            org.joda.time.MutableDateTime mutableDateTime14 = dateTimeFormatter0.parseMutableDateTime("DateTimeField[yearOfCentury]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[yearOfCentury]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
//        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
//        long long5 = property4.remainder();
//        org.joda.time.DateTime dateTime6 = property4.withMaximumValue();
//        org.joda.time.DateTime dateTime8 = dateTime6.minusDays(19);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 192480938L + "'", long5 == 192480938L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.add(19674);
        org.joda.time.MutableDateTime mutableDateTime10 = property7.roundHalfFloor();
        org.joda.time.DateTimeField dateTimeField11 = mutableDateTime10.getRoundingField();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNull(dateTimeField11);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder2.toDateTimeZone("monthOfYear", false);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long13 = zeroIsMaxDateTimeField10.set((long) 52, "59");
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = zeroIsMaxDateTimeField10.getType();
        java.util.Locale locale17 = null;
        try {
            long long18 = zeroIsMaxDateTimeField10.set((long) 3, "19666", locale17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19666 for monthOfYear must be in the range [1,60]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 59052L + "'", long13 == 59052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("monthOfYear", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (short) 1, 'a', 0, 2, 19671, true, 60);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addCutover(0, 'a', (-2), 19674, 19681, false, 27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 2000);
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str3 = julianChronology2.toString();
        org.joda.time.Chronology chronology4 = julianChronology2.withUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime1, (org.joda.time.Chronology) julianChronology2);
        try {
            long long10 = julianChronology2.getDateTimeMillis(60, (int) (short) 1, 100, 19669);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology4);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
//        java.util.Locale locale12 = null;
//        int int13 = zeroIsMaxDateTimeField10.getMaximumTextLength(locale12);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField15 = gJChronology14.weekyears();
//        org.joda.time.DurationField durationField16 = gJChronology14.millis();
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology14.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property19 = mutableDateTime18.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property19.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField24 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField17, dateTimeFieldType20);
//        long long26 = zeroIsMaxDateTimeField24.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.monthOfYear();
//        int int29 = mutableDateTime27.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = mutableDateTime27.toDateTime(dateTimeZone30);
//        org.joda.time.DateTime dateTime32 = dateTime31.toDateTime();
//        org.joda.time.LocalTime localTime33 = dateTime32.toLocalTime();
//        int int34 = zeroIsMaxDateTimeField24.getMaximumValue((org.joda.time.ReadablePartial) localTime33);
//        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.monthOfYear();
//        int int37 = mutableDateTime35.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTime dateTime39 = mutableDateTime35.toDateTime(dateTimeZone38);
//        org.joda.time.DateTime dateTime40 = dateTime39.toDateTime();
//        org.joda.time.LocalTime localTime41 = dateTime40.toLocalTime();
//        org.joda.time.Chronology chronology42 = null;
//        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField44 = gJChronology43.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField45 = gJChronology43.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField(chronology42, dateTimeField45);
//        org.joda.time.DateTimeField dateTimeField47 = skipUndoDateTimeField46.getWrappedField();
//        long long50 = skipUndoDateTimeField46.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial51 = null;
//        int[] intArray59 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray61 = skipUndoDateTimeField46.add(readablePartial51, 19670, intArray59, 0);
//        int int62 = zeroIsMaxDateTimeField24.getMaximumValue((org.joda.time.ReadablePartial) localTime41, intArray61);
//        int[] intArray69 = new int[] { 19674, 3, (byte) 10, 19672, 19 };
//        java.util.Locale locale71 = null;
//        int[] intArray72 = zeroIsMaxDateTimeField10.set((org.joda.time.ReadablePartial) localTime41, 0, intArray69, "19", locale71);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 19681 + "'", int29 == 19681);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(localTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 60 + "'", int34 == 60);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 19681 + "'", int37 == 19681);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(localTime41);
//        org.junit.Assert.assertNotNull(gJChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 49L + "'", long50 == 49L);
//        org.junit.Assert.assertNotNull(intArray59);
//        org.junit.Assert.assertNotNull(intArray61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 60 + "'", int62 == 60);
//        org.junit.Assert.assertNotNull(intArray69);
//        org.junit.Assert.assertNotNull(intArray72);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int int0 = org.joda.time.MutableDateTime.ROUND_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("2019-W24");
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        java.lang.String str2 = property1.getName();
        int int3 = property1.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "monthOfYear" + "'", str2.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
//        int int3 = mutableDateTime1.getSecondOfDay();
//        int int6 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime1, "monthOfYear", (int) (short) 1);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime1.dayOfWeek();
//        org.joda.time.DurationField durationField8 = property7.getDurationField();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19683 + "'", int3 == 19683);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2) + "'", int6 == (-2));
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(durationField8);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 2000);
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str3 = julianChronology2.toString();
        org.joda.time.Chronology chronology4 = julianChronology2.withUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime5.addDays(0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime dateTime11 = dateTime9.withYear((int) 'a');
        mutableDateTime4.setMillis((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property14 = dateTime13.minuteOfDay();
        java.util.Locale locale15 = null;
        int int16 = property14.getMaximumShortTextLength(locale15);
        org.joda.time.DateTime dateTime18 = property14.setCopy((int) (byte) 0);
        boolean boolean19 = dateTime11.isAfter((org.joda.time.ReadableInstant) dateTime18);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        try {
//            mutableDateTime0.setWeekOfWeekyear((-19666));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -19666 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19683 + "'", int2 == 19683);
//        org.junit.Assert.assertNotNull(dateTime4);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
//        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
//        long long10 = skipUndoDateTimeField4.roundFloor((long) (short) 1);
//        int int11 = skipUndoDateTimeField4.getMaximumValue();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField15 = gJChronology13.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField(chronology12, dateTimeField15);
//        org.joda.time.DateTimeField dateTimeField17 = skipUndoDateTimeField16.getWrappedField();
//        long long20 = skipUndoDateTimeField16.getDifferenceAsLong(1560342467589L, (long) ' ');
//        long long22 = skipUndoDateTimeField16.roundFloor((long) (short) 1);
//        int int23 = skipUndoDateTimeField16.getMaximumValue();
//        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property25 = mutableDateTime24.monthOfYear();
//        int int26 = mutableDateTime24.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = mutableDateTime24.toDateTime(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = dateTime28.toDateTime();
//        org.joda.time.LocalTime localTime30 = dateTime29.toLocalTime();
//        int int31 = skipUndoDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localTime30);
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField35 = gJChronology34.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField36 = gJChronology34.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField(chronology33, dateTimeField36);
//        org.joda.time.DateTimeField dateTimeField38 = skipUndoDateTimeField37.getWrappedField();
//        long long41 = skipUndoDateTimeField37.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial42 = null;
//        int[] intArray50 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray52 = skipUndoDateTimeField37.add(readablePartial42, 19670, intArray50, 0);
//        java.util.Locale locale54 = null;
//        try {
//            int[] intArray55 = skipUndoDateTimeField4.set((org.joda.time.ReadablePartial) localTime30, 19678, intArray52, "2019-W24", locale54);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-W24\" for yearOfCentury is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 49L + "'", long20 == 49L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31507200000L) + "'", long22 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19683 + "'", int26 == 19683);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(gJChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 49L + "'", long41 == 49L);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertNotNull(intArray52);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer3, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(chronology2);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        java.lang.String str5 = mutableDateTime0.toString();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19683 + "'", int2 == 19683);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-12T05:28:03.598-07:00" + "'", str5.equals("2019-06-12T05:28:03.598-07:00"));
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
        long long15 = zeroIsMaxDateTimeField10.add(12L, 2000);
        long long17 = zeroIsMaxDateTimeField10.roundCeiling((long) (short) 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2000012L + "'", long15 == 2000012L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        try {
            org.joda.time.DateTime dateTime4 = dateTimeFormatter0.parseDateTime("19666");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"19666\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(chronology2);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime5.era();
//        try {
//            org.joda.time.DateTime dateTime8 = property6.addToCopy(52);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19684 + "'", int2 == 19684);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.monthOfYear();
//        int int15 = mutableDateTime13.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = mutableDateTime13.toDateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
//        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
//        int int20 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime19);
//        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.monthOfYear();
//        int int23 = mutableDateTime21.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = mutableDateTime21.toDateTime(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = dateTime25.toDateTime();
//        org.joda.time.LocalTime localTime27 = dateTime26.toLocalTime();
//        org.joda.time.Chronology chronology28 = null;
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField31 = gJChronology29.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField(chronology28, dateTimeField31);
//        org.joda.time.DateTimeField dateTimeField33 = skipUndoDateTimeField32.getWrappedField();
//        long long36 = skipUndoDateTimeField32.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        int[] intArray45 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray47 = skipUndoDateTimeField32.add(readablePartial37, 19670, intArray45, 0);
//        int int48 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime27, intArray47);
//        long long50 = zeroIsMaxDateTimeField10.roundHalfFloor((long) 19679);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19684 + "'", int15 == 19684);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 60 + "'", int20 == 60);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19684 + "'", int23 == 19684);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(localTime27);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 49L + "'", long36 == 49L);
//        org.junit.Assert.assertNotNull(intArray45);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 60 + "'", int48 == 60);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 20000L + "'", long50 == 20000L);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.lang.String str1 = julianChronology0.toString();
//        org.joda.time.DurationField durationField2 = julianChronology0.hours();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
//        org.joda.time.DurationField durationField5 = gJChronology3.millis();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType9);
//        int int15 = zeroIsMaxDateTimeField13.getMaximumValue((long) 2);
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField17 = gJChronology16.weekyears();
//        org.joda.time.DurationField durationField18 = gJChronology16.millis();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology16.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType22);
//        int int28 = zeroIsMaxDateTimeField26.getMaximumValue((long) 2);
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
//        int int31 = mutableDateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = mutableDateTime29.toDateTime(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = dateTime33.toDateTime();
//        org.joda.time.LocalTime localTime35 = dateTime34.toLocalTime();
//        org.joda.time.Chronology chronology36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField38 = gJChronology37.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField39 = gJChronology37.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField(chronology36, dateTimeField39);
//        org.joda.time.DateTimeField dateTimeField41 = skipUndoDateTimeField40.getWrappedField();
//        long long44 = skipUndoDateTimeField40.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        int[] intArray53 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray55 = skipUndoDateTimeField40.add(readablePartial45, 19670, intArray53, 0);
//        int int56 = zeroIsMaxDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime35, intArray53);
//        java.util.Locale locale58 = null;
//        java.lang.String str59 = zeroIsMaxDateTimeField13.getAsText((org.joda.time.ReadablePartial) localTime35, 12, locale58);
//        long long61 = julianChronology0.set((org.joda.time.ReadablePartial) localTime35, (long) '#');
//        try {
//            long long66 = julianChronology0.getDateTimeMillis(100, (int) (short) 10, 19666, 3);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19666 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str1.equals("JulianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 60 + "'", int15 == 60);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 60 + "'", int28 == 60);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 19685 + "'", int31 == 19685);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(localTime35);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 49L + "'", long44 == 49L);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 60 + "'", int56 == 60);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "12" + "'", str59.equals("12"));
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-37914840L) + "'", long61 == (-37914840L));
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
        boolean boolean14 = zeroIsMaxDateTimeField10.isLeap((-1L));
        java.util.Locale locale17 = null;
        try {
            long long18 = zeroIsMaxDateTimeField10.set((long) 19670, "19666", locale17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19666 for monthOfYear must be in the range [1,60]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.addMonths((-1));
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime8 = mutableDateTime4.copy();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        mutableDateTime8.add(readablePeriod9);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) (-2), 19675);
        long long9 = dateTimeParserBucket7.computeMillis(false);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 30800012L + "'", long9 == 30800012L);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime0.secondOfDay();
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        mutableDateTime0.add(readableDuration6, (int) (byte) 10);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19685 + "'", int2 == 19685);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder8.toDateTimeZone("monthOfYear", false);
        java.lang.String str13 = dateTimeZone11.getShortName(0L);
        mutableDateTime4.setZoneRetainFields(dateTimeZone11);
        try {
            org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (long) 0, 19685);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 19685");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType9, (int) (short) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter22.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser24 = dateTimeFormatter23.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder21.append(dateTimeParser24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeParser24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.plusYears((int) (short) 0);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime4.plus(readablePeriod7);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19685 + "'", int2 == 19685);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        boolean boolean1 = dateTimeFormatter0.isParser();
        try {
            org.joda.time.LocalTime localTime3 = dateTimeFormatter0.parseLocalTime("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong((long) 19670, (-1L));
        long long10 = skipUndoDateTimeField4.roundHalfEven(0L);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4);
        long long13 = skipUndoDateTimeField4.roundCeiling((long) 19666);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800000L + "'", long13 == 28800000L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendClockhourOfDay(19667);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendClockhourOfHalfday((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder23.appendYear(0, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder23.appendClockhourOfDay(2000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField9 = gJChronology8.weekyears();
//        org.joda.time.DurationField durationField10 = gJChronology8.millis();
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField18 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField11, dateTimeFieldType14);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder5.appendFixedDecimal(dateTimeFieldType14, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property27 = mutableDateTime0.property(dateTimeFieldType14);
//        org.joda.time.DurationField durationField28 = property27.getLeapDurationField();
//        try {
//            org.joda.time.MutableDateTime mutableDateTime30 = property27.set("monthOfYear");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"monthOfYear\" for monthOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19686 + "'", int2 == 19686);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(durationField28);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("monthOfYear", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (short) 1, 'a', 0, 2, 19671, true, 60);
        java.io.OutputStream outputStream13 = null;
        try {
            dateTimeZoneBuilder0.writeTo("JulianChronology[America/Los_Angeles]", outputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            mutableDateTime4.add(durationFieldType6, 69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.monthOfYear();
//        int int15 = mutableDateTime13.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = mutableDateTime13.toDateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
//        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
//        int int20 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime19);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField22 = gJChronology21.weekyears();
//        org.joda.time.DurationField durationField23 = gJChronology21.millis();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType27, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField31 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField24, dateTimeFieldType27);
//        long long33 = zeroIsMaxDateTimeField31.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.monthOfYear();
//        int int36 = mutableDateTime34.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTime dateTime38 = mutableDateTime34.toDateTime(dateTimeZone37);
//        org.joda.time.DateTime dateTime39 = dateTime38.toDateTime();
//        org.joda.time.LocalTime localTime40 = dateTime39.toLocalTime();
//        int int41 = zeroIsMaxDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) localTime40);
//        org.joda.time.MutableDateTime mutableDateTime42 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property43 = mutableDateTime42.monthOfYear();
//        int int44 = mutableDateTime42.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateTime dateTime46 = mutableDateTime42.toDateTime(dateTimeZone45);
//        org.joda.time.DateTime dateTime47 = dateTime46.toDateTime();
//        org.joda.time.LocalTime localTime48 = dateTime47.toLocalTime();
//        org.joda.time.Chronology chronology49 = null;
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology50.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField(chronology49, dateTimeField52);
//        org.joda.time.DateTimeField dateTimeField54 = skipUndoDateTimeField53.getWrappedField();
//        long long57 = skipUndoDateTimeField53.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial58 = null;
//        int[] intArray66 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray68 = skipUndoDateTimeField53.add(readablePartial58, 19670, intArray66, 0);
//        int int69 = zeroIsMaxDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) localTime48, intArray68);
//        java.util.Locale locale71 = null;
//        java.lang.String str72 = zeroIsMaxDateTimeField10.getAsText((org.joda.time.ReadablePartial) localTime48, 52, locale71);
//        org.joda.time.MutableDateTime mutableDateTime73 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property74 = mutableDateTime73.monthOfYear();
//        int int75 = mutableDateTime73.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone76 = null;
//        org.joda.time.DateTime dateTime77 = mutableDateTime73.toDateTime(dateTimeZone76);
//        org.joda.time.DateTime dateTime78 = dateTime77.toDateTime();
//        org.joda.time.chrono.GJChronology gJChronology79 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField80 = gJChronology79.weekyears();
//        org.joda.time.DurationField durationField81 = gJChronology79.millis();
//        org.joda.time.DateTimeField dateTimeField82 = gJChronology79.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime83 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property84 = mutableDateTime83.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType85 = property84.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException88 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType85, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField89 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField82, dateTimeFieldType85);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException92 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType85, (java.lang.Number) (short) 100, "monthOfYear");
//        org.joda.time.DateTime.Property property93 = dateTime77.property(dateTimeFieldType85);
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField94 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType85);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19686 + "'", int15 == 19686);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 60 + "'", int20 == 60);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 19686 + "'", int36 == 19686);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(localTime40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 60 + "'", int41 == 60);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 19686 + "'", int44 == 19686);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(localTime48);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 49L + "'", long57 == 49L);
//        org.junit.Assert.assertNotNull(intArray66);
//        org.junit.Assert.assertNotNull(intArray68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 60 + "'", int69 == 60);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "52" + "'", str72.equals("52"));
//        org.junit.Assert.assertNotNull(property74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 19686 + "'", int75 == 19686);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertNotNull(gJChronology79);
//        org.junit.Assert.assertNotNull(durationField80);
//        org.junit.Assert.assertNotNull(durationField81);
//        org.junit.Assert.assertNotNull(dateTimeField82);
//        org.junit.Assert.assertNotNull(property84);
//        org.junit.Assert.assertNotNull(dateTimeFieldType85);
//        org.junit.Assert.assertNotNull(property93);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType9, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("July", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 0, "DateTimeField[monthOfYear]");
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime2 = mutableDateTime0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.copy();
        int int4 = mutableDateTime3.getCenturyOfEra();
        mutableDateTime3.addSeconds(5);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.lang.String str1 = julianChronology0.toString();
//        org.joda.time.DurationField durationField2 = julianChronology0.hours();
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.monthOfYear();
//        int int5 = mutableDateTime3.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = mutableDateTime3.toDateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime7.toDateTime();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField10 = gJChronology9.weekyears();
//        org.joda.time.DurationField durationField11 = gJChronology9.millis();
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField12, dateTimeFieldType15);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, (java.lang.Number) (short) 100, "monthOfYear");
//        org.joda.time.DateTime.Property property23 = dateTime7.property(dateTimeFieldType15);
//        org.joda.time.DurationField durationField24 = property23.getRangeDurationField();
//        boolean boolean25 = julianChronology0.equals((java.lang.Object) durationField24);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str1.equals("JulianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19686 + "'", int5 == 19686);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.monthOfYear();
//        int int5 = mutableDateTime3.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths(1);
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTimeZoneBuilder10.toDateTimeZone("monthOfYear", false);
//        org.joda.time.DateTime dateTime14 = dateTime9.withZone(dateTimeZone13);
//        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology1, (org.joda.time.ReadableDateTime) mutableDateTime3, (org.joda.time.ReadableDateTime) dateTime14);
//        boolean boolean16 = dateTime0.isBefore((org.joda.time.ReadableInstant) dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19687 + "'", int5 == 19687);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(limitChronology15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        java.lang.Object obj2 = mutableDateTime0.clone();
//        mutableDateTime0.addMinutes(19669);
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.monthOfYear();
//        int int7 = mutableDateTime5.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = mutableDateTime5.toDateTime(dateTimeZone8);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField14 = gJChronology13.weekyears();
//        org.joda.time.DurationField durationField15 = gJChronology13.millis();
//        org.joda.time.DateTimeField dateTimeField16 = gJChronology13.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField16, dateTimeFieldType19);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder10.appendFixedDecimal(dateTimeFieldType19, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property32 = mutableDateTime5.property(dateTimeFieldType19);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 0.0f, "59");
//        try {
//            mutableDateTime0.set(dateTimeFieldType19, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19687 + "'", int7 == 19687);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(property32);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.monthOfYear();
//        int int4 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusMonths(1);
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("monthOfYear", false);
//        org.joda.time.DateTime dateTime13 = dateTime8.withZone(dateTimeZone12);
//        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) mutableDateTime2, (org.joda.time.ReadableDateTime) dateTime13);
//        try {
//            long long22 = limitChronology14.getDateTimeMillis((int) (short) 100, 19680, (int) '#', 5929, 2, 2000, 19687);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5929 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19687 + "'", int4 == 19687);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(limitChronology14);
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.monthOfYear();
//        int int4 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusMonths(1);
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("monthOfYear", false);
//        org.joda.time.DateTime dateTime13 = dateTime8.withZone(dateTimeZone12);
//        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) mutableDateTime2, (org.joda.time.ReadableDateTime) dateTime13);
//        try {
//            long long20 = limitChronology14.getDateTimeMillis((long) ' ', 5929, 52, 2019, 19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 2019-06-12T05:28:07.634-07:00 (GJChronology[America/Los_Angeles])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19687 + "'", int4 == 19687);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(limitChronology14);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
        boolean boolean14 = zeroIsMaxDateTimeField10.isLeap((-1L));
        long long17 = zeroIsMaxDateTimeField10.getDifferenceAsLong((long) '#', (-61567747621948L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 61567747621L + "'", long17 == 61567747621L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear(19666);
        org.joda.time.DateTime.Property property6 = dateTime3.year();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.dayOfMonth();
        try {
            org.joda.time.MutableDateTime mutableDateTime9 = property7.set(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withDayOfYear((int) (short) 100);
//        org.joda.time.DateTime dateTime11 = dateTime9.withYear((int) 'a');
//        mutableDateTime4.setMillis((org.joda.time.ReadableInstant) dateTime11);
//        int int13 = dateTime11.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        try {
            mutableDateTime4.setDate((int) ' ', 5, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong((long) 19670, (-1L));
        long long10 = skipUndoDateTimeField4.roundHalfEven(0L);
        boolean boolean11 = skipUndoDateTimeField4.isLenient();
        int int12 = skipUndoDateTimeField4.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 19674);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.DateTime dateTime4 = instant3.toDateTime();
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField14 = gJChronology13.weekyears();
//        org.joda.time.DurationField durationField15 = gJChronology13.millis();
//        org.joda.time.DateTimeField dateTimeField16 = gJChronology13.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField16, dateTimeFieldType19);
//        org.joda.time.DurationField durationField24 = zeroIsMaxDateTimeField23.getDurationField();
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = zeroIsMaxDateTimeField23.getAsText((long) (short) -1, locale26);
//        long long29 = zeroIsMaxDateTimeField23.roundCeiling((-31507200000L));
//        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.monthOfYear();
//        int int32 = mutableDateTime30.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = mutableDateTime30.toDateTime(dateTimeZone33);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField39 = gJChronology38.weekyears();
//        org.joda.time.DurationField durationField40 = gJChronology38.millis();
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology38.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime42 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property43 = mutableDateTime42.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException47 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType44, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField48 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField41, dateTimeFieldType44);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType44, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException54 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType44, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType44, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property57 = mutableDateTime30.property(dateTimeFieldType44);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField61 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField23, dateTimeFieldType44, 4, (int) ' ', 19666);
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType44);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "59" + "'", str27.equals("59"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-31507200000L) + "'", long29 == (-31507200000L));
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 19688 + "'", int32 == 19688);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(gJChronology38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertNotNull(property57);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long11 = skipUndoDateTimeField4.getDifferenceAsLong((long) 0, (long) (short) 10);
        long long13 = skipUndoDateTimeField4.roundHalfEven((long) 19670);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800000L + "'", long13 == 28800000L);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
//        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
//        int int19 = mutableDateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
//        org.joda.time.DurationField durationField27 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
//        int int50 = offsetDateTimeField48.getLeapAmount((long) (short) 10);
//        long long52 = offsetDateTimeField48.remainder(6241369870356L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19689 + "'", int19 == 19689);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 356L + "'", long52 == 356L);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeZoneBuilder4.toDateTimeZone("monthOfYear", false);
        org.joda.time.DateTime dateTime8 = dateTime3.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour(0);
        try {
            org.joda.time.DateTime dateTime15 = dateTime8.withTime(3, 8, 0, 19666);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19666 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long10 = skipUndoDateTimeField4.roundFloor((long) (short) 1);
        int int11 = skipUndoDateTimeField4.getMaximumValue();
        try {
            long long14 = skipUndoDateTimeField4.set(100L, "JulianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"JulianChronology[America/Los_Angeles]\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withYear(19666);
//        org.joda.time.YearMonthDay yearMonthDay7 = dateTime6.toYearMonthDay();
//        long long9 = gregorianChronology0.set((org.joda.time.ReadablePartial) yearMonthDay7, 2000012L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(yearMonthDay7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 558445966400012L + "'", long9 == 558445966400012L);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
        int int9 = mutableDateTime4.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = mutableDateTime4.getZone();
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now(dateTimeZone10);
        mutableDateTime11.addWeekyears(1);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("hi!", 19685, 3, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19685 for hi! must be in the range [3,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField9 = gJChronology8.weekyears();
//        org.joda.time.DurationField durationField10 = gJChronology8.millis();
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField18 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField11, dateTimeFieldType14);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder5.appendFixedDecimal(dateTimeFieldType14, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property27 = mutableDateTime0.property(dateTimeFieldType14);
//        org.joda.time.DurationField durationField28 = property27.getLeapDurationField();
//        org.joda.time.DurationFieldType durationFieldType29 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField28, durationFieldType29, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19689 + "'", int2 == 19689);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(durationField28);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(3, 69, 19676, (int) (short) 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-12T05", (java.lang.Number) 2, (java.lang.Number) 0, number3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong((long) 19670, (-1L));
        int int9 = skipUndoDateTimeField4.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("DateTimeField[yearOfCentury]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"DateTimeField[yearOfCentury]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfDay((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(2, false);
//        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.monthOfYear();
//        int int10 = mutableDateTime8.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = mutableDateTime8.toDateTime(dateTimeZone11);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField17 = gJChronology16.weekyears();
//        org.joda.time.DurationField durationField18 = gJChronology16.millis();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology16.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType22);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder13.appendFixedDecimal(dateTimeFieldType22, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property35 = mutableDateTime8.property(dateTimeFieldType22);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType22, 19679, 52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19690 + "'", int10 == 19690);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatterBuilder0.toFormatter();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Both printing and parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
        org.joda.time.DateTime dateTime3 = dateTime0.plusMinutes((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField7 = gJChronology6.weekyears();
        org.joda.time.DurationField durationField8 = gJChronology6.millis();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.minus(readablePeriod11);
        org.joda.time.DateTime.Property property13 = dateTime10.weekOfWeekyear();
        boolean boolean14 = gJChronology6.equals((java.lang.Object) dateTime10);
        org.joda.time.DateTime dateTime15 = dateTime5.toDateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeZoneBuilder16.toDateTimeZone("monthOfYear", false);
        java.lang.String str21 = dateTimeZone19.getShortName(0L);
        try {
            org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((java.lang.Object) gJChronology6, dateTimeZone19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GJChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00" + "'", str21.equals("+00:00"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.hourOfHalfday();
        java.util.Locale locale20 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket21 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology18, locale20);
        java.util.Locale locale22 = dateTimeParserBucket21.getLocale();
        try {
            long long23 = zeroIsMaxDateTimeField10.set(19049L, "DateTimeField[yearOfCentury]", locale22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[yearOfCentury]\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(locale22);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
//        mutableDateTime4.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        mutableDateTime4.setMillis(readableInstant9);
//        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime4);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560342490972L + "'", long11 == 1560342490972L);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology1.getZone();
        org.joda.time.DurationField durationField6 = gJChronology1.years();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
        org.joda.time.DateTime dateTime3 = dateTime0.plusMinutes((int) '4');
        org.joda.time.DateTime.Property property4 = dateTime0.minuteOfHour();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        java.lang.String str5 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField6 = gregorianChronology0.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str5.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int8 = gregorianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology11 = gregorianChronology7.withZone(dateTimeZone10);
        long long14 = dateTimeZone10.convertLocalToUTC(19L, false);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) '#', 19690, 19687, 19689, (int) (short) 0, (-2), 19666, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19689 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 19L + "'", long14 == 19L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        java.lang.String str5 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str5.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
//        java.util.Locale locale3 = null;
//        int int4 = property2.getMaximumShortTextLength(locale3);
//        org.joda.time.DateTime dateTime6 = property2.setCopy((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        java.lang.String str8 = dateTime6.toString(dateTimeFormatter7);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.parse("July", dateTimeFormatter7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"July\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019163T000011.232-0700" + "'", str8.equals("2019163T000011.232-0700"));
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        long long5 = durationField2.subtract(0L, 100L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-8643600000L) + "'", long5 == (-8643600000L));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.addMonths((-1));
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundHalfEven();
        try {
            mutableDateTime8.setMinuteOfHour(60);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 60 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str1 = julianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        try {
            long long7 = julianChronology0.getDateTimeMillis(0, (int) (short) 0, 19689901, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str1.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        long long13 = zeroIsMaxDateTimeField10.set((long) 52, "59");
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = zeroIsMaxDateTimeField10.getType();
//        int int16 = zeroIsMaxDateTimeField10.getMaximumValue((long) (-1));
//        org.joda.time.Chronology chronology17 = null;
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField(chronology17, dateTimeField20);
//        org.joda.time.DateTimeField dateTimeField22 = skipUndoDateTimeField21.getWrappedField();
//        long long25 = skipUndoDateTimeField21.getDifferenceAsLong(1560342467589L, (long) ' ');
//        long long27 = skipUndoDateTimeField21.roundFloor((long) (short) 1);
//        int int28 = skipUndoDateTimeField21.getMaximumValue();
//        org.joda.time.DurationField durationField29 = skipUndoDateTimeField21.getLeapDurationField();
//        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.monthOfYear();
//        int int32 = mutableDateTime30.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = mutableDateTime30.toDateTime(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = dateTime34.toDateTime();
//        org.joda.time.LocalTime localTime36 = dateTime35.toLocalTime();
//        int int37 = skipUndoDateTimeField21.getMinimumValue((org.joda.time.ReadablePartial) localTime36);
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField40 = gJChronology39.weekyears();
//        org.joda.time.DurationField durationField41 = gJChronology39.millis();
//        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime43.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property44.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField49 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField42, dateTimeFieldType45);
//        long long51 = zeroIsMaxDateTimeField49.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime52 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property53 = mutableDateTime52.monthOfYear();
//        int int54 = mutableDateTime52.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.DateTime dateTime56 = mutableDateTime52.toDateTime(dateTimeZone55);
//        org.joda.time.DateTime dateTime57 = dateTime56.toDateTime();
//        org.joda.time.LocalTime localTime58 = dateTime57.toLocalTime();
//        int int59 = zeroIsMaxDateTimeField49.getMaximumValue((org.joda.time.ReadablePartial) localTime58);
//        org.joda.time.MutableDateTime mutableDateTime60 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property61 = mutableDateTime60.monthOfYear();
//        int int62 = mutableDateTime60.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone63 = null;
//        org.joda.time.DateTime dateTime64 = mutableDateTime60.toDateTime(dateTimeZone63);
//        org.joda.time.DateTime dateTime65 = dateTime64.toDateTime();
//        org.joda.time.LocalTime localTime66 = dateTime65.toLocalTime();
//        org.joda.time.Chronology chronology67 = null;
//        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField69 = gJChronology68.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField70 = gJChronology68.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField71 = new org.joda.time.field.SkipUndoDateTimeField(chronology67, dateTimeField70);
//        org.joda.time.DateTimeField dateTimeField72 = skipUndoDateTimeField71.getWrappedField();
//        long long75 = skipUndoDateTimeField71.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial76 = null;
//        int[] intArray84 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray86 = skipUndoDateTimeField71.add(readablePartial76, 19670, intArray84, 0);
//        int int87 = zeroIsMaxDateTimeField49.getMaximumValue((org.joda.time.ReadablePartial) localTime66, intArray86);
//        try {
//            int[] intArray89 = zeroIsMaxDateTimeField10.addWrapField((org.joda.time.ReadablePartial) localTime36, 19685, intArray86, (int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19685");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 59052L + "'", long13 == 59052L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 60 + "'", int16 == 60);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 49L + "'", long25 == 49L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-31507200000L) + "'", long27 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
//        org.junit.Assert.assertNull(durationField29);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 19691 + "'", int32 == 19691);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(localTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 19691 + "'", int54 == 19691);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(localTime58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 60 + "'", int59 == 60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 19691 + "'", int62 == 19691);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(localTime66);
//        org.junit.Assert.assertNotNull(gJChronology68);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 49L + "'", long75 == 49L);
//        org.junit.Assert.assertNotNull(intArray84);
//        org.junit.Assert.assertNotNull(intArray86);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 60 + "'", int87 == 60);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        java.lang.String str17 = illegalFieldValueException16.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 0 for monthOfYear must be in the range [4,0.0]" + "'", str17.equals("org.joda.time.IllegalFieldValueException: Value 0 for monthOfYear must be in the range [4,0.0]"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
//        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
//        long long10 = skipUndoDateTimeField4.roundFloor((long) (short) 1);
//        int int11 = skipUndoDateTimeField4.getMaximumValue();
//        org.joda.time.DurationField durationField12 = skipUndoDateTimeField4.getLeapDurationField();
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.monthOfYear();
//        int int15 = mutableDateTime13.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = mutableDateTime13.toDateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
//        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
//        int int20 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime19);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField22 = gJChronology21.weekyears();
//        org.joda.time.DurationField durationField23 = gJChronology21.millis();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType27, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField31 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField24, dateTimeFieldType27);
//        int int33 = zeroIsMaxDateTimeField31.getMaximumValue((long) 2);
//        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.monthOfYear();
//        int int36 = mutableDateTime34.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTime dateTime38 = mutableDateTime34.toDateTime(dateTimeZone37);
//        org.joda.time.DateTime dateTime39 = dateTime38.toDateTime();
//        org.joda.time.LocalTime localTime40 = dateTime39.toLocalTime();
//        org.joda.time.Chronology chronology41 = null;
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = gJChronology42.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField44 = gJChronology42.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField45 = new org.joda.time.field.SkipUndoDateTimeField(chronology41, dateTimeField44);
//        org.joda.time.DateTimeField dateTimeField46 = skipUndoDateTimeField45.getWrappedField();
//        long long49 = skipUndoDateTimeField45.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial50 = null;
//        int[] intArray58 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray60 = skipUndoDateTimeField45.add(readablePartial50, 19670, intArray58, 0);
//        int int61 = zeroIsMaxDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) localTime40, intArray58);
//        int[] intArray62 = null;
//        try {
//            int int63 = skipUndoDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localTime40, intArray62);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
//        org.junit.Assert.assertNull(durationField12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19692 + "'", int15 == 19692);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 60 + "'", int33 == 60);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 19692 + "'", int36 == 19692);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(localTime40);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 49L + "'", long49 == 49L);
//        org.junit.Assert.assertNotNull(intArray58);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 60 + "'", int61 == 60);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        int int9 = dateTimeZone7.getOffsetFromLocal((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone10);
        int int13 = cachedDateTimeZone10.getStandardOffset((long) 12);
        try {
            org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime(5929, 12, 19667, 20, (int) (byte) 0, 19680, 19689901, (org.joda.time.DateTimeZone) cachedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19680 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, "hi!");
        java.lang.String str13 = illegalFieldValueException12.getFieldName();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "monthOfYear" + "'", str13.equals("monthOfYear"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 19674);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        long long4 = instant1.getMillis();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 19674L + "'", long4 == 19674L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 1, 19691);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19691 + "'", int2 == 19691);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        org.joda.time.format.DateTimePrinter dateTimePrinter21 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter22.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser24 = dateTimeFormatter23.getParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter21, dateTimeParser24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeParser24);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField7 = gJChronology6.weekyears();
//        org.joda.time.DurationField durationField8 = gJChronology6.millis();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime10.minus(readablePeriod11);
//        org.joda.time.DateTime.Property property13 = dateTime10.weekOfWeekyear();
//        boolean boolean14 = gJChronology6.equals((java.lang.Object) dateTime10);
//        int int15 = property5.getDifference((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology18);
//        mutableDateTime21.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        mutableDateTime21.setZoneRetainFields(dateTimeZone24);
//        int int26 = mutableDateTime21.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone27 = mutableDateTime21.getZone();
//        long long30 = dateTimeZone27.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField34 = gregorianChronology33.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder35 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone38 = dateTimeZoneBuilder35.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology39 = gregorianChronology33.withZone(dateTimeZone38);
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.hourOfHalfday();
//        java.util.Locale locale43 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket44 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology41, locale43);
//        java.util.Locale locale45 = dateTimeParserBucket44.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket47 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology39, locale45, (java.lang.Integer) 19671);
//        java.lang.String str48 = dateTimeZone27.getShortName((long) 2000, locale45);
//        try {
//            java.lang.String str49 = dateTime10.toString("", locale45);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-18059) + "'", int15 == (-18059));
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 19684L + "'", long30 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(chronology39);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(locale45);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "PST" + "'", str48.equals("PST"));
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField7 = gJChronology6.weekyears();
//        org.joda.time.DurationField durationField8 = gJChronology6.millis();
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField16 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType12);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) (short) 100, "monthOfYear");
//        org.joda.time.DateTime.Property property20 = dateTime4.property(dateTimeFieldType12);
//        try {
//            org.joda.time.DateTime dateTime22 = property20.setCopy((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19692 + "'", int2 == 19692);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(property20);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int6 = gregorianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology9 = gregorianChronology5.withZone(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(52, 52, 27, 19670, 19676, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19670 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(19671, 0, 19683, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime5 = property4.getDateTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(19686, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19686 + "'", int2 == 19686);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        long long6 = cachedDateTimeZone3.nextTransition((long) 19672);
        int int8 = cachedDateTimeZone3.getOffsetFromLocal((-1861920000000L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19672L + "'", long6 == 19672L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("1969-12-18T16:12:02.000-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-18T16:12:02.000-08:00\" is malformed at \"-12-18T16:12:02.000-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        long long6 = cachedDateTimeZone3.previousTransition((long) 4);
        long long8 = cachedDateTimeZone3.nextTransition(1613L);
        try {
            org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone3, (long) 328, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 4L + "'", long6 == 4L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1613L + "'", long8 == 1613L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        int int1 = dateTimeFormatter0.getDefaultYear();
        try {
            org.joda.time.LocalDateTime localDateTime3 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("monthOfYear", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (short) 1, 'a', 0, 2, 19671, true, 60);
        java.io.OutputStream outputStream13 = null;
        try {
            dateTimeZoneBuilder11.writeTo("July", outputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("monthOfYear", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (short) 1, 'a', 0, 2, 19671, true, 60);
        java.io.DataOutput dataOutput13 = null;
        try {
            dateTimeZoneBuilder0.writeTo("-1", dataOutput13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        java.lang.String str2 = property1.getName();
        try {
            org.joda.time.MutableDateTime mutableDateTime4 = property1.set(163);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 163 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "monthOfYear" + "'", str2.equals("monthOfYear"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(0, 5929, 0, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5929 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
//        mutableDateTime4.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
//        int int9 = mutableDateTime4.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = mutableDateTime4.getZone();
//        long long13 = dateTimeZone10.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField17 = gregorianChronology16.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone21 = dateTimeZoneBuilder18.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology22 = gregorianChronology16.withZone(dateTimeZone21);
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.hourOfHalfday();
//        java.util.Locale locale26 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology24, locale26);
//        java.util.Locale locale28 = dateTimeParserBucket27.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket30 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology22, locale28, (java.lang.Integer) 19671);
//        java.lang.String str31 = dateTimeZone10.getShortName((long) 2000, locale28);
//        java.lang.String str33 = dateTimeZone10.getName(0L);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 19684L + "'", long13 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(locale28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "PST" + "'", str31.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Pacific Standard Time" + "'", str33.equals("Pacific Standard Time"));
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = property1.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType2, (java.lang.Number) 19666, "");
        java.lang.Number number6 = illegalFieldValueException5.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeFieldType2);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 19666 + "'", number6.equals(19666));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int int0 = org.joda.time.MutableDateTime.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        java.lang.String str2 = property1.getName();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.add((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime4.toMutableDateTime(dateTimeZone5);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            mutableDateTime4.add(durationFieldType7, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "monthOfYear" + "'", str2.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfCentury(52);
        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes(19679);
        int int9 = dateTime8.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2052 + "'", int9 == 2052);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime dateTime11 = dateTime9.withYear((int) 'a');
        mutableDateTime4.setMillis((org.joda.time.ReadableInstant) dateTime11);
        try {
            org.joda.time.DateTime dateTime16 = dateTime11.withDate(19687, 19688, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19688 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter2.getParser();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeFormatter2.getZone();
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.parse("+00:00", dateTimeFormatter2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) (short) 100, "monthOfYear");
        java.lang.Number number14 = illegalFieldValueException13.getIllegalNumberValue();
        java.lang.Number number15 = illegalFieldValueException13.getLowerBound();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 100 + "'", number14.equals((short) 100));
        org.junit.Assert.assertNull(number15);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.addMonths((-1));
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.secondOfDay();
        mutableDateTime4.addYears((int) '#');
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology11);
        mutableDateTime14.addMonths((-1));
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime14.secondOfDay();
        boolean boolean18 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime14.secondOfMinute();
        try {
            mutableDateTime14.setMonthOfYear(19678);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19678 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(property19);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.monthOfYear();
//        int int15 = mutableDateTime13.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = mutableDateTime13.toDateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
//        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
//        int int20 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime19);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField22 = gJChronology21.weekyears();
//        org.joda.time.DurationField durationField23 = gJChronology21.millis();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType27, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField31 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField24, dateTimeFieldType27);
//        long long33 = zeroIsMaxDateTimeField31.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.monthOfYear();
//        int int36 = mutableDateTime34.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTime dateTime38 = mutableDateTime34.toDateTime(dateTimeZone37);
//        org.joda.time.DateTime dateTime39 = dateTime38.toDateTime();
//        org.joda.time.LocalTime localTime40 = dateTime39.toLocalTime();
//        int int41 = zeroIsMaxDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) localTime40);
//        org.joda.time.MutableDateTime mutableDateTime42 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property43 = mutableDateTime42.monthOfYear();
//        int int44 = mutableDateTime42.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateTime dateTime46 = mutableDateTime42.toDateTime(dateTimeZone45);
//        org.joda.time.DateTime dateTime47 = dateTime46.toDateTime();
//        org.joda.time.LocalTime localTime48 = dateTime47.toLocalTime();
//        org.joda.time.Chronology chronology49 = null;
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology50.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField(chronology49, dateTimeField52);
//        org.joda.time.DateTimeField dateTimeField54 = skipUndoDateTimeField53.getWrappedField();
//        long long57 = skipUndoDateTimeField53.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial58 = null;
//        int[] intArray66 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray68 = skipUndoDateTimeField53.add(readablePartial58, 19670, intArray66, 0);
//        int int69 = zeroIsMaxDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) localTime48, intArray68);
//        java.util.Locale locale71 = null;
//        java.lang.String str72 = zeroIsMaxDateTimeField10.getAsText((org.joda.time.ReadablePartial) localTime48, 52, locale71);
//        org.joda.time.chrono.GJChronology gJChronology73 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField74 = gJChronology73.weekyears();
//        org.joda.time.DurationField durationField75 = gJChronology73.millis();
//        org.joda.time.DateTimeField dateTimeField76 = gJChronology73.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime77 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property78 = mutableDateTime77.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType79 = property78.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException82 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType79, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField83 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField76, dateTimeFieldType79);
//        long long85 = zeroIsMaxDateTimeField83.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime86 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property87 = mutableDateTime86.monthOfYear();
//        int int88 = mutableDateTime86.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone89 = null;
//        org.joda.time.DateTime dateTime90 = mutableDateTime86.toDateTime(dateTimeZone89);
//        org.joda.time.DateTime dateTime91 = dateTime90.toDateTime();
//        org.joda.time.LocalTime localTime92 = dateTime91.toLocalTime();
//        int int93 = zeroIsMaxDateTimeField83.getMaximumValue((org.joda.time.ReadablePartial) localTime92);
//        int int94 = zeroIsMaxDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localTime92);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19695 + "'", int15 == 19695);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 60 + "'", int20 == 60);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 19695 + "'", int36 == 19695);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(localTime40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 60 + "'", int41 == 60);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 19695 + "'", int44 == 19695);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(localTime48);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 49L + "'", long57 == 49L);
//        org.junit.Assert.assertNotNull(intArray66);
//        org.junit.Assert.assertNotNull(intArray68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 60 + "'", int69 == 60);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "52" + "'", str72.equals("52"));
//        org.junit.Assert.assertNotNull(gJChronology73);
//        org.junit.Assert.assertNotNull(durationField74);
//        org.junit.Assert.assertNotNull(durationField75);
//        org.junit.Assert.assertNotNull(dateTimeField76);
//        org.junit.Assert.assertNotNull(property78);
//        org.junit.Assert.assertNotNull(dateTimeFieldType79);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 0L + "'", long85 == 0L);
//        org.junit.Assert.assertNotNull(property87);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 19695 + "'", int88 == 19695);
//        org.junit.Assert.assertNotNull(dateTime90);
//        org.junit.Assert.assertNotNull(dateTime91);
//        org.junit.Assert.assertNotNull(localTime92);
//        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 60 + "'", int93 == 60);
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1 + "'", int94 == 1);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.hours();
        long long5 = durationField2.subtract((long) 12, 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
        org.joda.time.DateTime dateTime3 = dateTime0.plusMinutes((int) '4');
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField7 = gJChronology6.weekyears();
        org.joda.time.DurationField durationField8 = gJChronology6.millis();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.minus(readablePeriod11);
        org.joda.time.DateTime.Property property13 = dateTime10.weekOfWeekyear();
        boolean boolean14 = gJChronology6.equals((java.lang.Object) dateTime10);
        org.joda.time.DateTime dateTime15 = dateTime5.toDateTime((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTime.Property property16 = dateTime15.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        int int19 = dateTimeZone17.getOffsetFromLocal((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone20 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone17);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone20);
        java.lang.String str23 = cachedDateTimeZone20.getNameKey((long) (byte) 10);
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime15.toMutableDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone20);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UTC" + "'", str23.equals("UTC"));
        org.junit.Assert.assertNotNull(mutableDateTime24);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime5.era();
//        try {
//            org.joda.time.DateTime dateTime8 = property6.setCopy(19680);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19680 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19697 + "'", int2 == 19697);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        int int5 = dateTimeZone3.getOffsetFromLocal((long) 19);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime5.era();
//        try {
//            org.joda.time.DateTime dateTime8 = property6.setCopy("UTC");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for era is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19697 + "'", int2 == 19697);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendClockhourOfDay(19667);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendClockhourOfHalfday((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder23.appendYear(0, (int) (short) 10);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap29 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder23.appendTimeZoneShortName(strMap29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder23.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: PST");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime4.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.add(69);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendClockhourOfDay(19667);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendHourOfHalfday((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekOfWeekyear();
        org.joda.time.Chronology chronology4 = gJChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = buddhistChronology6.withUTC();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(19691, 19669, 12, 0, (-19666), 19670, chronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19669 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay(19676);
        org.joda.time.DateTime dateTime7 = dateTime3.plusWeeks(8);
        org.joda.time.DateTime dateTime8 = dateTime3.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        int int7 = dateTime5.getYearOfCentury();
//        boolean boolean8 = dateTime5.isAfterNow();
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear(2019);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for dayOfYear must be in the range [1,365]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19697 + "'", int2 == 19697);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.monthOfYear();
//        int int7 = mutableDateTime5.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = mutableDateTime5.toDateTime(dateTimeZone8);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime5.secondOfDay();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime5);
//        try {
//            mutableDateTime5.setHourOfDay(19687);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19687 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19697 + "'", int7 == 19697);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime2 = mutableDateTime0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfSecond();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder8.toDateTimeZone("monthOfYear", false);
        java.lang.String str13 = dateTimeZone11.getShortName(0L);
        mutableDateTime4.setZoneRetainFields(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.monthOfYear();
//        int int4 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusMonths(1);
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("monthOfYear", false);
//        org.joda.time.DateTime dateTime13 = dateTime8.withZone(dateTimeZone12);
//        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) mutableDateTime2, (org.joda.time.ReadableDateTime) dateTime13);
//        try {
//            long long20 = limitChronology14.getDateTimeMillis((-192458L), 0, (int) (short) 0, 2019, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 2019-06-12T05:28:17.947-07:00 (GJChronology[America/Los_Angeles])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19697 + "'", int4 == 19697);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(limitChronology14);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gJChronology0.add(readablePeriod5, (long) 12, (-2));
        org.joda.time.DurationField durationField9 = gJChronology0.weekyears();
        int int10 = gJChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gJChronology0.add(readablePeriod5, (long) 12, (-2));
        org.joda.time.DurationField durationField9 = gJChronology0.weekyears();
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        int int11 = mutableDateTime10.getRoundingMode();
        mutableDateTime10.addHours((int) (short) 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(2019, 2000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4038000 + "'", int2 == 4038000);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gJChronology0.add(readablePeriod5, (long) 12, (-2));
        org.joda.time.DurationField durationField9 = gJChronology0.weekyears();
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime12 = property11.roundHalfCeiling();
        long long13 = property11.remainder();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 19670);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-209167272000000L) + "'", long1 == (-209167272000000L));
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime0.minus(readablePeriod2);
//        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay(19676);
//        org.joda.time.DateTime dateTime7 = dateTime3.plusSeconds(19679);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, dateTimeField11);
//        org.joda.time.DateTimeField dateTimeField13 = skipUndoDateTimeField12.getWrappedField();
//        long long16 = skipUndoDateTimeField12.getDifferenceAsLong((long) 19670, (-1L));
//        long long18 = skipUndoDateTimeField12.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.monthOfYear();
//        int int21 = mutableDateTime19.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = mutableDateTime19.toDateTime(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = dateTime23.toDateTime();
//        org.joda.time.LocalTime localTime25 = dateTime24.toLocalTime();
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField12.getAsText((org.joda.time.ReadablePartial) localTime25, 19, locale27);
//        boolean boolean29 = dateTime7.equals((java.lang.Object) 19);
//        boolean boolean30 = dateTime7.isAfterNow();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 19698 + "'", int21 == 19698);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(localTime25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "19" + "'", str28.equals("19"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology2);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) 100, (org.joda.time.Chronology) gJChronology2);
        boolean boolean7 = mutableDateTime6.isEqualNow();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime6.dayOfYear();
        boolean boolean10 = mutableDateTime6.isEqual((long) 19675);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime6.minuteOfHour();
        org.joda.time.ReadablePartial readablePartial12 = null;
        try {
            int int13 = property11.compareTo(readablePartial12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long10 = skipUndoDateTimeField4.roundFloor((long) (short) 1);
        boolean boolean12 = skipUndoDateTimeField4.isLeap((long) 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField17 = gJChronology16.weekyears();
        org.joda.time.DurationField durationField18 = gJChronology16.millis();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology16.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType22);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder13.appendFixedDecimal(dateTimeFieldType22, (int) (short) 100);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType22, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 2000);
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str3 = julianChronology2.toString();
        org.joda.time.Chronology chronology4 = julianChronology2.withUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime1, (org.joda.time.Chronology) julianChronology2);
        mutableDateTime5.setDate((long) 2000);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str3.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay(19676);
        org.joda.time.DateTime dateTime7 = dateTime3.plusSeconds(19679);
        boolean boolean8 = dateTime3.isAfterNow();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 2000);
        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime2);
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = dateTimeFormatter0.parseMutableDateTime("2019-06-12T05");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-12T05\" is malformed at \"19-06-12T05\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "16:00" + "'", str3.equals("16:00"));
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((java.lang.Object) instant0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) instant0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560342498872L + "'", long2 == 1560342498872L);
//    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
//        org.joda.time.DurationField durationField2 = gJChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
//        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
//        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
//        int int19 = mutableDateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
//        org.joda.time.DurationField durationField27 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
//        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
//        int int49 = offsetDateTimeField48.getOffset();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19698 + "'", int19 == 19698);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, "hi!");
        java.lang.String str13 = illegalFieldValueException12.getIllegalStringValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        org.joda.time.DurationField durationField3 = gJChronology0.years();
        java.lang.String str4 = gJChronology0.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str4.equals("GJChronology[America/Los_Angeles]"));
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
//        java.util.Locale locale2 = null;
//        int int3 = property1.getMaximumShortTextLength(locale2);
//        org.joda.time.DateTime dateTime5 = property1.setCopy((int) (byte) 0);
//        int int6 = dateTime5.getMillisOfDay();
//        int int7 = dateTime5.getDayOfYear();
//        org.joda.time.DateTime dateTime8 = dateTime5.withEarlierOffsetAtOverlap();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19148 + "'", int6 == 19148);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 163 + "'", int7 == 163);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.addMonths((-1));
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundCeiling();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology1, locale3);
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        try {
            int[] intArray8 = gJChronology1.get(readablePeriod6, (long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
//        try {
//            mutableDateTime0.setDayOfYear((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19699 + "'", int2 == 19699);
//        org.junit.Assert.assertNotNull(dateTime4);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readablePeriod5);
        org.joda.time.DateTime.Property property7 = dateTime4.weekOfWeekyear();
        boolean boolean8 = gJChronology0.equals((java.lang.Object) dateTime4);
        org.joda.time.DurationField durationField9 = gJChronology0.halfdays();
        org.joda.time.DurationField durationField10 = gJChronology0.halfdays();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology2);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) 100, (org.joda.time.Chronology) gJChronology2);
        boolean boolean7 = mutableDateTime6.isEqualNow();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime6.dayOfYear();
        boolean boolean10 = mutableDateTime6.isEqual((long) 19675);
        try {
            mutableDateTime6.setTime((int) '#', 0, 328, 19680);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType9, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendHourOfHalfday((int) (byte) 1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendSecondOfMinute((-18059));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) 'a');
        org.joda.time.DateTime.Property property6 = dateTime3.weekyear();
        org.joda.time.DateTime.Property property7 = dateTime3.dayOfYear();
        try {
            org.joda.time.DateTime dateTime9 = property7.setCopy("GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[America/Los_Angeles]\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField6 = gJChronology5.hours();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology8);
        mutableDateTime11.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        mutableDateTime11.setZoneRetainFields(dateTimeZone14);
        int int16 = mutableDateTime11.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone17 = mutableDateTime11.getZone();
        org.joda.time.Chronology chronology18 = gJChronology5.withZone(dateTimeZone17);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10, 12885, 19689, 12885, 19669, dateTimeZone17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12885 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "19666");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.addMonths((-1));
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime10 = property7.add((long) 19);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        java.lang.String str2 = property1.getName();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.add((long) 'a');
        org.joda.time.Interval interval5 = property1.toInterval();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "monthOfYear" + "'", str2.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 5929);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology3);
        mutableDateTime6.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        mutableDateTime6.setZoneRetainFields(dateTimeZone9);
        int int11 = mutableDateTime6.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = mutableDateTime6.getZone();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = instant1.toMutableDateTime(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(3, 27, (-1), 4038000);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 30 + "'", int4 == 30);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths(1);
//        int int4 = dateTime3.getYearOfCentury();
//        org.joda.time.DateTime dateTime6 = dateTime3.minusMillis((int) (short) 1);
//        org.joda.time.DateMidnight dateMidnight7 = dateTime6.toDateMidnight();
//        long long8 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562934500444L + "'", long8 == 1562934500444L);
//    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.lang.String str1 = julianChronology0.toString();
//        org.joda.time.DurationField durationField2 = julianChronology0.hours();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
//        org.joda.time.DurationField durationField5 = gJChronology3.millis();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType9);
//        int int15 = zeroIsMaxDateTimeField13.getMaximumValue((long) 2);
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DurationField durationField17 = gJChronology16.weekyears();
//        org.joda.time.DurationField durationField18 = gJChronology16.millis();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology16.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 19666, "");
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType22);
//        int int28 = zeroIsMaxDateTimeField26.getMaximumValue((long) 2);
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
//        int int31 = mutableDateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = mutableDateTime29.toDateTime(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = dateTime33.toDateTime();
//        org.joda.time.LocalTime localTime35 = dateTime34.toLocalTime();
//        org.joda.time.Chronology chronology36 = null;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField38 = gJChronology37.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField39 = gJChronology37.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField(chronology36, dateTimeField39);
//        org.joda.time.DateTimeField dateTimeField41 = skipUndoDateTimeField40.getWrappedField();
//        long long44 = skipUndoDateTimeField40.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial45 = null;
//        int[] intArray53 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray55 = skipUndoDateTimeField40.add(readablePartial45, 19670, intArray53, 0);
//        int int56 = zeroIsMaxDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localTime35, intArray53);
//        java.util.Locale locale58 = null;
//        java.lang.String str59 = zeroIsMaxDateTimeField13.getAsText((org.joda.time.ReadablePartial) localTime35, 12, locale58);
//        long long61 = julianChronology0.set((org.joda.time.ReadablePartial) localTime35, (long) '#');
//        org.joda.time.DateTimeField dateTimeField62 = julianChronology0.hourOfDay();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str1.equals("JulianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 60 + "'", int15 == 60);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 60 + "'", int28 == 60);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 19700 + "'", int31 == 19700);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(localTime35);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 49L + "'", long44 == 49L);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 60 + "'", int56 == 60);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "12" + "'", str59.equals("12"));
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-37899509L) + "'", long61 == (-37899509L));
//        org.junit.Assert.assertNotNull(dateTimeField62);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) (-2), 19675);
        java.lang.Object obj8 = dateTimeParserBucket7.saveState();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField13 = gJChronology12.weekyears();
        org.joda.time.DurationField durationField14 = gJChronology12.millis();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology12.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField15, dateTimeFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder9.appendFixedDecimal(dateTimeFieldType18, (int) (short) 100);
        dateTimeParserBucket7.saveField(dateTimeFieldType18, 0);
        try {
            long long34 = dateTimeParserBucket7.computeMillis(false);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("Property[era]");
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
        java.util.Locale locale2 = null;
        int int3 = property1.getMaximumShortTextLength(locale2);
        int int4 = property1.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
        int int9 = mutableDateTime4.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = mutableDateTime4.getZone();
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now(dateTimeZone10);
        java.lang.String str12 = dateTimeZone10.toString();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, 1613L, (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -2");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField3 = gJChronology2.weekyears();
        org.joda.time.DurationField durationField4 = gJChronology2.hours();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology2);
        java.lang.StringBuffer stringBuffer6 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology8);
        mutableDateTime11.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        mutableDateTime11.setZoneRetainFields(dateTimeZone14);
        int int16 = mutableDateTime11.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone17 = mutableDateTime11.getZone();
        org.joda.time.DateTime dateTime18 = mutableDateTime11.toDateTimeISO();
        try {
            dateTimeFormatter5.printTo(stringBuffer6, (org.joda.time.ReadableInstant) mutableDateTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendClockhourOfDay(19667);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField28 = gJChronology27.weekyears();
        org.joda.time.DurationField durationField29 = gJChronology27.millis();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology27.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime31.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField30, dateTimeFieldType33);
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder24.appendFixedDecimal(dateTimeFieldType33, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType33, 3, 19677);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType9, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendSecondOfDay(19676);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology25.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.yearOfCentury();
        java.util.Locale locale28 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology25, locale28, (java.lang.Integer) (-2), 19675);
        java.lang.Object obj32 = dateTimeParserBucket31.saveState();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField37 = gJChronology36.weekyears();
        org.joda.time.DurationField durationField38 = gJChronology36.millis();
        org.joda.time.DateTimeField dateTimeField39 = gJChronology36.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property41 = mutableDateTime40.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException45 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField39, dateTimeFieldType42);
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException52 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder33.appendFixedDecimal(dateTimeFieldType42, (int) (short) 100);
        dateTimeParserBucket31.saveField(dateTimeFieldType42, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder23.appendText(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyear();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = gJChronology6.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8);
//        org.joda.time.DateTimeField dateTimeField10 = skipUndoDateTimeField9.getWrappedField();
//        long long13 = skipUndoDateTimeField9.getDifferenceAsLong((long) 19670, (-1L));
//        long long15 = skipUndoDateTimeField9.roundHalfEven(0L);
//        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.monthOfYear();
//        int int18 = mutableDateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = mutableDateTime16.toDateTime(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = dateTime20.toDateTime();
//        org.joda.time.LocalTime localTime22 = dateTime21.toLocalTime();
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = skipUndoDateTimeField9.getAsText((org.joda.time.ReadablePartial) localTime22, 19, locale24);
//        int[] intArray26 = null;
//        try {
//            gJChronology0.validate((org.joda.time.ReadablePartial) localTime22, intArray26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 19701 + "'", int18 == 19701);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(localTime22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "19" + "'", str25.equals("19"));
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        long long6 = gJChronology0.add((long) (short) 100, 0L, (int) (byte) 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField10);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11);
        int int14 = skipUndoDateTimeField11.get((long) 100);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 69 + "'", int14 == 69);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeZoneBuilder4.toDateTimeZone("monthOfYear", false);
        org.joda.time.DateTime dateTime8 = dateTime3.withZone(dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime3.yearOfCentury();
        org.joda.time.DateTime.Property property10 = dateTime3.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        long long6 = gJChronology0.add((long) (short) 100, 0L, (int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) mutableDateTime7);
        org.joda.time.Instant instant9 = mutableDateTime7.toInstant();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str1 = julianChronology0.toString();
        org.joda.time.DurationField durationField2 = julianChronology0.hours();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology4);
        mutableDateTime7.addMonths((-1));
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime7.secondOfDay();
        mutableDateTime7.addYears((int) '#');
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology14);
        mutableDateTime17.addMonths((-1));
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime17.secondOfDay();
        boolean boolean21 = mutableDateTime7.isEqual((org.joda.time.ReadableInstant) mutableDateTime17);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime17.minuteOfHour();
        boolean boolean23 = julianChronology0.equals((java.lang.Object) mutableDateTime17);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str1.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
//        int int2 = mutableDateTime0.getSecondOfDay();
//        mutableDateTime0.addWeeks(19669);
//        mutableDateTime0.addSeconds(19669);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime0.monthOfYear();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property7.getAsText(locale8);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.hourOfHalfday();
//        java.util.Locale locale14 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology12, locale14);
//        java.util.Locale locale16 = dateTimeParserBucket15.getLocale();
//        try {
//            org.joda.time.MutableDateTime mutableDateTime17 = property7.set("America/Los_Angeles", locale16);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for monthOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19702 + "'", int2 == 19702);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "May" + "'", str9.equals("May"));
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(locale16);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(1562934500444L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        int int9 = dateTimeZone7.getOffsetFromLocal((long) (short) 0);
        try {
            org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(0, 0, 19700, 12885, 19674, 19677, 19669, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12885 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gJChronology0.add(readablePeriod5, (long) 12, (-2));
        org.joda.time.DurationField durationField9 = gJChronology0.weekyears();
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        int int11 = mutableDateTime10.getRoundingMode();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime10.dayOfYear();
        boolean boolean13 = mutableDateTime10.isAfterNow();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
//        long long6 = gJChronology0.add((long) (short) 100, 0L, (int) (byte) 0);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField10);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11);
//        java.lang.String str14 = skipUndoDateTimeField11.getAsShortText((long) (short) 100);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.millisOfDay();
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField21 = gJChronology20.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField22 = gJChronology20.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology19, dateTimeField22);
//        org.joda.time.DateTimeField dateTimeField24 = skipUndoDateTimeField23.getWrappedField();
//        long long27 = skipUndoDateTimeField23.getDifferenceAsLong((long) 19670, (-1L));
//        int int30 = skipUndoDateTimeField23.getDifference((long) (-1), (long) (byte) -1);
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField35 = gJChronology33.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology33);
//        mutableDateTime36.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        mutableDateTime36.setZoneRetainFields(dateTimeZone39);
//        int int41 = mutableDateTime36.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone42 = mutableDateTime36.getZone();
//        long long45 = dateTimeZone42.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField49 = gregorianChronology48.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder50 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone53 = dateTimeZoneBuilder50.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology54 = gregorianChronology48.withZone(dateTimeZone53);
//        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField57 = gJChronology56.hourOfHalfday();
//        java.util.Locale locale58 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket59 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology56, locale58);
//        java.util.Locale locale60 = dateTimeParserBucket59.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket62 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology54, locale60, (java.lang.Integer) 19671);
//        java.lang.String str63 = dateTimeZone42.getShortName((long) 2000, locale60);
//        java.lang.String str64 = skipUndoDateTimeField23.getAsShortText(0, locale60);
//        org.joda.time.DateTime dateTime65 = property17.setCopy("0", locale60);
//        java.lang.String str66 = skipUndoDateTimeField11.getAsShortText(4038000, locale60);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 19684L + "'", long45 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(chronology54);
//        org.junit.Assert.assertNotNull(gJChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(locale60);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "PST" + "'", str63.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "0" + "'", str64.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "4038000" + "'", str66.equals("4038000"));
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong((long) 19670, (-1L));
        boolean boolean9 = skipUndoDateTimeField4.isLenient();
        long long11 = skipUndoDateTimeField4.roundHalfCeiling((long) 19686);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800000L + "'", long11 == 28800000L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) (-2), 19675);
        java.lang.Object obj8 = dateTimeParserBucket7.saveState();
        org.joda.time.Chronology chronology9 = dateTimeParserBucket7.getChronology();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.hourOfDay();
        org.joda.time.DateTime dateTime6 = property5.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField7 = gJChronology6.weekyears();
        org.joda.time.DurationField durationField8 = gJChronology6.millis();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.minus(readablePeriod11);
        org.joda.time.DateTime.Property property13 = dateTime10.weekOfWeekyear();
        boolean boolean14 = gJChronology6.equals((java.lang.Object) dateTime10);
        int int15 = property5.getDifference((org.joda.time.ReadableInstant) dateTime10);
        int int16 = property5.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-18089) + "'", int15 == (-18089));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.monthOfYear();
        int int4 = mutableDateTime2.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.plusMonths(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("monthOfYear", false);
        org.joda.time.DateTime dateTime13 = dateTime8.withZone(dateTimeZone12);
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) mutableDateTime2, (org.joda.time.ReadableDateTime) dateTime13);
        try {
            long long19 = limitChronology14.getDateTimeMillis(0, 0, (-2), 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19700 + "'", int4 == 19700);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(limitChronology14);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendClockhourOfDay(19667);
        org.joda.time.format.DateTimeParser dateTimeParser24 = dateTimeFormatterBuilder23.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeParser24);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime.Property property4 = dateTime1.era();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime8 = dateTimeFormatter0.parseDateTime("2019-W24");
        org.joda.time.ReadablePartial readablePartial9 = null;
        try {
            java.lang.String str10 = dateTimeFormatter0.print(readablePartial9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019-W28" + "'", str6.equals("2019-W28"));
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        int int3 = mutableDateTime1.getSecondOfDay();
        int int6 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime1, "monthOfYear", (int) (short) 1);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime1.dayOfWeek();
        java.lang.String str8 = property7.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19700 + "'", int3 == 19700);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2) + "'", int6 == (-2));
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[dayOfWeek]" + "'", str8.equals("Property[dayOfWeek]"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.add(19674);
        org.joda.time.ReadableInstant readableInstant10 = null;
        long long11 = property7.getDifferenceAsLong(readableInstant10);
        try {
            org.joda.time.MutableDateTime mutableDateTime13 = property7.set("America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1583L + "'", long11 == 1583L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = mutableDateTime0.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
        mutableDateTime0.addYears(19689901);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19700 + "'", int2 == 19700);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "GJChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendClockhourOfDay(19667);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendSecondOfMinute(27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder25.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(19666, (int) '4', (int) (byte) -1, 0, 19702);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19702 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.add(19674);
        java.lang.String str10 = property7.getAsText();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "12" + "'", str10.equals("12"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField7 = gJChronology6.weekyears();
        org.joda.time.DurationField durationField8 = gJChronology6.millis();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.minus(readablePeriod11);
        org.joda.time.DateTime.Property property13 = dateTime10.weekOfWeekyear();
        boolean boolean14 = gJChronology6.equals((java.lang.Object) dateTime10);
        int int15 = property5.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime17.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime dateTime21 = dateTime19.withYear((int) 'a');
        org.joda.time.DateTime.Property property22 = dateTime19.weekyear();
        org.joda.time.DateTime.Property property23 = dateTime19.dayOfYear();
        org.joda.time.DateTime dateTime25 = dateTime19.plusMillis(2019);
        int int26 = property5.compareTo((org.joda.time.ReadableInstant) dateTime25);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-18089) + "'", int15 == (-18089));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.monthOfYear();
        int int7 = mutableDateTime5.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = mutableDateTime5.toDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime5.secondOfDay();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime5);
        mutableDateTime5.addYears(19692);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19700 + "'", int7 == 19700);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, dateTimeField6);
//        org.joda.time.DateTimeField dateTimeField8 = skipUndoDateTimeField7.getWrappedField();
//        long long11 = skipUndoDateTimeField7.getDifferenceAsLong((long) 19670, (-1L));
//        int int14 = skipUndoDateTimeField7.getDifference((long) (-1), (long) (byte) -1);
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology17.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology17);
//        mutableDateTime20.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        mutableDateTime20.setZoneRetainFields(dateTimeZone23);
//        int int25 = mutableDateTime20.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone26 = mutableDateTime20.getZone();
//        long long29 = dateTimeZone26.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField33 = gregorianChronology32.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder34 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone37 = dateTimeZoneBuilder34.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology38 = gregorianChronology32.withZone(dateTimeZone37);
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.hourOfHalfday();
//        java.util.Locale locale42 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket43 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology40, locale42);
//        java.util.Locale locale44 = dateTimeParserBucket43.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket46 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology38, locale44, (java.lang.Integer) 19671);
//        java.lang.String str47 = dateTimeZone26.getShortName((long) 2000, locale44);
//        java.lang.String str48 = skipUndoDateTimeField7.getAsShortText(0, locale44);
//        org.joda.time.DateTime dateTime49 = property1.setCopy("0", locale44);
//        org.joda.time.DateTime dateTime51 = dateTime49.minusMillis(5);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 19684L + "'", long29 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(locale44);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "PST" + "'", str47.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0" + "'", str48.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime51);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = property1.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType2, (java.lang.Number) 19666, "");
        java.lang.String str6 = illegalFieldValueException5.getFieldName();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeFieldType2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "monthOfYear" + "'", str6.equals("monthOfYear"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder20.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder20.appendWeekyear(19691, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear(19670);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMinuteOfDay(19685);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfSecond((int) (byte) 100, 19676);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.append(dateTimeFormatter10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No formatter supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long13 = zeroIsMaxDateTimeField10.set((long) 52, "59");
        int int14 = zeroIsMaxDateTimeField10.getMinimumValue();
        int int15 = zeroIsMaxDateTimeField10.getMinimumValue();
        long long17 = zeroIsMaxDateTimeField10.roundHalfCeiling((long) 52);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 59052L + "'", long13 == 59052L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.weekyears();
        org.joda.time.DurationField durationField3 = gJChronology1.millis();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField11 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField4, dateTimeFieldType7);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, (java.lang.Number) (short) 100, "monthOfYear");
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gJChronology0.add(readablePeriod5, (long) 12, (-2));
        org.joda.time.DurationField durationField9 = gJChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear(19670);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendTimeZoneOffset("PST", "July", false, 19671, 19669);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withYear(19666);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        int int6 = dateTime5.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19666 + "'", int6 == 19666);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.addMonths((-1));
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.secondOfDay();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.yearOfCentury();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) 'a');
        org.joda.time.DateTime.Property property6 = dateTime3.weekyear();
        org.joda.time.DateTime.Property property7 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime9 = dateTime3.plusMillis(2019);
        org.joda.time.DateTime dateTime11 = dateTime3.minusWeeks(27);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendClockhourOfDay(19667);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendClockhourOfHalfday((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder23.appendYear(0, (int) (short) 10);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap29 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder23.appendTimeZoneShortName(strMap29);
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime31.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder23.appendDecimal(dateTimeFieldType33, 19700, (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.hours();
        org.joda.time.Chronology chronology2 = gJChronology0.withUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField4);
        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField5.getWrappedField();
        long long9 = skipUndoDateTimeField5.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long11 = skipUndoDateTimeField5.roundFloor((long) (short) 1);
        int int12 = skipUndoDateTimeField5.getMaximumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField5);
        java.util.Locale locale14 = null;
        int int15 = skipDateTimeField13.getMaximumTextLength(locale14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField13.getAsText(0, locale17);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 49L + "'", long9 == 49L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-31507200000L) + "'", long11 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        java.lang.Object obj3 = mutableDateTime1.clone();
        mutableDateTime1.addMinutes(19669);
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime1, "America/Los_Angeles", 19694);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-19695) + "'", int8 == (-19695));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField4);
        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField5.getWrappedField();
        long long9 = skipUndoDateTimeField5.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long11 = skipUndoDateTimeField5.roundFloor((long) (short) 1);
        int int12 = skipUndoDateTimeField5.getMaximumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField5);
        java.util.Locale locale14 = null;
        int int15 = skipDateTimeField13.getMaximumTextLength(locale14);
        try {
            long long18 = skipDateTimeField13.set((long) (byte) 10, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfCentury must be in the range [1,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 49L + "'", long9 == 49L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-31507200000L) + "'", long11 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.minus(readableDuration1);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.monthOfYear();
        int int15 = mutableDateTime13.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = mutableDateTime13.toDateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        int int20 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime19);
        long long23 = zeroIsMaxDateTimeField10.add(63071807542L, (-19666));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19700 + "'", int15 == 19700);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 60 + "'", int20 == 60);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 63052141542L + "'", long23 == 63052141542L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 5929, (long) 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29645 + "'", int2 == 29645);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, "hi!");
        java.lang.Number number13 = illegalFieldValueException12.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(number13);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        int int9 = dateTimeZone7.getOffsetFromLocal((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        long long13 = dateTimeZone7.convertLocalToUTC((long) 19689901, true);
        try {
            org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime(0, (-2), (int) (short) 100, (int) (byte) 10, 19679, 5, (int) (byte) 0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19679 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 19689901L + "'", long13 == 19689901L);
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
//        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
//        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int[] intArray17 = new int[] { 60, 60, 1, 69, ' ', 19670 };
//        int[] intArray19 = skipUndoDateTimeField4.add(readablePartial9, 19670, intArray17, 0);
//        int int21 = skipUndoDateTimeField4.getMaximumValue((long) (short) 100);
//        org.joda.time.Chronology chronology22 = null;
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.yearOfCentury();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField(chronology22, dateTimeField25);
//        org.joda.time.DateTimeField dateTimeField27 = skipUndoDateTimeField26.getWrappedField();
//        long long30 = skipUndoDateTimeField26.getDifferenceAsLong((long) 19670, (-1L));
//        int int33 = skipUndoDateTimeField26.getDifference((long) (-1), (long) (byte) -1);
//        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField38 = gJChronology36.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology36);
//        mutableDateTime39.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        mutableDateTime39.setZoneRetainFields(dateTimeZone42);
//        int int44 = mutableDateTime39.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone45 = mutableDateTime39.getZone();
//        long long48 = dateTimeZone45.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField52 = gregorianChronology51.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder53 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone56 = dateTimeZoneBuilder53.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology57 = gregorianChronology51.withZone(dateTimeZone56);
//        org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField60 = gJChronology59.hourOfHalfday();
//        java.util.Locale locale61 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket62 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology59, locale61);
//        java.util.Locale locale63 = dateTimeParserBucket62.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket65 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology57, locale63, (java.lang.Integer) 19671);
//        java.lang.String str66 = dateTimeZone45.getShortName((long) 2000, locale63);
//        java.lang.String str67 = skipUndoDateTimeField26.getAsShortText(0, locale63);
//        int int68 = skipUndoDateTimeField4.getMaximumShortTextLength(locale63);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(gJChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 19684L + "'", long48 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertNotNull(chronology57);
//        org.junit.Assert.assertNotNull(gJChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(locale63);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "PST" + "'", str66.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "0" + "'", str67.equals("0"));
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 3 + "'", int68 == 3);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = mutableDateTime0.getSecondOfDay();
        mutableDateTime0.addDays(0);
        mutableDateTime0.addDays(100);
        try {
            mutableDateTime0.setMonthOfYear((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19700 + "'", int2 == 19700);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay(19676);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readablePeriod6);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay(19676);
        org.joda.time.DateTime dateTime7 = dateTime3.minusMonths((int) (short) 10);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("12", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = mutableDateTime0.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime0.secondOfDay();
        int int6 = property5.getMaximumValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19700 + "'", int2 == 19700);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 86399 + "'", int6 == 86399);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
        int int9 = mutableDateTime4.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = mutableDateTime4.getZone();
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now(dateTimeZone10);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            mutableDateTime11.add(durationFieldType12, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfCentury(52);
        org.joda.time.DateTime dateTime8 = dateTime6.plusYears(19690);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.hours();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology4);
        mutableDateTime7.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        mutableDateTime7.setZoneRetainFields(dateTimeZone10);
        int int12 = mutableDateTime7.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone13 = mutableDateTime7.getZone();
        org.joda.time.Chronology chronology14 = gJChronology1.withZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) "2019-06-12T05:28:03.598-07:00", (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField16 = gJChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology8);
        mutableDateTime11.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        mutableDateTime11.setZoneRetainFields(dateTimeZone14);
        int int16 = mutableDateTime11.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone17 = mutableDateTime11.getZone();
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now(dateTimeZone17);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(19696, 4038000, 19702, 2052, 19670, 0, 19685, dateTimeZone17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2052 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.monthOfYear();
        int int15 = mutableDateTime13.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = mutableDateTime13.toDateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        int int20 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime19);
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.monthOfYear();
        int int23 = mutableDateTime21.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = mutableDateTime21.toDateTime(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTime();
        org.joda.time.LocalTime localTime27 = dateTime26.toLocalTime();
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology29.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField(chronology28, dateTimeField31);
        org.joda.time.DateTimeField dateTimeField33 = skipUndoDateTimeField32.getWrappedField();
        long long36 = skipUndoDateTimeField32.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial37 = null;
        int[] intArray45 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray47 = skipUndoDateTimeField32.add(readablePartial37, 19670, intArray45, 0);
        int int48 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime27, intArray47);
        org.joda.time.DurationField durationField49 = zeroIsMaxDateTimeField10.getLeapDurationField();
        int int51 = zeroIsMaxDateTimeField10.get((-187200000L));
        boolean boolean53 = zeroIsMaxDateTimeField10.isLeap((long) 20);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19700 + "'", int15 == 19700);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 60 + "'", int20 == 60);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19700 + "'", int23 == 19700);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localTime27);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 49L + "'", long36 == 49L);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 60 + "'", int48 == 60);
        org.junit.Assert.assertNull(durationField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 60 + "'", int51 == 60);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long13 = zeroIsMaxDateTimeField10.set((long) 52, "59");
        long long15 = zeroIsMaxDateTimeField10.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 59052L + "'", long13 == 59052L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendClockhourOfDay(19667);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendSecondOfMinute(27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder25.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property29 = dateTime28.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime31 = dateTime28.minus(readablePeriod30);
        java.lang.String str32 = dateTimeFormatter27.print((org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.format.DateTimePrinter dateTimePrinter33 = dateTimeFormatter27.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter34.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser36 = dateTimeFormatter35.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter37.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser39 = dateTimeFormatter38.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter40.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser42 = dateTimeFormatter41.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray43 = new org.joda.time.format.DateTimeParser[] { dateTimeParser36, dateTimeParser39, dateTimeParser42 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder26.append(dateTimePrinter33, dateTimeParserArray43);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019-07-12T05" + "'", str32.equals("2019-07-12T05"));
        org.junit.Assert.assertNotNull(dateTimePrinter33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeParser36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeParser39);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTimeParser42);
        org.junit.Assert.assertNotNull(dateTimeParserArray43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter2.printTo(stringBuffer3, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime0.minusHours(0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readablePeriod5);
        org.joda.time.DateTime.Property property7 = dateTime4.weekOfWeekyear();
        boolean boolean8 = gJChronology0.equals((java.lang.Object) dateTime4);
        org.joda.time.DurationField durationField9 = gJChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField11 = gJChronology0.minutes();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        int int7 = dateTimeZone5.getOffsetFromLocal((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        long long11 = cachedDateTimeZone8.nextTransition((long) 19672);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((-28800000), 19679, (-18089), 19695, (-28800000), (org.joda.time.DateTimeZone) cachedDateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19695 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 19672L + "'", long11 == 19672L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long10 = skipUndoDateTimeField4.roundFloor((long) (short) 1);
        int int11 = skipUndoDateTimeField4.getMaximumValue();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField13 = gJChronology12.weekyears();
        org.joda.time.DurationField durationField14 = gJChronology12.millis();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology12.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField15, dateTimeFieldType18);
        int int24 = zeroIsMaxDateTimeField22.getMaximumValue((long) 2);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
        org.joda.time.DurationField durationField27 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
        int int37 = zeroIsMaxDateTimeField35.getMaximumValue((long) 2);
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime38.monthOfYear();
        int int40 = mutableDateTime38.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = mutableDateTime38.toDateTime(dateTimeZone41);
        org.joda.time.DateTime dateTime43 = dateTime42.toDateTime();
        org.joda.time.LocalTime localTime44 = dateTime43.toLocalTime();
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField47 = gJChronology46.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField48 = gJChronology46.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField(chronology45, dateTimeField48);
        org.joda.time.DateTimeField dateTimeField50 = skipUndoDateTimeField49.getWrappedField();
        long long53 = skipUndoDateTimeField49.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial54 = null;
        int[] intArray62 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray64 = skipUndoDateTimeField49.add(readablePartial54, 19670, intArray62, 0);
        int int65 = zeroIsMaxDateTimeField35.getMaximumValue((org.joda.time.ReadablePartial) localTime44, intArray62);
        java.util.Locale locale67 = null;
        java.lang.String str68 = zeroIsMaxDateTimeField22.getAsText((org.joda.time.ReadablePartial) localTime44, 12, locale67);
        int int69 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime44);
        long long71 = skipUndoDateTimeField4.roundHalfFloor((long) 4038000);
        org.joda.time.ReadablePartial readablePartial72 = null;
        try {
            int int73 = skipUndoDateTimeField4.getMaximumValue(readablePartial72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 60 + "'", int24 == 60);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 60 + "'", int37 == 60);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19700 + "'", int40 == 19700);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localTime44);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 49L + "'", long53 == 49L);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 60 + "'", int65 == 60);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "12" + "'", str68.equals("12"));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 28800000L + "'", long71 == 28800000L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (-31507200000L), 0);
        try {
            long long10 = gregorianChronology0.getDateTimeMillis(19148, 3, 52, 27);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths(1);
        int int4 = dateTime3.getYearOfCentury();
        org.joda.time.DateTime dateTime6 = dateTime3.minusMillis((int) (short) 1);
        org.joda.time.DateMidnight dateMidnight7 = dateTime6.toDateMidnight();
        org.joda.time.DateTime dateTime9 = dateTime6.minusHours((int) ' ');
        try {
            org.joda.time.DateTime dateTime11 = dateTime6.withDayOfMonth(19673);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19673 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(60, 19679, 12885, 29645, (-28800000), (int) (byte) 0, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 29645 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withYear(19666);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime5.plusHours(2052);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = property4.addToCopy(12885);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "org.joda.time.IllegalFieldValueException: Value 0 for monthOfYear must be in the range [4,0.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long10 = skipUndoDateTimeField4.roundFloor((long) (short) 1);
        int int11 = skipUndoDateTimeField4.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.monthOfYear();
        int int14 = mutableDateTime12.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = mutableDateTime12.toDateTime(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = dateTime16.toDateTime();
        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
        int int19 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime18);
        long long21 = skipUndoDateTimeField4.remainder((long) (-1));
        java.util.Locale locale23 = null;
        java.lang.String str24 = skipUndoDateTimeField4.getAsShortText(19, locale23);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19700 + "'", int14 == 19700);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 31507199999L + "'", long21 == 31507199999L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "19" + "'", str24.equals("19"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gJChronology0.add(readablePeriod5, (long) 12, (-2));
        org.joda.time.DurationField durationField9 = gJChronology0.weekyears();
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        int int11 = mutableDateTime10.getYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime10.yearOfCentury();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "19");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withYear(19666);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withDurationAdded(readableDuration4, (int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((-18059));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
        int int9 = mutableDateTime4.getMinuteOfDay();
        boolean boolean10 = mutableDateTime4.isAfterNow();
        try {
            mutableDateTime4.setMillisOfSecond(19701);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19701 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) 'a');
        org.joda.time.DateTime.Property property6 = dateTime3.weekyear();
        org.joda.time.DateTime.Property property7 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime8 = dateTime3.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField3 = gJChronology2.weekyears();
        org.joda.time.DurationField durationField4 = gJChronology2.hours();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology2);
        try {
            org.joda.time.LocalTime localTime7 = dateTimeFormatter5.parseLocalTime("BuddhistChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"BuddhistChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
        boolean boolean2 = dateTimeFormatter1.isPrinter();
        java.util.Locale locale3 = dateTimeFormatter1.getLocale();
        try {
            org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("DateTimeField[monthOfYear]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[monthOfYear]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(locale3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) 'a');
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded((long) 60, (int) (byte) 0);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths(19148);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long13 = zeroIsMaxDateTimeField10.set((long) 52, "59");
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = zeroIsMaxDateTimeField10.getType();
        int int16 = zeroIsMaxDateTimeField10.getMaximumValue((long) (-1));
        org.joda.time.DurationField durationField17 = zeroIsMaxDateTimeField10.getRangeDurationField();
        long long20 = zeroIsMaxDateTimeField10.add(2440587L, 19697);
        long long22 = zeroIsMaxDateTimeField10.roundHalfEven((long) 4);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 59052L + "'", long13 == 59052L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 60 + "'", int16 == 60);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 22137587L + "'", long20 == 22137587L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.Chronology chronology7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(12885, 29645, 1, 19672, 19, 2052, 19673, chronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19672 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.add(19674);
        java.lang.String str10 = property7.getName();
        org.joda.time.MutableDateTime mutableDateTime11 = property7.roundHalfCeiling();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "dayOfMonth" + "'", str10.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DurationField durationField3 = gJChronology0.eras();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        java.lang.Integer int4 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
        org.junit.Assert.assertNull(int4);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.add(19674);
        org.joda.time.MutableDateTime mutableDateTime10 = property7.roundHalfFloor();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str12 = julianChronology11.toString();
        int int13 = julianChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone17 = dateTimeZoneBuilder14.toDateTimeZone("monthOfYear", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder25 = dateTimeZoneBuilder14.addCutover((int) (short) 1, 'a', 0, 2, 19671, true, 60);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder28 = dateTimeZoneBuilder14.setFixedSavings("2019-W24", 3);
        boolean boolean29 = julianChronology11.equals((java.lang.Object) 3);
        boolean boolean30 = property7.equals((java.lang.Object) 3);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str12.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder25);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.monthOfYear();
        int int4 = mutableDateTime2.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.plusMonths(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("monthOfYear", false);
        org.joda.time.DateTime dateTime13 = dateTime8.withZone(dateTimeZone12);
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) mutableDateTime2, (org.joda.time.ReadableDateTime) dateTime13);
        try {
            long long22 = limitChronology14.getDateTimeMillis((int) (byte) -1, (int) '4', (int) 'a', (-2), 19699, (int) (short) 100, 86399);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19700 + "'", int4 == 19700);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(limitChronology14);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.addMonths((-1));
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundHalfEven();
        java.lang.String str9 = property7.getAsString();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "57600" + "'", str9.equals("57600"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        mutableDateTime4.setZoneRetainFields(dateTimeZone7);
        int int9 = mutableDateTime4.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = mutableDateTime4.getZone();
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now(dateTimeZone10);
        try {
            mutableDateTime11.setDayOfYear(19692);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19692 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Pacific Standard Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, 19686, (int) 'a', 19679);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19686 for yearOfCentury must be in the range [97,19679]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant3 = instant0.withDurationAdded((long) (short) 10, 12);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendClockhourOfDay(19667);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendClockhourOfHalfday((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder23.appendYear(0, (int) (short) 10);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap29 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder23.appendTimeZoneShortName(strMap29);
        org.joda.time.format.DateTimeParser dateTimeParser31 = dateTimeFormatterBuilder23.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeParser31);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder20.appendHalfdayOfDayText();
        try {
            org.joda.time.format.DateTimePrinter dateTimePrinter22 = dateTimeFormatterBuilder21.toPrinter();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "July");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant2 = instant0.withMillis((long) 'a');
        org.joda.time.Instant instant4 = instant2.plus((long) (byte) 0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant4, readableInstant5);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
        int int19 = mutableDateTime17.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
        org.joda.time.DurationField durationField27 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField52 = gJChronology50.yearOfCentury();
        java.util.Locale locale53 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology50, locale53, (java.lang.Integer) (-2), 19675);
        java.lang.Object obj57 = dateTimeParserBucket56.saveState();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder58.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField62 = gJChronology61.weekyears();
        org.joda.time.DurationField durationField63 = gJChronology61.millis();
        org.joda.time.DateTimeField dateTimeField64 = gJChronology61.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime65 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property66 = mutableDateTime65.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property66.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField71 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField64, dateTimeFieldType67);
        org.joda.time.IllegalFieldValueException illegalFieldValueException73 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException77 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder58.appendFixedDecimal(dateTimeFieldType67, (int) (short) 100);
        dateTimeParserBucket56.saveField(dateTimeFieldType67, 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType67, 19683);
        int int86 = zeroIsMaxDateTimeField10.getDifference(19049L, (long) 19683);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19700 + "'", int19 == 19700);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology1);
        mutableDateTime4.addMonths((-1));
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime8 = mutableDateTime4.copy();
        int int9 = mutableDateTime4.getMinuteOfHour();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 59 + "'", int9 == 59);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) 'a');
        org.joda.time.DateTime.Property property6 = dateTime3.weekyear();
        try {
            org.joda.time.DateTime dateTime8 = dateTime3.withDayOfYear(19671);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19671 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, dateTimeZone1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) 'a');
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded((long) 60, (int) (byte) 0);
        org.joda.time.DateTime dateTime10 = dateTime8.minusWeeks((int) 'a');
        int int11 = dateTime10.getHourOfDay();
        org.joda.time.DateTime dateTime13 = dateTime10.plusHours(19670);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology1, locale4, (java.lang.Integer) (-2), 19675);
        java.lang.Object obj8 = dateTimeParserBucket7.saveState();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField13 = gJChronology12.weekyears();
        org.joda.time.DurationField durationField14 = gJChronology12.millis();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology12.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField15, dateTimeFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder9.appendFixedDecimal(dateTimeFieldType18, (int) (short) 100);
        dateTimeParserBucket7.saveField(dateTimeFieldType18, 0);
        dateTimeParserBucket7.setOffset((int) (byte) 100);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.hours();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology3);
        mutableDateTime6.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        mutableDateTime6.setZoneRetainFields(dateTimeZone9);
        int int11 = mutableDateTime6.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = mutableDateTime6.getZone();
        org.joda.time.Chronology chronology13 = gJChronology0.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = gJChronology0.hours();
        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField16 = gJChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = mutableDateTime0.getSecondOfDay();
        mutableDateTime0.addDays(0);
        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime0.copy();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.yearOfCentury();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19700 + "'", int2 == 19700);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
        boolean boolean14 = zeroIsMaxDateTimeField10.isLeap((-1L));
        int int17 = zeroIsMaxDateTimeField10.getDifference((long) 19673, (long) 2);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((java.lang.Object) instant0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.era();
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withYear(19666);
        mutableDateTime1.setDate((org.joda.time.ReadableInstant) dateTime3);
        mutableDateTime1.setTime(0L);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.weekyear();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gJChronology0.add(readablePeriod5, (long) 12, (-2));
        long long13 = gJChronology0.getDateTimeMillis(19, 1, (int) (byte) 1, 52);
        try {
            long long18 = gJChronology0.getDateTimeMillis((int) (byte) 1, 1, (-19666), 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -19666 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61567747621948L) + "'", long13 == (-61567747621948L));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str1 = julianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        long long6 = julianChronology0.add(192467526L, (-210866673619666L), 12885);
        try {
            long long14 = julianChronology0.getDateTimeMillis(19679, 19702, 19691, 0, 20, 2000, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str1.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2717017089396928884L) + "'", long6 == (-2717017089396928884L));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.hours();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology3);
        mutableDateTime6.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        mutableDateTime6.setZoneRetainFields(dateTimeZone9);
        int int11 = mutableDateTime6.getMinuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = mutableDateTime6.getZone();
        org.joda.time.Chronology chronology13 = gJChronology0.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = gJChronology0.hours();
        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.Instant instant16 = gJChronology0.getGregorianCutover();
        java.lang.String str17 = gJChronology0.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str17.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField4);
        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField5.getWrappedField();
        long long9 = skipUndoDateTimeField5.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long11 = skipUndoDateTimeField5.roundFloor((long) (short) 1);
        int int12 = skipUndoDateTimeField5.getMaximumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField5);
        int int15 = skipDateTimeField13.get(558445966400012L);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField17 = gJChronology16.weekyears();
        org.joda.time.DurationField durationField18 = gJChronology16.millis();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology16.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField26 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField19, dateTimeFieldType22);
        long long29 = zeroIsMaxDateTimeField26.set((long) 52, "59");
        int int30 = zeroIsMaxDateTimeField26.getMinimumValue();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField32 = gJChronology31.weekyears();
        org.joda.time.DurationField durationField33 = gJChronology31.millis();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology31.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property36.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField41 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField34, dateTimeFieldType37);
        long long43 = zeroIsMaxDateTimeField41.roundHalfEven(0L);
        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime44.monthOfYear();
        int int46 = mutableDateTime44.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.DateTime dateTime48 = mutableDateTime44.toDateTime(dateTimeZone47);
        org.joda.time.DateTime dateTime49 = dateTime48.toDateTime();
        org.joda.time.LocalTime localTime50 = dateTime49.toLocalTime();
        int int51 = zeroIsMaxDateTimeField41.getMaximumValue((org.joda.time.ReadablePartial) localTime50);
        org.joda.time.MutableDateTime mutableDateTime52 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property53 = mutableDateTime52.monthOfYear();
        int int54 = mutableDateTime52.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.DateTime dateTime56 = mutableDateTime52.toDateTime(dateTimeZone55);
        org.joda.time.DateTime dateTime57 = dateTime56.toDateTime();
        org.joda.time.LocalTime localTime58 = dateTime57.toLocalTime();
        org.joda.time.Chronology chronology59 = null;
        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField61 = gJChronology60.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField62 = gJChronology60.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField63 = new org.joda.time.field.SkipUndoDateTimeField(chronology59, dateTimeField62);
        org.joda.time.DateTimeField dateTimeField64 = skipUndoDateTimeField63.getWrappedField();
        long long67 = skipUndoDateTimeField63.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial68 = null;
        int[] intArray76 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray78 = skipUndoDateTimeField63.add(readablePartial68, 19670, intArray76, 0);
        int int79 = zeroIsMaxDateTimeField41.getMaximumValue((org.joda.time.ReadablePartial) localTime58, intArray78);
        int[] intArray80 = null;
        int int81 = zeroIsMaxDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localTime58, intArray80);
        int[] intArray86 = new int[] { 19683, 19681, 19700, (byte) 0 };
        int int87 = skipDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localTime58, intArray86);
        org.joda.time.DurationField durationField88 = skipDateTimeField13.getLeapDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 49L + "'", long9 == 49L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-31507200000L) + "'", long11 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 66 + "'", int15 == 66);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 59052L + "'", long29 == 59052L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 19700 + "'", int46 == 19700);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(localTime50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 60 + "'", int51 == 60);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 19700 + "'", int54 == 19700);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(localTime58);
        org.junit.Assert.assertNotNull(gJChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 49L + "'", long67 == 49L);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 60 + "'", int79 == 60);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 100 + "'", int87 == 100);
        org.junit.Assert.assertNull(durationField88);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withDayOfYear((int) (short) 100);
        org.joda.time.DateTime.Property property4 = dateTime1.era();
        boolean boolean5 = property4.isLeap();
        java.lang.String str6 = property4.toString();
        org.joda.time.DateTime dateTime7 = property4.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[era]" + "'", str6.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendClockhourOfDay(19667);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendSecondOfMinute(27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder25.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property29 = dateTime28.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime31 = dateTime28.minus(readablePeriod30);
        java.lang.String str32 = dateTimeFormatter27.print((org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.format.DateTimePrinter dateTimePrinter33 = dateTimeFormatter27.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter34.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser36 = dateTimeFormatter35.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter37.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser39 = dateTimeFormatter38.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter40.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser42 = dateTimeFormatter41.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray43 = new org.joda.time.format.DateTimeParser[] { dateTimeParser36, dateTimeParser39, dateTimeParser42 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder26.append(dateTimePrinter33, dateTimeParserArray43);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder44.appendFractionOfHour(19695, (-19695));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019-07-12T05" + "'", str32.equals("2019-07-12T05"));
        org.junit.Assert.assertNotNull(dateTimePrinter33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeParser36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeParser39);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTimeParser42);
        org.junit.Assert.assertNotNull(dateTimeParserArray43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = mutableDateTime0.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField9 = gJChronology8.weekyears();
        org.joda.time.DurationField durationField10 = gJChronology8.millis();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField18 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField11, dateTimeFieldType14);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder5.appendFixedDecimal(dateTimeFieldType14, (int) (short) 100);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime0.property(dateTimeFieldType14);
        int int28 = mutableDateTime0.getSecondOfMinute();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19700 + "'", int2 == 19700);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20 + "'", int28 == 20);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(30, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfCentury(52);
        org.joda.time.DateTime dateTime8 = dateTime1.plusHours(19689901);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
        int int10 = property9.get();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendClockhourOfDay(19667);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendSecondOfMinute(27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder25.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property29 = dateTime28.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime31 = dateTime28.minus(readablePeriod30);
        java.lang.String str32 = dateTimeFormatter27.print((org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.format.DateTimePrinter dateTimePrinter33 = dateTimeFormatter27.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter34.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser36 = dateTimeFormatter35.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter37.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser39 = dateTimeFormatter38.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter40.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser42 = dateTimeFormatter41.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray43 = new org.joda.time.format.DateTimeParser[] { dateTimeParser36, dateTimeParser39, dateTimeParser42 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder26.append(dateTimePrinter33, dateTimeParserArray43);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap45 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder26.appendTimeZoneShortName(strMap45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019-07-12T05" + "'", str32.equals("2019-07-12T05"));
        org.junit.Assert.assertNotNull(dateTimePrinter33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeParser36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeParser39);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTimeParser42);
        org.junit.Assert.assertNotNull(dateTimeParserArray43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(strMap45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        int int6 = cachedDateTimeZone3.getStandardOffset((long) 12);
        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone3.getUncachedZone();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendClockhourOfDay(19667);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendClockhourOfHalfday((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder23.appendYear(0, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter32 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = dateTimeFormatter33.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser35 = dateTimeFormatter34.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter36.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser38 = dateTimeFormatter37.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter39.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser41 = dateTimeFormatter40.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter42.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser44 = dateTimeFormatter43.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter45.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser47 = dateTimeFormatter46.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray48 = new org.joda.time.format.DateTimeParser[] { dateTimeParser35, dateTimeParser38, dateTimeParser41, dateTimeParser44, dateTimeParser47 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder29.append(dateTimePrinter32, dateTimeParserArray48);
        boolean boolean50 = dateTimeFormatterBuilder29.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder29.appendClockhourOfDay(19667);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder52.appendSecondOfMinute(27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder54.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property58 = dateTime57.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod59 = null;
        org.joda.time.DateTime dateTime60 = dateTime57.minus(readablePeriod59);
        java.lang.String str61 = dateTimeFormatter56.print((org.joda.time.ReadableInstant) dateTime57);
        org.joda.time.format.DateTimePrinter dateTimePrinter62 = dateTimeFormatter56.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter63 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter64 = dateTimeFormatter63.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser65 = dateTimeFormatter64.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter66 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter67 = dateTimeFormatter66.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser68 = dateTimeFormatter67.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter69 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = dateTimeFormatter69.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser71 = dateTimeFormatter70.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray72 = new org.joda.time.format.DateTimeParser[] { dateTimeParser65, dateTimeParser68, dateTimeParser71 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder55.append(dateTimePrinter62, dateTimeParserArray72);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder23.append(dateTimePrinter62);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder23.appendYearOfEra(19702, (int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeParser35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimeParser38);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimeParser41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(dateTimeParser44);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(dateTimeParser47);
        org.junit.Assert.assertNotNull(dateTimeParserArray48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "2019-07-12T05" + "'", str61.equals("2019-07-12T05"));
        org.junit.Assert.assertNotNull(dateTimePrinter62);
        org.junit.Assert.assertNotNull(dateTimeFormatter63);
        org.junit.Assert.assertNotNull(dateTimeFormatter64);
        org.junit.Assert.assertNotNull(dateTimeParser65);
        org.junit.Assert.assertNotNull(dateTimeFormatter66);
        org.junit.Assert.assertNotNull(dateTimeFormatter67);
        org.junit.Assert.assertNotNull(dateTimeParser68);
        org.junit.Assert.assertNotNull(dateTimeFormatter69);
        org.junit.Assert.assertNotNull(dateTimeFormatter70);
        org.junit.Assert.assertNotNull(dateTimeParser71);
        org.junit.Assert.assertNotNull(dateTimeParserArray72);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        boolean boolean21 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendLiteral('a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField4);
        org.joda.time.DateTimeField dateTimeField6 = skipUndoDateTimeField5.getWrappedField();
        long long9 = skipUndoDateTimeField5.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long11 = skipUndoDateTimeField5.roundFloor((long) (short) 1);
        int int12 = skipUndoDateTimeField5.getMaximumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField5);
        int int16 = skipDateTimeField13.getDifference((long) 10, 0L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 49L + "'", long9 == 49L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-31507200000L) + "'", long11 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.minus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfDay(19676);
        org.joda.time.DateTime dateTime8 = dateTime4.plusSeconds(19679);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField12);
        org.joda.time.DateTimeField dateTimeField14 = skipUndoDateTimeField13.getWrappedField();
        long long17 = skipUndoDateTimeField13.getDifferenceAsLong((long) 19670, (-1L));
        long long19 = skipUndoDateTimeField13.roundHalfEven(0L);
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.monthOfYear();
        int int22 = mutableDateTime20.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = mutableDateTime20.toDateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime25 = dateTime24.toDateTime();
        org.joda.time.LocalTime localTime26 = dateTime25.toLocalTime();
        java.util.Locale locale28 = null;
        java.lang.String str29 = skipUndoDateTimeField13.getAsText((org.joda.time.ReadablePartial) localTime26, 19, locale28);
        boolean boolean30 = dateTime8.equals((java.lang.Object) 19);
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property32 = dateTime8.yearOfEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800000L + "'", long19 == 28800000L);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 19700 + "'", int22 == 19700);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localTime26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "19" + "'", str29.equals("19"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(property32);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 1, 19702);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 19702");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
        int int19 = mutableDateTime17.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
        org.joda.time.DurationField durationField27 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
        long long51 = offsetDateTimeField48.add((long) 19681, 19689);
        java.lang.String str53 = offsetDateTimeField48.getAsShortText(10L);
        long long55 = offsetDateTimeField48.roundFloor((long) 19683);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19700 + "'", int19 == 19700);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 19708681L + "'", long51 == 19708681L);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "64" + "'", str53.equals("64"));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 19000L + "'", long55 == 19000L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        int int12 = zeroIsMaxDateTimeField10.getMaximumValue((long) 2);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField14 = gJChronology13.weekyears();
        org.joda.time.DurationField durationField15 = gJChronology13.millis();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology13.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField16, dateTimeFieldType19);
        int int25 = zeroIsMaxDateTimeField23.getMaximumValue((long) 2);
        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime26.monthOfYear();
        int int28 = mutableDateTime26.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = mutableDateTime26.toDateTime(dateTimeZone29);
        org.joda.time.DateTime dateTime31 = dateTime30.toDateTime();
        org.joda.time.LocalTime localTime32 = dateTime31.toLocalTime();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gJChronology34.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField36 = gJChronology34.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField(chronology33, dateTimeField36);
        org.joda.time.DateTimeField dateTimeField38 = skipUndoDateTimeField37.getWrappedField();
        long long41 = skipUndoDateTimeField37.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial42 = null;
        int[] intArray50 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray52 = skipUndoDateTimeField37.add(readablePartial42, 19670, intArray50, 0);
        int int53 = zeroIsMaxDateTimeField23.getMaximumValue((org.joda.time.ReadablePartial) localTime32, intArray50);
        java.util.Locale locale55 = null;
        java.lang.String str56 = zeroIsMaxDateTimeField10.getAsText((org.joda.time.ReadablePartial) localTime32, 12, locale55);
        long long59 = zeroIsMaxDateTimeField10.add(49L, (long) 19);
        long long61 = zeroIsMaxDateTimeField10.roundCeiling((long) (short) 10);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 60 + "'", int12 == 60);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 60 + "'", int25 == 60);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 19700 + "'", int28 == 19700);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localTime32);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 49L + "'", long41 == 49L);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 60 + "'", int53 == 60);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "12" + "'", str56.equals("12"));
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 19049L + "'", long59 == 19049L);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1000L + "'", long61 == 1000L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        int int12 = zeroIsMaxDateTimeField10.getMaximumValue((long) 2);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField14 = gJChronology13.weekyears();
        org.joda.time.DurationField durationField15 = gJChronology13.millis();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology13.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField16, dateTimeFieldType19);
        int int25 = zeroIsMaxDateTimeField23.getMaximumValue((long) 2);
        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime26.monthOfYear();
        int int28 = mutableDateTime26.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = mutableDateTime26.toDateTime(dateTimeZone29);
        org.joda.time.DateTime dateTime31 = dateTime30.toDateTime();
        org.joda.time.LocalTime localTime32 = dateTime31.toLocalTime();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gJChronology34.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField36 = gJChronology34.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField(chronology33, dateTimeField36);
        org.joda.time.DateTimeField dateTimeField38 = skipUndoDateTimeField37.getWrappedField();
        long long41 = skipUndoDateTimeField37.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial42 = null;
        int[] intArray50 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray52 = skipUndoDateTimeField37.add(readablePartial42, 19670, intArray50, 0);
        int int53 = zeroIsMaxDateTimeField23.getMaximumValue((org.joda.time.ReadablePartial) localTime32, intArray50);
        java.util.Locale locale55 = null;
        java.lang.String str56 = zeroIsMaxDateTimeField10.getAsText((org.joda.time.ReadablePartial) localTime32, 12, locale55);
        int int59 = zeroIsMaxDateTimeField10.getDifference((long) 2000, (long) 19688);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 60 + "'", int12 == 60);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 60 + "'", int25 == 60);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 19700 + "'", int28 == 19700);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localTime32);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 49L + "'", long41 == 49L);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 60 + "'", int53 == 60);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "12" + "'", str56.equals("12"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-17) + "'", int59 == (-17));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology6.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField8);
        org.joda.time.DateTimeField dateTimeField10 = skipUndoDateTimeField9.getWrappedField();
        long long13 = skipUndoDateTimeField9.getDifferenceAsLong(1560342467589L, (long) ' ');
        long long15 = skipUndoDateTimeField9.roundFloor((long) (short) 1);
        int int16 = skipUndoDateTimeField9.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
        int int19 = mutableDateTime17.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime22 = dateTime21.toDateTime();
        org.joda.time.LocalTime localTime23 = dateTime22.toLocalTime();
        int int24 = skipUndoDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) localTime23);
        org.joda.time.DateTime dateTime25 = dateTime1.withFields((org.joda.time.ReadablePartial) localTime23);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 49L + "'", long13 == 49L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-31507200000L) + "'", long15 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19700 + "'", int19 == 19700);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(dateTime25);
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (short) 0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone3);
//        boolean boolean5 = cachedDateTimeZone3.isFixed();
//        java.lang.String str7 = cachedDateTimeZone3.getShortName((long) 19678);
//        org.joda.time.LocalDateTime localDateTime8 = null;
//        boolean boolean9 = cachedDateTimeZone3.isLocalDateTimeGap(localDateTime8);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone3, 0L, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) (short) 100, "monthOfYear");
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, (java.lang.Number) 19666, "");
        java.lang.Number number20 = illegalFieldValueException19.getLowerBound();
        illegalFieldValueException13.addSuppressed((java.lang.Throwable) illegalFieldValueException19);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(number20);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 19674);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.Instant instant6 = instant1.withDurationAdded(63052141542L, 19684);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        java.lang.String str3 = gJChronology0.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str3.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = mutableDateTime0.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        boolean boolean7 = dateTime5.isAfterNow();
        org.joda.time.DateTime dateTime8 = dateTime5.toDateTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField13 = gJChronology12.weekyears();
        org.joda.time.DurationField durationField14 = gJChronology12.millis();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology12.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField15, dateTimeFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder9.appendFixedDecimal(dateTimeFieldType18, (int) (short) 100);
        try {
            org.joda.time.DateTime dateTime32 = dateTime5.withField(dateTimeFieldType18, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19700 + "'", int2 == 19700);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = mutableDateTime0.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        int int7 = dateTime5.getYearOfCentury();
        org.joda.time.DateTime.Property property8 = dateTime5.secondOfMinute();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19700 + "'", int2 == 19700);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType9, (int) (short) 100);
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 0L, "47");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("monthOfYear", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (short) 1, 'a', 0, 2, 19671, true, 60);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.setFixedSavings("2019-W24", 3);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder25 = dateTimeZoneBuilder14.addRecurringSavings("59", (int) (byte) 100, 19693, (-1), ' ', 69, 4, 2019, true, 0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder25);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfCentury(52);
        org.joda.time.DateTime dateTime8 = dateTime1.plusHours(19689901);
        org.joda.time.DateTime dateTime9 = dateTime1.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = property1.getMaximumValueOverall();
        int int3 = property1.getLeapAmount();
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = property1.set("hi!");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long12 = zeroIsMaxDateTimeField10.roundHalfEven(0L);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.monthOfYear();
        int int15 = mutableDateTime13.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = mutableDateTime13.toDateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        int int20 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime19);
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.monthOfYear();
        int int23 = mutableDateTime21.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = mutableDateTime21.toDateTime(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime25.toDateTime();
        org.joda.time.LocalTime localTime27 = dateTime26.toLocalTime();
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology29.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField(chronology28, dateTimeField31);
        org.joda.time.DateTimeField dateTimeField33 = skipUndoDateTimeField32.getWrappedField();
        long long36 = skipUndoDateTimeField32.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial37 = null;
        int[] intArray45 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray47 = skipUndoDateTimeField32.add(readablePartial37, 19670, intArray45, 0);
        int int48 = zeroIsMaxDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime27, intArray47);
        org.joda.time.DurationField durationField49 = zeroIsMaxDateTimeField10.getLeapDurationField();
        int int51 = zeroIsMaxDateTimeField10.get((-187200000L));
        try {
            long long54 = zeroIsMaxDateTimeField10.set((long) 3, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,60]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19700 + "'", int15 == 19700);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 60 + "'", int20 == 60);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19700 + "'", int23 == 19700);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localTime27);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 49L + "'", long36 == 49L);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 60 + "'", int48 == 60);
        org.junit.Assert.assertNull(durationField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 60 + "'", int51 == 60);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = property1.getFieldType();
        java.util.Locale locale3 = null;
        int int4 = property1.getMaximumShortTextLength(locale3);
        int int5 = property1.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeFieldType2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology3);
//        mutableDateTime6.setSecondOfDay((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        mutableDateTime6.setZoneRetainFields(dateTimeZone9);
//        int int11 = mutableDateTime6.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = mutableDateTime6.getZone();
//        long long15 = dateTimeZone12.adjustOffset((long) 19684, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField19 = gregorianChronology18.weekyears();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone23 = dateTimeZoneBuilder20.toDateTimeZone("monthOfYear", false);
//        org.joda.time.Chronology chronology24 = gregorianChronology18.withZone(dateTimeZone23);
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.hourOfHalfday();
//        java.util.Locale locale28 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology26, locale28);
//        java.util.Locale locale30 = dateTimeParserBucket29.getLocale();
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket32 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology24, locale30, (java.lang.Integer) 19671);
//        java.lang.String str33 = dateTimeZone12.getShortName((long) 2000, locale30);
//        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance(chronology1, dateTimeZone12);
//        try {
//            long long39 = zonedChronology34.getDateTimeMillis((-18059), 0, 19684, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 19684L + "'", long15 == 19684L);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(locale30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PST" + "'", str33.equals("PST"));
//        org.junit.Assert.assertNotNull(zonedChronology34);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology2);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) 100, (org.joda.time.Chronology) gJChronology2);
        boolean boolean7 = mutableDateTime6.isEqualNow();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime6.dayOfYear();
        boolean boolean10 = mutableDateTime6.isEqual((long) 19675);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime6.minuteOfHour();
        org.joda.time.DurationField durationField12 = property11.getLeapDurationField();
        try {
            org.joda.time.MutableDateTime mutableDateTime14 = property11.set("1969-12-18T16:12:02.000-08:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-18T16:12:02.000-08:00\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNull(durationField12);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeZoneBuilder4.toDateTimeZone("monthOfYear", false);
        org.joda.time.DateTime dateTime8 = dateTime3.withZone(dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime11 = dateTime3.withSecondOfMinute(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = mutableDateTime0.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property6 = dateTime5.minuteOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.plusMinutes((int) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.withYear((int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField12 = gJChronology11.weekyears();
        org.joda.time.DurationField durationField13 = gJChronology11.millis();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.minus(readablePeriod16);
        org.joda.time.DateTime.Property property18 = dateTime15.weekOfWeekyear();
        boolean boolean19 = gJChronology11.equals((java.lang.Object) dateTime15);
        org.joda.time.DateTime dateTime20 = dateTime10.toDateTime((org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTime.Property property21 = dateTime20.hourOfDay();
        org.joda.time.DateTime dateTime23 = dateTime20.minusMinutes(8);
        boolean boolean24 = dateTime4.isEqual((org.joda.time.ReadableInstant) dateTime20);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19700 + "'", int2 == 19700);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = mutableDateTime0.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField9 = gJChronology8.weekyears();
        org.joda.time.DurationField durationField10 = gJChronology8.millis();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField18 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField11, dateTimeFieldType14);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder5.appendFixedDecimal(dateTimeFieldType14, (int) (short) 100);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime0.property(dateTimeFieldType14);
        org.joda.time.DurationField durationField28 = property27.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology31.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField33 = gJChronology31.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology31);
        mutableDateTime34.setSecondOfDay((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        mutableDateTime34.setZoneRetainFields(dateTimeZone37);
        org.joda.time.ReadableInstant readableInstant39 = null;
        mutableDateTime34.setMillis(readableInstant39);
        org.joda.time.MutableDateTime.Property property41 = mutableDateTime34.dayOfMonth();
        long long42 = property27.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime34);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19700 + "'", int2 == 19700);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime1.minusHours(60);
        org.joda.time.DateTime.Property property6 = dateTime1.monthOfYear();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((-187200000L));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Pacific Standard Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, readableInstant7);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019-W28" + "'", str6.equals("2019-W28"));
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (-31507200000L), 0);
        try {
            long long13 = gregorianChronology0.getDateTimeMillis(19688, 19685, 5929, 19695, 3, 86399, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19695 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-31507200000L) + "'", long5 == (-31507200000L));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 35, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusMonths(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeZoneBuilder4.toDateTimeZone("monthOfYear", false);
        org.joda.time.DateTime dateTime8 = dateTime3.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.plus((long) 19691);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology12.yearOfCentury();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket(2000012L, (org.joda.time.Chronology) gJChronology12, locale15, (java.lang.Integer) (-2), 19675);
        java.lang.Object obj19 = dateTimeParserBucket18.saveState();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField24 = gJChronology23.weekyears();
        org.joda.time.DurationField durationField25 = gJChronology23.millis();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology23.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField33 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField26, dateTimeFieldType29);
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder20.appendFixedDecimal(dateTimeFieldType29, (int) (short) 100);
        dateTimeParserBucket18.saveField(dateTimeFieldType29, 0);
        org.joda.time.DateTime.Property property44 = dateTime8.property(dateTimeFieldType29);
        org.joda.time.MutableDateTime mutableDateTime45 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property46 = mutableDateTime45.monthOfYear();
        int int47 = mutableDateTime45.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.DateTime dateTime49 = mutableDateTime45.toDateTime(dateTimeZone48);
        org.joda.time.DateTime dateTime50 = dateTime49.toDateTime();
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime8, (org.joda.time.ReadableInstant) dateTime49);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 19700 + "'", int47 == 19700);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(chronology51);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        long long13 = zeroIsMaxDateTimeField10.set((long) 52, "59");
        int int14 = zeroIsMaxDateTimeField10.getMinimumValue();
        org.joda.time.DurationField durationField15 = zeroIsMaxDateTimeField10.getLeapDurationField();
        int int16 = zeroIsMaxDateTimeField10.getMinimumValue();
        int int19 = zeroIsMaxDateTimeField10.getDifference((long) 19693, 192480938L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 59052L + "'", long13 == 59052L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-192461) + "'", int19 == (-192461));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType6, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField3, dateTimeFieldType6);
        org.joda.time.DurationField durationField11 = zeroIsMaxDateTimeField10.getDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = zeroIsMaxDateTimeField10.getAsText((long) (short) -1, locale13);
        long long16 = zeroIsMaxDateTimeField10.roundCeiling((-31507200000L));
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.monthOfYear();
        int int19 = mutableDateTime17.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = mutableDateTime17.toDateTime(dateTimeZone20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField26 = gJChronology25.weekyears();
        org.joda.time.DurationField durationField27 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField35 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField28, dateTimeFieldType31);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType31, (int) (short) 100);
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime17.property(dateTimeFieldType31);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField10, dateTimeFieldType31, 4, (int) ' ', 19666);
        long long50 = offsetDateTimeField48.roundHalfFloor(0L);
        long long53 = offsetDateTimeField48.add(19708681L, 30);
        int int56 = offsetDateTimeField48.getDifference((long) 19674, (long) (byte) 10);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "59" + "'", str14.equals("59"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31507200000L) + "'", long16 == (-31507200000L));
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19700 + "'", int19 == 19700);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 19738681L + "'", long53 == 19738681L);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 19 + "'", int56 == 19);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.yearOfCentury();
        long long6 = gJChronology0.add((long) (short) 100, 0L, (int) (byte) 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField10);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTime dateTime14 = dateTime13.withEarlierOffsetAtOverlap();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.DateTime dateTime17 = dateTime14.withField(dateTimeFieldType15, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readablePeriod2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withDurationAdded(readableDuration4, 2019);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.minus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfDay(19676);
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType9, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendMillisOfDay(19677);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendTwoDigitYear((-19666));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendDayOfYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder27.appendFractionOfSecond(0, 19674);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 19674);
        long long2 = instant1.getMillis();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 19674L + "'", long2 == 19674L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.weekOfWeekyear();
        org.joda.time.Chronology chronology4 = gJChronology0.withUTC();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology5.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.centuryOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField8, 95);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField4 = gJChronology3.weekyears();
        org.joda.time.DurationField durationField5 = gJChronology3.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField13 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType9);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType9, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendSecondOfDay(19676);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.appendDayOfYear((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.monthOfYear();
        int int2 = mutableDateTime0.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime(dateTimeZone3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay(19);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField9 = gJChronology8.weekyears();
        org.joda.time.DurationField durationField10 = gJChronology8.millis();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField18 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField11, dateTimeFieldType14);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "hi!");
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) (byte) 0, (java.lang.Number) 4, (java.lang.Number) 0.0f);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder5.appendFixedDecimal(dateTimeFieldType14, (int) (short) 100);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime0.property(dateTimeFieldType14);
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 0.0f, "59");
        java.lang.Number number31 = illegalFieldValueException30.getUpperBound();
        java.lang.String str32 = illegalFieldValueException30.getIllegalStringValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19700 + "'", int2 == 19700);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNull(number31);
        org.junit.Assert.assertNull(str32);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(19);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter7.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter10.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6, dateTimeParser9, dateTimeParser12, dateTimeParser15, dateTimeParser18 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter3, dateTimeParserArray19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder20.appendHalfdayOfDayText();
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField23 = gJChronology22.weekyears();
        org.joda.time.DurationField durationField24 = gJChronology22.millis();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology22.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime26.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 19666, "");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType28);
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) (short) 100, "monthOfYear");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder21.appendDecimal(dateTimeFieldType28, 19696, 19671);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder21.appendMinuteOfHour(19683);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder21.appendClockhourOfHalfday(19693);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeParserArray19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.weekyears();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("monthOfYear", false);
        org.joda.time.Chronology chronology7 = gregorianChronology1.withZone(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.hourOfHalfday();
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gJChronology9, locale11);
        java.util.Locale locale13 = dateTimeParserBucket12.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket(1560342467589L, chronology7, locale13, (java.lang.Integer) 19671);
        org.joda.time.Chronology chronology16 = dateTimeParserBucket15.getChronology();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime((-1L), (org.joda.time.Chronology) gJChronology18);
        mutableDateTime21.setSecondOfDay((int) (short) 100);
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime21.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder25 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone28 = dateTimeZoneBuilder25.toDateTimeZone("monthOfYear", false);
        java.lang.String str30 = dateTimeZone28.getShortName(0L);
        mutableDateTime21.setZoneRetainFields(dateTimeZone28);
        dateTimeParserBucket15.setZone(dateTimeZone28);
        int int33 = dateTimeParserBucket15.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(locale13);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+00:00" + "'", str30.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (byte) 100);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        try {
            mutableDateTime1.setDate(19696, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(27, (-19695));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 27");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gJChronology0.millis();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readablePeriod5);
        org.joda.time.DateTime.Property property7 = dateTime4.weekOfWeekyear();
        boolean boolean8 = gJChronology0.equals((java.lang.Object) dateTime4);
        try {
            org.joda.time.DateTime dateTime10 = dateTime4.withMillisOfSecond(12885);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12885 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str2 = julianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.Chronology chronology4 = buddhistChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("May");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"May\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str1 = julianChronology0.toString();
        org.joda.time.DurationField durationField2 = julianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str1.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField3);
        org.joda.time.DateTimeField dateTimeField5 = skipUndoDateTimeField4.getWrappedField();
        long long8 = skipUndoDateTimeField4.getDifferenceAsLong(1560342467589L, (long) ' ');
        org.joda.time.ReadablePartial readablePartial9 = null;
        int[] intArray17 = new int[] { 60, 60, 1, 69, ' ', 19670 };
        int[] intArray19 = skipUndoDateTimeField4.add(readablePartial9, 19670, intArray17, 0);
        java.lang.String str20 = skipUndoDateTimeField4.toString();
        org.joda.time.DurationField durationField21 = skipUndoDateTimeField4.getLeapDurationField();
        java.lang.String str23 = skipUndoDateTimeField4.getAsText((long) '4');
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 49L + "'", long8 == 49L);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[yearOfCentury]" + "'", str20.equals("DateTimeField[yearOfCentury]"));
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "69" + "'", str23.equals("69"));
    }
}

