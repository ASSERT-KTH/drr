import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDecimal(dateTimeFieldType3, 903, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        long long8 = fixedDateTimeZone4.previousTransition((long) 23);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 23L + "'", long8 == 23L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
//        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField26.getLeapDurationField();
//        try {
//            int int28 = unsupportedDateTimeField26.getMinimumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200100L + "'", long21 == 7200100L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertNull(durationField27);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-25200000));
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("1970-W01-4T00:58:24-08:00", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        try {
            long long15 = gregorianChronology6.getDateTimeMillis(6, 12, 2000, (-19), 35, 14, (-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -19 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusHours(365);
        org.joda.time.DateTime dateTime4 = dateTime0.minusMonths((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime0.plusMinutes(10);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfHalfday();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.secondOfMinute();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        boolean boolean12 = dateTimeZone10.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property14 = dateTime13.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField8, dateTimeFieldType15, 2019);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType15, 365);
        java.util.Locale locale22 = null;
        try {
            long long23 = remainderDateTimeField19.set((-1703601849599948L), "53979", locale22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53979 for secondOfDay must be in the range [0,364]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        long long15 = dividedDateTimeField12.roundCeiling((-1L));
        long long18 = dividedDateTimeField12.add((long) 50, (int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = dividedDateTimeField12.getAsText((int) (short) 10, locale20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.secondOfMinute();
        java.util.TimeZone timeZone26 = null;
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forTimeZone(timeZone26);
        boolean boolean29 = dateTimeZone27.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone27);
        org.joda.time.DateTime.Property property31 = dateTime30.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property31.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType32, 2019);
        java.util.TimeZone timeZone35 = null;
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forTimeZone(timeZone35);
        boolean boolean38 = dateTimeZone36.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.YearMonthDay yearMonthDay40 = dateTime39.toYearMonthDay();
        int int41 = dividedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.clockhourOfHalfday();
        java.util.TimeZone timeZone44 = null;
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forTimeZone(timeZone44);
        boolean boolean47 = dateTimeZone45.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(dateTimeZone45);
        org.joda.time.YearMonthDay yearMonthDay49 = dateTime48.toYearMonthDay();
        int[] intArray51 = iSOChronology42.get((org.joda.time.ReadablePartial) yearMonthDay49, (long) 35);
        int int52 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay40, intArray51);
        long long54 = dividedDateTimeField12.roundHalfCeiling(0L);
        int int55 = dividedDateTimeField12.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1959000L + "'", long15 == 1959000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 195843050L + "'", long18 == 195843050L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(yearMonthDay40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(yearMonthDay49);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long20 = offsetDateTimeField18.remainder((long) 10);
//        long long22 = offsetDateTimeField18.remainder(1560635971473L);
//        int int23 = offsetDateTimeField18.getMaximumValue();
//        int int24 = offsetDateTimeField18.getOffset();
//        long long26 = offsetDateTimeField18.roundFloor((long) (byte) 0);
//        int int28 = offsetDateTimeField18.get(0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 3571473L + "'", long22 == 3571473L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 12 + "'", int23 == 12);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 34 + "'", int28 == 34);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.secondOfMinute();
        java.util.TimeZone timeZone23 = null;
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
        boolean boolean26 = dateTimeZone24.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone24);
        org.joda.time.DateTime.Property property28 = dateTime27.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField(dateTimeField22, dateTimeFieldType29, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType29, (int) (byte) -1, 17, 0);
        int int40 = offsetDateTimeField18.getMinimumValue();
        boolean boolean42 = offsetDateTimeField18.isLeap((long) 53958);
        long long44 = offsetDateTimeField18.roundFloor((long) 0);
        long long46 = offsetDateTimeField18.roundHalfFloor((long) 53982065);
        long long48 = offsetDateTimeField18.remainder(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 11 + "'", int40 == 11);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 54000000L + "'", long46 == 54000000L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DurationField durationField7 = gregorianChronology6.weeks();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        boolean boolean16 = dateTimeZone14.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime17.toYearMonthDay();
        int int19 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay18);
        long long22 = dividedDateTimeField12.getDifferenceAsLong((-100L), 1L);
        int int24 = dividedDateTimeField12.getLeapAmount((-1L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(yearMonthDay18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
//        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
//        int int29 = unsupportedDateTimeField26.getDifference(1560549571543L, (long) 23);
//        long long32 = unsupportedDateTimeField26.add((long) 100, 0);
//        org.joda.time.DurationField durationField33 = unsupportedDateTimeField26.getLeapDurationField();
//        try {
//            long long36 = unsupportedDateTimeField26.set((long) 433485, "Pacific Daylight Time");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200100L + "'", long21 == 7200100L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 433485 + "'", int29 == 433485);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
//        org.junit.Assert.assertNull(durationField33);
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime4.getZone();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = dateTime10.minusMonths(0);
//        org.joda.time.DateTime dateTime15 = dateTime10.withMillisOfDay(2000);
//        java.util.TimeZone timeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
//        boolean boolean19 = dateTimeZone17.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.Chronology chronology21 = dateTime20.getChronology();
//        org.joda.time.DateTime dateTime23 = dateTime20.minusDays(1);
//        int int24 = dateTime20.getYearOfCentury();
//        org.joda.time.DateTime dateTime26 = dateTime20.minus(1263557883L);
//        int int27 = dateTime20.getYearOfEra();
//        org.joda.time.DateTime dateTime28 = dateTime20.toDateTime();
//        int int29 = dateTime20.getMinuteOfHour();
//        boolean boolean30 = dateTime15.isEqual((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime.Property property31 = dateTime20.era();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 19 + "'", int24 == 19);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(property31);
//    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfWeek();
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        long long7 = dateTimeZone4.adjustOffset(0L, false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
//        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone4);
//        java.util.TimeZone timeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
//        long long15 = dateTimeZone12.adjustOffset(0L, false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
//        java.lang.String str18 = cachedDateTimeZone16.getNameKey((long) 86399999);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(195843050L, (org.joda.time.DateTimeZone) cachedDateTimeZone16);
//        org.joda.time.DateTime.Property property20 = dateTime19.secondOfMinute();
//        boolean boolean21 = zonedChronology9.equals((java.lang.Object) property20);
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.secondOfMinute();
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology24);
//        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
//        org.joda.time.DateTime dateTime28 = dateTime26.toDateTimeISO();
//        long long29 = dateTime26.getMillis();
//        org.joda.time.ReadablePeriod readablePeriod30 = null;
//        org.joda.time.DateTime dateTime31 = dateTime26.minus(readablePeriod30);
//        int int32 = property20.compareTo((org.joda.time.ReadableInstant) dateTime31);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
//        org.junit.Assert.assertNotNull(zonedChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560636021802L + "'", long29 == 1560636021802L);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
        int int8 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime10 = dateTime4.minus(1263557883L);
        int int11 = dateTime4.getYearOfEra();
        org.joda.time.DateTime dateTime12 = dateTime4.toDateTime();
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.secondOfMinute();
        java.util.TimeZone timeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone18);
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, dateTimeFieldType23, 2019);
        boolean boolean26 = dividedDateTimeField25.isLenient();
        long long28 = dividedDateTimeField25.roundCeiling((-1L));
        long long31 = dividedDateTimeField25.add((long) 50, (int) 'a');
        int int32 = dateTime12.get((org.joda.time.DateTimeField) dividedDateTimeField25);
        java.util.Locale locale33 = null;
        int int34 = dividedDateTimeField25.getMaximumShortTextLength(locale33);
        boolean boolean36 = dividedDateTimeField25.isLeap((long) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1959000L + "'", long28 == 1959000L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 195843050L + "'", long31 == 195843050L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        try {
            long long11 = gregorianChronology3.getDateTimeMillis((-772931), 53985461, 2000, 86399999, 17, 0, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.secondOfMinute();
//        java.util.TimeZone timeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        boolean boolean26 = dateTimeZone24.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.DateTime.Property property28 = dateTime27.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField(dateTimeField22, dateTimeFieldType29, 2019);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType29, (int) (byte) -1, 17, 0);
//        int int40 = offsetDateTimeField18.getMinimumValue();
//        boolean boolean42 = offsetDateTimeField18.isLeap((long) 53958);
//        long long44 = offsetDateTimeField18.roundFloor((long) 0);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = offsetDateTimeField18.getAsText(9972000000L, locale46);
//        long long49 = offsetDateTimeField18.roundHalfCeiling(1560549565386L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 11 + "'", int40 == 11);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "20" + "'", str47.equals("20"));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560549600000L + "'", long49 == 1560549600000L);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        long long4 = dateTimeZone1.adjustOffset(0L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.Chronology chronology11 = dateTime10.getChronology();
        org.joda.time.DateTime dateTime13 = dateTime10.minusDays(1);
        org.joda.time.DateTime dateTime15 = dateTime13.plusMillis((int) '#');
        int int16 = dateTime13.getYearOfEra();
        org.joda.time.DateTime dateTime18 = dateTime13.minusDays(0);
        org.joda.time.DateTime.Property property19 = dateTime18.minuteOfDay();
        org.joda.time.DateTime dateTime21 = property19.addWrapFieldToCopy((int) (byte) 10);
        boolean boolean22 = cachedDateTimeZone5.equals((java.lang.Object) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime21.plusMonths(19);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (byte) 0);
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear(2019);
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra(52);
        org.joda.time.DateTime dateTime13 = dateTime11.plusHours((-28800000));
        try {
            org.joda.time.DateTime dateTime15 = dateTime11.withDayOfWeek((-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfWeek();
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        long long7 = dateTimeZone4.adjustOffset(0L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone4);
        org.joda.time.DurationField durationField10 = zonedChronology9.millis();
        long long13 = durationField10.subtract((long) 1, (long) '#');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-34L) + "'", long13 == (-34L));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(1560549571543L);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.dayOfWeek();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology2);
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.secondOfMinute();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        boolean boolean16 = dateTimeZone14.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone14);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField(dateTimeField12, dateTimeFieldType19, 2019);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
//        boolean boolean26 = dateTime8.isSupported(dateTimeFieldType19);
//        int int27 = dateTime8.getDayOfMonth();
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime8.plus(readablePeriod28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
//        org.junit.Assert.assertNotNull(dateTime29);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.monthOfYear();
        long long8 = iSOChronology2.add((long) 19, (long) 50, (int) '4');
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2619L + "'", long8 == 2619L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
//        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField26.getLeapDurationField();
//        java.util.Locale locale29 = null;
//        try {
//            java.lang.String str30 = unsupportedDateTimeField26.getAsShortText(0L, locale29);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200100L + "'", long21 == 7200100L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertNull(durationField27);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        boolean boolean16 = dateTimeZone14.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime17.toYearMonthDay();
        int int19 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay18);
        long long22 = dividedDateTimeField12.getDifferenceAsLong((-100L), 1L);
        long long25 = dividedDateTimeField12.add((long) 18, (long) 15);
        org.joda.time.DurationField durationField26 = dividedDateTimeField12.getRangeDurationField();
        java.util.Locale locale27 = null;
        int int28 = dividedDateTimeField12.getMaximumShortTextLength(locale27);
        org.joda.time.DurationField durationField29 = dividedDateTimeField12.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(yearMonthDay18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 30285018L + "'", long25 == 30285018L);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(durationField29);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
//        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
//        int int29 = unsupportedDateTimeField26.getDifference(1560549571543L, (long) 23);
//        long long32 = unsupportedDateTimeField26.add((long) 100, 0);
//        try {
//            long long34 = unsupportedDateTimeField26.roundHalfFloor((long) 12);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200100L + "'", long21 == 7200100L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 433485 + "'", int29 == 433485);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        int int7 = property5.getLeapAmount();
        boolean boolean8 = property5.isLeap();
        org.joda.time.DateTime dateTime9 = property5.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.secondOfMinute();
//        int int12 = dateTime4.get(dateTimeField11);
//        int int13 = dateTime4.getHourOfDay();
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime4.plus(readableDuration14);
//        long long16 = dateTime4.getMillis();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 22 + "'", int12 == 22);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 22 + "'", int13 == 22);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560636022931L + "'", long16 == 1560636022931L);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(9972000000L, 2000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 19944000000000L + "'", long2 == 19944000000000L);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusMillis((int) '#');
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime7.plus(readableDuration10);
//        long long12 = dateTime11.getMillis();
//        org.joda.time.DateTime dateTime14 = dateTime11.minusYears(20);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded(readableDuration15, (-25200000));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560549622980L + "'", long12 == 1560549622980L);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        java.lang.Object obj9 = null;
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        boolean boolean11 = org.joda.time.field.FieldUtils.equals(obj9, (java.lang.Object) dateTime10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime14 = dateTime10.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime dateTime16 = dateTime10.plusWeeks(10);
        org.joda.time.DateTime dateTime19 = dateTime10.withDurationAdded((-100L), (int) '#');
        org.joda.time.DateTime.Property property20 = dateTime10.era();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("America/Los_Angeles", number1, (java.lang.Number) 2019, (java.lang.Number) 54002);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "null" + "'", str5.equals("null"));
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
//        java.lang.Object obj9 = null;
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        boolean boolean11 = org.joda.time.field.FieldUtils.equals(obj9, (java.lang.Object) dateTime10);
//        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime14 = dateTime10.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime.Property property15 = dateTime10.weekyear();
//        org.joda.time.DateTime dateTime17 = dateTime10.plusMinutes((-1));
//        org.joda.time.DateTime dateTime18 = dateTime10.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime.Property property19 = dateTime18.hourOfDay();
//        org.joda.time.DateTime dateTime21 = property19.addWrapFieldToCopy(16);
//        java.lang.String str22 = property19.getAsString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "22" + "'", str22.equals("22"));
//    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTime1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        boolean boolean6 = dateTimeZone4.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear((int) (byte) 0);
//        int int11 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime13 = dateTime7.minusWeeks(0);
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        int int16 = dateTime15.getHourOfDay();
//        int int17 = dateTime15.getMonthOfYear();
//        org.joda.time.DateTime dateTime19 = dateTime15.plusSeconds(544);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 22 + "'", int16 == 22);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        java.util.Locale locale15 = null;
        java.lang.String str16 = dividedDateTimeField12.getAsText(2619L, locale15);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField12, (-25200000));
        java.util.Locale locale20 = null;
        java.lang.String str21 = dividedDateTimeField12.getAsShortText(1560549571543L, locale20);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (byte) 0);
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear(2019);
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra(52);
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.secondOfMinute();
        java.util.TimeZone timeZone16 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
        boolean boolean19 = dateTimeZone17.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.DateTime.Property property21 = dateTime20.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField15, dateTimeFieldType22, 2019);
        boolean boolean25 = dividedDateTimeField24.isLenient();
        java.util.TimeZone timeZone26 = null;
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forTimeZone(timeZone26);
        boolean boolean29 = dateTimeZone27.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone27);
        org.joda.time.DateTime.Property property31 = dateTime30.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property31.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField24, dateTimeFieldType32, (int) '4');
        org.joda.time.DateTime dateTime36 = dateTime11.withField(dateTimeFieldType32, 0);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType32, (-19), 86399999, 41);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -19 for secondOfDay must be in the range [86399999,41]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime36);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendSecondOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTime1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        boolean boolean6 = dateTimeZone4.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear((int) (byte) 0);
//        int int11 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime13 = dateTime7.minusWeeks(0);
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getShortName((long) 54, locale16);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UTC" + "'", str17.equals("UTC"));
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.secondOfMinute();
//        java.util.TimeZone timeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        boolean boolean26 = dateTimeZone24.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.DateTime.Property property28 = dateTime27.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField(dateTimeField22, dateTimeFieldType29, 2019);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType29, (int) (byte) -1, 17, 0);
//        long long42 = offsetDateTimeField18.addWrapField(0L, (int) (byte) 1);
//        try {
//            long long45 = offsetDateTimeField18.add((long) 18, 7200100L);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 14 for secondOfDay must be in the range [11,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 3600000L + "'", long42 == 3600000L);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(16, (-292275054), 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-292275039) + "'", int3 == (-292275039));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfHalfday();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        boolean boolean5 = dateTimeZone3.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime6.toYearMonthDay();
        int[] intArray9 = iSOChronology0.get((org.joda.time.ReadablePartial) yearMonthDay7, (long) 35);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(yearMonthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 100, 66, 17, 5, 53958, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53958 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        boolean boolean17 = dateTimeZone15.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone15);
        org.joda.time.DateTime.Property property19 = dateTime18.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property19.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField22 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField12, dateTimeFieldType20, (int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter23.withChronology((org.joda.time.Chronology) iSOChronology24);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology24.clockhourOfHalfday();
        java.util.TimeZone timeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forTimeZone(timeZone28);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.secondOfMinute();
        java.util.TimeZone timeZone32 = null;
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forTimeZone(timeZone32);
        boolean boolean35 = dateTimeZone33.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(dateTimeZone33);
        org.joda.time.DateTime.Property property37 = dateTime36.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField31, dateTimeFieldType38, 2019);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField(dateTimeField27, dateTimeFieldType38, 365);
        java.util.TimeZone timeZone43 = null;
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forTimeZone(timeZone43);
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology45.secondOfMinute();
        java.util.TimeZone timeZone47 = null;
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forTimeZone(timeZone47);
        boolean boolean50 = dateTimeZone48.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone48);
        org.joda.time.DateTime.Property property52 = dateTime51.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property52.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField55 = new org.joda.time.field.DividedDateTimeField(dateTimeField46, dateTimeFieldType53, 2019);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField56 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField42, dateTimeFieldType53);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField22, dateTimeFieldType53);
        long long59 = remainderDateTimeField57.remainder((long) ' ');
        try {
            long long62 = remainderDateTimeField57.addWrapField((long) (byte) 10, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for secondOfDay must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 32L + "'", long59 == 32L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("2019-06-15T14:59:47.555-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-15T14:59:47.555-07:00\" is malformed at \"-06-15T14:59:47.555-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        int int8 = dateTime4.getYearOfCentury();
//        org.joda.time.DateTime dateTime10 = dateTime4.minus(1263557883L);
//        org.joda.time.LocalTime localTime11 = dateTime4.toLocalTime();
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.secondOfMinute();
//        java.util.TimeZone timeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
//        boolean boolean19 = dateTimeZone17.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.DateTime.Property property21 = dateTime20.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField15, dateTimeFieldType22, 2019);
//        boolean boolean25 = dividedDateTimeField24.isLenient();
//        java.util.TimeZone timeZone26 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forTimeZone(timeZone26);
//        boolean boolean29 = dateTimeZone27.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone27);
//        org.joda.time.DateTime.Property property31 = dateTime30.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property31.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField24, dateTimeFieldType32, (int) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.clockhourOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter35.withChronology((org.joda.time.Chronology) iSOChronology36);
//        org.joda.time.DateTimeField dateTimeField39 = iSOChronology36.clockhourOfHalfday();
//        java.util.TimeZone timeZone40 = null;
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forTimeZone(timeZone40);
//        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
//        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.secondOfMinute();
//        java.util.TimeZone timeZone44 = null;
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forTimeZone(timeZone44);
//        boolean boolean47 = dateTimeZone45.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(dateTimeZone45);
//        org.joda.time.DateTime.Property property49 = dateTime48.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = property49.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField52 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType50, 2019);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField54 = new org.joda.time.field.RemainderDateTimeField(dateTimeField39, dateTimeFieldType50, 365);
//        java.util.TimeZone timeZone55 = null;
//        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.forTimeZone(timeZone55);
//        org.joda.time.chrono.ISOChronology iSOChronology57 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone56);
//        org.joda.time.DateTimeField dateTimeField58 = iSOChronology57.secondOfMinute();
//        java.util.TimeZone timeZone59 = null;
//        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.forTimeZone(timeZone59);
//        boolean boolean62 = dateTimeZone60.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime(dateTimeZone60);
//        org.joda.time.DateTime.Property property64 = dateTime63.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType65 = property64.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField67 = new org.joda.time.field.DividedDateTimeField(dateTimeField58, dateTimeFieldType65, 2019);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField54, dateTimeFieldType65);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField69 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField34, dateTimeFieldType65);
//        int int70 = dateTime4.get(dateTimeFieldType65);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(iSOChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertNotNull(iSOChronology57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertNotNull(dateTimeFieldType65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 79224 + "'", int70 == 79224);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("166");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
        org.joda.time.DateTime dateTime11 = dateTime7.minusYears(23);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime7.minus(readableDuration12);
        org.joda.time.DateTime.Property property14 = dateTime7.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withOffsetParsed();
        java.lang.Appendable appendable3 = null;
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.secondOfMinute();
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        boolean boolean11 = dateTimeZone9.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.DateTime.Property property13 = dateTime12.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(dateTimeField7, dateTimeFieldType14, 2019);
        java.util.TimeZone timeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
        boolean boolean20 = dateTimeZone18.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone18);
        org.joda.time.YearMonthDay yearMonthDay22 = dateTime21.toYearMonthDay();
        int int23 = dividedDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay22);
        long long26 = dividedDateTimeField16.getDifferenceAsLong((-100L), 1L);
        long long29 = dividedDateTimeField16.add((long) 18, (long) 15);
        org.joda.time.DurationField durationField30 = dividedDateTimeField16.getRangeDurationField();
        java.util.TimeZone timeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forTimeZone(timeZone31);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.secondOfMinute();
        java.util.TimeZone timeZone35 = null;
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forTimeZone(timeZone35);
        boolean boolean38 = dateTimeZone36.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.DateTime.Property property40 = dateTime39.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property40.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField43 = new org.joda.time.field.DividedDateTimeField(dateTimeField34, dateTimeFieldType41, 2019);
        boolean boolean44 = dividedDateTimeField43.isLenient();
        java.util.TimeZone timeZone45 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forTimeZone(timeZone45);
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology47.secondOfMinute();
        java.util.TimeZone timeZone49 = null;
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forTimeZone(timeZone49);
        boolean boolean52 = dateTimeZone50.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone50);
        org.joda.time.DateTime.Property property54 = dateTime53.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property54.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField(dateTimeField48, dateTimeFieldType55, 2019);
        java.util.TimeZone timeZone58 = null;
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.forTimeZone(timeZone58);
        boolean boolean61 = dateTimeZone59.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(dateTimeZone59);
        org.joda.time.YearMonthDay yearMonthDay63 = dateTime62.toYearMonthDay();
        int int64 = dividedDateTimeField57.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay63);
        java.util.TimeZone timeZone65 = null;
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forTimeZone(timeZone65);
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone66);
        org.joda.time.DateTimeField dateTimeField68 = iSOChronology67.secondOfMinute();
        java.util.TimeZone timeZone69 = null;
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forTimeZone(timeZone69);
        boolean boolean72 = dateTimeZone70.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime(dateTimeZone70);
        org.joda.time.DateTime.Property property74 = dateTime73.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property74.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField(dateTimeField68, dateTimeFieldType75, 2019);
        org.joda.time.DateTimeField dateTimeField78 = dividedDateTimeField77.getWrappedField();
        org.joda.time.ReadablePartial readablePartial79 = null;
        int[] intArray81 = new int[] { 2000 };
        int int82 = dividedDateTimeField77.getMinimumValue(readablePartial79, intArray81);
        int int83 = dividedDateTimeField43.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay63, intArray81);
        java.util.Locale locale85 = null;
        java.lang.String str86 = dividedDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay63, 0, locale85);
        try {
            dateTimeFormatter2.printTo(appendable3, (org.joda.time.ReadablePartial) yearMonthDay63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(yearMonthDay22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 30285018L + "'", long29 == 30285018L);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(yearMonthDay63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertNotNull(dateTimeField78);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "0" + "'", str86.equals("0"));
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        long long5 = dateTimeZone1.convertLocalToUTC(0L, true, (long) 3);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneId();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday((-1440));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
        org.joda.time.DateTime.Property property8 = dateTime4.hourOfDay();
        org.joda.time.DateTime.Property property9 = dateTime4.monthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime4.plusDays(15);
        boolean boolean13 = dateTime11.isEqual((long) (-1));
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.secondOfMinute();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeZone dateTimeZone19 = dateTime18.getZone();
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        boolean boolean23 = dateTimeZone21.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime18, (org.joda.time.ReadableInstant) dateTime24);
        java.lang.Object obj26 = null;
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        boolean boolean28 = org.joda.time.field.FieldUtils.equals(obj26, (java.lang.Object) dateTime27);
        java.util.TimeZone timeZone29 = null;
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forTimeZone(timeZone29);
        boolean boolean32 = dateTimeZone30.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone30);
        org.joda.time.DateTime.Property property34 = dateTime33.secondOfDay();
        org.joda.time.DateTime dateTime36 = dateTime33.withYear((int) (byte) 0);
        int int37 = dateTime27.compareTo((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime39 = dateTime33.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone40 = dateTime39.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass42 = dateTimeFormatter41.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone44 = iSOChronology43.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = dateTimeFormatter41.withChronology((org.joda.time.Chronology) iSOChronology43);
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology43.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField47 = iSOChronology43.hourOfDay();
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology43.dayOfWeek();
        org.joda.time.DateTime dateTime49 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology43);
        java.util.TimeZone timeZone50 = null;
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forTimeZone(timeZone50);
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology52.secondOfMinute();
        java.util.TimeZone timeZone54 = null;
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.forTimeZone(timeZone54);
        boolean boolean57 = dateTimeZone55.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime(dateTimeZone55);
        org.joda.time.DateTime.Property property59 = dateTime58.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = property59.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField62 = new org.joda.time.field.DividedDateTimeField(dateTimeField53, dateTimeFieldType60, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException66 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType60, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        boolean boolean67 = dateTime49.isSupported(dateTimeFieldType60);
        boolean boolean68 = dateTime39.isSupported(dateTimeFieldType60);
        boolean boolean69 = dateTime24.isSupported(dateTimeFieldType60);
        boolean boolean70 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
//        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
//        long long29 = unsupportedDateTimeField26.getDifferenceAsLong((long) 17, 2619L);
//        java.lang.String str30 = unsupportedDateTimeField26.toString();
//        org.joda.time.ReadablePartial readablePartial31 = null;
//        try {
//            int int32 = unsupportedDateTimeField26.getMinimumValue(readablePartial31);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200100L + "'", long21 == 7200100L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UnsupportedDateTimeField" + "'", str30.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        int int6 = dateTimeFormatter4.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2000 + "'", int6 == 2000);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.secondOfMinute();
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        boolean boolean21 = dateTimeZone19.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType24, 2019);
        java.util.TimeZone timeZone27 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
        boolean boolean30 = dateTimeZone28.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone28);
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime31.toYearMonthDay();
        int int33 = dividedDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32);
        java.util.TimeZone timeZone34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.secondOfMinute();
        java.util.TimeZone timeZone38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
        boolean boolean41 = dateTimeZone39.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property43 = dateTime42.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType44, 2019);
        org.joda.time.DateTimeField dateTimeField47 = dividedDateTimeField46.getWrappedField();
        org.joda.time.ReadablePartial readablePartial48 = null;
        int[] intArray50 = new int[] { 2000 };
        int int51 = dividedDateTimeField46.getMinimumValue(readablePartial48, intArray50);
        int int52 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32, intArray50);
        int int55 = dividedDateTimeField12.getDifference((long) 100, 1560549565386L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass57 = dateTimeFormatter56.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone59 = iSOChronology58.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = dateTimeFormatter56.withChronology((org.joda.time.Chronology) iSOChronology58);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology58.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField62 = iSOChronology58.hourOfDay();
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology58.dayOfWeek();
        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology58);
        java.util.TimeZone timeZone65 = null;
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forTimeZone(timeZone65);
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone66);
        org.joda.time.DateTimeField dateTimeField68 = iSOChronology67.secondOfMinute();
        java.util.TimeZone timeZone69 = null;
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forTimeZone(timeZone69);
        boolean boolean72 = dateTimeZone70.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime(dateTimeZone70);
        org.joda.time.DateTime.Property property74 = dateTime73.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property74.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField(dateTimeField68, dateTimeFieldType75, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException81 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        boolean boolean82 = dateTime64.isSupported(dateTimeFieldType75);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 50, (java.lang.Number) 100.0d, (java.lang.Number) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField87 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField12, dateTimeFieldType75);
        long long89 = dividedDateTimeField12.roundFloor(1560549565927L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(yearMonthDay32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-772931) + "'", int55 == (-772931));
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(dateTimeFormatter60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 1560549540000L + "'", long89 == 1560549540000L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (-1), 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.clockhourOfHalfday();
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        boolean boolean10 = dateTimeZone8.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime11.toYearMonthDay();
        int[] intArray14 = iSOChronology5.get((org.joda.time.ReadablePartial) yearMonthDay12, (long) 35);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology5.yearOfCentury();
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(31, 15, 79224, (int) (byte) 100, 79218660, (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology3.getZone();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
//        int int13 = fixedDateTimeZone11.getOffsetFromLocal(0L);
//        boolean boolean14 = fixedDateTimeZone11.isFixed();
//        org.joda.time.Chronology chronology15 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
//        java.lang.Object obj16 = null;
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        boolean boolean18 = org.joda.time.field.FieldUtils.equals(obj16, (java.lang.Object) dateTime17);
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        boolean boolean22 = dateTimeZone20.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone20);
//        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
//        org.joda.time.DateTime dateTime26 = dateTime23.withYear((int) (byte) 0);
//        int int27 = dateTime17.compareTo((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.DateTime dateTime29 = dateTime23.minusWeeks(0);
//        org.joda.time.DateTimeZone dateTimeZone30 = dateTime29.getZone();
//        int int32 = dateTimeZone30.getOffsetFromLocal((long) 2019);
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30);
//        org.joda.time.Chronology chronology34 = gregorianChronology3.withZone(dateTimeZone30);
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology3.monthOfYear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "dayOfYear", "");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "hi!", "org.joda.time.IllegalFieldValueException: hi!: Value 1560635951378 for hi! must be in the range [10.0,10]");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "Pacific Daylight Time", "dayOfYear");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.secondOfMinute();
//        java.util.TimeZone timeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        boolean boolean26 = dateTimeZone24.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.DateTime.Property property28 = dateTime27.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField(dateTimeField22, dateTimeFieldType29, 2019);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType29, (int) (byte) -1, 17, 0);
//        long long42 = offsetDateTimeField18.addWrapField(0L, (int) (byte) 1);
//        int int44 = offsetDateTimeField18.get((long) (short) 100);
//        long long47 = offsetDateTimeField18.addWrapField(0L, 433485);
//        int int49 = offsetDateTimeField18.getLeapAmount((long) 55146);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 3600000L + "'", long42 == 3600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 34 + "'", int44 == 34);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3600000L + "'", long47 == 3600000L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMillis((int) '#');
        int int10 = dateTime7.getYearOfEra();
        org.joda.time.DateTime dateTime12 = dateTime7.minusDays(0);
        org.joda.time.DateTime.Property property13 = dateTime12.minuteOfDay();
        org.joda.time.DurationField durationField14 = property13.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(365);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusMillis((int) '#');
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime7.plus(readableDuration10);
//        long long12 = dateTime11.getMillis();
//        org.joda.time.DateTime dateTime14 = dateTime11.minusYears(20);
//        org.joda.time.DateTime dateTime16 = dateTime14.withMillisOfSecond(19);
//        org.joda.time.DateTime dateTime17 = dateTime16.toDateTimeISO();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560549627747L + "'", long12 == 1560549627747L);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
//        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
//        java.lang.String str27 = unsupportedDateTimeField26.getName();
//        try {
//            long long29 = unsupportedDateTimeField26.roundHalfEven((long) 15);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200100L + "'", long21 == 7200100L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "secondOfDay" + "'", str27.equals("secondOfDay"));
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
        int int8 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime10 = dateTime4.minus(1263557883L);
        int int11 = dateTime4.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime4.withZoneRetainFields(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime13.withMillisOfSecond(365);
        org.joda.time.DateTime dateTime17 = dateTime13.withMillisOfSecond(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.secondOfMinute();
//        java.util.TimeZone timeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        boolean boolean26 = dateTimeZone24.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.DateTime.Property property28 = dateTime27.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField(dateTimeField22, dateTimeFieldType29, 2019);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType29, (int) (byte) -1, 17, 0);
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = offsetDateTimeField18.getAsText(1560549569678L, locale41);
//        long long44 = offsetDateTimeField18.roundHalfFloor((long) 4);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "31" + "'", str42.equals("31"));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        long long5 = dateTimeZone2.adjustOffset(0L, false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        java.lang.String str8 = cachedDateTimeZone6.getNameKey((long) 86399999);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(195843050L, (org.joda.time.DateTimeZone) cachedDateTimeZone6);
//        int int11 = cachedDateTimeZone6.getOffsetFromLocal((long) 54006);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
//        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (byte) 0);
//        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear(2019);
//        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra(52);
//        boolean boolean12 = dateTime7.isBeforeNow();
//        int int13 = dateTime7.getDayOfYear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 167 + "'", int13 == 167);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(50L, 1560549596151L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 78027479807550L + "'", long2 == 78027479807550L);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.secondOfMinute();
//        int int12 = dateTime4.get(dateTimeField11);
//        org.joda.time.DateTime dateTime14 = dateTime4.plusMinutes(10);
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime4.plus(readableDuration15);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 28 + "'", int12 == 28);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        org.joda.time.DateTimeField dateTimeField13 = dividedDateTimeField12.getWrappedField();
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray16 = new int[] { 2000 };
        int int17 = dividedDateTimeField12.getMinimumValue(readablePartial14, intArray16);
        long long20 = dividedDateTimeField12.set(1263557883L, 0);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dividedDateTimeField12.getAsShortText((long) 12, locale22);
        int int25 = dividedDateTimeField12.getLeapAmount((long) 54002);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1263557883L + "'", long20 == 1263557883L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
//        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
//        java.lang.String str27 = unsupportedDateTimeField26.getName();
//        java.util.Locale locale30 = null;
//        try {
//            long long31 = unsupportedDateTimeField26.set(74189915097L, "GregorianChronology[]", locale30);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200100L + "'", long21 == 7200100L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "secondOfDay" + "'", str27.equals("secondOfDay"));
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        int int8 = fixedDateTimeZone4.getStandardOffset((long) 'a');
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        int int11 = fixedDateTimeZone4.getStandardOffset(0L);
        int int13 = fixedDateTimeZone4.getStandardOffset((long) 53958);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 19 + "'", int13 == 19);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 1);
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.secondOfMinute();
        java.util.TimeZone timeZone23 = null;
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
        boolean boolean26 = dateTimeZone24.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone24);
        org.joda.time.DateTime.Property property28 = dateTime27.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField(dateTimeField22, dateTimeFieldType29, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType29, (int) (byte) -1, 17, 0);
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField39.getAsShortText(41, locale41);
        int int43 = offsetDateTimeField39.getOffset();
        org.joda.time.ReadablePartial readablePartial44 = null;
        int[] intArray46 = null;
        try {
            int[] intArray48 = offsetDateTimeField39.add(readablePartial44, (int) 'a', intArray46, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "41" + "'", str42.equals("41"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.secondOfMinute();
//        int int12 = dateTime4.get(dateTimeField11);
//        int int13 = dateTime4.getHourOfDay();
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime4.minus(readableDuration14);
//        org.joda.time.DateTime dateTime17 = dateTime15.withWeekyear(54002);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 28 + "'", int12 == 28);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 22 + "'", int13 == 22);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.secondOfMinute();
//        int int12 = dateTime4.get(dateTimeField11);
//        int int13 = dateTime4.getHourOfDay();
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime4.minus(readableDuration14);
//        int int16 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTime.Property property17 = dateTime4.dayOfYear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 28 + "'", int12 == 28);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 22 + "'", int13 == 22);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 79228 + "'", int16 == 79228);
//        org.junit.Assert.assertNotNull(property17);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
//        long long24 = offsetDateTimeField18.roundHalfCeiling((long) 86399999);
//        long long27 = offsetDateTimeField18.getDifferenceAsLong((-100L), 614L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200100L + "'", long21 == 7200100L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 86400000L + "'", long24 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        long long15 = dividedDateTimeField12.roundCeiling((-1L));
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfHalfday();
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        boolean boolean21 = dateTimeZone19.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.YearMonthDay yearMonthDay23 = dateTime22.toYearMonthDay();
        int[] intArray25 = iSOChronology16.get((org.joda.time.ReadablePartial) yearMonthDay23, (long) 35);
        java.util.Locale locale27 = null;
        java.lang.String str28 = dividedDateTimeField12.getAsText((org.joda.time.ReadablePartial) yearMonthDay23, 50, locale27);
        long long31 = dividedDateTimeField12.getDifferenceAsLong(9972000000L, 1615693235000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1959000L + "'", long15 == 1959000L);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(yearMonthDay23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "50" + "'", str28.equals("50"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-795305L) + "'", long31 == (-795305L));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.monthOfYear();
        long long8 = iSOChronology2.add((long) 19, (long) 50, (int) '4');
        org.joda.time.DurationField durationField9 = iSOChronology2.weeks();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2619L + "'", long8 == 2619L);
        org.junit.Assert.assertNotNull(durationField9);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
//        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
//        long long29 = unsupportedDateTimeField26.getDifferenceAsLong((long) 17, 2619L);
//        java.lang.String str30 = unsupportedDateTimeField26.toString();
//        try {
//            int int31 = unsupportedDateTimeField26.getMaximumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200100L + "'", long21 == 7200100L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UnsupportedDateTimeField" + "'", str30.equals("UnsupportedDateTimeField"));
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.secondOfMinute();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology5);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.Chronology chronology9 = iSOChronology2.withZone(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone10 = iSOChronology2.getZone();
//        long long13 = dateTimeZone10.convertLocalToUTC((long) (byte) 0, false);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone10.getShortName(0L, locale15);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        org.joda.time.DateTimeField dateTimeField13 = dividedDateTimeField12.getWrappedField();
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray16 = new int[] { 2000 };
        int int17 = dividedDateTimeField12.getMinimumValue(readablePartial14, intArray16);
        long long20 = dividedDateTimeField12.set(1263557883L, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = dividedDateTimeField12.getType();
        int int23 = dividedDateTimeField12.getMinimumValue(0L);
        java.util.TimeZone timeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
        boolean boolean27 = dateTimeZone25.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone25);
        org.joda.time.Chronology chronology29 = dateTime28.getChronology();
        org.joda.time.DateTime dateTime31 = dateTime28.minusDays(1);
        org.joda.time.DateTime.Property property32 = dateTime28.millisOfDay();
        java.lang.Object obj33 = null;
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now();
        boolean boolean35 = org.joda.time.field.FieldUtils.equals(obj33, (java.lang.Object) dateTime34);
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime28, (org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime dateTime38 = dateTime34.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property39 = dateTime34.weekyear();
        org.joda.time.DateTime.Property property40 = dateTime34.hourOfDay();
        org.joda.time.TimeOfDay timeOfDay41 = dateTime34.toTimeOfDay();
        java.util.TimeZone timeZone43 = null;
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forTimeZone(timeZone43);
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology45.secondOfMinute();
        java.util.TimeZone timeZone47 = null;
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forTimeZone(timeZone47);
        boolean boolean50 = dateTimeZone48.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone48);
        org.joda.time.DateTime.Property property52 = dateTime51.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property52.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField55 = new org.joda.time.field.DividedDateTimeField(dateTimeField46, dateTimeFieldType53, 2019);
        boolean boolean56 = dividedDateTimeField55.isLenient();
        long long58 = dividedDateTimeField55.roundCeiling((-1L));
        long long61 = dividedDateTimeField55.add((long) 50, (int) 'a');
        java.util.Locale locale63 = null;
        java.lang.String str64 = dividedDateTimeField55.getAsText((int) (short) 10, locale63);
        java.util.TimeZone timeZone65 = null;
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forTimeZone(timeZone65);
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone66);
        org.joda.time.DateTimeField dateTimeField68 = iSOChronology67.secondOfMinute();
        java.util.TimeZone timeZone69 = null;
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forTimeZone(timeZone69);
        boolean boolean72 = dateTimeZone70.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime(dateTimeZone70);
        org.joda.time.DateTime.Property property74 = dateTime73.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property74.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField(dateTimeField68, dateTimeFieldType75, 2019);
        java.util.TimeZone timeZone78 = null;
        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.forTimeZone(timeZone78);
        boolean boolean81 = dateTimeZone79.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime82 = new org.joda.time.DateTime(dateTimeZone79);
        org.joda.time.YearMonthDay yearMonthDay83 = dateTime82.toYearMonthDay();
        int int84 = dividedDateTimeField77.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay83);
        org.joda.time.chrono.ISOChronology iSOChronology85 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField86 = iSOChronology85.clockhourOfHalfday();
        java.util.TimeZone timeZone87 = null;
        org.joda.time.DateTimeZone dateTimeZone88 = org.joda.time.DateTimeZone.forTimeZone(timeZone87);
        boolean boolean90 = dateTimeZone88.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime91 = new org.joda.time.DateTime(dateTimeZone88);
        org.joda.time.YearMonthDay yearMonthDay92 = dateTime91.toYearMonthDay();
        int[] intArray94 = iSOChronology85.get((org.joda.time.ReadablePartial) yearMonthDay92, (long) 35);
        int int95 = dividedDateTimeField55.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay83, intArray94);
        try {
            int[] intArray97 = dividedDateTimeField12.addWrapField((org.joda.time.ReadablePartial) timeOfDay41, 20, intArray94, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 20");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1263557883L + "'", long20 == 1263557883L);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(timeOfDay41);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1959000L + "'", long58 == 1959000L);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 195843050L + "'", long61 == 195843050L);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertNotNull(dateTimeZone79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(yearMonthDay83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(iSOChronology85);
        org.junit.Assert.assertNotNull(dateTimeField86);
        org.junit.Assert.assertNotNull(dateTimeZone88);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(yearMonthDay92);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfHalfday();
//        java.lang.String str5 = iSOChronology0.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        java.util.Locale locale3 = dateTimeFormatter2.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (byte) 0);
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear(2019);
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra(52);
        boolean boolean12 = dateTime7.isBeforeNow();
        org.joda.time.DateTime dateTime14 = dateTime7.plus((long) 5);
        try {
            org.joda.time.DateTime dateTime19 = dateTime14.withTime(22, 17, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
        java.util.TimeZone timeZone7 = fixedDateTimeZone6.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter1.withZone(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        org.joda.time.DateTimeField dateTimeField13 = dividedDateTimeField12.getWrappedField();
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray16 = new int[] { 2000 };
        int int17 = dividedDateTimeField12.getMinimumValue(readablePartial14, intArray16);
        long long20 = dividedDateTimeField12.set(1263557883L, 0);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField12, (-772931));
        long long24 = offsetDateTimeField22.roundFloor((-60000L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1263557883L + "'", long20 == 1263557883L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-60000L) + "'", long24 == (-60000L));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendTimeZoneOffset("20", "DateTimeField[secondOfDay]", false, 17, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        int int7 = property5.getLeapAmount();
        int int8 = property5.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 86399 + "'", int8 == 86399);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
//        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
//        java.lang.String str27 = unsupportedDateTimeField26.getName();
//        java.lang.String str28 = unsupportedDateTimeField26.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200100L + "'", long21 == 7200100L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "secondOfDay" + "'", str27.equals("secondOfDay"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UnsupportedDateTimeField" + "'", str28.equals("UnsupportedDateTimeField"));
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusHours(365);
//        org.joda.time.DateTime dateTime4 = dateTime0.minusMonths((int) (short) 1);
//        org.joda.time.DateTime dateTime6 = dateTime0.minusWeeks(58);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withDefaultYear((int) (short) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter9.withOffsetParsed();
//        java.lang.String str11 = dateTime6.toString(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2018-W18-6T22:00:29Z" + "'", str11.equals("2018-W18-6T22:00:29Z"));
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfHalfday();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        boolean boolean5 = dateTimeZone3.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.YearMonthDay yearMonthDay7 = dateTime6.toYearMonthDay();
//        int[] intArray9 = iSOChronology0.get((org.joda.time.ReadablePartial) yearMonthDay7, (long) 35);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology0.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.secondOfMinute();
//        java.util.TimeZone timeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        boolean boolean20 = dateTimeZone18.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone18);
//        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, dateTimeFieldType23, 2019);
//        boolean boolean26 = dividedDateTimeField25.isLenient();
//        long long28 = dividedDateTimeField25.roundCeiling((-1L));
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.clockhourOfHalfday();
//        java.util.TimeZone timeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forTimeZone(timeZone31);
//        boolean boolean34 = dateTimeZone32.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone32);
//        org.joda.time.YearMonthDay yearMonthDay36 = dateTime35.toYearMonthDay();
//        int[] intArray38 = iSOChronology29.get((org.joda.time.ReadablePartial) yearMonthDay36, (long) 35);
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dividedDateTimeField25.getAsText((org.joda.time.ReadablePartial) yearMonthDay36, 50, locale40);
//        java.lang.String str42 = dateTimeFormatter12.print((org.joda.time.ReadablePartial) yearMonthDay36);
//        long long44 = iSOChronology0.set((org.joda.time.ReadablePartial) yearMonthDay36, (long) 66);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(yearMonthDay7);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1959000L + "'", long28 == 1959000L);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(yearMonthDay36);
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "50" + "'", str41.equals("50"));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "����-W��" + "'", str42.equals("����-W��"));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560556800066L + "'", long44 == 1560556800066L);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 1);
        java.util.Locale locale3 = dateTimeFormatter0.getLocale();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology(chronology4);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTime4.getZone();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime10);
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        boolean boolean15 = dateTimeZone13.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.Chronology chronology17 = dateTime16.getChronology();
        org.joda.time.DateTime dateTime19 = dateTime16.minusDays(1);
        int int20 = dateTime16.getYearOfCentury();
        org.joda.time.DateTime dateTime22 = dateTime16.minus(1263557883L);
        int int23 = dateTime16.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime16.withZoneRetainFields(dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.minusMinutes((-28800000));
        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime27);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 19 + "'", int20 == 19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTime1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        boolean boolean6 = dateTimeZone4.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear((int) (byte) 0);
//        int int11 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime13 = dateTime7.minusWeeks(0);
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
//        int int16 = dateTimeZone14.getOffsetFromLocal((long) 2019);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.secondOfMinute();
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        boolean boolean25 = dateTimeZone23.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone23);
//        org.joda.time.DateTime.Property property27 = dateTime26.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField30 = new org.joda.time.field.DividedDateTimeField(dateTimeField21, dateTimeFieldType28, 2019);
//        org.joda.time.DateTimeField dateTimeField31 = dividedDateTimeField30.getWrappedField();
//        boolean boolean32 = gregorianChronology17.equals((java.lang.Object) dateTimeField31);
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology17.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology17.centuryOfEra();
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("America/Los_Angeles", number1, (java.lang.Number) 2019, (java.lang.Number) 54002);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType5);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.secondOfMinute();
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        boolean boolean21 = dateTimeZone19.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType24, 2019);
        java.util.TimeZone timeZone27 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
        boolean boolean30 = dateTimeZone28.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone28);
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime31.toYearMonthDay();
        int int33 = dividedDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32);
        java.util.TimeZone timeZone34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.secondOfMinute();
        java.util.TimeZone timeZone38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
        boolean boolean41 = dateTimeZone39.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property43 = dateTime42.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType44, 2019);
        org.joda.time.DateTimeField dateTimeField47 = dividedDateTimeField46.getWrappedField();
        org.joda.time.ReadablePartial readablePartial48 = null;
        int[] intArray50 = new int[] { 2000 };
        int int51 = dividedDateTimeField46.getMinimumValue(readablePartial48, intArray50);
        int int52 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32, intArray50);
        int int55 = dividedDateTimeField12.getDifference((long) 100, 1560549565386L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass57 = dateTimeFormatter56.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone59 = iSOChronology58.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = dateTimeFormatter56.withChronology((org.joda.time.Chronology) iSOChronology58);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology58.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField62 = iSOChronology58.hourOfDay();
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology58.dayOfWeek();
        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology58);
        java.util.TimeZone timeZone65 = null;
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forTimeZone(timeZone65);
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone66);
        org.joda.time.DateTimeField dateTimeField68 = iSOChronology67.secondOfMinute();
        java.util.TimeZone timeZone69 = null;
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forTimeZone(timeZone69);
        boolean boolean72 = dateTimeZone70.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime(dateTimeZone70);
        org.joda.time.DateTime.Property property74 = dateTime73.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property74.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField(dateTimeField68, dateTimeFieldType75, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException81 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        boolean boolean82 = dateTime64.isSupported(dateTimeFieldType75);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 50, (java.lang.Number) 100.0d, (java.lang.Number) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField87 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField12, dateTimeFieldType75);
        long long89 = zeroIsMaxDateTimeField87.roundFloor(1560549581846L);
        long long91 = zeroIsMaxDateTimeField87.roundHalfCeiling(30285001L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(yearMonthDay32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-772931) + "'", int55 == (-772931));
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(dateTimeFormatter60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 1560549540000L + "'", long89 == 1560549540000L);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 30240000L + "'", long91 == 30240000L);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        boolean boolean4 = dateTimeZone2.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone2);
//        org.joda.time.YearMonthDay yearMonthDay6 = dateTime5.toYearMonthDay();
//        org.joda.time.DateTime.Property property7 = dateTime5.dayOfYear();
//        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) "", (java.lang.Object) property7);
//        int int9 = property7.getLeapAmount();
//        org.joda.time.DurationField durationField10 = property7.getDurationField();
//        long long11 = property7.remainder();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(yearMonthDay6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 79230622L + "'", long11 == 79230622L);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(47, 54002);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54049 + "'", int2 == 54049);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMonthOfYear(292278993);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology4.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone5);
//        java.lang.String str7 = zonedChronology6.toString();
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.secondOfMinute();
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        boolean boolean15 = dateTimeZone13.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.DateTime.Property property17 = dateTime16.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField20 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType18, 2019);
//        org.joda.time.DateTimeField dateTimeField21 = dividedDateTimeField20.getWrappedField();
//        org.joda.time.ReadablePartial readablePartial22 = null;
//        int[] intArray24 = new int[] { 2000 };
//        int int25 = dividedDateTimeField20.getMinimumValue(readablePartial22, intArray24);
//        long long28 = dividedDateTimeField20.set(1263557883L, 0);
//        boolean boolean29 = zonedChronology6.equals((java.lang.Object) 1263557883L);
//        try {
//            long long35 = zonedChronology6.getDateTimeMillis((long) 10, 28, (int) (byte) 1, 66, 20);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1263557883L + "'", long28 == 1263557883L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        boolean boolean17 = dateTimeZone15.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone15);
        org.joda.time.DateTime.Property property19 = dateTime18.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property19.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField22 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField12, dateTimeFieldType20, (int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter23.withChronology((org.joda.time.Chronology) iSOChronology24);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology24.clockhourOfHalfday();
        java.util.TimeZone timeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forTimeZone(timeZone28);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.secondOfMinute();
        java.util.TimeZone timeZone32 = null;
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forTimeZone(timeZone32);
        boolean boolean35 = dateTimeZone33.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(dateTimeZone33);
        org.joda.time.DateTime.Property property37 = dateTime36.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField(dateTimeField31, dateTimeFieldType38, 2019);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField(dateTimeField27, dateTimeFieldType38, 365);
        java.util.TimeZone timeZone43 = null;
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forTimeZone(timeZone43);
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology45.secondOfMinute();
        java.util.TimeZone timeZone47 = null;
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forTimeZone(timeZone47);
        boolean boolean50 = dateTimeZone48.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone48);
        org.joda.time.DateTime.Property property52 = dateTime51.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property52.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField55 = new org.joda.time.field.DividedDateTimeField(dateTimeField46, dateTimeFieldType53, 2019);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField56 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField42, dateTimeFieldType53);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField22, dateTimeFieldType53);
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.clockhourOfDay();
        java.util.TimeZone timeZone60 = null;
        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.forTimeZone(timeZone60);
        org.joda.time.chrono.ISOChronology iSOChronology62 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone61);
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology62.secondOfMinute();
        java.util.TimeZone timeZone64 = null;
        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeZone.forTimeZone(timeZone64);
        boolean boolean67 = dateTimeZone65.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime(dateTimeZone65);
        org.joda.time.DateTime.Property property69 = dateTime68.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = property69.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField72 = new org.joda.time.field.DividedDateTimeField(dateTimeField63, dateTimeFieldType70, 2019);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField(dateTimeField59, dateTimeFieldType70, (int) (short) 10, (int) (byte) -1, 12);
        java.util.TimeZone timeZone77 = null;
        org.joda.time.DateTimeZone dateTimeZone78 = org.joda.time.DateTimeZone.forTimeZone(timeZone77);
        org.joda.time.chrono.ISOChronology iSOChronology79 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone78);
        org.joda.time.DateTimeField dateTimeField80 = iSOChronology79.secondOfMinute();
        java.util.TimeZone timeZone81 = null;
        org.joda.time.DateTimeZone dateTimeZone82 = org.joda.time.DateTimeZone.forTimeZone(timeZone81);
        boolean boolean84 = dateTimeZone82.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime85 = new org.joda.time.DateTime(dateTimeZone82);
        org.joda.time.DateTime.Property property86 = dateTime85.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType87 = property86.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField89 = new org.joda.time.field.DividedDateTimeField(dateTimeField80, dateTimeFieldType87, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException93 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType87, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField97 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField76, dateTimeFieldType87, (int) (byte) -1, 17, 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField98 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField57, dateTimeFieldType87);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertNotNull(iSOChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertNotNull(dateTimeZone78);
        org.junit.Assert.assertNotNull(iSOChronology79);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertNotNull(dateTimeZone82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(property86);
        org.junit.Assert.assertNotNull(dateTimeFieldType87);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (byte) 0);
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear(2019);
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra(52);
        org.joda.time.DateTime dateTime13 = dateTime11.plusHours((-28800000));
        org.joda.time.DateTime dateTime15 = dateTime11.withMillisOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTime1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        boolean boolean6 = dateTimeZone4.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear((int) (byte) 0);
//        int int11 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime13 = dateTime7.minusWeeks(0);
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillis(1560549569678L);
//        try {
//            org.joda.time.DateTime dateTime18 = dateTime13.withMonthOfYear(47);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 47 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (-292275054), 1560636022931L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1560928297985L) + "'", long2 == (-1560928297985L));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        boolean boolean16 = dateTimeZone14.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime17.toYearMonthDay();
        int int19 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay18);
        long long22 = dividedDateTimeField12.getDifferenceAsLong((-100L), 1L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = dividedDateTimeField12.getAsText((long) 35, locale24);
        long long27 = dividedDateTimeField12.remainder(1263560556L);
        java.lang.String str28 = dividedDateTimeField12.getName();
        int int30 = dividedDateTimeField12.getLeapAmount((long) 54006);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(yearMonthDay18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1263560556L + "'", long27 == 1263560556L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "secondOfDay" + "'", str28.equals("secondOfDay"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 34);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
        int int19 = offsetDateTimeField18.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfWeek();
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        long long7 = dateTimeZone4.adjustOffset(0L, false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
//        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone4);
//        java.lang.String str11 = dateTimeZone4.getName((-100L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
//        org.junit.Assert.assertNotNull(zonedChronology9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        java.lang.Object obj9 = null;
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        boolean boolean11 = org.joda.time.field.FieldUtils.equals(obj9, (java.lang.Object) dateTime10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime14 = dateTime10.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property15 = dateTime10.weekyear();
        org.joda.time.DateTime dateTime17 = dateTime10.withMinuteOfHour(19);
        org.joda.time.DateTime dateTime19 = dateTime17.withWeekOfWeekyear(41);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        org.joda.time.DateTime.Property property8 = dateTime4.hourOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime4.monthOfYear();
//        org.joda.time.DateTime dateTime11 = dateTime4.plusDays(15);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime11.toMutableDateTime();
//        int int13 = mutableDateTime12.getMillisOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 79232589 + "'", int13 == 79232589);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology4.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.secondOfMinute();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = zonedChronology6.add(readablePeriod8, (long) 22, 899);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 22L + "'", long11 == 22L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        boolean boolean16 = dateTimeZone14.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime17.toYearMonthDay();
        int int19 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay18);
        long long22 = dividedDateTimeField12.getDifferenceAsLong((-100L), 1L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = dividedDateTimeField12.getAsText((long) 35, locale24);
        long long27 = dividedDateTimeField12.remainder(1263560556L);
        java.lang.String str28 = dividedDateTimeField12.getName();
        java.util.Locale locale29 = null;
        int int30 = dividedDateTimeField12.getMaximumTextLength(locale29);
        org.joda.time.DurationField durationField31 = dividedDateTimeField12.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(yearMonthDay18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1263560556L + "'", long27 == 1263560556L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "secondOfDay" + "'", str28.equals("secondOfDay"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(durationField31);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
//        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
//        int int29 = unsupportedDateTimeField26.getDifference(1560549571543L, (long) 23);
//        java.util.TimeZone timeZone30 = null;
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forTimeZone(timeZone30);
//        boolean boolean33 = dateTimeZone31.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone31);
//        org.joda.time.Chronology chronology35 = dateTime34.getChronology();
//        org.joda.time.DateTime dateTime37 = dateTime34.minusDays(1);
//        java.util.TimeZone timeZone38 = null;
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.secondOfMinute();
//        int int42 = dateTime34.get(dateTimeField41);
//        int int43 = dateTime34.getHourOfDay();
//        org.joda.time.ReadablePeriod readablePeriod44 = null;
//        org.joda.time.DateTime dateTime45 = dateTime34.plus(readablePeriod44);
//        org.joda.time.DateTime dateTime46 = dateTime34.withLaterOffsetAtOverlap();
//        org.joda.time.LocalDateTime localDateTime47 = dateTime34.toLocalDateTime();
//        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.clockhourOfHalfday();
//        java.util.TimeZone timeZone50 = null;
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forTimeZone(timeZone50);
//        boolean boolean53 = dateTimeZone51.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone51);
//        org.joda.time.YearMonthDay yearMonthDay55 = dateTime54.toYearMonthDay();
//        int[] intArray57 = iSOChronology48.get((org.joda.time.ReadablePartial) yearMonthDay55, (long) 35);
//        try {
//            int int58 = unsupportedDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localDateTime47, intArray57);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200100L + "'", long21 == 7200100L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 433485 + "'", int29 == 433485);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 32 + "'", int42 == 32);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 22 + "'", int43 == 22);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(localDateTime47);
//        org.junit.Assert.assertNotNull(iSOChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertNotNull(yearMonthDay55);
//        org.junit.Assert.assertNotNull(intArray57);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.secondOfMinute();
//        java.util.TimeZone timeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        boolean boolean26 = dateTimeZone24.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.DateTime.Property property28 = dateTime27.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField(dateTimeField22, dateTimeFieldType29, 2019);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType29, (int) (byte) -1, 17, 0);
//        long long42 = offsetDateTimeField18.addWrapField(0L, (int) (byte) 1);
//        int int44 = offsetDateTimeField18.get((long) (short) 100);
//        long long47 = offsetDateTimeField18.addWrapField(0L, 433485);
//        long long49 = offsetDateTimeField18.roundFloor(0L);
//        long long51 = offsetDateTimeField18.roundHalfFloor(0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 3600000L + "'", long42 == 3600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 34 + "'", int44 == 34);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3600000L + "'", long47 == 3600000L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        int int8 = dateTime4.getYearOfCentury();
//        org.joda.time.DateTime dateTime10 = dateTime4.minus(1263557883L);
//        org.joda.time.LocalTime localTime11 = dateTime4.toLocalTime();
//        int int12 = dateTime4.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
//        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
//        java.lang.String str27 = unsupportedDateTimeField26.getName();
//        try {
//            int int29 = unsupportedDateTimeField26.getMaximumValue(25200100L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200100L + "'", long21 == 7200100L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "secondOfDay" + "'", str27.equals("secondOfDay"));
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        long long4 = dateTimeZone1.adjustOffset(0L, false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        long long7 = cachedDateTimeZone5.nextTransition((long) 16);
//        long long9 = cachedDateTimeZone5.nextTransition(0L);
//        long long12 = cachedDateTimeZone5.convertLocalToUTC((long) 17, true);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 16L + "'", long7 == 16L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 17L + "'", long12 == 17L);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019", (java.lang.Number) 35, (java.lang.Number) 433485, (java.lang.Number) (short) 10);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        long long4 = dateTimeZone1.adjustOffset(0L, false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        long long7 = cachedDateTimeZone5.nextTransition((long) 16);
//        long long9 = cachedDateTimeZone5.nextTransition(0L);
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.secondOfMinute();
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
//        org.joda.time.DateTime dateTime16 = dateTime14.toDateTimeISO();
//        org.joda.time.DateTime dateTime17 = dateTime16.toDateTimeISO();
//        int int18 = cachedDateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 16L + "'", long7 == 16L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.secondOfMinute();
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        boolean boolean21 = dateTimeZone19.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType24, 2019);
        java.util.TimeZone timeZone27 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
        boolean boolean30 = dateTimeZone28.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone28);
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime31.toYearMonthDay();
        int int33 = dividedDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32);
        java.util.TimeZone timeZone34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.secondOfMinute();
        java.util.TimeZone timeZone38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
        boolean boolean41 = dateTimeZone39.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property43 = dateTime42.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType44, 2019);
        org.joda.time.DateTimeField dateTimeField47 = dividedDateTimeField46.getWrappedField();
        org.joda.time.ReadablePartial readablePartial48 = null;
        int[] intArray50 = new int[] { 2000 };
        int int51 = dividedDateTimeField46.getMinimumValue(readablePartial48, intArray50);
        int int52 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32, intArray50);
        int int55 = dividedDateTimeField12.getDifference((long) 100, 1560549565386L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass57 = dateTimeFormatter56.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone59 = iSOChronology58.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = dateTimeFormatter56.withChronology((org.joda.time.Chronology) iSOChronology58);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology58.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField62 = iSOChronology58.hourOfDay();
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology58.dayOfWeek();
        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology58);
        java.util.TimeZone timeZone65 = null;
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forTimeZone(timeZone65);
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone66);
        org.joda.time.DateTimeField dateTimeField68 = iSOChronology67.secondOfMinute();
        java.util.TimeZone timeZone69 = null;
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forTimeZone(timeZone69);
        boolean boolean72 = dateTimeZone70.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime(dateTimeZone70);
        org.joda.time.DateTime.Property property74 = dateTime73.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property74.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField(dateTimeField68, dateTimeFieldType75, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException81 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        boolean boolean82 = dateTime64.isSupported(dateTimeFieldType75);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 50, (java.lang.Number) 100.0d, (java.lang.Number) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField87 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField12, dateTimeFieldType75);
        boolean boolean89 = zeroIsMaxDateTimeField87.isLeap((long) 14);
        org.joda.time.DateTimeFieldType dateTimeFieldType90 = zeroIsMaxDateTimeField87.getType();
        long long92 = zeroIsMaxDateTimeField87.roundCeiling((long) 66);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(yearMonthDay32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-772931) + "'", int55 == (-772931));
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(dateTimeFormatter60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType90);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 2019000L + "'", long92 == 2019000L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology3.getZone();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology3.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 1);
        int int3 = dateTimeFormatter2.getDefaultYear();
        boolean boolean4 = dateTimeFormatter2.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.secondOfMinute();
//        int int12 = dateTime4.get(dateTimeField11);
//        int int13 = dateTime4.getHourOfDay();
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime4.plus(readableDuration14);
//        int int16 = dateTime4.getMinuteOfHour();
//        org.joda.time.DateTime.Property property17 = dateTime4.millisOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 33 + "'", int12 == 33);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 22 + "'", int13 == 22);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(property17);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        org.joda.time.DateTimeField dateTimeField13 = dividedDateTimeField12.getWrappedField();
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray16 = new int[] { 2000 };
        int int17 = dividedDateTimeField12.getMinimumValue(readablePartial14, intArray16);
        long long20 = dividedDateTimeField12.set(1263557883L, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = dividedDateTimeField12.getType();
        long long24 = dividedDateTimeField12.add((long) '#', (long) 41);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1263557883L + "'", long20 == 1263557883L);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 82779035L + "'", long24 == 82779035L);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
//        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
//        int int29 = unsupportedDateTimeField26.getDifference(1560549571543L, (long) 23);
//        long long32 = unsupportedDateTimeField26.add((long) 100, 0);
//        org.joda.time.DurationField durationField33 = unsupportedDateTimeField26.getLeapDurationField();
//        try {
//            long long35 = unsupportedDateTimeField26.roundHalfEven((-1L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200100L + "'", long21 == 7200100L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 433485 + "'", int29 == 433485);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
//        org.junit.Assert.assertNull(durationField33);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
//        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
//        try {
//            int int27 = unsupportedDateTimeField26.getMaximumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200100L + "'", long21 == 7200100L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.secondOfMinute();
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        boolean boolean21 = dateTimeZone19.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType24, 2019);
        java.util.TimeZone timeZone27 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
        boolean boolean30 = dateTimeZone28.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone28);
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime31.toYearMonthDay();
        int int33 = dividedDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32);
        java.util.TimeZone timeZone34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.secondOfMinute();
        java.util.TimeZone timeZone38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
        boolean boolean41 = dateTimeZone39.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property43 = dateTime42.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType44, 2019);
        org.joda.time.DateTimeField dateTimeField47 = dividedDateTimeField46.getWrappedField();
        org.joda.time.ReadablePartial readablePartial48 = null;
        int[] intArray50 = new int[] { 2000 };
        int int51 = dividedDateTimeField46.getMinimumValue(readablePartial48, intArray50);
        int int52 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32, intArray50);
        int int55 = dividedDateTimeField12.getDifference((long) 100, 1560549565386L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass57 = dateTimeFormatter56.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone59 = iSOChronology58.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = dateTimeFormatter56.withChronology((org.joda.time.Chronology) iSOChronology58);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology58.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField62 = iSOChronology58.hourOfDay();
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology58.dayOfWeek();
        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology58);
        java.util.TimeZone timeZone65 = null;
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forTimeZone(timeZone65);
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone66);
        org.joda.time.DateTimeField dateTimeField68 = iSOChronology67.secondOfMinute();
        java.util.TimeZone timeZone69 = null;
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forTimeZone(timeZone69);
        boolean boolean72 = dateTimeZone70.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime(dateTimeZone70);
        org.joda.time.DateTime.Property property74 = dateTime73.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property74.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField(dateTimeField68, dateTimeFieldType75, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException81 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        boolean boolean82 = dateTime64.isSupported(dateTimeFieldType75);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 50, (java.lang.Number) 100.0d, (java.lang.Number) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField87 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField12, dateTimeFieldType75);
        long long89 = zeroIsMaxDateTimeField87.roundCeiling(0L);
        long long91 = zeroIsMaxDateTimeField87.roundHalfFloor(1560549569678L);
        long long94 = zeroIsMaxDateTimeField87.add((long) (byte) 10, (long) 16);
        long long96 = zeroIsMaxDateTimeField87.roundHalfFloor(0L);
        long long98 = zeroIsMaxDateTimeField87.remainder((long) 33);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(yearMonthDay32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-772931) + "'", int55 == (-772931));
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(dateTimeFormatter60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 0L + "'", long89 == 0L);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 1560549540000L + "'", long91 == 1560549540000L);
        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 32304010L + "'", long94 == 32304010L);
        org.junit.Assert.assertTrue("'" + long96 + "' != '" + 0L + "'", long96 == 0L);
        org.junit.Assert.assertTrue("'" + long98 + "' != '" + 33L + "'", long98 == 33L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology4.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        try {
            int[] intArray10 = iSOChronology2.get(readablePeriod7, 0L, 14L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
//        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField26.getLeapDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.clockhourOfHalfday();
//        java.util.TimeZone timeZone30 = null;
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forTimeZone(timeZone30);
//        boolean boolean33 = dateTimeZone31.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone31);
//        org.joda.time.YearMonthDay yearMonthDay35 = dateTime34.toYearMonthDay();
//        int[] intArray37 = iSOChronology28.get((org.joda.time.ReadablePartial) yearMonthDay35, (long) 35);
//        try {
//            int int38 = unsupportedDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay35);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200100L + "'", long21 == 7200100L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertNull(durationField27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(yearMonthDay35);
//        org.junit.Assert.assertNotNull(intArray37);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMillis((int) '#');
        int int10 = dateTime7.getYearOfEra();
        org.joda.time.DateTime dateTime12 = dateTime7.withMillisOfDay((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.secondOfMinute();
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        boolean boolean21 = dateTimeZone19.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType24, 2019);
        java.util.TimeZone timeZone27 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
        boolean boolean30 = dateTimeZone28.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone28);
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime31.toYearMonthDay();
        int int33 = dividedDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32);
        java.util.TimeZone timeZone34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.secondOfMinute();
        java.util.TimeZone timeZone38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
        boolean boolean41 = dateTimeZone39.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property43 = dateTime42.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType44, 2019);
        org.joda.time.DateTimeField dateTimeField47 = dividedDateTimeField46.getWrappedField();
        org.joda.time.ReadablePartial readablePartial48 = null;
        int[] intArray50 = new int[] { 2000 };
        int int51 = dividedDateTimeField46.getMinimumValue(readablePartial48, intArray50);
        int int52 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32, intArray50);
        int int55 = dividedDateTimeField12.getDifference((long) 100, 1560549565386L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass57 = dateTimeFormatter56.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone59 = iSOChronology58.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = dateTimeFormatter56.withChronology((org.joda.time.Chronology) iSOChronology58);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology58.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField62 = iSOChronology58.hourOfDay();
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology58.dayOfWeek();
        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology58);
        java.util.TimeZone timeZone65 = null;
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forTimeZone(timeZone65);
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone66);
        org.joda.time.DateTimeField dateTimeField68 = iSOChronology67.secondOfMinute();
        java.util.TimeZone timeZone69 = null;
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forTimeZone(timeZone69);
        boolean boolean72 = dateTimeZone70.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime(dateTimeZone70);
        org.joda.time.DateTime.Property property74 = dateTime73.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property74.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField(dateTimeField68, dateTimeFieldType75, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException81 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        boolean boolean82 = dateTime64.isSupported(dateTimeFieldType75);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 50, (java.lang.Number) 100.0d, (java.lang.Number) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField87 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField12, dateTimeFieldType75);
        int int89 = zeroIsMaxDateTimeField87.getMaximumValue(1560635971712L);
        long long91 = zeroIsMaxDateTimeField87.remainder((long) 52);
        boolean boolean93 = zeroIsMaxDateTimeField87.isLeap((long) 15);
        int int94 = zeroIsMaxDateTimeField87.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(yearMonthDay32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-772931) + "'", int55 == (-772931));
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(dateTimeFormatter60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 52L + "'", long91 == 52L);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1 + "'", int94 == 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
        int int6 = fixedDateTimeZone4.getStandardOffset(1360427398500L);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(15);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder0.toDateTimeZone("America/Los_Angeles", true);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        int int9 = fixedDateTimeZone4.getOffsetFromLocal(1263557883L);
        boolean boolean11 = fixedDateTimeZone4.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.dayOfWeek();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField9 = iSOChronology2.millis();
        long long12 = durationField9.subtract(1560549587286L, 86399999);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560463187287L + "'", long12 == 1560463187287L);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.DateTime dateTime7 = property5.roundFloorCopy();
//        int int8 = dateTime7.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        java.lang.Object obj0 = null;
//        java.lang.Object obj1 = null;
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        boolean boolean3 = org.joda.time.field.FieldUtils.equals(obj1, (java.lang.Object) dateTime2);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
//        org.joda.time.DateTime dateTime11 = dateTime8.withYear((int) (byte) 0);
//        int int12 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime14 = dateTime8.minusWeeks(0);
//        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
//        int int17 = dateTimeZone15.getOffsetFromLocal((long) 2019);
//        boolean boolean19 = dateTimeZone15.isStandardOffset((long) (-28800000));
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(obj0, dateTimeZone15);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.monthOfYear();
//        org.joda.time.DateTime dateTime23 = dateTime20.withChronology((org.joda.time.Chronology) iSOChronology21);
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.clockhourOfDay();
//        java.util.TimeZone timeZone26 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forTimeZone(timeZone26);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone27);
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.secondOfMinute();
//        java.util.TimeZone timeZone30 = null;
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forTimeZone(timeZone30);
//        boolean boolean33 = dateTimeZone31.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone31);
//        org.joda.time.DateTime.Property property35 = dateTime34.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property35.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(dateTimeField29, dateTimeFieldType36, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, dateTimeFieldType36, (int) (short) 10, (int) (byte) -1, 12);
//        long long45 = offsetDateTimeField42.addWrapField((long) (byte) 100, 50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = offsetDateTimeField42.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone48 = iSOChronology47.getZone();
//        org.joda.time.DurationField durationField49 = iSOChronology47.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType46, durationField49);
//        org.joda.time.DateTime dateTime52 = dateTime20.withField(dateTimeFieldType46, 3);
//        org.joda.time.DateTime dateTime54 = dateTime20.withEra(0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 7200100L + "'", long45 == 7200100L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime54);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        long long10 = dateTimeZone7.adjustOffset(0L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        boolean boolean15 = dateTimeZone13.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.Chronology chronology17 = dateTime16.getChronology();
        org.joda.time.DateTime dateTime19 = dateTime16.minusDays(1);
        org.joda.time.DateTime dateTime21 = dateTime19.plusMillis((int) '#');
        int int22 = dateTime19.getYearOfEra();
        org.joda.time.DateTime dateTime24 = dateTime19.minusDays(0);
        org.joda.time.DateTime.Property property25 = dateTime24.minuteOfDay();
        org.joda.time.DateTime dateTime27 = property25.addWrapFieldToCopy((int) (byte) 10);
        boolean boolean28 = cachedDateTimeZone11.equals((java.lang.Object) dateTime27);
        try {
            org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(79228, 20, 544, 55146, (int) (byte) 1, 0, (org.joda.time.DateTimeZone) cachedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55146 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass3 = dateTimeFormatter2.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology4.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.hourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.dayOfWeek();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology4);
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfMinute();
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        boolean boolean18 = dateTimeZone16.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTime.Property property20 = dateTime19.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType21, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        boolean boolean28 = dateTime10.isSupported(dateTimeFieldType21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType21, 79218660, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder1.appendYearOfCentury(55, (-1));
        dateTimeFormatterBuilder1.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.secondOfMinute();
//        java.util.TimeZone timeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
//        boolean boolean26 = dateTimeZone24.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.DateTime.Property property28 = dateTime27.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField(dateTimeField22, dateTimeFieldType29, 2019);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType29, (int) (byte) -1, 17, 0);
//        long long42 = offsetDateTimeField18.addWrapField(0L, (int) (byte) 1);
//        int int44 = offsetDateTimeField18.get((long) (short) 100);
//        long long46 = offsetDateTimeField18.roundHalfFloor((long) 50);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 3600000L + "'", long42 == 3600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 34 + "'", int44 == 34);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology4.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.centuryOfEra();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
        int int14 = fixedDateTimeZone12.getOffsetFromLocal(0L);
        boolean boolean15 = fixedDateTimeZone12.isFixed();
        org.joda.time.Chronology chronology16 = zonedChronology6.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        java.util.Locale locale18 = null;
        java.lang.String str19 = fixedDateTimeZone12.getName(0L, locale18);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00:00.052" + "'", str19.equals("+00:00:00.052"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.secondOfMinute();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = iSOChronology5.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology3, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.centuryOfEra();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) zonedChronology7);
        org.joda.time.Chronology chronology10 = zonedChronology7.withUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.secondOfMinute();
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        boolean boolean21 = dateTimeZone19.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType24, 2019);
        java.util.TimeZone timeZone27 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
        boolean boolean30 = dateTimeZone28.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone28);
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime31.toYearMonthDay();
        int int33 = dividedDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32);
        java.util.TimeZone timeZone34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.secondOfMinute();
        java.util.TimeZone timeZone38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
        boolean boolean41 = dateTimeZone39.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property43 = dateTime42.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType44, 2019);
        org.joda.time.DateTimeField dateTimeField47 = dividedDateTimeField46.getWrappedField();
        org.joda.time.ReadablePartial readablePartial48 = null;
        int[] intArray50 = new int[] { 2000 };
        int int51 = dividedDateTimeField46.getMinimumValue(readablePartial48, intArray50);
        int int52 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32, intArray50);
        int int55 = dividedDateTimeField12.getDifference((long) 100, 1560549565386L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass57 = dateTimeFormatter56.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone59 = iSOChronology58.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = dateTimeFormatter56.withChronology((org.joda.time.Chronology) iSOChronology58);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology58.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField62 = iSOChronology58.hourOfDay();
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology58.dayOfWeek();
        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology58);
        java.util.TimeZone timeZone65 = null;
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forTimeZone(timeZone65);
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone66);
        org.joda.time.DateTimeField dateTimeField68 = iSOChronology67.secondOfMinute();
        java.util.TimeZone timeZone69 = null;
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forTimeZone(timeZone69);
        boolean boolean72 = dateTimeZone70.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime(dateTimeZone70);
        org.joda.time.DateTime.Property property74 = dateTime73.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property74.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField(dateTimeField68, dateTimeFieldType75, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException81 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        boolean boolean82 = dateTime64.isSupported(dateTimeFieldType75);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 50, (java.lang.Number) 100.0d, (java.lang.Number) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField87 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField12, dateTimeFieldType75);
        long long89 = zeroIsMaxDateTimeField87.roundCeiling(0L);
        long long92 = zeroIsMaxDateTimeField87.add((long) 19, 19);
        long long94 = zeroIsMaxDateTimeField87.roundFloor((-14L));
        long long96 = zeroIsMaxDateTimeField87.roundHalfCeiling(1402934059282114L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(yearMonthDay32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-772931) + "'", int55 == (-772931));
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(dateTimeFormatter60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 0L + "'", long89 == 0L);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 38361019L + "'", long92 == 38361019L);
        org.junit.Assert.assertTrue("'" + long94 + "' != '" + (-60000L) + "'", long94 == (-60000L));
        org.junit.Assert.assertTrue("'" + long96 + "' != '" + 1402934059260000L + "'", long96 == 1402934059260000L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.DurationField durationField5 = iSOChronology1.weeks();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1560635951378L, (java.lang.Number) 10.0f, (java.lang.Number) 10);
        java.lang.Number number11 = illegalFieldValueException10.getIllegalNumberValue();
        java.lang.String str12 = illegalFieldValueException10.toString();
        java.lang.String str13 = illegalFieldValueException10.getFieldName();
        java.lang.String str14 = illegalFieldValueException10.toString();
        java.lang.Throwable[] throwableArray15 = illegalFieldValueException10.getSuppressed();
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) throwableArray15);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1560635951378L + "'", number11.equals(1560635951378L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1560635951378 for hi! must be in the range [10.0,10]" + "'", str12.equals("org.joda.time.IllegalFieldValueException: Value 1560635951378 for hi! must be in the range [10.0,10]"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1560635951378 for hi! must be in the range [10.0,10]" + "'", str14.equals("org.joda.time.IllegalFieldValueException: Value 1560635951378 for hi! must be in the range [10.0,10]"));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
//        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
//        long long29 = unsupportedDateTimeField26.add(74549915097L, (-100L));
//        try {
//            int int31 = unsupportedDateTimeField26.getLeapAmount((long) 31);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200100L + "'", long21 == 7200100L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 74189915097L + "'", long29 == 74189915097L);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        long long15 = dividedDateTimeField12.roundCeiling((-1L));
        long long18 = dividedDateTimeField12.add((long) 50, (int) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = dividedDateTimeField12.getAsText((int) (short) 10, locale20);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.secondOfMinute();
        java.util.TimeZone timeZone26 = null;
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forTimeZone(timeZone26);
        boolean boolean29 = dateTimeZone27.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone27);
        org.joda.time.DateTime.Property property31 = dateTime30.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property31.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField(dateTimeField25, dateTimeFieldType32, 2019);
        java.util.TimeZone timeZone35 = null;
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forTimeZone(timeZone35);
        boolean boolean38 = dateTimeZone36.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.YearMonthDay yearMonthDay40 = dateTime39.toYearMonthDay();
        int int41 = dividedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay40);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.clockhourOfHalfday();
        java.util.TimeZone timeZone44 = null;
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forTimeZone(timeZone44);
        boolean boolean47 = dateTimeZone45.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(dateTimeZone45);
        org.joda.time.YearMonthDay yearMonthDay49 = dateTime48.toYearMonthDay();
        int[] intArray51 = iSOChronology42.get((org.joda.time.ReadablePartial) yearMonthDay49, (long) 35);
        int int52 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay40, intArray51);
        long long54 = dividedDateTimeField12.roundHalfFloor((long) 15);
        java.lang.String str56 = dividedDateTimeField12.getAsText((long) 12);
        long long59 = dividedDateTimeField12.add(0L, (int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1959000L + "'", long15 == 1959000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 195843050L + "'", long18 == 195843050L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(yearMonthDay40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(yearMonthDay49);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "0" + "'", str56.equals("0"));
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 20190000L + "'", long59 == 20190000L);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTime1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        boolean boolean6 = dateTimeZone4.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear((int) (byte) 0);
//        int int11 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime13 = dateTime7.minusWeeks(0);
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
//        int int16 = dateTimeZone14.getOffsetFromLocal((long) 2019);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.secondOfMinute();
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        boolean boolean25 = dateTimeZone23.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone23);
//        org.joda.time.DateTime.Property property27 = dateTime26.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField30 = new org.joda.time.field.DividedDateTimeField(dateTimeField21, dateTimeFieldType28, 2019);
//        org.joda.time.DateTimeField dateTimeField31 = dividedDateTimeField30.getWrappedField();
//        boolean boolean32 = gregorianChronology17.equals((java.lang.Object) dateTimeField31);
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology17.clockhourOfHalfday();
//        java.lang.String str34 = gregorianChronology17.toString();
//        java.util.TimeZone timeZone35 = null;
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forTimeZone(timeZone35);
//        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology37.secondOfMinute();
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone40 = iSOChronology39.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology41 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology37, dateTimeZone40);
//        org.joda.time.DateTimeField dateTimeField42 = zonedChronology41.centuryOfEra();
//        org.joda.time.DateTimeZone dateTimeZone43 = null;
//        org.joda.time.Chronology chronology44 = zonedChronology41.withZone(dateTimeZone43);
//        boolean boolean45 = gregorianChronology17.equals((java.lang.Object) chronology44);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "GregorianChronology[UTC]" + "'", str34.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(iSOChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(zonedChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(chronology44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
//        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
//        boolean boolean22 = offsetDateTimeField18.isSupported();
//        boolean boolean23 = offsetDateTimeField18.isLenient();
//        org.joda.time.ReadablePartial readablePartial24 = null;
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = offsetDateTimeField18.getAsShortText(readablePartial24, (-11), locale26);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200100L + "'", long21 == 7200100L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-11" + "'", str27.equals("-11"));
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        org.joda.time.DateTimeField dateTimeField13 = dividedDateTimeField12.getWrappedField();
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray16 = new int[] { 2000 };
        int int17 = dividedDateTimeField12.getMinimumValue(readablePartial14, intArray16);
        long long20 = dividedDateTimeField12.set(1263557883L, 0);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField12, (-772931));
        int int23 = dividedDateTimeField12.getDivisor();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1263557883L + "'", long20 == 1263557883L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMillis((int) '#');
        int int10 = dateTime7.getYearOfEra();
        org.joda.time.DateTime.Property property11 = dateTime7.minuteOfHour();
        int int12 = dateTime7.getEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.ReadableInstant readableInstant7 = null;
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        boolean boolean11 = dateTimeZone9.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.DateTime.Property property13 = dateTime12.secondOfDay();
        org.joda.time.DateTime dateTime15 = dateTime12.withYear((int) (byte) 0);
        org.joda.time.DateTime dateTime17 = dateTime15.withWeekyear(2019);
        org.joda.time.DateTime.Property property18 = dateTime17.hourOfDay();
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant7, (org.joda.time.ReadableInstant) dateTime17);
        try {
            org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(66, 79228, 59, 0, 17, 2, 7, chronology19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 79228 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (byte) 0);
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear(2019);
        org.joda.time.DateTime dateTime11 = dateTime7.plusHours(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0, (java.lang.Object) dateTimeFormatter12);
        try {
            org.joda.time.LocalDateTime localDateTime15 = dateTimeFormatter12.parseLocalDateTime("+00:10");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:10\" is malformed at \":10\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.dayOfWeek();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology2);
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.secondOfMinute();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        boolean boolean16 = dateTimeZone14.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone14);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField(dateTimeField12, dateTimeFieldType19, 2019);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
//        boolean boolean26 = dateTime8.isSupported(dateTimeFieldType19);
//        int int27 = dateTime8.getDayOfMonth();
//        org.joda.time.DateTime.Property property28 = dateTime8.millisOfDay();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((java.lang.Object) dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
//        org.junit.Assert.assertNotNull(property28);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.halfdayOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 1560549581846L, (org.joda.time.Chronology) iSOChronology1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.plusMillis((int) (short) 10);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 14 + "'", int5 == 14);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        java.lang.Object obj9 = null;
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        boolean boolean11 = org.joda.time.field.FieldUtils.equals(obj9, (java.lang.Object) dateTime10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime14 = dateTime10.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property15 = dateTime10.weekyear();
        org.joda.time.DateTime dateTime17 = dateTime10.plusMinutes((-1));
        org.joda.time.DateTime dateTime18 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.hourOfDay();
        org.joda.time.DateTime dateTime21 = property19.addToCopy((long) 11);
        org.joda.time.DateTime dateTime23 = property19.addToCopy((-795305L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        long long9 = fixedDateTimeZone4.nextTransition((long) 2019);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfHalfday();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.secondOfMinute();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        boolean boolean12 = dateTimeZone10.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property14 = dateTime13.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField8, dateTimeFieldType15, 2019);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType15, 365);
        int int20 = remainderDateTimeField19.getDivisor();
        long long22 = remainderDateTimeField19.roundHalfEven((long) (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 365 + "'", int20 == 365);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-28800000L) + "'", long22 == (-28800000L));
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTime1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        boolean boolean6 = dateTimeZone4.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear((int) (byte) 0);
//        int int11 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime13 = dateTime7.minusWeeks(0);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560636038703L + "'", long14 == 1560636038703L);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTime1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        boolean boolean6 = dateTimeZone4.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear((int) (byte) 0);
//        int int11 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime13 = dateTime7.minusWeeks(0);
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
//        org.joda.time.DateTime dateTime15 = dateTime13.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime17 = dateTime13.withHourOfDay(0);
//        int int18 = dateTime17.getDayOfYear();
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 166 + "'", int18 == 166);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-25200000));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("2019-06-15T14:59:24.853-07:00", 2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1560635951378L, (java.lang.Number) 10.0f, (java.lang.Number) 10);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.Number number7 = illegalFieldValueException4.getLowerBound();
        illegalFieldValueException4.prependMessage("hi!");
        illegalFieldValueException4.prependMessage("GregorianChronology[America/Los_Angeles]");
        java.lang.Number number12 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str13 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1560635951378L + "'", number5.equals(1560635951378L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1560635951378 for hi! must be in the range [10.0,10]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 1560635951378 for hi! must be in the range [10.0,10]"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1560635951378L + "'", number12.equals(1560635951378L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        org.joda.time.DateTimeField dateTimeField13 = dividedDateTimeField12.getWrappedField();
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray16 = new int[] { 2000 };
        int int17 = dividedDateTimeField12.getMinimumValue(readablePartial14, intArray16);
        long long20 = dividedDateTimeField12.set(1263557883L, 0);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField12, (-772931));
        int int23 = offsetDateTimeField22.getMaximumValue();
        long long25 = offsetDateTimeField22.remainder(18L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1263557883L + "'", long20 == 1263557883L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-772931) + "'", int23 == (-772931));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 18L + "'", long25 == 18L);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.secondOfMinute();
//        int int12 = dateTime4.get(dateTimeField11);
//        int int13 = dateTime4.getHourOfDay();
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime4.plus(readablePeriod14);
//        org.joda.time.DateTime dateTime16 = dateTime4.withEarlierOffsetAtOverlap();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 38 + "'", int12 == 38);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter9, dateTimeParser11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withChronology((org.joda.time.Chronology) iSOChronology23);
        org.joda.time.format.DateTimePrinter dateTimePrinter25 = dateTimeFormatter24.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter25, dateTimeParser27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser30 = dateTimeFormatter29.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withDefaultYear(52);
        org.joda.time.format.DateTimeParser dateTimeParser34 = dateTimeFormatter33.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray35 = new org.joda.time.format.DateTimeParser[] { dateTimeParser14, dateTimeParser19, dateTimeParser27, dateTimeParser30, dateTimeParser34 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder2.append(dateTimePrinter9, dateTimeParserArray35);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.util.TimeZone timeZone38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology40);
        org.joda.time.format.DateTimePrinter dateTimePrinter42 = dateTimeFormatter41.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = dateTimeFormatter43.withDefaultYear(52);
        org.joda.time.format.DateTimeParser dateTimeParser46 = dateTimeFormatter45.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter42, dateTimeParser46);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter9, dateTimeParser46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimePrinter25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeParser30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeParser34);
        org.junit.Assert.assertNotNull(dateTimeParserArray35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTimePrinter42);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTimeParser46);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.DurationField durationField5 = iSOChronology1.weeks();
        org.joda.time.DurationField durationField6 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str7 = gregorianChronology6.toString();
        try {
            long long15 = gregorianChronology6.getDateTimeMillis(55146, 26, 30, 54049, 899, 6, 38);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54049 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[]" + "'", str7.equals("GregorianChronology[]"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMillis((int) '#');
        int int10 = dateTime7.getYearOfEra();
        org.joda.time.DateTime.Property property11 = dateTime7.minuteOfHour();
        org.joda.time.DateTime dateTime12 = property11.roundHalfFloorCopy();
        java.util.Locale locale14 = null;
        try {
            org.joda.time.DateTime dateTime15 = property11.setCopy("ISOChronology[UTC]", locale14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ISOChronology[UTC]\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
        int int8 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime10 = dateTime4.minus(1263557883L);
        int int11 = dateTime4.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime4.withZoneRetainFields(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime13.withDayOfYear(7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        org.joda.time.DurationField durationField13 = dividedDateTimeField12.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(15);
        java.io.OutputStream outputStream4 = null;
        try {
            dateTimeZoneBuilder0.writeTo("secondOfDay", outputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendPattern("2019-06-15T14:59:15.938-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.secondOfMinute();
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        boolean boolean21 = dateTimeZone19.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType24, 2019);
        java.util.TimeZone timeZone27 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
        boolean boolean30 = dateTimeZone28.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone28);
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime31.toYearMonthDay();
        int int33 = dividedDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32);
        java.util.TimeZone timeZone34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.secondOfMinute();
        java.util.TimeZone timeZone38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
        boolean boolean41 = dateTimeZone39.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property43 = dateTime42.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType44, 2019);
        org.joda.time.DateTimeField dateTimeField47 = dividedDateTimeField46.getWrappedField();
        org.joda.time.ReadablePartial readablePartial48 = null;
        int[] intArray50 = new int[] { 2000 };
        int int51 = dividedDateTimeField46.getMinimumValue(readablePartial48, intArray50);
        int int52 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32, intArray50);
        int int55 = dividedDateTimeField12.getDifference((long) 100, 1560549565386L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass57 = dateTimeFormatter56.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone59 = iSOChronology58.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = dateTimeFormatter56.withChronology((org.joda.time.Chronology) iSOChronology58);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology58.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField62 = iSOChronology58.hourOfDay();
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology58.dayOfWeek();
        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology58);
        java.util.TimeZone timeZone65 = null;
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forTimeZone(timeZone65);
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone66);
        org.joda.time.DateTimeField dateTimeField68 = iSOChronology67.secondOfMinute();
        java.util.TimeZone timeZone69 = null;
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forTimeZone(timeZone69);
        boolean boolean72 = dateTimeZone70.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime(dateTimeZone70);
        org.joda.time.DateTime.Property property74 = dateTime73.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property74.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField(dateTimeField68, dateTimeFieldType75, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException81 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        boolean boolean82 = dateTime64.isSupported(dateTimeFieldType75);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 50, (java.lang.Number) 100.0d, (java.lang.Number) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField87 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField12, dateTimeFieldType75);
        boolean boolean89 = zeroIsMaxDateTimeField87.isLeap((long) 14);
        long long91 = zeroIsMaxDateTimeField87.roundHalfFloor((long) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(yearMonthDay32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-772931) + "'", int55 == (-772931));
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(dateTimeFormatter60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 0L + "'", long91 == 0L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = null;
//        java.lang.String str7 = dateTime4.toString(dateTimeFormatter6);
//        int int8 = dateTime4.getCenturyOfEra();
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        boolean boolean12 = dateTimeZone10.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
//        org.joda.time.DateTime.Property property15 = dateTime13.weekyear();
//        org.joda.time.DateTime dateTime17 = property15.setCopy("166");
//        boolean boolean18 = dateTime4.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime20 = dateTime17.plusHours(365);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime20.minus(readablePeriod21);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-15T15:00:41.269-07:00" + "'", str7.equals("2019-06-15T15:00:41.269-07:00"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(yearMonthDay14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTime1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        boolean boolean6 = dateTimeZone4.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear((int) (byte) 0);
//        int int11 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime13 = dateTime7.minusWeeks(0);
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
//        int int16 = dateTimeZone14.getOffsetFromLocal((long) 2019);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        java.lang.String str18 = gregorianChronology17.toString();
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str18.equals("GregorianChronology[America/Los_Angeles]"));
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
//        int int9 = property8.getMaximumValue();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property8.getAsText(locale10);
//        int int12 = property8.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 86399999 + "'", int9 == 86399999);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "54041385" + "'", str11.equals("54041385"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter2.getParser();
        org.joda.time.LocalDateTime localDateTime5 = dateTimeFormatter2.parseLocalDateTime("14:59:46-07:00");
        boolean boolean6 = dateTimeZone1.isLocalDateTimeGap(localDateTime5);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(localDateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.halfdayOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 1560549581846L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DurationField durationField5 = iSOChronology1.centuries();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
//        java.io.Writer writer2 = null;
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        boolean boolean6 = dateTimeZone4.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.Chronology chronology8 = dateTime7.getChronology();
//        org.joda.time.DateTime dateTime10 = dateTime7.minusDays(1);
//        java.util.TimeZone timeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfMinute();
//        int int15 = dateTime7.get(dateTimeField14);
//        org.joda.time.DateTime dateTime17 = dateTime7.plusMinutes(10);
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.secondOfMinute();
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        boolean boolean25 = dateTimeZone23.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone23);
//        org.joda.time.DateTime.Property property27 = dateTime26.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField30 = new org.joda.time.field.DividedDateTimeField(dateTimeField21, dateTimeFieldType28, 2019);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
//        org.joda.time.DateTime dateTime36 = dateTime17.withField(dateTimeFieldType28, 23);
//        org.joda.time.DateTime dateTime38 = dateTime36.plus(1L);
//        try {
//            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) dateTime38);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 41 + "'", int15 == 41);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.secondOfMinute();
//        int int12 = dateTime4.get(dateTimeField11);
//        org.joda.time.DateTime dateTime14 = dateTime4.plusMinutes(10);
//        org.joda.time.LocalTime localTime15 = dateTime4.toLocalTime();
//        int int16 = dateTime4.getEra();
//        try {
//            org.joda.time.DateTime dateTime18 = dateTime4.withHourOfDay(38);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 38 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 41 + "'", int12 == 41);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(localTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.String str6 = dateTimeZone1.getShortName((-50399900L));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PST" + "'", str6.equals("PST"));
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime4.weekyear();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.plus(readablePeriod7);
        int int9 = dateTime4.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
        java.lang.Object obj9 = null;
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        boolean boolean11 = org.joda.time.field.FieldUtils.equals(obj9, (java.lang.Object) dateTime10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime14 = dateTime10.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property15 = dateTime10.weekyear();
        org.joda.time.DateTime dateTime17 = dateTime10.plusMinutes((-1));
        org.joda.time.DateTime dateTime18 = dateTime10.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property19 = dateTime18.hourOfDay();
        int int20 = property19.getLeapAmount();
        org.joda.time.DateTime dateTime21 = property19.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1560549627747L, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
        long long29 = unsupportedDateTimeField26.getDifferenceAsLong((long) 17, 2619L);
        java.lang.String str30 = unsupportedDateTimeField26.toString();
        java.lang.Object obj31 = null;
        java.lang.Object obj32 = null;
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        boolean boolean34 = org.joda.time.field.FieldUtils.equals(obj32, (java.lang.Object) dateTime33);
        java.util.TimeZone timeZone35 = null;
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forTimeZone(timeZone35);
        boolean boolean38 = dateTimeZone36.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.DateTime.Property property40 = dateTime39.secondOfDay();
        org.joda.time.DateTime dateTime42 = dateTime39.withYear((int) (byte) 0);
        int int43 = dateTime33.compareTo((org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.DateTime dateTime45 = dateTime39.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone46 = dateTime45.getZone();
        int int48 = dateTimeZone46.getOffsetFromLocal((long) 2019);
        boolean boolean50 = dateTimeZone46.isStandardOffset((long) (-28800000));
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(obj31, dateTimeZone46);
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology52.monthOfYear();
        org.joda.time.DateTime dateTime54 = dateTime51.withChronology((org.joda.time.Chronology) iSOChronology52);
        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology55.clockhourOfDay();
        java.util.TimeZone timeZone57 = null;
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.forTimeZone(timeZone57);
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.secondOfMinute();
        java.util.TimeZone timeZone61 = null;
        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forTimeZone(timeZone61);
        boolean boolean64 = dateTimeZone62.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime(dateTimeZone62);
        org.joda.time.DateTime.Property property66 = dateTime65.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property66.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField(dateTimeField60, dateTimeFieldType67, 2019);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField73 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, dateTimeFieldType67, (int) (short) 10, (int) (byte) -1, 12);
        long long76 = offsetDateTimeField73.addWrapField((long) (byte) 100, 50);
        org.joda.time.DateTimeFieldType dateTimeFieldType77 = offsetDateTimeField73.getType();
        org.joda.time.chrono.ISOChronology iSOChronology78 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone79 = iSOChronology78.getZone();
        org.joda.time.DurationField durationField80 = iSOChronology78.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField81 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType77, durationField80);
        org.joda.time.DateTime dateTime83 = dateTime51.withField(dateTimeFieldType77, 3);
        org.joda.time.TimeOfDay timeOfDay84 = dateTime51.toTimeOfDay();
        java.util.Locale locale86 = null;
        try {
            java.lang.String str87 = unsupportedDateTimeField26.getAsShortText((org.joda.time.ReadablePartial) timeOfDay84, (int) (short) 10, locale86);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-50399900L) + "'", long21 == (-50399900L));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UnsupportedDateTimeField" + "'", str30.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-28800000) + "'", int48 == (-28800000));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(iSOChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-50399900L) + "'", long76 == (-50399900L));
        org.junit.Assert.assertNotNull(dateTimeFieldType77);
        org.junit.Assert.assertNotNull(iSOChronology78);
        org.junit.Assert.assertNotNull(dateTimeZone79);
        org.junit.Assert.assertNotNull(durationField80);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField81);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(timeOfDay84);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        illegalFieldValueException16.prependMessage("-11");
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
        int int13 = fixedDateTimeZone11.getOffsetFromLocal(0L);
        boolean boolean14 = fixedDateTimeZone11.isFixed();
        long long16 = fixedDateTimeZone11.nextTransition(1560635971712L);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((-28800000), 30, 33, 15, 0, 33, 0, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 30 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560635971712L + "'", long16 == 1560635971712L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder2.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter9, dateTimeParser11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withChronology((org.joda.time.Chronology) iSOChronology23);
        org.joda.time.format.DateTimePrinter dateTimePrinter25 = dateTimeFormatter24.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter25, dateTimeParser27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser30 = dateTimeFormatter29.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withDefaultYear(52);
        org.joda.time.format.DateTimeParser dateTimeParser34 = dateTimeFormatter33.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray35 = new org.joda.time.format.DateTimeParser[] { dateTimeParser14, dateTimeParser19, dateTimeParser27, dateTimeParser30, dateTimeParser34 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder2.append(dateTimePrinter9, dateTimeParserArray35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder2.appendHourOfDay(0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap39 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendTimeZoneName(strMap39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimePrinter25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeParser30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeParser34);
        org.junit.Assert.assertNotNull(dateTimeParserArray35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        long long9 = fixedDateTimeZone4.previousTransition((long) (byte) 100);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusHours(365);
        org.joda.time.DateTime dateTime4 = dateTime0.minusMonths((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime0.plusMinutes(10);
        org.joda.time.DateTime dateTime8 = dateTime0.plusMillis((int) ' ');
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTime1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        boolean boolean6 = dateTimeZone4.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear((int) (byte) 0);
//        int int11 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime13 = dateTime7.minusWeeks(0);
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
//        org.joda.time.DateTime dateTime15 = dateTime13.withLaterOffsetAtOverlap();
//        int int16 = dateTime15.getMillisOfDay();
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 54042594 + "'", int16 == 54042594);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
        int int11 = fixedDateTimeZone9.getOffsetFromLocal(0L);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((int) '4', (-28800000), 0, 54042594, 48, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54042594 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyear();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField3, 27, 10, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 27 for weekyear must be in the range [10,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.secondOfMinute();
        java.util.TimeZone timeZone23 = null;
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
        boolean boolean26 = dateTimeZone24.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone24);
        org.joda.time.DateTime.Property property28 = dateTime27.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField(dateTimeField22, dateTimeFieldType29, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType29, (int) (byte) -1, 17, 0);
        int int40 = offsetDateTimeField18.getMinimumValue();
        boolean boolean42 = offsetDateTimeField18.isLeap((long) 53958);
        long long44 = offsetDateTimeField18.roundFloor((long) 0);
        long long46 = offsetDateTimeField18.roundHalfFloor((long) 53982065);
        boolean boolean47 = offsetDateTimeField18.isSupported();
        org.joda.time.DurationField durationField48 = offsetDateTimeField18.getRangeDurationField();
        java.lang.String str50 = offsetDateTimeField18.getAsShortText(28800014L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 11 + "'", int40 == 11);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 54000000L + "'", long46 == 54000000L);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "34" + "'", str50.equals("34"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
        long long29 = unsupportedDateTimeField26.add(74549915097L, (-100L));
        java.lang.String str30 = unsupportedDateTimeField26.getName();
        java.util.TimeZone timeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forTimeZone(timeZone31);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.secondOfMinute();
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone36 = iSOChronology35.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology37 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology33, dateTimeZone36);
        java.util.TimeZone timeZone38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.secondOfMinute();
        java.util.TimeZone timeZone42 = null;
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forTimeZone(timeZone42);
        boolean boolean45 = dateTimeZone43.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(dateTimeZone43);
        org.joda.time.DateTime.Property property47 = dateTime46.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = property47.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField(dateTimeField41, dateTimeFieldType48, 2019);
        java.util.TimeZone timeZone51 = null;
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forTimeZone(timeZone51);
        boolean boolean54 = dateTimeZone52.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.YearMonthDay yearMonthDay56 = dateTime55.toYearMonthDay();
        int int57 = dividedDateTimeField50.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay56);
        int[] intArray59 = iSOChronology33.get((org.joda.time.ReadablePartial) yearMonthDay56, 1560549567921L);
        org.joda.time.chrono.ISOChronology iSOChronology61 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone62 = iSOChronology61.getZone();
        org.joda.time.DurationField durationField63 = iSOChronology61.hours();
        java.util.TimeZone timeZone64 = null;
        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeZone.forTimeZone(timeZone64);
        org.joda.time.chrono.ISOChronology iSOChronology66 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone65);
        org.joda.time.DateTimeField dateTimeField67 = iSOChronology66.secondOfMinute();
        org.joda.time.DateTime dateTime68 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology66);
        org.joda.time.DateTimeZone dateTimeZone69 = dateTime68.getZone();
        org.joda.time.DateTime dateTime70 = dateTime68.toDateTimeISO();
        org.joda.time.TimeOfDay timeOfDay71 = dateTime68.toTimeOfDay();
        int[] intArray73 = iSOChronology61.get((org.joda.time.ReadablePartial) timeOfDay71, 0L);
        try {
            int[] intArray75 = unsupportedDateTimeField26.addWrapField((org.joda.time.ReadablePartial) yearMonthDay56, (int) '#', intArray73, 53982065);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-50399900L) + "'", long21 == (-50399900L));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 74189915097L + "'", long29 == 74189915097L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "secondOfDay" + "'", str30.equals("secondOfDay"));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(zonedChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(yearMonthDay56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(iSOChronology61);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertNotNull(iSOChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(dateTimeZone69);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(timeOfDay71);
        org.junit.Assert.assertNotNull(intArray73);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
        org.joda.time.Interval interval7 = property5.toInterval();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval7);
        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(readableInterval9);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfWeek();
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        long long7 = dateTimeZone4.adjustOffset(0L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone4);
        org.joda.time.DurationField durationField10 = zonedChronology9.millis();
        org.joda.time.DurationField durationField11 = zonedChronology9.weeks();
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology9.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(1560549565386L, locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Daylight Time" + "'", str4.equals("Pacific Daylight Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
        org.joda.time.DateTime.Property property8 = dateTime4.hourOfDay();
        org.joda.time.DateTime dateTime10 = property8.addToCopy((long) (byte) 0);
        org.joda.time.DateTime dateTime11 = dateTime10.toDateTimeISO();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.DateTime dateTime14 = dateTime10.withFieldAdded(durationFieldType12, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter9, dateTimeParser11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatter13.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter20.withChronology((org.joda.time.Chronology) iSOChronology23);
        org.joda.time.format.DateTimePrinter dateTimePrinter25 = dateTimeFormatter24.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter25, dateTimeParser27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser30 = dateTimeFormatter29.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withDefaultYear(52);
        org.joda.time.format.DateTimeParser dateTimeParser34 = dateTimeFormatter33.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray35 = new org.joda.time.format.DateTimeParser[] { dateTimeParser14, dateTimeParser19, dateTimeParser27, dateTimeParser30, dateTimeParser34 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder2.append(dateTimePrinter9, dateTimeParserArray35);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder2.appendTimeZoneOffset("secondOfDay", "54041385", false, 0, 38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimePrinter25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeParser30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeParser34);
        org.junit.Assert.assertNotNull(dateTimeParserArray35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.secondOfMinute();
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        boolean boolean21 = dateTimeZone19.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType24, 2019);
        java.util.TimeZone timeZone27 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
        boolean boolean30 = dateTimeZone28.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone28);
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime31.toYearMonthDay();
        int int33 = dividedDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32);
        java.util.TimeZone timeZone34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.secondOfMinute();
        java.util.TimeZone timeZone38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
        boolean boolean41 = dateTimeZone39.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property43 = dateTime42.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType44, 2019);
        org.joda.time.DateTimeField dateTimeField47 = dividedDateTimeField46.getWrappedField();
        org.joda.time.ReadablePartial readablePartial48 = null;
        int[] intArray50 = new int[] { 2000 };
        int int51 = dividedDateTimeField46.getMinimumValue(readablePartial48, intArray50);
        int int52 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32, intArray50);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = dividedDateTimeField12.getType();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(yearMonthDay32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 10);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 1560549581846L, dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
        org.joda.time.DurationField durationField27 = unsupportedDateTimeField26.getLeapDurationField();
        org.joda.time.DurationField durationField28 = unsupportedDateTimeField26.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-50399900L) + "'", long21 == (-50399900L));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNull(durationField27);
        org.junit.Assert.assertNull(durationField28);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
        long long20 = offsetDateTimeField18.remainder((long) 10);
        long long22 = offsetDateTimeField18.remainder(1560635971473L);
        int int23 = offsetDateTimeField18.getMaximumValue();
        try {
            long long26 = offsetDateTimeField18.set((long) 79218660, (-292275054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for secondOfDay must be in the range [11,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 3571473L + "'", long22 == 3571473L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 12 + "'", int23 == 12);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.TimeZone timeZone3 = dateTimeZone1.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        java.lang.String str10 = fixedDateTimeZone8.getID();
        long long12 = fixedDateTimeZone8.previousTransition(1560549565927L);
        long long14 = dateTimeZone1.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone8, (long) 2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560549565927L + "'", long12 == 1560549565927L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-28800050L) + "'", long14 == (-28800050L));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1560635951378L, (java.lang.Number) 10.0f, (java.lang.Number) 10);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.Number number7 = illegalFieldValueException4.getLowerBound();
        illegalFieldValueException4.prependMessage("hi!");
        java.lang.Number number10 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1560635951378L + "'", number5.equals(1560635951378L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1560635951378 for hi! must be in the range [10.0,10]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 1560635951378 for hi! must be in the range [10.0,10]"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10 + "'", number10.equals(10));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        org.joda.time.DateTimeField dateTimeField13 = dividedDateTimeField12.getWrappedField();
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray16 = new int[] { 2000 };
        int int17 = dividedDateTimeField12.getMinimumValue(readablePartial14, intArray16);
        long long20 = dividedDateTimeField12.set(1263557883L, 0);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField12, (-772931));
        int int23 = offsetDateTimeField22.getMaximumValue();
        java.util.TimeZone timeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
        boolean boolean27 = dateTimeZone25.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone25);
        org.joda.time.YearMonthDay yearMonthDay29 = dateTime28.toYearMonthDay();
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
        java.util.TimeZone timeZone32 = null;
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forTimeZone(timeZone32);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.secondOfMinute();
        java.util.TimeZone timeZone36 = null;
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.forTimeZone(timeZone36);
        boolean boolean39 = dateTimeZone37.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(dateTimeZone37);
        org.joda.time.DateTime.Property property41 = dateTime40.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField(dateTimeField35, dateTimeFieldType42, 2019);
        boolean boolean45 = dividedDateTimeField44.isLenient();
        long long47 = dividedDateTimeField44.roundCeiling((-1L));
        long long50 = dividedDateTimeField44.add((long) 50, (int) 'a');
        java.util.Locale locale52 = null;
        java.lang.String str53 = dividedDateTimeField44.getAsText((int) (short) 10, locale52);
        java.util.TimeZone timeZone54 = null;
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.forTimeZone(timeZone54);
        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone55);
        org.joda.time.DateTimeField dateTimeField57 = iSOChronology56.secondOfMinute();
        java.util.TimeZone timeZone58 = null;
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.forTimeZone(timeZone58);
        boolean boolean61 = dateTimeZone59.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(dateTimeZone59);
        org.joda.time.DateTime.Property property63 = dateTime62.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property63.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField66 = new org.joda.time.field.DividedDateTimeField(dateTimeField57, dateTimeFieldType64, 2019);
        java.util.TimeZone timeZone67 = null;
        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forTimeZone(timeZone67);
        boolean boolean70 = dateTimeZone68.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime(dateTimeZone68);
        org.joda.time.YearMonthDay yearMonthDay72 = dateTime71.toYearMonthDay();
        int int73 = dividedDateTimeField66.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay72);
        org.joda.time.chrono.ISOChronology iSOChronology74 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField75 = iSOChronology74.clockhourOfHalfday();
        java.util.TimeZone timeZone76 = null;
        org.joda.time.DateTimeZone dateTimeZone77 = org.joda.time.DateTimeZone.forTimeZone(timeZone76);
        boolean boolean79 = dateTimeZone77.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime80 = new org.joda.time.DateTime(dateTimeZone77);
        org.joda.time.YearMonthDay yearMonthDay81 = dateTime80.toYearMonthDay();
        int[] intArray83 = iSOChronology74.get((org.joda.time.ReadablePartial) yearMonthDay81, (long) 35);
        int int84 = dividedDateTimeField44.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay72, intArray83);
        int[] intArray86 = iSOChronology31.get((org.joda.time.ReadablePartial) yearMonthDay72, (long) 53982065);
        java.util.Locale locale88 = null;
        try {
            int[] intArray89 = offsetDateTimeField22.set((org.joda.time.ReadablePartial) yearMonthDay29, 21, intArray86, "", locale88);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1263557883L + "'", long20 == 1263557883L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-772931) + "'", int23 == (-772931));
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(yearMonthDay29);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1959000L + "'", long47 == 1959000L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 195843050L + "'", long50 == 195843050L);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "10" + "'", str53.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(iSOChronology56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(yearMonthDay72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(iSOChronology74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(dateTimeZone77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(yearMonthDay81);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(intArray86);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.secondOfMinute();
//        int int12 = dateTime4.get(dateTimeField11);
//        org.joda.time.DateTime dateTime14 = dateTime4.plusMinutes(10);
//        org.joda.time.LocalTime localTime15 = dateTime4.toLocalTime();
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime4.withDurationAdded(readableDuration16, 53985461);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 44 + "'", int12 == 44);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(localTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        long long4 = dateTimeZone1.adjustOffset(0L, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.Chronology chronology11 = dateTime10.getChronology();
        org.joda.time.DateTime dateTime13 = dateTime10.minusDays(1);
        org.joda.time.DateTime dateTime15 = dateTime13.plusMillis((int) '#');
        int int16 = dateTime13.getYearOfEra();
        org.joda.time.DateTime dateTime18 = dateTime13.minusDays(0);
        org.joda.time.DateTime.Property property19 = dateTime18.minuteOfDay();
        org.joda.time.DateTime dateTime21 = property19.addWrapFieldToCopy((int) (byte) 10);
        boolean boolean22 = cachedDateTimeZone5.equals((java.lang.Object) dateTime21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime25 = dateTime21.withPeriodAdded(readablePeriod23, (-292275039));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        long long15 = dividedDateTimeField12.roundCeiling((-1L));
        long long18 = dividedDateTimeField12.add((long) 50, (int) 'a');
        int int19 = dividedDateTimeField12.getMaximumValue();
        long long22 = dividedDateTimeField12.add(0L, (-292275039));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1959000L + "'", long15 == 1959000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 195843050L + "'", long18 == 195843050L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1692784189000L) + "'", long22 == (-1692784189000L));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.io.Writer writer1 = null;
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        boolean boolean5 = dateTimeZone3.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime6.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) yearMonthDay7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(yearMonthDay7);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.year();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(19, (int) (short) 10, (int) (byte) 100, (int) (byte) 10, 1, 0, 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(52, 12);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear((int) (short) 1);
        try {
            org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("GregorianChronology[America/Los_Angeles]", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[America/Los_...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        dateTimeFormatterBuilder6.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendCenturyOfEra(903, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
        long long20 = offsetDateTimeField18.remainder((long) 10);
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        boolean boolean24 = dateTimeZone22.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.DateTime.Property property26 = dateTime25.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType27, 15);
        java.util.Locale locale30 = null;
        int int31 = dividedDateTimeField29.getMaximumTextLength(locale30);
        java.lang.String str33 = dividedDateTimeField29.getAsShortText(1560636002596L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology4.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology6.centuryOfEra();
        org.joda.time.Chronology chronology8 = zonedChronology6.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.secondOfMinute();
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        boolean boolean21 = dateTimeZone19.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType24, 2019);
        java.util.TimeZone timeZone27 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
        boolean boolean30 = dateTimeZone28.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone28);
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime31.toYearMonthDay();
        int int33 = dividedDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32);
        java.util.TimeZone timeZone34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.secondOfMinute();
        java.util.TimeZone timeZone38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
        boolean boolean41 = dateTimeZone39.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property43 = dateTime42.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType44, 2019);
        org.joda.time.DateTimeField dateTimeField47 = dividedDateTimeField46.getWrappedField();
        org.joda.time.ReadablePartial readablePartial48 = null;
        int[] intArray50 = new int[] { 2000 };
        int int51 = dividedDateTimeField46.getMinimumValue(readablePartial48, intArray50);
        int int52 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32, intArray50);
        int int55 = dividedDateTimeField12.getDifference((long) 100, 1560549565386L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass57 = dateTimeFormatter56.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone59 = iSOChronology58.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = dateTimeFormatter56.withChronology((org.joda.time.Chronology) iSOChronology58);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology58.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField62 = iSOChronology58.hourOfDay();
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology58.dayOfWeek();
        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology58);
        java.util.TimeZone timeZone65 = null;
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forTimeZone(timeZone65);
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone66);
        org.joda.time.DateTimeField dateTimeField68 = iSOChronology67.secondOfMinute();
        java.util.TimeZone timeZone69 = null;
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forTimeZone(timeZone69);
        boolean boolean72 = dateTimeZone70.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime(dateTimeZone70);
        org.joda.time.DateTime.Property property74 = dateTime73.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property74.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField(dateTimeField68, dateTimeFieldType75, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException81 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        boolean boolean82 = dateTime64.isSupported(dateTimeFieldType75);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 50, (java.lang.Number) 100.0d, (java.lang.Number) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField87 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField12, dateTimeFieldType75);
        long long89 = zeroIsMaxDateTimeField87.roundCeiling(0L);
        long long92 = zeroIsMaxDateTimeField87.add((long) 19, 19);
        long long94 = zeroIsMaxDateTimeField87.roundFloor((-14L));
        long long96 = zeroIsMaxDateTimeField87.roundFloor(1560636002596L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(yearMonthDay32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-772931) + "'", int55 == (-772931));
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(dateTimeFormatter60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 0L + "'", long89 == 0L);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 38361019L + "'", long92 == 38361019L);
        org.junit.Assert.assertTrue("'" + long94 + "' != '" + (-60000L) + "'", long94 == (-60000L));
        org.junit.Assert.assertTrue("'" + long96 + "' != '" + 1560636000000L + "'", long96 == 1560636000000L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        int int8 = fixedDateTimeZone4.getStandardOffset((long) 'a');
        java.lang.String str10 = fixedDateTimeZone4.getNameKey((long) 12);
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime11);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass3 = dateTimeFormatter2.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology4.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.hourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.dayOfWeek();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology4);
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfMinute();
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        boolean boolean18 = dateTimeZone16.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTime.Property property20 = dateTime19.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType21, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        boolean boolean28 = dateTime10.isSupported(dateTimeFieldType21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType21, 79218660, (int) (short) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = dateTimeFormatter32.withChronology((org.joda.time.Chronology) iSOChronology33);
        org.joda.time.format.DateTimeParser dateTimeParser36 = dateTimeFormatter35.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder1.appendOptional(dateTimeParser36);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder37.appendHourOfDay(53982065);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeParser36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfHalfday();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.secondOfMinute();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        boolean boolean12 = dateTimeZone10.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property14 = dateTime13.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField8, dateTimeFieldType15, 2019);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType15, 365);
        int int20 = remainderDateTimeField19.getDivisor();
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        boolean boolean24 = dateTimeZone22.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.Chronology chronology26 = dateTime25.getChronology();
        org.joda.time.DateTime dateTime28 = dateTime25.minusDays(1);
        int int29 = dateTime25.getYearOfCentury();
        org.joda.time.DateTime dateTime31 = dateTime25.minus(1263557883L);
        int int32 = dateTime25.getYearOfEra();
        org.joda.time.DateTime dateTime33 = dateTime25.toDateTime();
        java.util.TimeZone timeZone34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.secondOfMinute();
        java.util.TimeZone timeZone38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
        boolean boolean41 = dateTimeZone39.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property43 = dateTime42.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType44, 2019);
        boolean boolean47 = dividedDateTimeField46.isLenient();
        long long49 = dividedDateTimeField46.roundCeiling((-1L));
        long long52 = dividedDateTimeField46.add((long) 50, (int) 'a');
        int int53 = dateTime33.get((org.joda.time.DateTimeField) dividedDateTimeField46);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = dividedDateTimeField46.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField55 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField19, dateTimeFieldType54);
        int int57 = remainderDateTimeField19.get((long) 26);
        int int58 = remainderDateTimeField19.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 365 + "'", int20 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 19 + "'", int29 == 19);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1959000L + "'", long49 == 1959000L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 195843050L + "'", long52 == 195843050L);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology3.getZone();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
//        int int13 = fixedDateTimeZone11.getOffsetFromLocal(0L);
//        boolean boolean14 = fixedDateTimeZone11.isFixed();
//        org.joda.time.Chronology chronology15 = gregorianChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
//        java.lang.Object obj16 = null;
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        boolean boolean18 = org.joda.time.field.FieldUtils.equals(obj16, (java.lang.Object) dateTime17);
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        boolean boolean22 = dateTimeZone20.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone20);
//        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
//        org.joda.time.DateTime dateTime26 = dateTime23.withYear((int) (byte) 0);
//        int int27 = dateTime17.compareTo((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.DateTime dateTime29 = dateTime23.minusWeeks(0);
//        org.joda.time.DateTimeZone dateTimeZone30 = dateTime29.getZone();
//        int int32 = dateTimeZone30.getOffsetFromLocal((long) 2019);
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone30);
//        org.joda.time.Chronology chronology34 = gregorianChronology3.withZone(dateTimeZone30);
//        long long38 = dateTimeZone30.convertLocalToUTC(20190000L, true, (long) 79218660);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-28800000) + "'", int32 == (-28800000));
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 48990000L + "'", long38 == 48990000L);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
        java.lang.String str27 = unsupportedDateTimeField26.getName();
        java.util.Locale locale29 = null;
        try {
            java.lang.String str30 = unsupportedDateTimeField26.getAsText((-14L), locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-50399900L) + "'", long21 == (-50399900L));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "secondOfDay" + "'", str27.equals("secondOfDay"));
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.dayOfWeek();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology2);
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.secondOfMinute();
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        boolean boolean16 = dateTimeZone14.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone14);
//        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField(dateTimeField12, dateTimeFieldType19, 2019);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
//        boolean boolean26 = dateTime8.isSupported(dateTimeFieldType19);
//        int int27 = dateTime8.getDayOfMonth();
//        java.util.TimeZone timeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forTimeZone(timeZone28);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
//        org.joda.time.DateTimeZone dateTimeZone32 = gregorianChronology31.getZone();
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology31.getZone();
//        org.joda.time.DateTime dateTime35 = dateTime8.toDateTime(dateTimeZone34);
//        int int36 = dateTime8.getYearOfEra();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.io.Writer writer1 = null;
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        boolean boolean5 = dateTimeZone3.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.Chronology chronology7 = dateTime6.getChronology();
        org.joda.time.DateTime dateTime9 = dateTime6.minusDays(1);
        int int10 = dateTime6.getYearOfCentury();
        org.joda.time.DateTime dateTime12 = dateTime6.minus(1263557883L);
        int int13 = dateTime6.getYearOfEra();
        org.joda.time.DateTime dateTime14 = dateTime6.toDateTime();
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.secondOfMinute();
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        boolean boolean22 = dateTimeZone20.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField27 = new org.joda.time.field.DividedDateTimeField(dateTimeField18, dateTimeFieldType25, 2019);
        boolean boolean28 = dividedDateTimeField27.isLenient();
        long long30 = dividedDateTimeField27.roundCeiling((-1L));
        long long33 = dividedDateTimeField27.add((long) 50, (int) 'a');
        int int34 = dateTime14.get((org.joda.time.DateTimeField) dividedDateTimeField27);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.util.TimeZone timeZone36 = null;
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.forTimeZone(timeZone36);
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology38.secondOfMinute();
        java.util.TimeZone timeZone40 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forTimeZone(timeZone40);
        boolean boolean43 = dateTimeZone41.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(dateTimeZone41);
        org.joda.time.DateTime.Property property45 = dateTime44.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField(dateTimeField39, dateTimeFieldType46, 2019);
        boolean boolean49 = dividedDateTimeField48.isLenient();
        long long51 = dividedDateTimeField48.roundCeiling((-1L));
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology52.clockhourOfHalfday();
        java.util.TimeZone timeZone54 = null;
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.forTimeZone(timeZone54);
        boolean boolean57 = dateTimeZone55.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime(dateTimeZone55);
        org.joda.time.YearMonthDay yearMonthDay59 = dateTime58.toYearMonthDay();
        int[] intArray61 = iSOChronology52.get((org.joda.time.ReadablePartial) yearMonthDay59, (long) 35);
        java.util.Locale locale63 = null;
        java.lang.String str64 = dividedDateTimeField48.getAsText((org.joda.time.ReadablePartial) yearMonthDay59, 50, locale63);
        java.lang.String str65 = dateTimeFormatter35.print((org.joda.time.ReadablePartial) yearMonthDay59);
        java.util.TimeZone timeZone66 = null;
        org.joda.time.DateTimeZone dateTimeZone67 = org.joda.time.DateTimeZone.forTimeZone(timeZone66);
        org.joda.time.chrono.ISOChronology iSOChronology68 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone67);
        org.joda.time.DateTimeField dateTimeField69 = iSOChronology68.secondOfMinute();
        java.util.TimeZone timeZone70 = null;
        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.forTimeZone(timeZone70);
        boolean boolean73 = dateTimeZone71.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime(dateTimeZone71);
        org.joda.time.DateTime.Property property75 = dateTime74.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType76 = property75.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField78 = new org.joda.time.field.DividedDateTimeField(dateTimeField69, dateTimeFieldType76, 2019);
        org.joda.time.DateTimeField dateTimeField79 = dividedDateTimeField78.getWrappedField();
        org.joda.time.ReadablePartial readablePartial80 = null;
        int[] intArray82 = new int[] { 2000 };
        int int83 = dividedDateTimeField78.getMinimumValue(readablePartial80, intArray82);
        int int84 = dividedDateTimeField27.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay59, intArray82);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) yearMonthDay59);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1959000L + "'", long30 == 1959000L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 195843050L + "'", long33 == 195843050L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1959000L + "'", long51 == 1959000L);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(yearMonthDay59);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "50" + "'", str64.equals("50"));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "����-W��" + "'", str65.equals("����-W��"));
        org.junit.Assert.assertNotNull(dateTimeZone67);
        org.junit.Assert.assertNotNull(iSOChronology68);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(property75);
        org.junit.Assert.assertNotNull(dateTimeFieldType76);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology3.getZone();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology3.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass3 = dateTimeFormatter2.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology4.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.hourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.dayOfWeek();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology4);
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.secondOfMinute();
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        boolean boolean18 = dateTimeZone16.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTime.Property property20 = dateTime19.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField(dateTimeField14, dateTimeFieldType21, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        boolean boolean28 = dateTime10.isSupported(dateTimeFieldType21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType21, 79218660, (int) (short) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 6, "00:00:00-08:00");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("����-W��", "GregorianChronology[America/Los_Angeles]", 45, 59);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime4.dayOfYear();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.plus(readablePeriod7);
        java.util.Date date9 = dateTime8.toDate();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField18.getType();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = iSOChronology23.getZone();
        org.joda.time.DurationField durationField25 = iSOChronology23.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField25);
        org.joda.time.DurationField durationField27 = unsupportedDateTimeField26.getLeapDurationField();
        java.util.Locale locale28 = null;
        try {
            int int29 = unsupportedDateTimeField26.getMaximumShortTextLength(locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-50399900L) + "'", long21 == (-50399900L));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNull(durationField27);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("166");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeZone3);
        java.lang.String str5 = jodaTimePermission1.getActions();
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("166");
        boolean boolean8 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission7);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
        org.joda.time.DateTime.Property property8 = dateTime4.hourOfDay();
        org.joda.time.DateTime dateTime10 = property8.addToCopy((long) (byte) 0);
        org.joda.time.DateTime.Property property11 = dateTime10.minuteOfHour();
        boolean boolean12 = property11.isLeap();
        org.joda.time.DurationField durationField13 = property11.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.secondOfMinute();
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        boolean boolean21 = dateTimeZone19.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType24, 2019);
        java.util.TimeZone timeZone27 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
        boolean boolean30 = dateTimeZone28.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone28);
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime31.toYearMonthDay();
        int int33 = dividedDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32);
        java.util.TimeZone timeZone34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.secondOfMinute();
        java.util.TimeZone timeZone38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
        boolean boolean41 = dateTimeZone39.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property43 = dateTime42.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType44, 2019);
        org.joda.time.DateTimeField dateTimeField47 = dividedDateTimeField46.getWrappedField();
        org.joda.time.ReadablePartial readablePartial48 = null;
        int[] intArray50 = new int[] { 2000 };
        int int51 = dividedDateTimeField46.getMinimumValue(readablePartial48, intArray50);
        int int52 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32, intArray50);
        int int55 = dividedDateTimeField12.getDifference((long) 100, 1560549565386L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass57 = dateTimeFormatter56.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone59 = iSOChronology58.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = dateTimeFormatter56.withChronology((org.joda.time.Chronology) iSOChronology58);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology58.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField62 = iSOChronology58.hourOfDay();
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology58.dayOfWeek();
        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology58);
        java.util.TimeZone timeZone65 = null;
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forTimeZone(timeZone65);
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone66);
        org.joda.time.DateTimeField dateTimeField68 = iSOChronology67.secondOfMinute();
        java.util.TimeZone timeZone69 = null;
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forTimeZone(timeZone69);
        boolean boolean72 = dateTimeZone70.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime(dateTimeZone70);
        org.joda.time.DateTime.Property property74 = dateTime73.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property74.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField(dateTimeField68, dateTimeFieldType75, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException81 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        boolean boolean82 = dateTime64.isSupported(dateTimeFieldType75);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 50, (java.lang.Number) 100.0d, (java.lang.Number) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField87 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField12, dateTimeFieldType75);
        int int89 = zeroIsMaxDateTimeField87.getMaximumValue(1560635971712L);
        long long91 = zeroIsMaxDateTimeField87.remainder((long) 52);
        boolean boolean93 = zeroIsMaxDateTimeField87.isLeap((long) 15);
        org.joda.time.DateTimeFieldType dateTimeFieldType94 = zeroIsMaxDateTimeField87.getType();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(yearMonthDay32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-772931) + "'", int55 == (-772931));
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(dateTimeFormatter60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 52L + "'", long91 == 52L);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType94);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
//        java.lang.Appendable appendable1 = null;
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        boolean boolean5 = dateTimeZone3.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.Chronology chronology7 = dateTime6.getChronology();
//        org.joda.time.DateTime dateTime9 = dateTime6.minusDays(1);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) '#');
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime9.plus(readableDuration12);
//        long long14 = dateTime13.getMillis();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone16 = iSOChronology15.getZone();
//        org.joda.time.MutableDateTime mutableDateTime17 = dateTime13.toMutableDateTime(dateTimeZone16);
//        boolean boolean19 = dateTime13.isAfter(10L);
//        org.joda.time.TimeOfDay timeOfDay20 = dateTime13.toTimeOfDay();
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) timeOfDay20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560549648187L + "'", long14 == 1560549648187L);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(timeOfDay20);
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.secondOfMinute();
//        int int12 = dateTime4.get(dateTimeField11);
//        org.joda.time.DateTime dateTime14 = dateTime4.plusMinutes(10);
//        java.util.TimeZone timeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.secondOfMinute();
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        boolean boolean22 = dateTimeZone20.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone20);
//        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField27 = new org.joda.time.field.DividedDateTimeField(dateTimeField18, dateTimeFieldType25, 2019);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
//        org.joda.time.DateTime dateTime33 = dateTime14.withField(dateTimeFieldType25, 23);
//        org.joda.time.ReadableDuration readableDuration34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime33.plus(readableDuration34);
//        int int36 = dateTime35.getWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 48 + "'", int12 == 48);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 27, 292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("+00:10", 26, (-25200000), 7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 26 for +00:10 must be in the range [-25200000,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfHalfday();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        boolean boolean5 = dateTimeZone3.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime6.toYearMonthDay();
        int[] intArray9 = iSOChronology0.get((org.joda.time.ReadablePartial) yearMonthDay7, (long) 35);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.millisOfDay();
        java.lang.Object obj12 = null;
        boolean boolean13 = iSOChronology0.equals(obj12);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(yearMonthDay7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.dayOfWeek();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.hourOfHalfday();
        org.joda.time.DurationField durationField10 = iSOChronology2.centuries();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology2.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusMillis((int) '#');
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime7.plus(readableDuration10);
//        long long12 = dateTime11.getMillis();
//        org.joda.time.DateTime dateTime14 = dateTime11.withSecondOfMinute(19);
//        org.joda.time.DateTime.Property property15 = dateTime14.era();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560549648635L + "'", long12 == 1560549648635L);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (-19));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("2019-06-15T15:00:41.269-07:00", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2019-06-15T15:00:41.269-07:00/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfMinute();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        boolean boolean9 = dateTimeZone7.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType12, 2019);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType12, (int) (short) 10, (int) (byte) -1, 12);
        long long21 = offsetDateTimeField18.addWrapField((long) (byte) 100, 50);
        boolean boolean22 = offsetDateTimeField18.isSupported();
        int int25 = offsetDateTimeField18.getDifference(1263557883L, 32304010L);
        int int27 = offsetDateTimeField18.getLeapAmount(1560556800066L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-50399900L) + "'", long21 == (-50399900L));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 342 + "'", int25 == 342);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime4.weekyear();
        org.joda.time.DateTime dateTime8 = property6.setCopy("166");
        java.util.Locale locale9 = null;
        java.lang.String str10 = property6.getAsText(locale9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        boolean boolean16 = dateTimeZone14.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime17.toYearMonthDay();
        int int19 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay18);
        long long22 = dividedDateTimeField12.getDifferenceAsLong((-100L), 1L);
        long long25 = dividedDateTimeField12.add((long) 18, (long) 15);
        long long27 = dividedDateTimeField12.remainder((long) 79218660);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(yearMonthDay18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 30285018L + "'", long25 == 30285018L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 79218660L + "'", long27 == 79218660L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        int int6 = property5.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property5.getFieldType();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
        org.joda.time.DateTime dateTime11 = dateTime7.minusYears(23);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime7.minus(readableDuration12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusMonths(3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        long long15 = dividedDateTimeField12.roundHalfEven(0L);
        long long17 = dividedDateTimeField12.roundHalfFloor(74189915097L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 74189880000L + "'", long17 == 74189880000L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(0, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMillisOfDay(50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 53985461);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        int int8 = fixedDateTimeZone4.getStandardOffset((long) 'a');
        long long11 = fixedDateTimeZone4.convertLocalToUTC(0L, true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-52L) + "'", long11 == (-52L));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.DurationField durationField5 = iSOChronology1.months();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfMinute();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        boolean boolean7 = dateTimeZone5.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 2019);
        boolean boolean13 = dividedDateTimeField12.isLenient();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.secondOfMinute();
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        boolean boolean21 = dateTimeZone19.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType24, 2019);
        java.util.TimeZone timeZone27 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forTimeZone(timeZone27);
        boolean boolean30 = dateTimeZone28.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone28);
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime31.toYearMonthDay();
        int int33 = dividedDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32);
        java.util.TimeZone timeZone34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.secondOfMinute();
        java.util.TimeZone timeZone38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone38);
        boolean boolean41 = dateTimeZone39.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.DateTime.Property property43 = dateTime42.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField37, dateTimeFieldType44, 2019);
        org.joda.time.DateTimeField dateTimeField47 = dividedDateTimeField46.getWrappedField();
        org.joda.time.ReadablePartial readablePartial48 = null;
        int[] intArray50 = new int[] { 2000 };
        int int51 = dividedDateTimeField46.getMinimumValue(readablePartial48, intArray50);
        int int52 = dividedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32, intArray50);
        int int55 = dividedDateTimeField12.getDifference((long) 100, 1560549565386L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Class<?> wildcardClass57 = dateTimeFormatter56.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone59 = iSOChronology58.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = dateTimeFormatter56.withChronology((org.joda.time.Chronology) iSOChronology58);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology58.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField62 = iSOChronology58.hourOfDay();
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology58.dayOfWeek();
        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology58);
        java.util.TimeZone timeZone65 = null;
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forTimeZone(timeZone65);
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone66);
        org.joda.time.DateTimeField dateTimeField68 = iSOChronology67.secondOfMinute();
        java.util.TimeZone timeZone69 = null;
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forTimeZone(timeZone69);
        boolean boolean72 = dateTimeZone70.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime(dateTimeZone70);
        org.joda.time.DateTime.Property property74 = dateTime73.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property74.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField77 = new org.joda.time.field.DividedDateTimeField(dateTimeField68, dateTimeFieldType75, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException81 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 35, (java.lang.Number) 2000, (java.lang.Number) 0.0f);
        boolean boolean82 = dateTime64.isSupported(dateTimeFieldType75);
        org.joda.time.IllegalFieldValueException illegalFieldValueException86 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType75, (java.lang.Number) 50, (java.lang.Number) 100.0d, (java.lang.Number) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField87 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField12, dateTimeFieldType75);
        long long89 = zeroIsMaxDateTimeField87.roundCeiling(0L);
        long long91 = zeroIsMaxDateTimeField87.roundHalfFloor(1560549569678L);
        long long93 = zeroIsMaxDateTimeField87.roundHalfFloor((long) 27);
        long long95 = zeroIsMaxDateTimeField87.roundCeiling((-100L));
        long long97 = zeroIsMaxDateTimeField87.roundHalfFloor(1560549567921L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(yearMonthDay32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-772931) + "'", int55 == (-772931));
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(dateTimeFormatter60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 0L + "'", long89 == 0L);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 1560549540000L + "'", long91 == 1560549540000L);
        org.junit.Assert.assertTrue("'" + long93 + "' != '" + 0L + "'", long93 == 0L);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 1959000L + "'", long95 == 1959000L);
        org.junit.Assert.assertTrue("'" + long97 + "' != '" + 1560549540000L + "'", long97 == 1560549540000L);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test272");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTime1);
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        boolean boolean6 = dateTimeZone4.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear((int) (byte) 0);
//        int int11 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime13 = dateTime7.minusWeeks(0);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readableDuration8);
        org.joda.time.DateTime dateTime11 = dateTime7.minusYears(23);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", (int) '4', 19);
        int int6 = fixedDateTimeZone4.getStandardOffset(1360427398500L);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        boolean boolean9 = fixedDateTimeZone4.isStandardOffset((long) 20);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
//        org.joda.time.DateTime dateTime7 = dateTime4.minusDays(1);
//        org.joda.time.DateTime.Property property8 = dateTime4.millisOfDay();
//        java.lang.Object obj9 = null;
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        boolean boolean11 = org.joda.time.field.FieldUtils.equals(obj9, (java.lang.Object) dateTime10);
//        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime14 = dateTime10.withMillisOfSecond((int) (short) 1);
//        org.joda.time.DateTime dateTime16 = dateTime10.plusWeeks(10);
//        java.lang.Object obj17 = null;
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals(obj17, (java.lang.Object) dateTime18);
//        java.util.TimeZone timeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
//        boolean boolean23 = dateTimeZone21.isStandardOffset((long) '#');
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone21);
//        org.joda.time.DateTime.Property property25 = dateTime24.secondOfDay();
//        org.joda.time.DateTime dateTime27 = dateTime24.withYear((int) (byte) 0);
//        int int28 = dateTime18.compareTo((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime30 = dateTime24.minusWeeks(0);
//        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
//        int int33 = dateTimeZone31.getOffsetFromLocal((long) 2019);
//        java.lang.String str35 = dateTimeZone31.getName((long) ' ');
//        org.joda.time.DateTime dateTime36 = dateTime10.toDateTime(dateTimeZone31);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-28800000) + "'", int33 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Pacific Standard Time" + "'", str35.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime36);
//    }
//}

