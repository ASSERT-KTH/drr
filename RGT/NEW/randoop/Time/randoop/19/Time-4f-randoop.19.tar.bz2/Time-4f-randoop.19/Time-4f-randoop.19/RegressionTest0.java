import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 0L, (java.lang.Number) (byte) -1, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        try {
            org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((java.lang.Object) "hi!", (org.joda.time.Chronology) iSOChronology3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) ' ', (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(10L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.halfdayOfDay();
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            int[] intArray6 = iSOChronology2.get(readablePartial4, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        try {
            org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 100.0d, dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.ReadablePartial readablePartial4 = null;
        int[] intArray9 = new int[] { 100, 1, 100, (-1) };
        try {
            iSOChronology2.validate(readablePartial4, intArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            int[] intArray6 = iSOChronology2.get(readablePartial4, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(10L, "hi!");
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        boolean boolean4 = instant2.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        boolean boolean7 = instant5.isBefore((org.joda.time.ReadableInstant) instant6);
        boolean boolean8 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology9 = instant5.getChronology();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance(chronology9, readableDateTime10, readableDateTime11);
        try {
            org.joda.time.Partial partial13 = new org.joda.time.Partial(dateTimeFieldType0, (int) (byte) -1, chronology9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(limitChronology12);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withEra(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        int int10 = dateTime8.getEra();
        try {
            org.joda.time.DateTime dateTime12 = dateTime8.withWeekOfWeekyear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray14 = new int[] { (byte) 10 };
        try {
            int[] intArray16 = skipUndoDateTimeField10.set(readablePartial11, (int) (short) 10, intArray14, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.halfdayOfDay();
        try {
            long long9 = iSOChronology2.getDateTimeMillis((long) (short) 0, 100, (int) (byte) 0, (int) (short) 1, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        int int12 = skipUndoDateTimeField10.getMaximumValue((long) 0);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale14 = null;
        try {
            java.lang.String str15 = skipUndoDateTimeField10.getAsShortText(readablePartial13, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.DateTime dateTime11 = dateTime8.withField(dateTimeFieldType9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        int[] intArray4 = new int[] { (-1), '#', (short) 0 };
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = iSOChronology7.minutes();
        try {
            org.joda.time.Partial partial9 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray4, (org.joda.time.Chronology) iSOChronology7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (byte) -1, (int) (byte) -1, (int) ' ', (-1), (int) '#', (int) (short) 10, 1, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.DateTime dateTime14 = dateTime8.withFieldAdded(durationFieldType12, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DurationField durationField4 = iSOChronology2.years();
        try {
            long long12 = iSOChronology2.getDateTimeMillis((int) (byte) 0, (int) (byte) 10, 0, 0, 1, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 100, (int) (byte) 100, (int) (byte) 100, (int) (byte) 1, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.lang.String str3 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        try {
            long long16 = limitChronology10.getDateTimeMillis((long) 'a', 1, 0, 365, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        java.util.Locale locale15 = null;
        try {
            long long16 = delegatedDateTimeField12.set((long) '4', "hi!", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for halfdayOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeField dateTimeField1 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        int int12 = skipUndoDateTimeField10.getMaximumValue((long) 0);
        try {
            long long15 = skipUndoDateTimeField10.set((long) 1, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for halfdayOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField9 = iSOChronology8.minutes();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology5, dateTimeField10, (int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((-1), (int) 'a', 100, (int) ' ', 10, (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        int int10 = dateTime8.getEra();
        try {
            org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfSecond((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        boolean boolean10 = instant8.isBefore((org.joda.time.ReadableInstant) instant9);
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
        boolean boolean14 = instant9.isBefore((org.joda.time.ReadableInstant) instant11);
        org.joda.time.Chronology chronology15 = instant11.getChronology();
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance(chronology15, readableDateTime16, readableDateTime17);
        org.joda.time.Partial partial19 = new org.joda.time.Partial(chronology15);
        org.joda.time.Instant instant20 = new org.joda.time.Instant();
        org.joda.time.Instant instant21 = new org.joda.time.Instant();
        boolean boolean22 = instant20.isBefore((org.joda.time.ReadableInstant) instant21);
        org.joda.time.Instant instant23 = new org.joda.time.Instant();
        org.joda.time.Instant instant24 = new org.joda.time.Instant();
        boolean boolean25 = instant23.isBefore((org.joda.time.ReadableInstant) instant24);
        boolean boolean26 = instant21.isBefore((org.joda.time.ReadableInstant) instant23);
        org.joda.time.Chronology chronology27 = instant23.getChronology();
        org.joda.time.ReadableDateTime readableDateTime28 = null;
        org.joda.time.ReadableDateTime readableDateTime29 = null;
        org.joda.time.chrono.LimitChronology limitChronology30 = org.joda.time.chrono.LimitChronology.getInstance(chronology27, readableDateTime28, readableDateTime29);
        org.joda.time.Partial partial31 = new org.joda.time.Partial(chronology27);
        boolean boolean32 = partial19.isMatch((org.joda.time.ReadablePartial) partial31);
        int[] intArray34 = new int[] {};
        try {
            int[] intArray36 = skipDateTimeField7.addWrapField((org.joda.time.ReadablePartial) partial31, 0, intArray34, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(limitChronology30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronology();
        boolean boolean4 = dateTimeFormatter2.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-1), (long) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        try {
            java.lang.String str13 = partial11.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.field.FieldUtils.verifyValueBounds("+00:00:00.052", (-1), (-1), 10);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfDay();
        try {
            org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((int) (short) 10, (-1), (int) (byte) 10, (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        int int14 = delegatedDateTimeField12.getMinimumValue((long) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField12, dateTimeFieldType15, 0, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis((int) (short) 10, (int) '#', (int) (short) 100, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(0, (int) 'a', (int) (short) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis((int) (byte) -1, (int) '#', (int) '4', (int) (short) -1, 1, (int) '#', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long5 = julianChronology0.getDateTimeMillis((int) (byte) 100, (-1), (int) (short) -1, 57600010);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        org.joda.time.Instant instant24 = new org.joda.time.Instant();
        org.joda.time.Instant instant25 = new org.joda.time.Instant();
        boolean boolean26 = instant24.isBefore((org.joda.time.ReadableInstant) instant25);
        org.joda.time.Instant instant27 = new org.joda.time.Instant();
        org.joda.time.Instant instant28 = new org.joda.time.Instant();
        boolean boolean29 = instant27.isBefore((org.joda.time.ReadableInstant) instant28);
        boolean boolean30 = instant25.isBefore((org.joda.time.ReadableInstant) instant27);
        org.joda.time.Chronology chronology31 = instant27.getChronology();
        org.joda.time.ReadableDateTime readableDateTime32 = null;
        org.joda.time.ReadableDateTime readableDateTime33 = null;
        org.joda.time.chrono.LimitChronology limitChronology34 = org.joda.time.chrono.LimitChronology.getInstance(chronology31, readableDateTime32, readableDateTime33);
        org.joda.time.Partial partial35 = new org.joda.time.Partial(chronology31);
        boolean boolean36 = partial23.isMatch((org.joda.time.ReadablePartial) partial35);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.clockhourOfHalfday();
        org.joda.time.Partial partial41 = partial35.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology39);
        boolean boolean42 = partial11.isMatch((org.joda.time.ReadablePartial) partial35);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType44 = partial11.getFieldType((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(limitChronology34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(partial41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone7.isLocalDateTimeGap(localDateTime9);
        java.lang.String str12 = dateTimeZone7.getName((long) '#');
        int int14 = dateTimeZone7.getOffsetFromLocal((long) 10);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) (short) 10, (int) (byte) 10, 57600010, (int) (short) 10, 365, (int) '#', dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        org.joda.time.Instant instant24 = new org.joda.time.Instant();
        org.joda.time.Instant instant25 = new org.joda.time.Instant();
        boolean boolean26 = instant24.isBefore((org.joda.time.ReadableInstant) instant25);
        org.joda.time.Instant instant27 = new org.joda.time.Instant();
        org.joda.time.Instant instant28 = new org.joda.time.Instant();
        boolean boolean29 = instant27.isBefore((org.joda.time.ReadableInstant) instant28);
        boolean boolean30 = instant25.isBefore((org.joda.time.ReadableInstant) instant27);
        org.joda.time.Chronology chronology31 = instant27.getChronology();
        org.joda.time.ReadableDateTime readableDateTime32 = null;
        org.joda.time.ReadableDateTime readableDateTime33 = null;
        org.joda.time.chrono.LimitChronology limitChronology34 = org.joda.time.chrono.LimitChronology.getInstance(chronology31, readableDateTime32, readableDateTime33);
        org.joda.time.Partial partial35 = new org.joda.time.Partial(chronology31);
        boolean boolean36 = partial23.isMatch((org.joda.time.ReadablePartial) partial35);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.clockhourOfHalfday();
        org.joda.time.Partial partial41 = partial35.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology39);
        boolean boolean42 = partial11.isMatch((org.joda.time.ReadablePartial) partial35);
        try {
            org.joda.time.DateTimeField dateTimeField44 = partial35.getField((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(limitChronology34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(partial41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) '#', 57600010);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds((int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        int int14 = delegatedDateTimeField12.getMinimumValue((long) (short) 100);
        long long17 = delegatedDateTimeField12.addWrapField(0L, 365);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField12, dateTimeFieldType18, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43200000L + "'", long17 == 43200000L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        long long15 = skipUndoDateTimeField10.add(0L, (long) (short) 10);
        try {
            long long18 = skipUndoDateTimeField10.set(35L, "+00:00:00.052");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00:00.052\" for halfdayOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 432000000L + "'", long15 == 432000000L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 365);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 365");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField10.getAsText((long) (short) 100, locale13);
        java.util.Locale locale17 = null;
        try {
            long long18 = skipUndoDateTimeField10.set((long) 1, "+00:00:00.052", locale17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00:00.052\" for halfdayOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withHourOfDay((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 0, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        try {
            org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((int) (short) 100, 35, (int) (short) 100, (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = partial23.getFormatter();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        try {
            int int27 = partial23.get(dateTimeFieldType26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(dateTimeFormatter25);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 10L + "'", long0 == 10L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        long long15 = delegatedDateTimeField12.set((long) '#', "AM");
        int int18 = delegatedDateTimeField12.getDifference((long) (short) 0, 43200000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.DateTime.Property property10 = dateTime8.property(dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        org.joda.time.Instant instant24 = new org.joda.time.Instant();
        org.joda.time.Instant instant25 = new org.joda.time.Instant();
        boolean boolean26 = instant24.isBefore((org.joda.time.ReadableInstant) instant25);
        org.joda.time.Instant instant27 = new org.joda.time.Instant();
        org.joda.time.Instant instant28 = new org.joda.time.Instant();
        boolean boolean29 = instant27.isBefore((org.joda.time.ReadableInstant) instant28);
        boolean boolean30 = instant25.isBefore((org.joda.time.ReadableInstant) instant27);
        org.joda.time.Chronology chronology31 = instant27.getChronology();
        org.joda.time.ReadableDateTime readableDateTime32 = null;
        org.joda.time.ReadableDateTime readableDateTime33 = null;
        org.joda.time.chrono.LimitChronology limitChronology34 = org.joda.time.chrono.LimitChronology.getInstance(chronology31, readableDateTime32, readableDateTime33);
        org.joda.time.Partial partial35 = new org.joda.time.Partial(chronology31);
        boolean boolean36 = partial23.isMatch((org.joda.time.ReadablePartial) partial35);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.clockhourOfHalfday();
        org.joda.time.Partial partial41 = partial35.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology39);
        boolean boolean42 = partial11.isMatch((org.joda.time.ReadablePartial) partial35);
        org.joda.time.DurationFieldType durationFieldType43 = null;
        try {
            org.joda.time.Partial partial45 = partial35.withFieldAdded(durationFieldType43, 57600010);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(limitChronology34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(partial41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        org.joda.time.Instant instant14 = new org.joda.time.Instant();
        boolean boolean15 = instant13.isBefore((org.joda.time.ReadableInstant) instant14);
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        org.joda.time.Instant instant17 = new org.joda.time.Instant();
        boolean boolean18 = instant16.isBefore((org.joda.time.ReadableInstant) instant17);
        boolean boolean19 = instant14.isBefore((org.joda.time.ReadableInstant) instant16);
        org.joda.time.Chronology chronology20 = instant16.getChronology();
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.ReadableDateTime readableDateTime22 = null;
        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology20, readableDateTime21, readableDateTime22);
        org.joda.time.Partial partial24 = new org.joda.time.Partial(chronology20);
        org.joda.time.Instant instant25 = new org.joda.time.Instant();
        org.joda.time.Instant instant26 = new org.joda.time.Instant();
        boolean boolean27 = instant25.isBefore((org.joda.time.ReadableInstant) instant26);
        org.joda.time.Instant instant28 = new org.joda.time.Instant();
        org.joda.time.Instant instant29 = new org.joda.time.Instant();
        boolean boolean30 = instant28.isBefore((org.joda.time.ReadableInstant) instant29);
        boolean boolean31 = instant26.isBefore((org.joda.time.ReadableInstant) instant28);
        org.joda.time.Chronology chronology32 = instant28.getChronology();
        org.joda.time.ReadableDateTime readableDateTime33 = null;
        org.joda.time.ReadableDateTime readableDateTime34 = null;
        org.joda.time.chrono.LimitChronology limitChronology35 = org.joda.time.chrono.LimitChronology.getInstance(chronology32, readableDateTime33, readableDateTime34);
        org.joda.time.Partial partial36 = new org.joda.time.Partial(chronology32);
        boolean boolean37 = partial24.isMatch((org.joda.time.ReadablePartial) partial36);
        org.joda.time.Partial partial38 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial36);
        int[] intArray45 = new int[] { (byte) 0, 100, 100, ' ', (short) 0 };
        try {
            int[] intArray47 = delegatedDateTimeField12.add((org.joda.time.ReadablePartial) partial38, 0, intArray45, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(limitChronology23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(limitChronology35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(intArray45);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = julianChronology0.withZone(dateTimeZone2);
        try {
            long long9 = julianChronology0.getDateTimeMillis(0, (int) '#', (int) 'a', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        long long15 = skipUndoDateTimeField10.add(0L, (long) (short) 10);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = iSOChronology19.minutes();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology16, dateTimeField21, (int) (byte) 1);
        org.joda.time.Instant instant24 = new org.joda.time.Instant();
        org.joda.time.Instant instant25 = new org.joda.time.Instant();
        boolean boolean26 = instant24.isBefore((org.joda.time.ReadableInstant) instant25);
        org.joda.time.Instant instant27 = new org.joda.time.Instant();
        org.joda.time.Instant instant28 = new org.joda.time.Instant();
        boolean boolean29 = instant27.isBefore((org.joda.time.ReadableInstant) instant28);
        boolean boolean30 = instant25.isBefore((org.joda.time.ReadableInstant) instant27);
        org.joda.time.Chronology chronology31 = instant27.getChronology();
        org.joda.time.ReadableDateTime readableDateTime32 = null;
        org.joda.time.ReadableDateTime readableDateTime33 = null;
        org.joda.time.chrono.LimitChronology limitChronology34 = org.joda.time.chrono.LimitChronology.getInstance(chronology31, readableDateTime32, readableDateTime33);
        org.joda.time.Partial partial35 = new org.joda.time.Partial(chronology31);
        int[] intArray43 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
        int[] intArray45 = skipDateTimeField23.addWrapPartial((org.joda.time.ReadablePartial) partial35, (int) (short) 0, intArray43, (int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
        org.joda.time.DurationField durationField51 = iSOChronology50.minutes();
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology50.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField54 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology47, dateTimeField52, (int) (byte) 1);
        org.joda.time.Instant instant55 = new org.joda.time.Instant();
        org.joda.time.Instant instant56 = new org.joda.time.Instant();
        boolean boolean57 = instant55.isBefore((org.joda.time.ReadableInstant) instant56);
        org.joda.time.Instant instant58 = new org.joda.time.Instant();
        org.joda.time.Instant instant59 = new org.joda.time.Instant();
        boolean boolean60 = instant58.isBefore((org.joda.time.ReadableInstant) instant59);
        boolean boolean61 = instant56.isBefore((org.joda.time.ReadableInstant) instant58);
        org.joda.time.Chronology chronology62 = instant58.getChronology();
        org.joda.time.ReadableDateTime readableDateTime63 = null;
        org.joda.time.ReadableDateTime readableDateTime64 = null;
        org.joda.time.chrono.LimitChronology limitChronology65 = org.joda.time.chrono.LimitChronology.getInstance(chronology62, readableDateTime63, readableDateTime64);
        org.joda.time.Partial partial66 = new org.joda.time.Partial(chronology62);
        int[] intArray74 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
        int[] intArray76 = skipDateTimeField54.addWrapPartial((org.joda.time.ReadablePartial) partial66, (int) (short) 0, intArray74, (int) (short) 1);
        try {
            int[] intArray78 = skipUndoDateTimeField10.addWrapPartial((org.joda.time.ReadablePartial) partial35, (int) (short) 10, intArray76, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 432000000L + "'", long15 == 432000000L);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(limitChronology34);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(chronology62);
        org.junit.Assert.assertNotNull(limitChronology65);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray76);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        boolean boolean10 = instant8.isBefore((org.joda.time.ReadableInstant) instant9);
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
        boolean boolean14 = instant9.isBefore((org.joda.time.ReadableInstant) instant11);
        org.joda.time.Chronology chronology15 = instant11.getChronology();
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance(chronology15, readableDateTime16, readableDateTime17);
        org.joda.time.Partial partial19 = new org.joda.time.Partial(chronology15);
        int[] intArray27 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
        int[] intArray29 = skipDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) partial19, (int) (short) 0, intArray27, (int) (short) 1);
        java.lang.Class<?> wildcardClass30 = partial19.getClass();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        int[] intArray6 = new int[] { (byte) 1, (byte) -1, (byte) 1, ' ', (short) 0 };
        try {
            org.joda.time.Partial partial7 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField9, (int) (byte) 1);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField11.getRangeDurationField();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = dateTime8.toString("", locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000011576d + "'", double1 == 2440587.5000011576d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DurationField durationField14 = iSOChronology13.minutes();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology10, dateTimeField15, (int) (byte) 1);
        org.joda.time.Instant instant18 = new org.joda.time.Instant();
        org.joda.time.Instant instant19 = new org.joda.time.Instant();
        boolean boolean20 = instant18.isBefore((org.joda.time.ReadableInstant) instant19);
        org.joda.time.Instant instant21 = new org.joda.time.Instant();
        org.joda.time.Instant instant22 = new org.joda.time.Instant();
        boolean boolean23 = instant21.isBefore((org.joda.time.ReadableInstant) instant22);
        boolean boolean24 = instant19.isBefore((org.joda.time.ReadableInstant) instant21);
        org.joda.time.Chronology chronology25 = instant21.getChronology();
        org.joda.time.ReadableDateTime readableDateTime26 = null;
        org.joda.time.ReadableDateTime readableDateTime27 = null;
        org.joda.time.chrono.LimitChronology limitChronology28 = org.joda.time.chrono.LimitChronology.getInstance(chronology25, readableDateTime26, readableDateTime27);
        org.joda.time.Partial partial29 = new org.joda.time.Partial(chronology25);
        int[] intArray37 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
        int[] intArray39 = skipDateTimeField17.addWrapPartial((org.joda.time.ReadablePartial) partial29, (int) (short) 0, intArray37, (int) (short) 1);
        try {
            int[] intArray41 = skipDateTimeField7.addWrapPartial(readablePartial8, 10, intArray37, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(limitChronology28);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology3.getZone();
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, (org.joda.time.Chronology) iSOChronology3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType4, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) 'a', (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 129 + "'", int2 == 129);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        org.joda.time.Instant instant6 = new org.joda.time.Instant();
//        org.joda.time.Instant instant7 = new org.joda.time.Instant();
//        boolean boolean8 = instant6.isBefore((org.joda.time.ReadableInstant) instant7);
//        boolean boolean9 = instant4.isBefore((org.joda.time.ReadableInstant) instant6);
//        org.joda.time.Chronology chronology10 = instant6.getChronology();
//        org.joda.time.DateTime dateTime11 = instant6.toDateTimeISO();
//        org.joda.time.DateTime.Property property12 = dateTime11.year();
//        int int13 = dateTime11.getEra();
//        int int14 = dateTime11.getDayOfYear();
//        org.joda.time.DateTime dateTime16 = dateTime11.withMinuteOfHour((int) (short) 1);
//        try {
//            java.lang.String str17 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime16);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 365 + "'", int14 == 365);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology0.add(readablePeriod2, 100L, 57600010);
        org.joda.time.DurationField durationField6 = iSOChronology0.years();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.clockhourOfHalfday();
        org.joda.time.Partial partial29 = partial23.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology27);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.Partial partial31 = partial29.minus(readablePeriod30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
        try {
            int int33 = partial29.get(dateTimeFieldType32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(partial29);
        org.junit.Assert.assertNotNull(partial31);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("+00:00:00.052");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+00:00:00.052/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.LocalDateTime localDateTime8 = null;
        boolean boolean9 = dateTimeZone6.isLocalDateTimeGap(localDateTime8);
        java.lang.String str11 = dateTimeZone6.getName((long) '#');
        int int13 = dateTimeZone6.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone14);
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(0, (int) (byte) -1, (int) (byte) 0, 57600010, (int) (short) 1, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600010 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.052" + "'", str11.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertNotNull(copticChronology15);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.clockhourOfHalfday();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (short) -1, (int) (byte) 100, (int) (short) 0, 57600010, 35, 10, (org.joda.time.Chronology) iSOChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600010 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.util.Collection<org.joda.time.DateTimeFieldType> dateTimeFieldTypeCollection0 = null;
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.forFields(dateTimeFieldTypeCollection0, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(53L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        try {
            long long18 = copticChronology10.getDateTimeMillis(2, (int) (byte) 10, (int) (byte) 100, 35, 0, 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(copticChronology10);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("+00:00:00.052", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+00:00:00.052/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
//        int int14 = delegatedDateTimeField12.getMinimumValue((long) (short) 100);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = delegatedDateTimeField12.getAsShortText(0L, locale16);
//        org.joda.time.DurationField durationField18 = delegatedDateTimeField12.getRangeDurationField();
//        org.joda.time.Instant instant19 = new org.joda.time.Instant();
//        org.joda.time.Instant instant20 = new org.joda.time.Instant();
//        boolean boolean21 = instant19.isBefore((org.joda.time.ReadableInstant) instant20);
//        org.joda.time.Instant instant22 = new org.joda.time.Instant();
//        org.joda.time.Instant instant23 = new org.joda.time.Instant();
//        boolean boolean24 = instant22.isBefore((org.joda.time.ReadableInstant) instant23);
//        boolean boolean25 = instant20.isBefore((org.joda.time.ReadableInstant) instant22);
//        org.joda.time.Chronology chronology26 = instant22.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime27 = null;
//        org.joda.time.ReadableDateTime readableDateTime28 = null;
//        org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance(chronology26, readableDateTime27, readableDateTime28);
//        org.joda.time.Partial partial30 = new org.joda.time.Partial(chronology26);
//        org.joda.time.Instant instant31 = new org.joda.time.Instant();
//        org.joda.time.Instant instant32 = new org.joda.time.Instant();
//        boolean boolean33 = instant31.isBefore((org.joda.time.ReadableInstant) instant32);
//        org.joda.time.Instant instant34 = new org.joda.time.Instant();
//        org.joda.time.Instant instant35 = new org.joda.time.Instant();
//        boolean boolean36 = instant34.isBefore((org.joda.time.ReadableInstant) instant35);
//        boolean boolean37 = instant32.isBefore((org.joda.time.ReadableInstant) instant34);
//        org.joda.time.Chronology chronology38 = instant34.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime39 = null;
//        org.joda.time.ReadableDateTime readableDateTime40 = null;
//        org.joda.time.chrono.LimitChronology limitChronology41 = org.joda.time.chrono.LimitChronology.getInstance(chronology38, readableDateTime39, readableDateTime40);
//        org.joda.time.Partial partial42 = new org.joda.time.Partial(chronology38);
//        boolean boolean43 = partial30.isMatch((org.joda.time.ReadablePartial) partial42);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone45);
//        org.joda.time.DateTimeField dateTimeField47 = iSOChronology46.clockhourOfHalfday();
//        org.joda.time.Partial partial48 = partial42.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology46);
//        java.util.Locale locale49 = null;
//        try {
//            java.lang.String str50 = delegatedDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) partial42, locale49);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'halfdayOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(limitChronology29);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(limitChronology41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(iSOChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(partial48);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        try {
//            org.joda.time.DateTime dateTime14 = dateTime8.withTime(680, (int) '4', (int) (byte) 100, 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 680 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
//        org.joda.time.Instant instant15 = new org.joda.time.Instant();
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
//        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
//        org.joda.time.Chronology chronology19 = instant15.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime20 = null;
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
//        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
//        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.clockhourOfHalfday();
//        org.joda.time.Partial partial29 = partial23.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology27);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = null;
//        try {
//            org.joda.time.Partial.Property property31 = partial23.property(dateTimeFieldType30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(limitChronology22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(partial29);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
//        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
//        org.joda.time.DurationField durationField12 = skipUndoDateTimeField10.getRangeDurationField();
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        org.joda.time.Instant instant14 = new org.joda.time.Instant();
//        boolean boolean15 = instant13.isBefore((org.joda.time.ReadableInstant) instant14);
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        org.joda.time.Instant instant17 = new org.joda.time.Instant();
//        boolean boolean18 = instant16.isBefore((org.joda.time.ReadableInstant) instant17);
//        boolean boolean19 = instant14.isBefore((org.joda.time.ReadableInstant) instant16);
//        org.joda.time.Chronology chronology20 = instant16.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.ReadableDateTime readableDateTime22 = null;
//        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology20, readableDateTime21, readableDateTime22);
//        org.joda.time.Partial partial24 = new org.joda.time.Partial(chronology20);
//        org.joda.time.Instant instant25 = new org.joda.time.Instant();
//        org.joda.time.Instant instant26 = new org.joda.time.Instant();
//        boolean boolean27 = instant25.isBefore((org.joda.time.ReadableInstant) instant26);
//        org.joda.time.Instant instant28 = new org.joda.time.Instant();
//        org.joda.time.Instant instant29 = new org.joda.time.Instant();
//        boolean boolean30 = instant28.isBefore((org.joda.time.ReadableInstant) instant29);
//        boolean boolean31 = instant26.isBefore((org.joda.time.ReadableInstant) instant28);
//        org.joda.time.Chronology chronology32 = instant28.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime33 = null;
//        org.joda.time.ReadableDateTime readableDateTime34 = null;
//        org.joda.time.chrono.LimitChronology limitChronology35 = org.joda.time.chrono.LimitChronology.getInstance(chronology32, readableDateTime33, readableDateTime34);
//        org.joda.time.Partial partial36 = new org.joda.time.Partial(chronology32);
//        boolean boolean37 = partial24.isMatch((org.joda.time.ReadablePartial) partial36);
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.clockhourOfHalfday();
//        org.joda.time.Partial partial42 = partial36.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology40);
//        java.util.Locale locale44 = null;
//        try {
//            java.lang.String str45 = skipUndoDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) partial36, 100, locale44);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(limitChronology23);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(limitChronology35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(partial42);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.util.Locale locale3 = dateTimeFormatter2.getLocale();
        java.lang.Integer int4 = dateTimeFormatter2.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNull(int4);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.clockhourOfHalfday();
        org.joda.time.Partial partial29 = partial23.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology27);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType31 = partial29.getFieldType(35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(partial29);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        try {
            org.joda.time.LocalDate localDate15 = localDate13.withDayOfWeek((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalInstantExce...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
//        org.joda.time.Instant instant15 = new org.joda.time.Instant();
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
//        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
//        org.joda.time.Chronology chronology19 = instant15.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime20 = null;
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
//        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
//        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = partial23.getFormatter();
//        org.joda.time.Partial partial26 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial23);
//        try {
//            org.joda.time.DateTimeFieldType dateTimeFieldType28 = partial26.getFieldType(365);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 365");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(limitChronology22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNull(dateTimeFormatter25);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 10, (long) 680);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6800L + "'", long2 == 6800L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.ReadWritableInstant readWritableInstant1 = null;
        try {
            int int4 = dateTimeFormatter0.parseInto(readWritableInstant1, "0", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.Object obj0 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName(0L);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 57600010);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
//        java.lang.Appendable appendable3 = null;
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        org.joda.time.Instant instant5 = new org.joda.time.Instant();
//        boolean boolean6 = instant4.isBefore((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.Instant instant7 = new org.joda.time.Instant();
//        org.joda.time.Instant instant8 = new org.joda.time.Instant();
//        boolean boolean9 = instant7.isBefore((org.joda.time.ReadableInstant) instant8);
//        boolean boolean10 = instant5.isBefore((org.joda.time.ReadableInstant) instant7);
//        org.joda.time.Chronology chronology11 = instant7.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime12 = null;
//        org.joda.time.ReadableDateTime readableDateTime13 = null;
//        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance(chronology11, readableDateTime12, readableDateTime13);
//        org.joda.time.Partial partial15 = new org.joda.time.Partial(chronology11);
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        org.joda.time.Instant instant17 = new org.joda.time.Instant();
//        boolean boolean18 = instant16.isBefore((org.joda.time.ReadableInstant) instant17);
//        org.joda.time.Instant instant19 = new org.joda.time.Instant();
//        org.joda.time.Instant instant20 = new org.joda.time.Instant();
//        boolean boolean21 = instant19.isBefore((org.joda.time.ReadableInstant) instant20);
//        boolean boolean22 = instant17.isBefore((org.joda.time.ReadableInstant) instant19);
//        org.joda.time.Chronology chronology23 = instant19.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime24 = null;
//        org.joda.time.ReadableDateTime readableDateTime25 = null;
//        org.joda.time.chrono.LimitChronology limitChronology26 = org.joda.time.chrono.LimitChronology.getInstance(chronology23, readableDateTime24, readableDateTime25);
//        org.joda.time.Partial partial27 = new org.joda.time.Partial(chronology23);
//        boolean boolean28 = partial15.isMatch((org.joda.time.ReadablePartial) partial27);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = partial27.getFormatter();
//        java.lang.String str31 = partial27.toString("+00:00:00.052");
//        try {
//            dateTimeFormatter2.printTo(appendable3, (org.joda.time.ReadablePartial) partial27);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(limitChronology14);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(limitChronology26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNull(dateTimeFormatter29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00:00.052" + "'", str31.equals("+00:00:00.052"));
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, durationField1, dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.LocalDate localDate4 = localDate1.withFieldAdded(durationFieldType2, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.DateTime dateTime11 = limitChronology10.getLowerLimit();
//        try {
//            long long19 = limitChronology10.getDateTimeMillis((int) (short) 100, 1, (int) (byte) 1, 100, 4, 0, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertNull(dateTime11);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
//        org.joda.time.Instant instant15 = new org.joda.time.Instant();
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
//        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
//        org.joda.time.Chronology chronology19 = instant15.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime20 = null;
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
//        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
//        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.clockhourOfHalfday();
//        org.joda.time.Partial partial29 = partial23.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology27);
//        try {
//            org.joda.time.DateTimeField dateTimeField31 = partial23.getField(57600);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 57600");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(limitChronology22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(partial29);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.joda.time.DateTime dateTime3 = instant0.toDateTime();
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        int int14 = delegatedDateTimeField12.getMinimumValue((long) (short) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField12.getAsShortText(0L, locale16);
        java.util.Locale locale19 = null;
        java.lang.String str20 = delegatedDateTimeField12.getAsShortText(0L, locale19);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AM" + "'", str20.equals("AM"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
        org.joda.time.Partial partial25 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial23);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        try {
            org.joda.time.Partial partial28 = partial23.withField(dateTimeFieldType26, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType0 };
        int[] intArray8 = new int[] { 680, 4, (short) 10, (short) 1, (byte) 1, 10 };
        try {
            org.joda.time.Partial partial9 = new org.joda.time.Partial(dateTimeFieldTypeArray1, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 100, 10, 100, (int) (short) 1, (int) (byte) 1, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology5 = julianChronology1.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.clockhourOfDay();
        boolean boolean7 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTimeField6);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField9, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType12);
        int int15 = delegatedDateTimeField13.getMinimumValue((long) (short) 100);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField13.getAsShortText(0L, locale17);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField13.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, durationField19, dateTimeFieldType20, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "AM" + "'", str18.equals("AM"));
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.DateMidnight dateMidnight2 = localDate1.toDateMidnight();
        try {
            org.joda.time.LocalDate localDate4 = localDate1.withDayOfWeek((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateMidnight2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        java.lang.String str15 = property14.getAsText();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "January" + "'", str15.equals("January"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(332, (-1), 365, 0, 2, 680);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 680 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        int int10 = dateTime8.getEra();
//        int int11 = dateTime8.getDayOfYear();
//        org.joda.time.DateTime dateTime13 = dateTime8.withMinuteOfHour((int) (short) 1);
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime8.withHourOfDay(365);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 166 + "'", int11 == 166);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
        java.lang.String str4 = dateTimeZone3.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.052" + "'", str4.equals("+00:00:00.052"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = julianChronology0.withZone(dateTimeZone2);
        try {
            org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, 53L, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        int int14 = delegatedDateTimeField12.getMinimumValue((long) (short) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField12.getAsShortText(0L, locale16);
        int int18 = delegatedDateTimeField12.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(0, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField10.getRangeDurationField();
        int int15 = skipUndoDateTimeField10.getDifference((long) 10, 35L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfDay();
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField5, durationFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType3, 365);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
//        org.joda.time.Instant instant15 = new org.joda.time.Instant();
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
//        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
//        org.joda.time.Chronology chronology19 = instant15.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime20 = null;
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
//        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
//        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = partial23.getFormatter();
//        org.joda.time.Partial partial26 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial23);
//        java.lang.String str27 = partial26.toString();
//        org.joda.time.DurationFieldType durationFieldType28 = null;
//        try {
//            org.joda.time.Partial partial30 = partial26.withFieldAdded(durationFieldType28, 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(limitChronology22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNull(dateTimeFormatter25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "[]" + "'", str27.equals("[]"));
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "January");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.weekyear();
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        org.joda.time.Instant instant18 = new org.joda.time.Instant();
        org.joda.time.Instant instant19 = new org.joda.time.Instant();
        boolean boolean20 = instant18.isBefore((org.joda.time.ReadableInstant) instant19);
        boolean boolean21 = instant16.isBefore((org.joda.time.ReadableInstant) instant18);
        org.joda.time.Chronology chronology22 = instant18.getChronology();
        org.joda.time.ReadableDateTime readableDateTime23 = null;
        org.joda.time.ReadableDateTime readableDateTime24 = null;
        org.joda.time.chrono.LimitChronology limitChronology25 = org.joda.time.chrono.LimitChronology.getInstance(chronology22, readableDateTime23, readableDateTime24);
        org.joda.time.Partial partial26 = new org.joda.time.Partial(chronology22);
        try {
            int int27 = localDate13.compareTo((org.joda.time.ReadablePartial) partial26);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(limitChronology25);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        int int10 = dateTime8.getEra();
//        int int11 = dateTime8.getDayOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
//        int int13 = dateTime8.getMillisOfDay();
//        long long14 = dateTime8.getMillis();
//        try {
//            org.joda.time.DateTime dateTime16 = dateTime8.withEra((int) '#');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 166 + "'", int11 == 166);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 82822155 + "'", int13 == 82822155);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639622103L + "'", long14 == 1560639622103L);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        try {
            org.joda.time.MutableDateTime mutableDateTime4 = dateTimeFormatter0.parseMutableDateTime("[]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"[]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        try {
            long long19 = gJChronology14.getDateTimeMillis((int) (short) 100, 129, (int) (short) 10, 129);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 129 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(gJChronology14);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
//        org.joda.time.Instant instant15 = new org.joda.time.Instant();
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
//        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
//        org.joda.time.Chronology chronology19 = instant15.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime20 = null;
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
//        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
//        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = partial23.getFormatter();
//        java.lang.String str27 = partial23.toString("+00:00:00.052");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = partial23.getFormatter();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(limitChronology22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNull(dateTimeFormatter25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00:00.052" + "'", str27.equals("+00:00:00.052"));
//        org.junit.Assert.assertNull(dateTimeFormatter28);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        org.joda.time.LocalDate localDate16 = localDate13.minusYears(57600);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        try {
            int int18 = localDate16.get(dateTimeFieldType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.DateTime dateTime11 = limitChronology10.getLowerLimit();
//        try {
//            long long19 = limitChronology10.getDateTimeMillis(1, 1, 4, 100, (int) (byte) 0, (int) (byte) 100, 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertNull(dateTime11);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 10, 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 57600010, "00");
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.LocalDateTime localDateTime4 = null;
//        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
//        java.lang.String str7 = dateTimeZone2.getName((long) '#');
//        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
//        int int14 = localDate13.getYearOfCentury();
//        org.joda.time.Instant instant15 = new org.joda.time.Instant();
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
//        org.joda.time.Instant instant18 = new org.joda.time.Instant();
//        org.joda.time.Instant instant19 = new org.joda.time.Instant();
//        boolean boolean20 = instant18.isBefore((org.joda.time.ReadableInstant) instant19);
//        boolean boolean21 = instant16.isBefore((org.joda.time.ReadableInstant) instant18);
//        org.joda.time.Chronology chronology22 = instant18.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime23 = null;
//        org.joda.time.ReadableDateTime readableDateTime24 = null;
//        org.joda.time.chrono.LimitChronology limitChronology25 = org.joda.time.chrono.LimitChronology.getInstance(chronology22, readableDateTime23, readableDateTime24);
//        org.joda.time.Partial partial26 = new org.joda.time.Partial(chronology22);
//        org.joda.time.Instant instant27 = new org.joda.time.Instant();
//        org.joda.time.Instant instant28 = new org.joda.time.Instant();
//        boolean boolean29 = instant27.isBefore((org.joda.time.ReadableInstant) instant28);
//        org.joda.time.Instant instant30 = new org.joda.time.Instant();
//        org.joda.time.Instant instant31 = new org.joda.time.Instant();
//        boolean boolean32 = instant30.isBefore((org.joda.time.ReadableInstant) instant31);
//        boolean boolean33 = instant28.isBefore((org.joda.time.ReadableInstant) instant30);
//        org.joda.time.Chronology chronology34 = instant30.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime35 = null;
//        org.joda.time.ReadableDateTime readableDateTime36 = null;
//        org.joda.time.chrono.LimitChronology limitChronology37 = org.joda.time.chrono.LimitChronology.getInstance(chronology34, readableDateTime35, readableDateTime36);
//        org.joda.time.Partial partial38 = new org.joda.time.Partial(chronology34);
//        boolean boolean39 = partial26.isMatch((org.joda.time.ReadablePartial) partial38);
//        org.joda.time.Partial partial40 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial38);
//        try {
//            int int41 = localDate13.compareTo((org.joda.time.ReadablePartial) partial38);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(limitChronology25);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(limitChronology37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.weekyear();
        try {
            long long23 = gJChronology14.getDateTimeMillis(52, 70, (int) (byte) -1, (int) 'a', 0, 332, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        try {
            long long18 = copticChronology10.getDateTimeMillis((int) (byte) -1, 4, 680, 680, (int) '#', (int) (short) 10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 680 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(copticChronology10);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) '#', 332, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 57600010, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 576000100L + "'", long2 == 576000100L);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
//        int int12 = skipUndoDateTimeField10.getMaximumValue((long) 0);
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        org.joda.time.Instant instant14 = new org.joda.time.Instant();
//        boolean boolean15 = instant13.isBefore((org.joda.time.ReadableInstant) instant14);
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        org.joda.time.Instant instant17 = new org.joda.time.Instant();
//        boolean boolean18 = instant16.isBefore((org.joda.time.ReadableInstant) instant17);
//        boolean boolean19 = instant14.isBefore((org.joda.time.ReadableInstant) instant16);
//        org.joda.time.Chronology chronology20 = instant16.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.ReadableDateTime readableDateTime22 = null;
//        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology20, readableDateTime21, readableDateTime22);
//        org.joda.time.Partial partial24 = new org.joda.time.Partial(chronology20);
//        org.joda.time.Instant instant25 = new org.joda.time.Instant();
//        org.joda.time.Instant instant26 = new org.joda.time.Instant();
//        boolean boolean27 = instant25.isBefore((org.joda.time.ReadableInstant) instant26);
//        org.joda.time.Instant instant28 = new org.joda.time.Instant();
//        org.joda.time.Instant instant29 = new org.joda.time.Instant();
//        boolean boolean30 = instant28.isBefore((org.joda.time.ReadableInstant) instant29);
//        boolean boolean31 = instant26.isBefore((org.joda.time.ReadableInstant) instant28);
//        org.joda.time.Chronology chronology32 = instant28.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime33 = null;
//        org.joda.time.ReadableDateTime readableDateTime34 = null;
//        org.joda.time.chrono.LimitChronology limitChronology35 = org.joda.time.chrono.LimitChronology.getInstance(chronology32, readableDateTime33, readableDateTime34);
//        org.joda.time.Partial partial36 = new org.joda.time.Partial(chronology32);
//        boolean boolean37 = partial24.isMatch((org.joda.time.ReadablePartial) partial36);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = partial36.getFormatter();
//        org.joda.time.Partial partial39 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial36);
//        java.lang.String str40 = partial39.toString();
//        java.util.Locale locale41 = null;
//        try {
//            java.lang.String str42 = skipUndoDateTimeField10.getAsText((org.joda.time.ReadablePartial) partial39, locale41);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'halfdayOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(limitChronology23);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(limitChronology35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNull(dateTimeFormatter38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "[]" + "'", str40.equals("[]"));
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        int int10 = dateTime8.getEra();
//        int int11 = dateTime8.getDayOfYear();
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime8.withDate((int) (byte) 10, (int) '#', (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 166 + "'", int11 == 166);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 680);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.DateMidnight dateMidnight2 = localDate1.toDateMidnight();
        long long3 = dateMidnight2.getMillis();
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-52L) + "'", long3 == (-52L));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.weekyear();
        org.joda.time.LocalDate localDate16 = localDate13.plusYears((int) (byte) 100);
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = localDate13.toString("hi!", locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "LimitChronology[ISOChronology[UTC], NoLimit, NoLimit]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
        org.joda.time.Partial partial25 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial23);
        int int26 = partial23.size();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = partial23.getFormatter();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        try {
            org.joda.time.Partial.Property property27 = partial23.property(dateTimeFieldType26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(dateTimeFormatter25);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DurationField durationField4 = iSOChronology2.years();
        long long7 = durationField4.subtract((long) 84480732, (long) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-315534719268L) + "'", long7 == (-315534719268L));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.util.Locale locale3 = dateTimeFormatter2.getLocale();
        java.lang.Appendable appendable4 = null;
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        boolean boolean7 = instant5.isBefore((org.joda.time.ReadableInstant) instant6);
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        boolean boolean10 = instant8.isBefore((org.joda.time.ReadableInstant) instant9);
        boolean boolean11 = instant6.isBefore((org.joda.time.ReadableInstant) instant8);
        org.joda.time.Chronology chronology12 = instant8.getChronology();
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.ReadableDateTime readableDateTime14 = null;
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance(chronology12, readableDateTime13, readableDateTime14);
        org.joda.time.Partial partial16 = new org.joda.time.Partial(chronology12);
        org.joda.time.Instant instant17 = new org.joda.time.Instant();
        org.joda.time.Instant instant18 = new org.joda.time.Instant();
        boolean boolean19 = instant17.isBefore((org.joda.time.ReadableInstant) instant18);
        org.joda.time.Instant instant20 = new org.joda.time.Instant();
        org.joda.time.Instant instant21 = new org.joda.time.Instant();
        boolean boolean22 = instant20.isBefore((org.joda.time.ReadableInstant) instant21);
        boolean boolean23 = instant18.isBefore((org.joda.time.ReadableInstant) instant20);
        org.joda.time.Chronology chronology24 = instant20.getChronology();
        org.joda.time.ReadableDateTime readableDateTime25 = null;
        org.joda.time.ReadableDateTime readableDateTime26 = null;
        org.joda.time.chrono.LimitChronology limitChronology27 = org.joda.time.chrono.LimitChronology.getInstance(chronology24, readableDateTime25, readableDateTime26);
        org.joda.time.Partial partial28 = new org.joda.time.Partial(chronology24);
        boolean boolean29 = partial16.isMatch((org.joda.time.ReadablePartial) partial28);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = partial28.getFormatter();
        org.joda.time.Partial partial31 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial28);
        java.lang.String str32 = partial31.toString();
        try {
            dateTimeFormatter2.printTo(appendable4, (org.joda.time.ReadablePartial) partial31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(limitChronology27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(dateTimeFormatter30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "[]" + "'", str32.equals("[]"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate localDate4 = localDate1.withDayOfYear((int) (short) 1);
        int int6 = localDate1.getValue((int) (short) 1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
        int int26 = partial23.indexOf(dateTimeFieldType25);
        try {
            org.joda.time.DateTimeField dateTimeField28 = partial23.getField((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.minutes();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField6, (int) (byte) 1);
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        org.joda.time.Instant instant10 = new org.joda.time.Instant();
        boolean boolean11 = instant9.isBefore((org.joda.time.ReadableInstant) instant10);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        boolean boolean15 = instant10.isBefore((org.joda.time.ReadableInstant) instant12);
        org.joda.time.Chronology chronology16 = instant12.getChronology();
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.ReadableDateTime readableDateTime18 = null;
        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance(chronology16, readableDateTime17, readableDateTime18);
        org.joda.time.Partial partial20 = new org.joda.time.Partial(chronology16);
        int[] intArray28 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
        int[] intArray30 = skipDateTimeField8.addWrapPartial((org.joda.time.ReadablePartial) partial20, (int) (short) 0, intArray28, (int) (short) 1);
        try {
            org.joda.time.Partial partial31 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(limitChronology19);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100.0d, "0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds((int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.DateTime dateTime14 = dateTime11.withField(dateTimeFieldType12, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Chronology chronology11 = limitChronology10.withUTC();
        org.joda.time.Chronology chronology12 = limitChronology10.withUTC();
        long long16 = limitChronology10.add(105433401600062L, (long) 35, 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 105433401600097L + "'", long16 == 105433401600097L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(6800L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.Partial partial2 = new org.joda.time.Partial(dateTimeFieldType0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.year();
        int int3 = localDate1.getWeekOfWeekyear();
        org.joda.time.LocalDate.Property property4 = localDate1.yearOfEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekOfWeekyear();
        org.joda.time.DurationField durationField5 = iSOChronology2.minutes();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(1L, "hi!");
        org.joda.time.IllegalInstantException illegalInstantException5 = new org.joda.time.IllegalInstantException(1L, "hi!");
        org.joda.time.IllegalInstantException illegalInstantException8 = new org.joda.time.IllegalInstantException((long) 1, "+00:00:00.052");
        illegalInstantException5.addSuppressed((java.lang.Throwable) illegalInstantException8);
        boolean boolean10 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException8);
        illegalInstantException2.addSuppressed((java.lang.Throwable) illegalInstantException8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DurationField durationField16 = iSOChronology15.minutes();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField17, (int) (byte) 1);
//        org.joda.time.Instant instant20 = new org.joda.time.Instant();
//        org.joda.time.Instant instant21 = new org.joda.time.Instant();
//        boolean boolean22 = instant20.isBefore((org.joda.time.ReadableInstant) instant21);
//        org.joda.time.Instant instant23 = new org.joda.time.Instant();
//        org.joda.time.Instant instant24 = new org.joda.time.Instant();
//        boolean boolean25 = instant23.isBefore((org.joda.time.ReadableInstant) instant24);
//        boolean boolean26 = instant21.isBefore((org.joda.time.ReadableInstant) instant23);
//        org.joda.time.Chronology chronology27 = instant23.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime28 = null;
//        org.joda.time.ReadableDateTime readableDateTime29 = null;
//        org.joda.time.chrono.LimitChronology limitChronology30 = org.joda.time.chrono.LimitChronology.getInstance(chronology27, readableDateTime28, readableDateTime29);
//        org.joda.time.Partial partial31 = new org.joda.time.Partial(chronology27);
//        int[] intArray39 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
//        int[] intArray41 = skipDateTimeField19.addWrapPartial((org.joda.time.ReadablePartial) partial31, (int) (short) 0, intArray39, (int) (short) 1);
//        int int44 = skipDateTimeField19.getDifference((long) 52, (long) (byte) 100);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField(chronology7, (org.joda.time.DateTimeField) skipDateTimeField19);
//        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone48);
//        org.joda.time.DurationField durationField50 = iSOChronology49.minutes();
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology46, dateTimeField51, (int) (byte) 1);
//        int int54 = skipDateTimeField53.getMinimumValue();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, (org.joda.time.DateTimeField) skipDateTimeField53, (int) ' ');
//        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.DateMidnight dateMidnight59 = localDate58.toDateMidnight();
//        org.joda.time.Instant instant61 = new org.joda.time.Instant();
//        org.joda.time.Instant instant62 = new org.joda.time.Instant();
//        boolean boolean63 = instant61.isBefore((org.joda.time.ReadableInstant) instant62);
//        org.joda.time.Instant instant64 = new org.joda.time.Instant();
//        org.joda.time.Instant instant65 = new org.joda.time.Instant();
//        boolean boolean66 = instant64.isBefore((org.joda.time.ReadableInstant) instant65);
//        boolean boolean67 = instant62.isBefore((org.joda.time.ReadableInstant) instant64);
//        org.joda.time.Chronology chronology68 = instant64.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime69 = null;
//        org.joda.time.ReadableDateTime readableDateTime70 = null;
//        org.joda.time.chrono.LimitChronology limitChronology71 = org.joda.time.chrono.LimitChronology.getInstance(chronology68, readableDateTime69, readableDateTime70);
//        org.joda.time.Partial partial72 = new org.joda.time.Partial(chronology68);
//        org.joda.time.Instant instant73 = new org.joda.time.Instant();
//        org.joda.time.Instant instant74 = new org.joda.time.Instant();
//        boolean boolean75 = instant73.isBefore((org.joda.time.ReadableInstant) instant74);
//        org.joda.time.Instant instant76 = new org.joda.time.Instant();
//        org.joda.time.Instant instant77 = new org.joda.time.Instant();
//        boolean boolean78 = instant76.isBefore((org.joda.time.ReadableInstant) instant77);
//        boolean boolean79 = instant74.isBefore((org.joda.time.ReadableInstant) instant76);
//        org.joda.time.Chronology chronology80 = instant76.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime81 = null;
//        org.joda.time.ReadableDateTime readableDateTime82 = null;
//        org.joda.time.chrono.LimitChronology limitChronology83 = org.joda.time.chrono.LimitChronology.getInstance(chronology80, readableDateTime81, readableDateTime82);
//        org.joda.time.Partial partial84 = new org.joda.time.Partial(chronology80);
//        boolean boolean85 = partial72.isMatch((org.joda.time.ReadablePartial) partial84);
//        int[] intArray86 = partial72.getValues();
//        try {
//            int[] intArray88 = skipUndoDateTimeField56.set((org.joda.time.ReadablePartial) localDate58, (int) (byte) 10, intArray86, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(limitChronology30);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertNotNull(intArray41);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology46);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
//        org.junit.Assert.assertNotNull(dateMidnight59);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertNotNull(chronology68);
//        org.junit.Assert.assertNotNull(limitChronology71);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(chronology80);
//        org.junit.Assert.assertNotNull(limitChronology83);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
//        org.junit.Assert.assertNotNull(intArray86);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        org.joda.time.LocalDate localDate16 = localDate13.minusYears(57600);
        int int17 = localDate16.getYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-55630) + "'", int17 == (-55630));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        int int10 = dateTime8.getEra();
//        int int11 = dateTime8.getDayOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
//        org.joda.time.DateTime.Property property13 = dateTime8.dayOfWeek();
//        int int14 = dateTime8.getEra();
//        org.joda.time.DateTime dateTime16 = dateTime8.withYear((int) (short) 0);
//        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 166 + "'", int11 == 166);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560639632523L + "'", long17 == 1560639632523L);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.date();
        try {
            org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.parse("00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"00\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 53L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(9, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        try {
            org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField10.getAsText((long) (short) 100, locale13);
        org.joda.time.DateTimeField dateTimeField15 = skipUndoDateTimeField10.getWrappedField();
        boolean boolean16 = skipUndoDateTimeField10.isSupported();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        illegalFieldValueException2.prependMessage("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
        java.lang.Number number6 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        int int10 = dateTime8.getEra();
//        int int11 = dateTime8.getDayOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
//        org.joda.time.DateTime.Property property13 = dateTime8.dayOfWeek();
//        int int14 = dateTime8.getEra();
//        int int15 = dateTime8.getMillisOfSecond();
//        org.joda.time.DateTime dateTime17 = dateTime8.plus((long) 2);
//        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
//        int int19 = dateTime8.getSecondOfMinute();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 166 + "'", int11 == 166);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 725 + "'", int15 == 725);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 35 + "'", int19 == 35);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTimeISO();
//        org.joda.time.Instant instant4 = mutableDateTime3.toInstant();
//        long long5 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560639635957L + "'", long5 == 1560639635957L);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        try {
            long long10 = skipDateTimeField7.set((-52L), "[]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"[]\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DurationField durationField16 = iSOChronology15.minutes();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField17, (int) (byte) 1);
//        org.joda.time.Instant instant20 = new org.joda.time.Instant();
//        org.joda.time.Instant instant21 = new org.joda.time.Instant();
//        boolean boolean22 = instant20.isBefore((org.joda.time.ReadableInstant) instant21);
//        org.joda.time.Instant instant23 = new org.joda.time.Instant();
//        org.joda.time.Instant instant24 = new org.joda.time.Instant();
//        boolean boolean25 = instant23.isBefore((org.joda.time.ReadableInstant) instant24);
//        boolean boolean26 = instant21.isBefore((org.joda.time.ReadableInstant) instant23);
//        org.joda.time.Chronology chronology27 = instant23.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime28 = null;
//        org.joda.time.ReadableDateTime readableDateTime29 = null;
//        org.joda.time.chrono.LimitChronology limitChronology30 = org.joda.time.chrono.LimitChronology.getInstance(chronology27, readableDateTime28, readableDateTime29);
//        org.joda.time.Partial partial31 = new org.joda.time.Partial(chronology27);
//        int[] intArray39 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
//        int[] intArray41 = skipDateTimeField19.addWrapPartial((org.joda.time.ReadablePartial) partial31, (int) (short) 0, intArray39, (int) (short) 1);
//        int int44 = skipDateTimeField19.getDifference((long) 52, (long) (byte) 100);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField(chronology7, (org.joda.time.DateTimeField) skipDateTimeField19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField19, dateTimeFieldType46, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(limitChronology30);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertNotNull(intArray41);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        java.util.Locale locale6 = null;
        java.util.Calendar calendar7 = dateTime5.toCalendar(locale6);
        org.joda.time.DateTime dateTime8 = dateTime5.withEarlierOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime10 = dateTime5.withYearOfEra((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(calendar7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.weekyear();
        org.joda.time.LocalDate localDate16 = localDate13.plusYears((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.LocalDateTime localDateTime20 = null;
        boolean boolean21 = dateTimeZone18.isLocalDateTimeGap(localDateTime20);
        java.lang.String str23 = dateTimeZone18.getName((long) '#');
        int int25 = dateTimeZone18.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone26 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone18);
        org.joda.time.LocalDateTime localDateTime27 = null;
        boolean boolean28 = cachedDateTimeZone26.isLocalDateTimeGap(localDateTime27);
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone26);
        org.joda.time.DateTimeZone dateTimeZone30 = cachedDateTimeZone26.getUncachedZone();
        org.joda.time.DateMidnight dateMidnight31 = localDate13.toDateMidnight(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateMidnight31);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTime0.getZone();
        try {
            org.joda.time.DateTime dateTime3 = dateTime0.withMinuteOfHour((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.DateTime dateTime11 = limitChronology10.getLowerLimit();
//        try {
//            long long16 = limitChronology10.getDateTimeMillis((int) (short) 100, 35, (int) (short) -1, 680);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertNull(dateTime11);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(int2);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
//        org.joda.time.DurationFieldType durationFieldType12 = null;
//        try {
//            org.joda.time.Partial partial14 = partial11.withFieldAddWrapped(durationFieldType12, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.Instant instant2 = new org.joda.time.Instant();
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        boolean boolean4 = instant2.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Instant instant5 = new org.joda.time.Instant();
//        org.joda.time.Instant instant6 = new org.joda.time.Instant();
//        boolean boolean7 = instant5.isBefore((org.joda.time.ReadableInstant) instant6);
//        boolean boolean8 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
//        org.joda.time.Chronology chronology9 = instant5.getChronology();
//        org.joda.time.DateTime dateTime10 = instant5.toDateTimeISO();
//        org.joda.time.DateTime dateTime12 = dateTime10.plusHours(10);
//        java.lang.Class<?> wildcardClass13 = dateTime10.getClass();
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.lang.Object obj0 = null;
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(obj0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField9, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField11, dateTimeFieldType12);
        int int15 = delegatedDateTimeField13.getMinimumValue((long) (short) 100);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField13.getAsShortText(0L, locale17);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField13.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField21 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField19, dateTimeFieldType20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "AM" + "'", str18.equals("AM"));
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("00", false);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("January", true);
        java.io.OutputStream outputStream8 = null;
        try {
            dateTimeZoneBuilder0.writeTo("1970-01-01", outputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.plusMillis((int) (byte) 0);
        try {
            dateTimeFormatter2.printTo(stringBuffer3, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        java.lang.String str11 = limitChronology10.toString();
        try {
            long long19 = limitChronology10.getDateTimeMillis((int) (byte) 0, 19, (int) (short) 0, 100, 52, 70, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "LimitChronology[ISOChronology[UTC], NoLimit, NoLimit]" + "'", str11.equals("LimitChronology[ISOChronology[UTC], NoLimit, NoLimit]"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property4 = localDate3.monthOfYear();
        org.joda.time.LocalDate localDate6 = localDate3.withDayOfYear((int) (short) 1);
        int[] intArray7 = new int[] {};
        try {
            gregorianChronology0.validate((org.joda.time.ReadablePartial) localDate6, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("January", (int) '4', 166, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for January must be in the range [166,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        int int10 = dateTime8.getEra();
//        org.joda.time.LocalTime localTime11 = dateTime8.toLocalTime();
//        long long12 = dateTime8.getMillis();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(localTime11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560639639715L + "'", long12 == 1560639639715L);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        long long10 = skipDateTimeField7.set((-1L), (int) (byte) -1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField7.getAsText(129, locale12);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "129" + "'", str13.equals("129"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("00", false);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("January", true);
        java.io.DataOutput dataOutput8 = null;
        try {
            dateTimeZoneBuilder0.writeTo("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)", dataOutput8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology8 = gregorianChronology7.withUTC();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(19, 82834373, 0, (int) ' ', 166, 725, 1, chronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        try {
            long long8 = gJChronology0.getDateTimeMillis(1, 10, 673, (int) (short) 100, 57600, 0, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
//        org.joda.time.Instant instant8 = new org.joda.time.Instant();
//        org.joda.time.Instant instant9 = new org.joda.time.Instant();
//        boolean boolean10 = instant8.isBefore((org.joda.time.ReadableInstant) instant9);
//        org.joda.time.Instant instant11 = new org.joda.time.Instant();
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
//        boolean boolean14 = instant9.isBefore((org.joda.time.ReadableInstant) instant11);
//        org.joda.time.Chronology chronology15 = instant11.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime16 = null;
//        org.joda.time.ReadableDateTime readableDateTime17 = null;
//        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance(chronology15, readableDateTime16, readableDateTime17);
//        org.joda.time.Partial partial19 = new org.joda.time.Partial(chronology15);
//        int[] intArray27 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
//        int[] intArray29 = skipDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) partial19, (int) (short) 0, intArray27, (int) (short) 1);
//        org.joda.time.Instant instant30 = new org.joda.time.Instant();
//        org.joda.time.Instant instant31 = new org.joda.time.Instant();
//        boolean boolean32 = instant30.isBefore((org.joda.time.ReadableInstant) instant31);
//        org.joda.time.Instant instant33 = new org.joda.time.Instant();
//        org.joda.time.Instant instant34 = new org.joda.time.Instant();
//        boolean boolean35 = instant33.isBefore((org.joda.time.ReadableInstant) instant34);
//        boolean boolean36 = instant31.isBefore((org.joda.time.ReadableInstant) instant33);
//        org.joda.time.Chronology chronology37 = instant33.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime38 = null;
//        org.joda.time.ReadableDateTime readableDateTime39 = null;
//        org.joda.time.chrono.LimitChronology limitChronology40 = org.joda.time.chrono.LimitChronology.getInstance(chronology37, readableDateTime38, readableDateTime39);
//        org.joda.time.Partial partial41 = new org.joda.time.Partial(chronology37);
//        org.joda.time.Instant instant42 = new org.joda.time.Instant();
//        org.joda.time.Instant instant43 = new org.joda.time.Instant();
//        boolean boolean44 = instant42.isBefore((org.joda.time.ReadableInstant) instant43);
//        org.joda.time.Instant instant45 = new org.joda.time.Instant();
//        org.joda.time.Instant instant46 = new org.joda.time.Instant();
//        boolean boolean47 = instant45.isBefore((org.joda.time.ReadableInstant) instant46);
//        boolean boolean48 = instant43.isBefore((org.joda.time.ReadableInstant) instant45);
//        org.joda.time.Chronology chronology49 = instant45.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime50 = null;
//        org.joda.time.ReadableDateTime readableDateTime51 = null;
//        org.joda.time.chrono.LimitChronology limitChronology52 = org.joda.time.chrono.LimitChronology.getInstance(chronology49, readableDateTime50, readableDateTime51);
//        org.joda.time.Partial partial53 = new org.joda.time.Partial(chronology49);
//        org.joda.time.Instant instant54 = new org.joda.time.Instant();
//        org.joda.time.Instant instant55 = new org.joda.time.Instant();
//        boolean boolean56 = instant54.isBefore((org.joda.time.ReadableInstant) instant55);
//        org.joda.time.Instant instant57 = new org.joda.time.Instant();
//        org.joda.time.Instant instant58 = new org.joda.time.Instant();
//        boolean boolean59 = instant57.isBefore((org.joda.time.ReadableInstant) instant58);
//        boolean boolean60 = instant55.isBefore((org.joda.time.ReadableInstant) instant57);
//        org.joda.time.Chronology chronology61 = instant57.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime62 = null;
//        org.joda.time.ReadableDateTime readableDateTime63 = null;
//        org.joda.time.chrono.LimitChronology limitChronology64 = org.joda.time.chrono.LimitChronology.getInstance(chronology61, readableDateTime62, readableDateTime63);
//        org.joda.time.Partial partial65 = new org.joda.time.Partial(chronology61);
//        boolean boolean66 = partial53.isMatch((org.joda.time.ReadablePartial) partial65);
//        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone68);
//        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.clockhourOfHalfday();
//        org.joda.time.Partial partial71 = partial65.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology69);
//        boolean boolean72 = partial41.isMatch((org.joda.time.ReadablePartial) partial65);
//        int[] intArray75 = new int[] { (byte) -1 };
//        int[] intArray77 = skipDateTimeField7.add((org.joda.time.ReadablePartial) partial41, (int) (byte) 100, intArray75, (int) (byte) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType78 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, dateTimeFieldType78, 59);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(limitChronology18);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertNotNull(intArray29);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(limitChronology40);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(limitChronology52);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertNotNull(chronology61);
//        org.junit.Assert.assertNotNull(limitChronology64);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertNotNull(iSOChronology69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(partial71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
//        org.junit.Assert.assertNotNull(intArray75);
//        org.junit.Assert.assertNotNull(intArray77);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = dateTimeZone5.isLocalDateTimeGap(localDateTime7);
        java.lang.String str10 = dateTimeZone5.getName((long) '#');
        int int12 = dateTimeZone5.getOffsetFromLocal((long) 10);
        java.util.Locale locale14 = null;
        java.lang.String str15 = dateTimeZone5.getShortName((long) 10, locale14);
        org.joda.time.Interval interval16 = localDate1.toInterval(dateTimeZone5);
        int int17 = localDate1.size();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.052" + "'", str10.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.052" + "'", str15.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(interval16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 673);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 673 + "'", int1 == 673);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("1970-01-01");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1970-01-01/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray1 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType0 };
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField6 = iSOChronology5.minutes();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField7, (int) (byte) 1);
//        org.joda.time.Instant instant10 = new org.joda.time.Instant();
//        org.joda.time.Instant instant11 = new org.joda.time.Instant();
//        boolean boolean12 = instant10.isBefore((org.joda.time.ReadableInstant) instant11);
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        org.joda.time.Instant instant14 = new org.joda.time.Instant();
//        boolean boolean15 = instant13.isBefore((org.joda.time.ReadableInstant) instant14);
//        boolean boolean16 = instant11.isBefore((org.joda.time.ReadableInstant) instant13);
//        org.joda.time.Chronology chronology17 = instant13.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime18 = null;
//        org.joda.time.ReadableDateTime readableDateTime19 = null;
//        org.joda.time.chrono.LimitChronology limitChronology20 = org.joda.time.chrono.LimitChronology.getInstance(chronology17, readableDateTime18, readableDateTime19);
//        org.joda.time.Partial partial21 = new org.joda.time.Partial(chronology17);
//        int[] intArray29 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
//        int[] intArray31 = skipDateTimeField9.addWrapPartial((org.joda.time.ReadablePartial) partial21, (int) (short) 0, intArray29, (int) (short) 1);
//        org.joda.time.Instant instant32 = new org.joda.time.Instant();
//        org.joda.time.Instant instant33 = new org.joda.time.Instant();
//        boolean boolean34 = instant32.isBefore((org.joda.time.ReadableInstant) instant33);
//        org.joda.time.Instant instant35 = new org.joda.time.Instant();
//        org.joda.time.Instant instant36 = new org.joda.time.Instant();
//        boolean boolean37 = instant35.isBefore((org.joda.time.ReadableInstant) instant36);
//        boolean boolean38 = instant33.isBefore((org.joda.time.ReadableInstant) instant35);
//        org.joda.time.Chronology chronology39 = instant35.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime40 = null;
//        org.joda.time.ReadableDateTime readableDateTime41 = null;
//        org.joda.time.chrono.LimitChronology limitChronology42 = org.joda.time.chrono.LimitChronology.getInstance(chronology39, readableDateTime40, readableDateTime41);
//        org.joda.time.Partial partial43 = new org.joda.time.Partial(chronology39);
//        org.joda.time.Instant instant44 = new org.joda.time.Instant();
//        org.joda.time.Instant instant45 = new org.joda.time.Instant();
//        boolean boolean46 = instant44.isBefore((org.joda.time.ReadableInstant) instant45);
//        org.joda.time.Instant instant47 = new org.joda.time.Instant();
//        org.joda.time.Instant instant48 = new org.joda.time.Instant();
//        boolean boolean49 = instant47.isBefore((org.joda.time.ReadableInstant) instant48);
//        boolean boolean50 = instant45.isBefore((org.joda.time.ReadableInstant) instant47);
//        org.joda.time.Chronology chronology51 = instant47.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime52 = null;
//        org.joda.time.ReadableDateTime readableDateTime53 = null;
//        org.joda.time.chrono.LimitChronology limitChronology54 = org.joda.time.chrono.LimitChronology.getInstance(chronology51, readableDateTime52, readableDateTime53);
//        org.joda.time.Partial partial55 = new org.joda.time.Partial(chronology51);
//        org.joda.time.Instant instant56 = new org.joda.time.Instant();
//        org.joda.time.Instant instant57 = new org.joda.time.Instant();
//        boolean boolean58 = instant56.isBefore((org.joda.time.ReadableInstant) instant57);
//        org.joda.time.Instant instant59 = new org.joda.time.Instant();
//        org.joda.time.Instant instant60 = new org.joda.time.Instant();
//        boolean boolean61 = instant59.isBefore((org.joda.time.ReadableInstant) instant60);
//        boolean boolean62 = instant57.isBefore((org.joda.time.ReadableInstant) instant59);
//        org.joda.time.Chronology chronology63 = instant59.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime64 = null;
//        org.joda.time.ReadableDateTime readableDateTime65 = null;
//        org.joda.time.chrono.LimitChronology limitChronology66 = org.joda.time.chrono.LimitChronology.getInstance(chronology63, readableDateTime64, readableDateTime65);
//        org.joda.time.Partial partial67 = new org.joda.time.Partial(chronology63);
//        boolean boolean68 = partial55.isMatch((org.joda.time.ReadablePartial) partial67);
//        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology71 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone70);
//        org.joda.time.DateTimeField dateTimeField72 = iSOChronology71.clockhourOfHalfday();
//        org.joda.time.Partial partial73 = partial67.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology71);
//        boolean boolean74 = partial43.isMatch((org.joda.time.ReadablePartial) partial67);
//        int[] intArray77 = new int[] { (byte) -1 };
//        int[] intArray79 = skipDateTimeField9.add((org.joda.time.ReadablePartial) partial43, (int) (byte) 100, intArray77, (int) (byte) 0);
//        try {
//            org.joda.time.Partial partial80 = new org.joda.time.Partial(dateTimeFieldTypeArray1, intArray77);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not contain null: index 0");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(limitChronology20);
//        org.junit.Assert.assertNotNull(intArray29);
//        org.junit.Assert.assertNotNull(intArray31);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(chronology39);
//        org.junit.Assert.assertNotNull(limitChronology42);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(chronology51);
//        org.junit.Assert.assertNotNull(limitChronology54);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(chronology63);
//        org.junit.Assert.assertNotNull(limitChronology66);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone70);
//        org.junit.Assert.assertNotNull(iSOChronology71);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertNotNull(partial73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
//        org.junit.Assert.assertNotNull(intArray77);
//        org.junit.Assert.assertNotNull(intArray79);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 680);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210808008000000L) + "'", long1 == (-210808008000000L));
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds((int) (byte) 1);
//        org.joda.time.DateTime.Property property12 = dateTime8.secondOfDay();
//        java.util.Locale locale14 = null;
//        try {
//            org.joda.time.DateTime dateTime15 = property12.setCopy("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)", locale14);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)\" for secondOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        int int15 = localDate13.getDayOfMonth();
        try {
            int int17 = localDate13.getValue(166);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 166");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        long long10 = skipDateTimeField7.set((-1L), (int) (byte) -1);
        org.joda.time.DateTimeField dateTimeField11 = skipDateTimeField7.getWrappedField();
        long long14 = skipDateTimeField7.getDifferenceAsLong((long) 35, (long) 680);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.LocalDateTime localDateTime19 = null;
        boolean boolean20 = dateTimeZone17.isLocalDateTimeGap(localDateTime19);
        java.lang.String str22 = dateTimeZone17.getName((long) '#');
        int int24 = dateTimeZone17.getOffsetFromLocal((long) 10);
        java.util.Locale locale26 = null;
        java.lang.String str27 = dateTimeZone17.getShortName((long) 10, locale26);
        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate((long) 2, dateTimeZone17);
        org.joda.time.LocalDate.Property property29 = localDate28.weekyear();
        org.joda.time.Instant instant31 = new org.joda.time.Instant();
        org.joda.time.Instant instant32 = new org.joda.time.Instant();
        boolean boolean33 = instant31.isBefore((org.joda.time.ReadableInstant) instant32);
        org.joda.time.Instant instant34 = new org.joda.time.Instant();
        org.joda.time.Instant instant35 = new org.joda.time.Instant();
        boolean boolean36 = instant34.isBefore((org.joda.time.ReadableInstant) instant35);
        boolean boolean37 = instant32.isBefore((org.joda.time.ReadableInstant) instant34);
        org.joda.time.Chronology chronology38 = instant34.getChronology();
        org.joda.time.ReadableDateTime readableDateTime39 = null;
        org.joda.time.ReadableDateTime readableDateTime40 = null;
        org.joda.time.chrono.LimitChronology limitChronology41 = org.joda.time.chrono.LimitChronology.getInstance(chronology38, readableDateTime39, readableDateTime40);
        org.joda.time.Partial partial42 = new org.joda.time.Partial(chronology38);
        org.joda.time.Instant instant43 = new org.joda.time.Instant();
        org.joda.time.Instant instant44 = new org.joda.time.Instant();
        boolean boolean45 = instant43.isBefore((org.joda.time.ReadableInstant) instant44);
        org.joda.time.Instant instant46 = new org.joda.time.Instant();
        org.joda.time.Instant instant47 = new org.joda.time.Instant();
        boolean boolean48 = instant46.isBefore((org.joda.time.ReadableInstant) instant47);
        boolean boolean49 = instant44.isBefore((org.joda.time.ReadableInstant) instant46);
        org.joda.time.Chronology chronology50 = instant46.getChronology();
        org.joda.time.ReadableDateTime readableDateTime51 = null;
        org.joda.time.ReadableDateTime readableDateTime52 = null;
        org.joda.time.chrono.LimitChronology limitChronology53 = org.joda.time.chrono.LimitChronology.getInstance(chronology50, readableDateTime51, readableDateTime52);
        org.joda.time.Partial partial54 = new org.joda.time.Partial(chronology50);
        boolean boolean55 = partial42.isMatch((org.joda.time.ReadablePartial) partial54);
        int[] intArray56 = partial54.getValues();
        java.util.Locale locale58 = null;
        try {
            int[] intArray59 = skipDateTimeField7.set((org.joda.time.ReadablePartial) localDate28, (int) (short) 1, intArray56, "-55630-01-01", locale58);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"-55630-01-01\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00:00.052" + "'", str22.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00:00.052" + "'", str27.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(limitChronology41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(limitChronology53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(intArray56);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        int int10 = dateTime8.getEra();
//        int int11 = dateTime8.getDayOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
//        org.joda.time.DateTime.Property property13 = dateTime8.dayOfWeek();
//        int int14 = dateTime8.getEra();
//        org.joda.time.DateTime dateTime16 = dateTime8.minusMillis(0);
//        java.util.Locale locale18 = null;
//        try {
//            java.lang.String str19 = dateTime8.toString("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)", locale18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 166 + "'", int11 == 166);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime dateTime10 = dateTime8.plusHours(10);
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime8.withDayOfMonth((int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter0.printTo(writer3, (long) 129);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        java.lang.String str12 = cachedDateTimeZone9.getNameKey((long) 35);
        long long15 = cachedDateTimeZone9.convertLocalToUTC((long) (byte) 10, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-42L) + "'", long15 == (-42L));
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        int int10 = dateTime8.getEra();
//        int int11 = dateTime8.getDayOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
//        int int13 = dateTime8.getMillisOfDay();
//        org.joda.time.DateTime.Property property14 = dateTime8.yearOfCentury();
//        boolean boolean15 = dateTime8.isBeforeNow();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 166 + "'", int11 == 166);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 82841045 + "'", int13 == 82841045);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.LocalDateTime localDateTime15 = null;
//        boolean boolean16 = dateTimeZone13.isLocalDateTimeGap(localDateTime15);
//        java.lang.String str18 = dateTimeZone13.getName((long) '#');
//        int int20 = dateTimeZone13.getOffsetFromLocal((long) 10);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone13.getShortName((long) 10, locale22);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) 2, dateTimeZone13);
//        org.joda.time.LocalDate.Property property25 = localDate24.weekyear();
//        long long27 = limitChronology10.set((org.joda.time.ReadablePartial) localDate24, 43200000L);
//        org.joda.time.LocalDate localDate29 = localDate24.plusWeeks(1);
//        org.joda.time.LocalDate localDate31 = localDate24.withDayOfMonth(19);
//        try {
//            int int33 = localDate24.getValue(673);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 673");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.052" + "'", str18.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43200000L + "'", long27 == 43200000L);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(localDate31);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.weekyear();
        java.lang.String str16 = gJChronology14.toString();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = iSOChronology19.minutes();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.year();
        boolean boolean22 = gJChronology14.equals((java.lang.Object) iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "GJChronology[+00:00:00.052]" + "'", str16.equals("GJChronology[+00:00:00.052]"));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronology();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter2.withLocale(locale4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(gregorianChronology13);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.DateMidnight dateMidnight2 = localDate1.toDateMidnight();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.LocalDate localDate4 = localDate1.plus(readablePeriod3);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(localDate4);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.LocalDateTime localDateTime3 = null;
//        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
//        java.lang.String str6 = dateTimeZone1.getName((long) '#');
//        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
//        org.joda.time.Instant instant11 = new org.joda.time.Instant();
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
//        org.joda.time.Instant instant14 = new org.joda.time.Instant();
//        org.joda.time.Instant instant15 = new org.joda.time.Instant();
//        boolean boolean16 = instant14.isBefore((org.joda.time.ReadableInstant) instant15);
//        boolean boolean17 = instant12.isBefore((org.joda.time.ReadableInstant) instant14);
//        org.joda.time.Chronology chronology18 = instant14.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime19 = null;
//        org.joda.time.ReadableDateTime readableDateTime20 = null;
//        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance(chronology18, readableDateTime19, readableDateTime20);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
//        org.joda.time.LocalDateTime localDateTime26 = null;
//        boolean boolean27 = dateTimeZone24.isLocalDateTimeGap(localDateTime26);
//        java.lang.String str29 = dateTimeZone24.getName((long) '#');
//        int int31 = dateTimeZone24.getOffsetFromLocal((long) 10);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = dateTimeZone24.getShortName((long) 10, locale33);
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) 2, dateTimeZone24);
//        org.joda.time.LocalDate.Property property36 = localDate35.weekyear();
//        long long38 = limitChronology21.set((org.joda.time.ReadablePartial) localDate35, 43200000L);
//        org.joda.time.LocalDate localDate40 = localDate35.plusWeeks(1);
//        boolean boolean41 = copticChronology10.equals((java.lang.Object) localDate35);
//        try {
//            org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((java.lang.Object) copticChronology10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.CopticChronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(limitChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+00:00:00.052" + "'", str29.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 52 + "'", int31 == 52);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "+00:00:00.052" + "'", str34.equals("+00:00:00.052"));
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43200000L + "'", long38 == 43200000L);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DurationField durationField11 = copticChronology10.millis();
        try {
            long long16 = copticChronology10.getDateTimeMillis((int) (byte) 100, 725, (int) (short) -1, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 725 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDate();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeFormatter3);
        java.lang.StringBuffer stringBuffer5 = null;
        try {
            dateTimeFormatter3.printTo(stringBuffer5, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
//        org.joda.time.Instant instant8 = new org.joda.time.Instant();
//        org.joda.time.Instant instant9 = new org.joda.time.Instant();
//        boolean boolean10 = instant8.isBefore((org.joda.time.ReadableInstant) instant9);
//        org.joda.time.Instant instant11 = new org.joda.time.Instant();
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
//        boolean boolean14 = instant9.isBefore((org.joda.time.ReadableInstant) instant11);
//        org.joda.time.Chronology chronology15 = instant11.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime16 = null;
//        org.joda.time.ReadableDateTime readableDateTime17 = null;
//        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance(chronology15, readableDateTime16, readableDateTime17);
//        org.joda.time.Partial partial19 = new org.joda.time.Partial(chronology15);
//        int[] intArray27 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
//        int[] intArray29 = skipDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) partial19, (int) (short) 0, intArray27, (int) (short) 1);
//        int int32 = skipDateTimeField7.getDifference((long) 52, (long) (byte) 100);
//        try {
//            long long35 = skipDateTimeField7.set(0L, 57600);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for minuteOfHour must be in the range [-1,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(limitChronology18);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertNotNull(intArray29);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 432000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        boolean boolean4 = instant1.isSupported(dateTimeFieldType3);
//        org.joda.time.Instant instant6 = instant1.minus(2440588L);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property9 = localDate8.monthOfYear();
//        org.joda.time.LocalDate.Property property10 = localDate8.weekyear();
//        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
//        int int15 = property10.getDifference((org.joda.time.ReadableInstant) instant12);
//        boolean boolean16 = instant6.isEqual((org.joda.time.ReadableInstant) instant12);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-49) + "'", int15 == (-49));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) 100);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, (long) 82834373);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(1560639635957L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2458650L + "'", long1 == 2458650L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField4 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(82841045);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 82841045");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
//        org.joda.time.Instant instant15 = new org.joda.time.Instant();
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
//        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
//        org.joda.time.Chronology chronology19 = instant15.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime20 = null;
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
//        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
//        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = partial23.getFormatter();
//        org.joda.time.Partial partial26 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial23);
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.Partial partial28 = partial26.plus(readablePeriod27);
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
//        org.joda.time.LocalDateTime localDateTime33 = null;
//        boolean boolean34 = dateTimeZone31.isLocalDateTimeGap(localDateTime33);
//        java.lang.String str36 = dateTimeZone31.getName((long) '#');
//        int int38 = dateTimeZone31.getOffsetFromLocal((long) 10);
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = dateTimeZone31.getShortName((long) 10, locale40);
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((long) 2, dateTimeZone31);
//        try {
//            org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate((java.lang.Object) partial26, dateTimeZone31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(limitChronology22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(partial28);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "+00:00:00.052" + "'", str36.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 52 + "'", int38 == 52);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "+00:00:00.052" + "'", str41.equals("+00:00:00.052"));
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 52, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
//        org.joda.time.Instant instant15 = new org.joda.time.Instant();
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
//        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
//        org.joda.time.Chronology chronology19 = instant15.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime20 = null;
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
//        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
//        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.clockhourOfHalfday();
//        org.joda.time.Partial partial29 = partial23.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology27);
//        long long35 = iSOChronology27.getDateTimeMillis((long) 19, 2, 1, (int) '4', 100);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(limitChronology22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(partial29);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 7312048L + "'", long35 == 7312048L);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        long long15 = skipUndoDateTimeField10.add(0L, (long) (short) 10);
        int int18 = skipUndoDateTimeField10.getDifference((long) (byte) -1, 576000100L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 432000000L + "'", long15 == 432000000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-13) + "'", int18 == (-13));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 23, 0, 82834373);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.Instant instant9 = new org.joda.time.Instant();
//        org.joda.time.Instant instant10 = new org.joda.time.Instant();
//        boolean boolean11 = instant9.isBefore((org.joda.time.ReadableInstant) instant10);
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
//        boolean boolean15 = instant10.isBefore((org.joda.time.ReadableInstant) instant12);
//        org.joda.time.Chronology chronology16 = instant12.getChronology();
//        org.joda.time.DateTime dateTime17 = instant12.toDateTimeISO();
//        org.joda.time.DateTime.Property property18 = dateTime17.year();
//        int int19 = dateTime17.getEra();
//        int int20 = dateTime17.getDayOfYear();
//        org.joda.time.DateTime.Property property21 = dateTime17.yearOfEra();
//        boolean boolean22 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        try {
//            org.joda.time.DateTime dateTime24 = dateTime17.withSecondOfMinute((-49));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -49 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 166 + "'", int20 == 166);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.DurationField durationField5 = property3.getRangeDurationField();
        org.joda.time.LocalDate localDate7 = property3.addToCopy((int) '4');
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("LimitChronology[ISOChronology[UTC], NoLimit, NoLimit]");
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = julianChronology0.withZone(dateTimeZone2);
        try {
            long long9 = julianChronology0.getDateTimeMillis(1, (int) '4', 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
        org.joda.time.Instant instant14 = new org.joda.time.Instant();
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        boolean boolean16 = instant14.isBefore((org.joda.time.ReadableInstant) instant15);
        boolean boolean17 = instant12.isBefore((org.joda.time.ReadableInstant) instant14);
        org.joda.time.Chronology chronology18 = instant14.getChronology();
        org.joda.time.ReadableDateTime readableDateTime19 = null;
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance(chronology18, readableDateTime19, readableDateTime20);
        org.joda.time.Partial partial22 = new org.joda.time.Partial(chronology18);
        org.joda.time.Instant instant23 = new org.joda.time.Instant();
        org.joda.time.Instant instant24 = new org.joda.time.Instant();
        boolean boolean25 = instant23.isBefore((org.joda.time.ReadableInstant) instant24);
        org.joda.time.Instant instant26 = new org.joda.time.Instant();
        org.joda.time.Instant instant27 = new org.joda.time.Instant();
        boolean boolean28 = instant26.isBefore((org.joda.time.ReadableInstant) instant27);
        boolean boolean29 = instant24.isBefore((org.joda.time.ReadableInstant) instant26);
        org.joda.time.Chronology chronology30 = instant26.getChronology();
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.ReadableDateTime readableDateTime32 = null;
        org.joda.time.chrono.LimitChronology limitChronology33 = org.joda.time.chrono.LimitChronology.getInstance(chronology30, readableDateTime31, readableDateTime32);
        org.joda.time.Partial partial34 = new org.joda.time.Partial(chronology30);
        org.joda.time.Instant instant35 = new org.joda.time.Instant();
        org.joda.time.Instant instant36 = new org.joda.time.Instant();
        boolean boolean37 = instant35.isBefore((org.joda.time.ReadableInstant) instant36);
        org.joda.time.Instant instant38 = new org.joda.time.Instant();
        org.joda.time.Instant instant39 = new org.joda.time.Instant();
        boolean boolean40 = instant38.isBefore((org.joda.time.ReadableInstant) instant39);
        boolean boolean41 = instant36.isBefore((org.joda.time.ReadableInstant) instant38);
        org.joda.time.Chronology chronology42 = instant38.getChronology();
        org.joda.time.ReadableDateTime readableDateTime43 = null;
        org.joda.time.ReadableDateTime readableDateTime44 = null;
        org.joda.time.chrono.LimitChronology limitChronology45 = org.joda.time.chrono.LimitChronology.getInstance(chronology42, readableDateTime43, readableDateTime44);
        org.joda.time.Partial partial46 = new org.joda.time.Partial(chronology42);
        boolean boolean47 = partial34.isMatch((org.joda.time.ReadablePartial) partial46);
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology50.clockhourOfHalfday();
        org.joda.time.Partial partial52 = partial46.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology50);
        boolean boolean53 = partial22.isMatch((org.joda.time.ReadablePartial) partial46);
        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone57);
        org.joda.time.DurationField durationField59 = iSOChronology58.minutes();
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology58.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField62 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology55, dateTimeField60, (int) (byte) 1);
        org.joda.time.Instant instant63 = new org.joda.time.Instant();
        org.joda.time.Instant instant64 = new org.joda.time.Instant();
        boolean boolean65 = instant63.isBefore((org.joda.time.ReadableInstant) instant64);
        org.joda.time.Instant instant66 = new org.joda.time.Instant();
        org.joda.time.Instant instant67 = new org.joda.time.Instant();
        boolean boolean68 = instant66.isBefore((org.joda.time.ReadableInstant) instant67);
        boolean boolean69 = instant64.isBefore((org.joda.time.ReadableInstant) instant66);
        org.joda.time.Chronology chronology70 = instant66.getChronology();
        org.joda.time.ReadableDateTime readableDateTime71 = null;
        org.joda.time.ReadableDateTime readableDateTime72 = null;
        org.joda.time.chrono.LimitChronology limitChronology73 = org.joda.time.chrono.LimitChronology.getInstance(chronology70, readableDateTime71, readableDateTime72);
        org.joda.time.Partial partial74 = new org.joda.time.Partial(chronology70);
        int[] intArray82 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
        int[] intArray84 = skipDateTimeField62.addWrapPartial((org.joda.time.ReadablePartial) partial74, (int) (short) 0, intArray82, (int) (short) 1);
        try {
            int[] intArray86 = skipUndoDateTimeField10.addWrapPartial((org.joda.time.ReadablePartial) partial46, 0, intArray84, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for halfdayOfDay must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(limitChronology21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(limitChronology33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(limitChronology45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(partial52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(iSOChronology55);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(chronology70);
        org.junit.Assert.assertNotNull(limitChronology73);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(intArray84);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.monthOfYear();
        boolean boolean3 = instant0.equals((java.lang.Object) dateTimeField2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant0.plus(readableDuration4);
        org.joda.time.Instant instant7 = instant0.withMillis((long) 680);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(durationFieldType4);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMinutes((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plus((long) (byte) 0);
        int int10 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = dateTime7.minusHours(19);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 84480052 + "'", int10 == 84480052);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = iSOChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology5, dateTimeField11, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology5.yearOfEra();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField14, (int) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.LocalDateTime localDateTime15 = null;
        boolean boolean16 = dateTimeZone13.isLocalDateTimeGap(localDateTime15);
        java.lang.String str18 = dateTimeZone13.getName((long) '#');
        int int20 = dateTimeZone13.getOffsetFromLocal((long) 10);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone13.getShortName((long) 10, locale22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) 2, dateTimeZone13);
        org.joda.time.LocalDate.Property property25 = localDate24.weekyear();
        long long27 = limitChronology10.set((org.joda.time.ReadablePartial) localDate24, 43200000L);
        org.joda.time.LocalDate localDate29 = localDate24.plusWeeks(1);
        try {
            int int31 = localDate29.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 32");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.052" + "'", str18.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43200000L + "'", long27 == 43200000L);
        org.junit.Assert.assertNotNull(localDate29);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Chronology chronology11 = limitChronology10.withUTC();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        try {
            org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((java.lang.Object) chronology11, (org.joda.time.Chronology) iSOChronology12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.LimitChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(iSOChronology12);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str5 = jodaTimePermission4.getName();
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.Instant instant7 = new org.joda.time.Instant();
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        boolean boolean9 = instant7.isBefore((org.joda.time.ReadableInstant) instant8);
        org.joda.time.Instant instant10 = new org.joda.time.Instant();
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        boolean boolean12 = instant10.isBefore((org.joda.time.ReadableInstant) instant11);
        boolean boolean13 = instant8.isBefore((org.joda.time.ReadableInstant) instant10);
        org.joda.time.Chronology chronology14 = instant10.getChronology();
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance(chronology14, readableDateTime15, readableDateTime16);
        org.joda.time.Partial partial18 = new org.joda.time.Partial(chronology14);
        org.joda.time.Instant instant19 = new org.joda.time.Instant();
        org.joda.time.Instant instant20 = new org.joda.time.Instant();
        boolean boolean21 = instant19.isBefore((org.joda.time.ReadableInstant) instant20);
        org.joda.time.Instant instant22 = new org.joda.time.Instant();
        org.joda.time.Instant instant23 = new org.joda.time.Instant();
        boolean boolean24 = instant22.isBefore((org.joda.time.ReadableInstant) instant23);
        boolean boolean25 = instant20.isBefore((org.joda.time.ReadableInstant) instant22);
        org.joda.time.Chronology chronology26 = instant22.getChronology();
        org.joda.time.ReadableDateTime readableDateTime27 = null;
        org.joda.time.ReadableDateTime readableDateTime28 = null;
        org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance(chronology26, readableDateTime27, readableDateTime28);
        org.joda.time.Partial partial30 = new org.joda.time.Partial(chronology26);
        boolean boolean31 = partial18.isMatch((org.joda.time.ReadablePartial) partial30);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.clockhourOfHalfday();
        org.joda.time.Partial partial36 = partial30.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology34);
        boolean boolean37 = jodaTimePermission4.equals((java.lang.Object) partial30);
        org.joda.time.Instant instant38 = new org.joda.time.Instant();
        org.joda.time.Instant instant39 = new org.joda.time.Instant();
        boolean boolean40 = instant38.isBefore((org.joda.time.ReadableInstant) instant39);
        org.joda.time.Instant instant41 = new org.joda.time.Instant();
        org.joda.time.Instant instant42 = new org.joda.time.Instant();
        boolean boolean43 = instant41.isBefore((org.joda.time.ReadableInstant) instant42);
        boolean boolean44 = instant39.isBefore((org.joda.time.ReadableInstant) instant41);
        org.joda.time.Chronology chronology45 = instant41.getChronology();
        org.joda.time.ReadableDateTime readableDateTime46 = null;
        org.joda.time.ReadableDateTime readableDateTime47 = null;
        org.joda.time.chrono.LimitChronology limitChronology48 = org.joda.time.chrono.LimitChronology.getInstance(chronology45, readableDateTime46, readableDateTime47);
        org.joda.time.Partial partial49 = new org.joda.time.Partial(chronology45);
        org.joda.time.Instant instant50 = new org.joda.time.Instant();
        org.joda.time.Instant instant51 = new org.joda.time.Instant();
        boolean boolean52 = instant50.isBefore((org.joda.time.ReadableInstant) instant51);
        org.joda.time.Instant instant53 = new org.joda.time.Instant();
        org.joda.time.Instant instant54 = new org.joda.time.Instant();
        boolean boolean55 = instant53.isBefore((org.joda.time.ReadableInstant) instant54);
        boolean boolean56 = instant51.isBefore((org.joda.time.ReadableInstant) instant53);
        org.joda.time.Chronology chronology57 = instant53.getChronology();
        org.joda.time.ReadableDateTime readableDateTime58 = null;
        org.joda.time.ReadableDateTime readableDateTime59 = null;
        org.joda.time.chrono.LimitChronology limitChronology60 = org.joda.time.chrono.LimitChronology.getInstance(chronology57, readableDateTime58, readableDateTime59);
        org.joda.time.Partial partial61 = new org.joda.time.Partial(chronology57);
        boolean boolean62 = partial49.isMatch((org.joda.time.ReadablePartial) partial61);
        org.joda.time.ReadablePeriod readablePeriod63 = null;
        org.joda.time.Partial partial64 = partial61.minus(readablePeriod63);
        boolean boolean65 = partial30.isMatch((org.joda.time.ReadablePartial) partial61);
        org.joda.time.DurationFieldType durationFieldType66 = null;
        try {
            org.joda.time.Partial partial68 = partial61.withFieldAddWrapped(durationFieldType66, 82843301);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(limitChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(limitChronology48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(limitChronology60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(partial64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = iSOChronology5.minutes();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.minuteOfHour();
        try {
            org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(680, (-55630), 0, (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -55630 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNull(dateTimeZone9);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.eras();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis(2, 0, 673, 82841);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        try {
            org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.parse("+00:00:00.052", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00:00.052\" is malformed at \":00:00.052\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(673, 100, 59, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        try {
            org.joda.time.MutableDateTime mutableDateTime4 = dateTimeFormatter2.parseMutableDateTime("[]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"[]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.Partial partial26 = partial23.minus(readablePeriod25);
        try {
            java.lang.String str28 = partial26.toString("January");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(partial26);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str5 = jodaTimePermission4.getName();
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.Instant instant7 = new org.joda.time.Instant();
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        boolean boolean9 = instant7.isBefore((org.joda.time.ReadableInstant) instant8);
        org.joda.time.Instant instant10 = new org.joda.time.Instant();
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        boolean boolean12 = instant10.isBefore((org.joda.time.ReadableInstant) instant11);
        boolean boolean13 = instant8.isBefore((org.joda.time.ReadableInstant) instant10);
        org.joda.time.Chronology chronology14 = instant10.getChronology();
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance(chronology14, readableDateTime15, readableDateTime16);
        org.joda.time.Partial partial18 = new org.joda.time.Partial(chronology14);
        org.joda.time.Instant instant19 = new org.joda.time.Instant();
        org.joda.time.Instant instant20 = new org.joda.time.Instant();
        boolean boolean21 = instant19.isBefore((org.joda.time.ReadableInstant) instant20);
        org.joda.time.Instant instant22 = new org.joda.time.Instant();
        org.joda.time.Instant instant23 = new org.joda.time.Instant();
        boolean boolean24 = instant22.isBefore((org.joda.time.ReadableInstant) instant23);
        boolean boolean25 = instant20.isBefore((org.joda.time.ReadableInstant) instant22);
        org.joda.time.Chronology chronology26 = instant22.getChronology();
        org.joda.time.ReadableDateTime readableDateTime27 = null;
        org.joda.time.ReadableDateTime readableDateTime28 = null;
        org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance(chronology26, readableDateTime27, readableDateTime28);
        org.joda.time.Partial partial30 = new org.joda.time.Partial(chronology26);
        boolean boolean31 = partial18.isMatch((org.joda.time.ReadablePartial) partial30);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.clockhourOfHalfday();
        org.joda.time.Partial partial36 = partial30.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology34);
        boolean boolean37 = jodaTimePermission4.equals((java.lang.Object) partial30);
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone40);
        org.joda.time.DurationField durationField42 = iSOChronology41.minutes();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology41.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology38, dateTimeField43, (int) (byte) 1);
        org.joda.time.Instant instant46 = new org.joda.time.Instant();
        org.joda.time.Instant instant47 = new org.joda.time.Instant();
        boolean boolean48 = instant46.isBefore((org.joda.time.ReadableInstant) instant47);
        org.joda.time.Instant instant49 = new org.joda.time.Instant();
        org.joda.time.Instant instant50 = new org.joda.time.Instant();
        boolean boolean51 = instant49.isBefore((org.joda.time.ReadableInstant) instant50);
        boolean boolean52 = instant47.isBefore((org.joda.time.ReadableInstant) instant49);
        org.joda.time.Chronology chronology53 = instant49.getChronology();
        org.joda.time.ReadableDateTime readableDateTime54 = null;
        org.joda.time.ReadableDateTime readableDateTime55 = null;
        org.joda.time.chrono.LimitChronology limitChronology56 = org.joda.time.chrono.LimitChronology.getInstance(chronology53, readableDateTime54, readableDateTime55);
        org.joda.time.Partial partial57 = new org.joda.time.Partial(chronology53);
        int[] intArray65 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
        int[] intArray67 = skipDateTimeField45.addWrapPartial((org.joda.time.ReadablePartial) partial57, (int) (short) 0, intArray65, (int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod68 = null;
        org.joda.time.Partial partial69 = partial57.plus(readablePeriod68);
        boolean boolean70 = partial30.isAfter((org.joda.time.ReadablePartial) partial57);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(limitChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(limitChronology56);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(partial69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.LocalDate localDate0 = org.joda.time.LocalDate.now();
        org.junit.Assert.assertNotNull(localDate0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (short) 0, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DurationField durationField4 = iSOChronology2.years();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray7 = iSOChronology2.get(readablePeriod5, (long) 129);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, 105433401600010L, 10);
        try {
            long long9 = gregorianChronology0.getDateTimeMillis((-13), 23, 1970, (-55630));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -55630 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 105433401600010L + "'", long4 == 105433401600010L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) 100, (java.lang.Number) 57600010, (java.lang.Number) 100L);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        illegalFieldValueException4.prependMessage("LimitChronology[ISOChronology[UTC], NoLimit, NoLimit]");
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 100 + "'", number6.equals((byte) 100));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType9, 129, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        illegalFieldValueException2.prependMessage("AM");
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(53L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.io.Writer writer2 = null;
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        org.joda.time.Instant instant7 = new org.joda.time.Instant();
        boolean boolean8 = instant6.isBefore((org.joda.time.ReadableInstant) instant7);
        boolean boolean9 = instant4.isBefore((org.joda.time.ReadableInstant) instant6);
        org.joda.time.Chronology chronology10 = instant6.getChronology();
        org.joda.time.DateTime dateTime11 = instant6.toDateTimeISO();
        org.joda.time.DateTime.Property property12 = dateTime11.year();
        int int13 = dateTime11.getEra();
        int int14 = dateTime11.getDayOfYear();
        org.joda.time.DateTime.Property property15 = dateTime11.yearOfEra();
        int int16 = dateTime11.getMillisOfDay();
        org.joda.time.DateTime.Property property17 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime19 = dateTime11.plusMinutes((int) '#');
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) dateTime19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 105 + "'", int16 == 105);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.year();
        org.joda.time.DurationField durationField3 = property2.getRangeDurationField();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNull(durationField3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        java.lang.Object obj7 = null;
        boolean boolean8 = property6.equals(obj7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) '#', 70, 129);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
        org.joda.time.Instant instant14 = new org.joda.time.Instant();
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        boolean boolean16 = instant14.isBefore((org.joda.time.ReadableInstant) instant15);
        boolean boolean17 = instant12.isBefore((org.joda.time.ReadableInstant) instant14);
        org.joda.time.Chronology chronology18 = instant14.getChronology();
        org.joda.time.ReadableDateTime readableDateTime19 = null;
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance(chronology18, readableDateTime19, readableDateTime20);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone24.isLocalDateTimeGap(localDateTime26);
        java.lang.String str29 = dateTimeZone24.getName((long) '#');
        int int31 = dateTimeZone24.getOffsetFromLocal((long) 10);
        java.util.Locale locale33 = null;
        java.lang.String str34 = dateTimeZone24.getShortName((long) 10, locale33);
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) 2, dateTimeZone24);
        org.joda.time.LocalDate.Property property36 = localDate35.weekyear();
        long long38 = limitChronology21.set((org.joda.time.ReadablePartial) localDate35, 43200000L);
        org.joda.time.LocalDate localDate40 = localDate35.plusWeeks(1);
        boolean boolean41 = copticChronology10.equals((java.lang.Object) localDate35);
        org.joda.time.DateTimeZone dateTimeZone42 = copticChronology10.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(limitChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+00:00:00.052" + "'", str29.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 52 + "'", int31 == 52);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "+00:00:00.052" + "'", str34.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43200000L + "'", long38 == 43200000L);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dateTimeZone42);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) 100, (java.lang.Number) 57600010, (java.lang.Number) 100L);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDate();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeFormatter3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str7 = jodaTimePermission6.getName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicDate();
        jodaTimePermission6.checkGuard((java.lang.Object) dateTimeFormatter8);
        org.joda.time.JodaTimePermission jodaTimePermission11 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str12 = jodaTimePermission11.getActions();
        boolean boolean13 = jodaTimePermission6.implies((java.security.Permission) jodaTimePermission11);
        boolean boolean14 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission6);
        jodaTimePermission6.checkGuard((java.lang.Object) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, number2, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) '4', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(dateTimeField10, dateTimeFieldType11, 82841726);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology2.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.clockhourOfHalfday();
        org.joda.time.DurationField durationField17 = iSOChronology15.seconds();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology15);
        org.joda.time.DateTime dateTime20 = dateTime18.minusMinutes((int) ' ');
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        boolean boolean22 = iSOChronology2.equals((java.lang.Object) localDateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours(10);
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfDay();
        int int12 = dateTime8.getMillisOfSecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 105 + "'", int12 == 105);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMinutes((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plus((long) (byte) 0);
        int int10 = dateTime7.getCenturyOfEra();
        org.joda.time.DateTime dateTime12 = dateTime7.withEra(0);
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.DateTime dateTime15 = dateTime12.withFieldAdded(durationFieldType13, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        int int14 = delegatedDateTimeField12.getMinimumValue((long) (short) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField12.getAsShortText(0L, locale16);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField12.getRangeDurationField();
        boolean boolean20 = delegatedDateTimeField12.isLeap((long) (byte) -1);
        java.lang.String str21 = delegatedDateTimeField12.getName();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "halfdayOfDay" + "'", str21.equals("halfdayOfDay"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gJChronology11);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Partial partial1 = new org.joda.time.Partial((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.DateTime dateTime11 = limitChronology10.getLowerLimit();
        try {
            long long16 = limitChronology10.getDateTimeMillis(100, (-13), 365, 82841);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -13 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNull(dateTime11);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime14 = null;
        boolean boolean15 = dateTimeZone1.isLocalDateTimeGap(localDateTime14);
        long long18 = dateTimeZone1.convertLocalToUTC((long) 365, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 313L + "'", long18 == 313L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        long long2 = org.joda.time.field.FieldUtils.safeDivide((long) (short) 0, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        org.joda.time.LocalDate localDate16 = localDate13.minusYears(57600);
        int int17 = localDate13.getMonthOfYear();
        int int18 = localDate13.getMonthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        try {
            org.joda.time.LocalDate localDate21 = localDate13.withField(dateTimeFieldType19, (-55630));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
        java.lang.String str4 = iSOChronology2.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[+00:00:00.052]" + "'", str4.equals("ISOChronology[+00:00:00.052]"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) 100, (java.lang.Number) 57600010, (java.lang.Number) 100L);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 100 + "'", number6.equals((byte) 100));
        org.junit.Assert.assertNull(durationFieldType7);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField10.getAsText((long) (short) 100, locale13);
        int int16 = skipUndoDateTimeField10.getMaximumValue((long) (short) -1);
        long long19 = skipUndoDateTimeField10.set((long) 82841045, 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 39641045L + "'", long19 == 39641045L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronology();
        java.lang.StringBuffer stringBuffer4 = null;
        try {
            dateTimeFormatter2.printTo(stringBuffer4, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        try {
            org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) 0, 129);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 129");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTime8.toString("82841", locale11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "82841" + "'", str12.equals("82841"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(673);
        java.util.Locale locale3 = dateTimeFormatter2.getLocale();
        java.lang.Appendable appendable4 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.clockhourOfHalfday();
        org.joda.time.DurationField durationField9 = iSOChronology7.seconds();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology7);
        java.util.Locale locale11 = null;
        java.util.Calendar calendar12 = dateTime10.toCalendar(locale11);
        org.joda.time.DateTime dateTime13 = dateTime10.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property14 = dateTime13.secondOfDay();
        try {
            dateTimeFormatter2.printTo(appendable4, (org.joda.time.ReadableInstant) dateTime13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(calendar12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.weekyear();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.hourOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = iSOChronology20.minutes();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology17, dateTimeField22, (int) (byte) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField22, (int) (short) 0);
        long long28 = skipDateTimeField26.roundHalfCeiling((long) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-52L) + "'", long28 == (-52L));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        long long10 = skipDateTimeField7.set((-1L), (int) (byte) -1);
        long long12 = skipDateTimeField7.roundHalfEven((long) 100);
        int int14 = skipDateTimeField7.get((long) 100);
        int int16 = skipDateTimeField7.getMinimumValue(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-52L) + "'", long12 == (-52L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            int int9 = dateTime5.get(dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 59);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str5 = jodaTimePermission4.getName();
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.Instant instant7 = new org.joda.time.Instant();
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        boolean boolean9 = instant7.isBefore((org.joda.time.ReadableInstant) instant8);
        org.joda.time.Instant instant10 = new org.joda.time.Instant();
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        boolean boolean12 = instant10.isBefore((org.joda.time.ReadableInstant) instant11);
        boolean boolean13 = instant8.isBefore((org.joda.time.ReadableInstant) instant10);
        org.joda.time.Chronology chronology14 = instant10.getChronology();
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance(chronology14, readableDateTime15, readableDateTime16);
        org.joda.time.Partial partial18 = new org.joda.time.Partial(chronology14);
        org.joda.time.Instant instant19 = new org.joda.time.Instant();
        org.joda.time.Instant instant20 = new org.joda.time.Instant();
        boolean boolean21 = instant19.isBefore((org.joda.time.ReadableInstant) instant20);
        org.joda.time.Instant instant22 = new org.joda.time.Instant();
        org.joda.time.Instant instant23 = new org.joda.time.Instant();
        boolean boolean24 = instant22.isBefore((org.joda.time.ReadableInstant) instant23);
        boolean boolean25 = instant20.isBefore((org.joda.time.ReadableInstant) instant22);
        org.joda.time.Chronology chronology26 = instant22.getChronology();
        org.joda.time.ReadableDateTime readableDateTime27 = null;
        org.joda.time.ReadableDateTime readableDateTime28 = null;
        org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance(chronology26, readableDateTime27, readableDateTime28);
        org.joda.time.Partial partial30 = new org.joda.time.Partial(chronology26);
        boolean boolean31 = partial18.isMatch((org.joda.time.ReadablePartial) partial30);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.clockhourOfHalfday();
        org.joda.time.Partial partial36 = partial30.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology34);
        boolean boolean37 = jodaTimePermission4.equals((java.lang.Object) partial30);
        org.joda.time.Instant instant38 = new org.joda.time.Instant();
        org.joda.time.Instant instant39 = new org.joda.time.Instant();
        boolean boolean40 = instant38.isBefore((org.joda.time.ReadableInstant) instant39);
        org.joda.time.Instant instant41 = new org.joda.time.Instant();
        org.joda.time.Instant instant42 = new org.joda.time.Instant();
        boolean boolean43 = instant41.isBefore((org.joda.time.ReadableInstant) instant42);
        boolean boolean44 = instant39.isBefore((org.joda.time.ReadableInstant) instant41);
        org.joda.time.Chronology chronology45 = instant41.getChronology();
        org.joda.time.ReadableDateTime readableDateTime46 = null;
        org.joda.time.ReadableDateTime readableDateTime47 = null;
        org.joda.time.chrono.LimitChronology limitChronology48 = org.joda.time.chrono.LimitChronology.getInstance(chronology45, readableDateTime46, readableDateTime47);
        org.joda.time.Partial partial49 = new org.joda.time.Partial(chronology45);
        org.joda.time.Instant instant50 = new org.joda.time.Instant();
        org.joda.time.Instant instant51 = new org.joda.time.Instant();
        boolean boolean52 = instant50.isBefore((org.joda.time.ReadableInstant) instant51);
        org.joda.time.Instant instant53 = new org.joda.time.Instant();
        org.joda.time.Instant instant54 = new org.joda.time.Instant();
        boolean boolean55 = instant53.isBefore((org.joda.time.ReadableInstant) instant54);
        boolean boolean56 = instant51.isBefore((org.joda.time.ReadableInstant) instant53);
        org.joda.time.Chronology chronology57 = instant53.getChronology();
        org.joda.time.ReadableDateTime readableDateTime58 = null;
        org.joda.time.ReadableDateTime readableDateTime59 = null;
        org.joda.time.chrono.LimitChronology limitChronology60 = org.joda.time.chrono.LimitChronology.getInstance(chronology57, readableDateTime58, readableDateTime59);
        org.joda.time.Partial partial61 = new org.joda.time.Partial(chronology57);
        boolean boolean62 = partial49.isMatch((org.joda.time.ReadablePartial) partial61);
        org.joda.time.ReadablePeriod readablePeriod63 = null;
        org.joda.time.Partial partial64 = partial61.minus(readablePeriod63);
        boolean boolean65 = partial30.isMatch((org.joda.time.ReadablePartial) partial61);
        java.util.Locale locale67 = null;
        try {
            java.lang.String str68 = partial61.toString("LimitChronology[ISOChronology[UTC], NoLimit, NoLimit]", locale67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: L");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(limitChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(limitChronology48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(limitChronology60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(partial64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        java.lang.String str12 = cachedDateTimeZone9.getNameKey((long) 35);
        long long14 = cachedDateTimeZone9.nextTransition((-315534719268L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-315534719268L) + "'", long14 == (-315534719268L));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField16 = iSOChronology15.minutes();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField17, (int) (byte) 1);
        org.joda.time.Instant instant20 = new org.joda.time.Instant();
        org.joda.time.Instant instant21 = new org.joda.time.Instant();
        boolean boolean22 = instant20.isBefore((org.joda.time.ReadableInstant) instant21);
        org.joda.time.Instant instant23 = new org.joda.time.Instant();
        org.joda.time.Instant instant24 = new org.joda.time.Instant();
        boolean boolean25 = instant23.isBefore((org.joda.time.ReadableInstant) instant24);
        boolean boolean26 = instant21.isBefore((org.joda.time.ReadableInstant) instant23);
        org.joda.time.Chronology chronology27 = instant23.getChronology();
        org.joda.time.ReadableDateTime readableDateTime28 = null;
        org.joda.time.ReadableDateTime readableDateTime29 = null;
        org.joda.time.chrono.LimitChronology limitChronology30 = org.joda.time.chrono.LimitChronology.getInstance(chronology27, readableDateTime28, readableDateTime29);
        org.joda.time.Partial partial31 = new org.joda.time.Partial(chronology27);
        int[] intArray39 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
        int[] intArray41 = skipDateTimeField19.addWrapPartial((org.joda.time.ReadablePartial) partial31, (int) (short) 0, intArray39, (int) (short) 1);
        int int44 = skipDateTimeField19.getDifference((long) 52, (long) (byte) 100);
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField(chronology7, (org.joda.time.DateTimeField) skipDateTimeField19);
        long long47 = skipDateTimeField45.roundCeiling((long) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(limitChronology30);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 59948L + "'", long47 == 59948L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.052", "1970-01-01", 365, (int) (byte) 1);
        org.joda.time.Chronology chronology19 = buddhistChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        long long21 = fixedDateTimeZone18.nextTransition((long) 9);
        java.util.TimeZone timeZone22 = fixedDateTimeZone18.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9L + "'", long21 == 9L);
        org.junit.Assert.assertNotNull(timeZone22);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.eras();
        try {
            long long5 = durationField2.subtract(105433401600062L, (-49));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = partial23.getFormatter();
        org.joda.time.Partial partial26 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial23);
        try {
            int int28 = partial26.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(dateTimeFormatter25);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        int int10 = dateTime8.getEra();
        int int11 = dateTime8.getDayOfYear();
        org.joda.time.DateTime dateTime13 = dateTime8.withMinuteOfHour((int) (short) 1);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = dateTime8.toDateTime(chronology14);
        try {
            org.joda.time.DateTime dateTime19 = dateTime15.withDate((-55630), 166, 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfHalfday();
        org.joda.time.DurationField durationField5 = iSOChronology3.seconds();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.MutableDateTime mutableDateTime7 = instant0.toMutableDateTime((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = instant0.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        int int15 = localDate13.getDayOfMonth();
        org.joda.time.Chronology chronology16 = localDate13.getChronology();
        org.joda.time.LocalDate.Property property17 = localDate13.era();
        org.joda.time.DateTime dateTime18 = localDate13.toDateTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(82841, (-13), 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -13 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        org.joda.time.DateTime dateTime9 = dateTime5.withMillis((long) 52);
        try {
            org.joda.time.DateTime dateTime11 = dateTime5.withDayOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.Partial partial14 = partial11.withPeriodAdded(readablePeriod12, 2);
        java.lang.String str15 = partial11.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(partial14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[]" + "'", str15.equals("[]"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 1, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9L) + "'", long2 == (-9L));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property3 = localDate2.monthOfYear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property3.getFieldType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField7 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(70, (int) (short) 1, 82841726);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 70 + "'", int3 == 70);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 1);
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now(dateTimeZone1);
        int int3 = localDate2.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.weekyear();
        org.joda.time.LocalDate localDate16 = localDate13.plusYears((int) (byte) 100);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property19 = localDate18.monthOfYear();
        java.util.Locale locale20 = null;
        int int21 = property19.getMaximumTextLength(locale20);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property19.getFieldType();
        try {
            org.joda.time.LocalDate localDate24 = localDate16.withField(dateTimeFieldType22, 70);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property4 = localDate3.monthOfYear();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property4.getFieldType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField8 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField1, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(dateTimeZone1);
        int int12 = localDate11.size();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField10.getRangeDurationField();
        int int13 = skipUndoDateTimeField10.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.weekyear();
        org.joda.time.LocalDate localDate15 = property14.getLocalDate();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate15);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours(10);
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfDay();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.Chronology chronology13 = dateTime8.getChronology();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDate();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeFormatter3);
        int int5 = dateTimeFormatter3.getDefaultYear();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2000 + "'", int5 == 2000);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        int int10 = dateTime8.getEra();
        int int11 = dateTime8.getDayOfYear();
        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
        org.joda.time.DateTime.Property property13 = dateTime8.dayOfWeek();
        int int14 = dateTime8.getEra();
        org.joda.time.DateTime dateTime16 = dateTime8.withYear((int) (short) 0);
        org.joda.time.DateTime.Property property17 = dateTime8.weekyear();
        int int18 = dateTime8.getMinuteOfDay();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.LocalDateTime localDateTime15 = null;
        boolean boolean16 = dateTimeZone13.isLocalDateTimeGap(localDateTime15);
        java.lang.String str18 = dateTimeZone13.getName((long) '#');
        int int20 = dateTimeZone13.getOffsetFromLocal((long) 10);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone13.getShortName((long) 10, locale22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) 2, dateTimeZone13);
        org.joda.time.LocalDate.Property property25 = localDate24.weekyear();
        long long27 = limitChronology10.set((org.joda.time.ReadablePartial) localDate24, 43200000L);
        org.joda.time.LocalDate localDate29 = localDate24.plusWeeks(1);
        org.joda.time.LocalDate localDate31 = localDate24.withDayOfMonth(19);
        org.joda.time.LocalDate localDate33 = localDate31.plusYears(82841726);
        java.util.Date date34 = localDate33.toDate();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.052" + "'", str18.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43200000L + "'", long27 == 43200000L);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(date34);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        boolean boolean3 = instant1.isBefore((org.joda.time.ReadableInstant) instant2);
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        boolean boolean6 = instant4.isBefore((org.joda.time.ReadableInstant) instant5);
        boolean boolean7 = instant2.isBefore((org.joda.time.ReadableInstant) instant4);
        org.joda.time.Chronology chronology8 = instant4.getChronology();
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.chrono.LimitChronology limitChronology11 = org.joda.time.chrono.LimitChronology.getInstance(chronology8, readableDateTime9, readableDateTime10);
        org.joda.time.Partial partial12 = new org.joda.time.Partial(chronology8);
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        org.joda.time.Instant instant14 = new org.joda.time.Instant();
        boolean boolean15 = instant13.isBefore((org.joda.time.ReadableInstant) instant14);
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        org.joda.time.Instant instant17 = new org.joda.time.Instant();
        boolean boolean18 = instant16.isBefore((org.joda.time.ReadableInstant) instant17);
        boolean boolean19 = instant14.isBefore((org.joda.time.ReadableInstant) instant16);
        org.joda.time.Chronology chronology20 = instant16.getChronology();
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.ReadableDateTime readableDateTime22 = null;
        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology20, readableDateTime21, readableDateTime22);
        org.joda.time.Partial partial24 = new org.joda.time.Partial(chronology20);
        boolean boolean25 = partial12.isMatch((org.joda.time.ReadablePartial) partial24);
        int[] intArray26 = partial12.getValues();
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            org.joda.time.Partial partial28 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray26, (org.joda.time.Chronology) julianChronology27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(limitChronology11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(limitChronology23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(julianChronology27);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds((int) (byte) 1);
        int int12 = dateTime8.getDayOfYear();
        org.joda.time.DateTime dateTime14 = dateTime8.withCenturyOfEra(3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDate();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeFormatter3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str7 = jodaTimePermission6.getName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicDate();
        jodaTimePermission6.checkGuard((java.lang.Object) dateTimeFormatter8);
        org.joda.time.JodaTimePermission jodaTimePermission11 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str12 = jodaTimePermission11.getActions();
        boolean boolean13 = jodaTimePermission6.implies((java.security.Permission) jodaTimePermission11);
        boolean boolean14 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission6);
        java.lang.String str15 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.year();
        org.joda.time.LocalDate.Property property3 = localDate1.centuryOfEra();
        org.joda.time.DurationField durationField4 = property3.getRangeDurationField();
        java.lang.String str5 = property3.getAsShortText();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19" + "'", str5.equals("19"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property7.getAsText(locale10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970" + "'", str11.equals("1970"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        try {
            java.lang.String str2 = dateTimeFormatter0.print((long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        try {
            long long15 = delegatedDateTimeField12.set(1560639632523L, "-55630-01-01");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"-55630-01-01\" for halfdayOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("00", false);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("1970-01-01", false);
        java.util.TimeZone timeZone7 = dateTimeZone6.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        try {
            org.joda.time.LocalDate localDate4 = localDate1.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Chronology chronology11 = limitChronology10.withUTC();
        org.joda.time.Chronology chronology12 = limitChronology10.withUTC();
        try {
            org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((java.lang.Object) chronology12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.LimitChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        int int10 = dateTime8.getEra();
        int int11 = dateTime8.getDayOfYear();
        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
        org.joda.time.DateTime.Property property13 = dateTime8.dayOfWeek();
        org.joda.time.DateTime.Property property14 = dateTime8.yearOfCentury();
        try {
            java.lang.String str16 = dateTime8.toString("AM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.DateMidnight dateMidnight4 = localDate3.toDateMidnight();
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        boolean boolean7 = instant5.isBefore((org.joda.time.ReadableInstant) instant6);
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        boolean boolean10 = instant8.isBefore((org.joda.time.ReadableInstant) instant9);
        boolean boolean11 = instant6.isBefore((org.joda.time.ReadableInstant) instant8);
        org.joda.time.Chronology chronology12 = instant8.getChronology();
        org.joda.time.DateTime dateTime13 = dateMidnight4.toDateTime(chronology12);
        boolean boolean14 = julianChronology0.equals((java.lang.Object) dateMidnight4);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (-55630));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-55630) + "'", int1 == (-55630));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(dateTimeZone3);
        java.lang.String str5 = dateTimeZone3.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.052" + "'", str5.equals("+00:00:00.052"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 10, 105, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 82841);
        java.lang.Class<?> wildcardClass2 = dateTime1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.LocalDateTime localDateTime15 = null;
        boolean boolean16 = dateTimeZone13.isLocalDateTimeGap(localDateTime15);
        java.lang.String str18 = dateTimeZone13.getName((long) '#');
        int int20 = dateTimeZone13.getOffsetFromLocal((long) 10);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone13.getShortName((long) 10, locale22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) 2, dateTimeZone13);
        org.joda.time.LocalDate.Property property25 = localDate24.weekyear();
        long long27 = limitChronology10.set((org.joda.time.ReadablePartial) localDate24, 43200000L);
        org.joda.time.LocalDate.Property property28 = localDate24.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField29 = property28.getField();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.052" + "'", str18.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43200000L + "'", long27 == 43200000L);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTimeField29);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis((int) (short) 0, 680, 105, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 680 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("minuteOfHour", (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.052", "+00:00:00.052", 35, 84480732);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) 82841726, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.LocalTime localTime7 = null;
        try {
            org.joda.time.LocalDateTime localDateTime8 = localDate6.toLocalDateTime(localTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        boolean boolean4 = instant2.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        boolean boolean7 = instant5.isBefore((org.joda.time.ReadableInstant) instant6);
        boolean boolean8 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology9 = instant5.getChronology();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance(chronology9, readableDateTime10, readableDateTime11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.LocalDateTime localDateTime17 = null;
        boolean boolean18 = dateTimeZone15.isLocalDateTimeGap(localDateTime17);
        java.lang.String str20 = dateTimeZone15.getName((long) '#');
        int int22 = dateTimeZone15.getOffsetFromLocal((long) 10);
        java.util.Locale locale24 = null;
        java.lang.String str25 = dateTimeZone15.getShortName((long) 10, locale24);
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) 2, dateTimeZone15);
        org.joda.time.LocalDate.Property property27 = localDate26.weekyear();
        long long29 = limitChronology12.set((org.joda.time.ReadablePartial) localDate26, 43200000L);
        org.joda.time.LocalDate localDate31 = localDate26.plusWeeks(1);
        org.joda.time.LocalDate localDate33 = localDate26.withDayOfMonth(19);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00:00.052" + "'", str20.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.052" + "'", str25.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43200000L + "'", long29 == 43200000L);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(localDate33);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((-1), (int) (short) 1, (int) '4', 2000, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, 105433401600010L, 10);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 105433401600010L + "'", long4 == 105433401600010L);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds((int) (byte) 1);
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime8.toYearMonthDay();
        int int13 = dateTime8.getWeekyear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.Instant instant14 = new org.joda.time.Instant();
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        boolean boolean16 = instant14.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Instant instant17 = new org.joda.time.Instant();
        org.joda.time.Instant instant18 = new org.joda.time.Instant();
        boolean boolean19 = instant17.isBefore((org.joda.time.ReadableInstant) instant18);
        boolean boolean20 = instant15.isBefore((org.joda.time.ReadableInstant) instant17);
        org.joda.time.Chronology chronology21 = instant17.getChronology();
        org.joda.time.DateTime dateTime22 = instant17.toDateTimeISO();
        org.joda.time.DateTime.Property property23 = dateTime22.year();
        org.joda.time.DateTime dateTime25 = dateTime22.plusSeconds((int) (byte) 1);
        int int26 = dateTime22.getSecondOfDay();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime22);
        try {
            long long32 = gJChronology27.getDateTimeMillis(0, 82841, 57600, 105);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82841 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(gJChronology27);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.052", "1970-01-01", 365, (int) (byte) 1);
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedDateTimeZone4.equals(obj5);
        long long8 = fixedDateTimeZone4.nextTransition(1560639639715L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560639639715L + "'", long8 == 1560639639715L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.LocalDateTime localDateTime15 = null;
        boolean boolean16 = dateTimeZone13.isLocalDateTimeGap(localDateTime15);
        java.lang.String str18 = dateTimeZone13.getName((long) '#');
        int int20 = dateTimeZone13.getOffsetFromLocal((long) 10);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone13.getShortName((long) 10, locale22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) 2, dateTimeZone13);
        org.joda.time.LocalDate.Property property25 = localDate24.weekyear();
        long long27 = limitChronology10.set((org.joda.time.ReadablePartial) localDate24, 43200000L);
        org.joda.time.LocalDate localDate29 = localDate24.plusWeeks(1);
        java.lang.String str30 = localDate24.toString();
        org.joda.time.LocalDate.Property property31 = localDate24.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = localDate24.toDateTimeAtCurrentTime(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.052" + "'", str18.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43200000L + "'", long27 == 43200000L);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970-01-01" + "'", str30.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDate();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeFormatter3);
        java.security.PermissionCollection permissionCollection5 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(permissionCollection5);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(19, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57 + "'", int2 == 57);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds((int) (byte) 1);
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime8.toYearMonthDay();
        org.joda.time.DateTime dateTime14 = dateTime8.minusWeeks(4);
        org.joda.time.DateTime dateTime16 = dateTime8.minusMinutes((int) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        java.util.Locale locale3 = null;
        int int4 = property2.getMaximumTextLength(locale3);
        org.joda.time.LocalDate localDate5 = property2.roundCeilingCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 10);
        java.lang.String str4 = dateTimeFormatter0.print(0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-W01-4" + "'", str4.equals("1970-W01-4"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 0);
        boolean boolean4 = gJChronology0.equals((java.lang.Object) dateTimeFormatter3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gJChronology0.add(readablePeriod5, (long) 725, 82843301);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 725L + "'", long8 == 725L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 105433401600149L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, 332);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        long long10 = skipDateTimeField7.set((-1L), (int) (byte) -1);
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
        org.joda.time.Instant instant14 = new org.joda.time.Instant();
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        boolean boolean16 = instant14.isBefore((org.joda.time.ReadableInstant) instant15);
        boolean boolean17 = instant12.isBefore((org.joda.time.ReadableInstant) instant14);
        org.joda.time.Chronology chronology18 = instant14.getChronology();
        org.joda.time.ReadableDateTime readableDateTime19 = null;
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance(chronology18, readableDateTime19, readableDateTime20);
        org.joda.time.Partial partial22 = new org.joda.time.Partial(chronology18);
        org.joda.time.Instant instant23 = new org.joda.time.Instant();
        org.joda.time.Instant instant24 = new org.joda.time.Instant();
        boolean boolean25 = instant23.isBefore((org.joda.time.ReadableInstant) instant24);
        org.joda.time.Instant instant26 = new org.joda.time.Instant();
        org.joda.time.Instant instant27 = new org.joda.time.Instant();
        boolean boolean28 = instant26.isBefore((org.joda.time.ReadableInstant) instant27);
        boolean boolean29 = instant24.isBefore((org.joda.time.ReadableInstant) instant26);
        org.joda.time.Chronology chronology30 = instant26.getChronology();
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.ReadableDateTime readableDateTime32 = null;
        org.joda.time.chrono.LimitChronology limitChronology33 = org.joda.time.chrono.LimitChronology.getInstance(chronology30, readableDateTime31, readableDateTime32);
        org.joda.time.Partial partial34 = new org.joda.time.Partial(chronology30);
        boolean boolean35 = partial22.isMatch((org.joda.time.ReadablePartial) partial34);
        org.joda.time.Partial partial36 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial34);
        org.joda.time.Instant instant38 = new org.joda.time.Instant();
        org.joda.time.Instant instant39 = new org.joda.time.Instant();
        boolean boolean40 = instant38.isBefore((org.joda.time.ReadableInstant) instant39);
        org.joda.time.Instant instant41 = new org.joda.time.Instant();
        org.joda.time.Instant instant42 = new org.joda.time.Instant();
        boolean boolean43 = instant41.isBefore((org.joda.time.ReadableInstant) instant42);
        boolean boolean44 = instant39.isBefore((org.joda.time.ReadableInstant) instant41);
        org.joda.time.Chronology chronology45 = instant41.getChronology();
        org.joda.time.ReadableDateTime readableDateTime46 = null;
        org.joda.time.ReadableDateTime readableDateTime47 = null;
        org.joda.time.chrono.LimitChronology limitChronology48 = org.joda.time.chrono.LimitChronology.getInstance(chronology45, readableDateTime46, readableDateTime47);
        org.joda.time.Partial partial49 = new org.joda.time.Partial(chronology45);
        org.joda.time.Instant instant50 = new org.joda.time.Instant();
        org.joda.time.Instant instant51 = new org.joda.time.Instant();
        boolean boolean52 = instant50.isBefore((org.joda.time.ReadableInstant) instant51);
        org.joda.time.Instant instant53 = new org.joda.time.Instant();
        org.joda.time.Instant instant54 = new org.joda.time.Instant();
        boolean boolean55 = instant53.isBefore((org.joda.time.ReadableInstant) instant54);
        boolean boolean56 = instant51.isBefore((org.joda.time.ReadableInstant) instant53);
        org.joda.time.Chronology chronology57 = instant53.getChronology();
        org.joda.time.ReadableDateTime readableDateTime58 = null;
        org.joda.time.ReadableDateTime readableDateTime59 = null;
        org.joda.time.chrono.LimitChronology limitChronology60 = org.joda.time.chrono.LimitChronology.getInstance(chronology57, readableDateTime58, readableDateTime59);
        org.joda.time.Partial partial61 = new org.joda.time.Partial(chronology57);
        boolean boolean62 = partial49.isMatch((org.joda.time.ReadablePartial) partial61);
        int[] intArray63 = partial49.getValues();
        try {
            int[] intArray65 = skipDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) partial34, 129, intArray63, 59);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 129");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(limitChronology21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(limitChronology33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(limitChronology48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(limitChronology60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(intArray63);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        int int14 = delegatedDateTimeField12.getMinimumValue((long) (short) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField12.getAsShortText(0L, locale16);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField12.getRangeDurationField();
        java.util.Locale locale19 = null;
        int int20 = delegatedDateTimeField12.getMaximumShortTextLength(locale19);
        java.lang.String str22 = delegatedDateTimeField12.getAsText((long) 35);
        long long25 = delegatedDateTimeField12.set((long) (byte) 1, "AM");
        java.util.Locale locale27 = null;
        java.lang.String str28 = delegatedDateTimeField12.getAsText(0, locale27);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "AM" + "'", str22.equals("AM"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "AM" + "'", str28.equals("AM"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        org.joda.time.DateTime dateTime9 = dateTime5.withMillis((long) 52);
        int int10 = dateTime5.getDayOfWeek();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.DateTime dateTime13 = dateTime5.withFieldAdded(durationFieldType11, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.IllegalInstantException illegalInstantException5 = new org.joda.time.IllegalInstantException(1L, "hi!");
        java.lang.String str6 = illegalInstantException5.toString();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalInstantException5);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("", "hi!");
        illegalInstantException5.addSuppressed((java.lang.Throwable) illegalFieldValueException10);
        java.lang.Number number12 = illegalFieldValueException10.getLowerBound();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)" + "'", str6.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)"));
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        long long2 = org.joda.time.field.FieldUtils.safeDivide(6800L, (-210808008000000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.DurationField durationField5 = property3.getRangeDurationField();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property8 = localDate7.monthOfYear();
        int int9 = property3.compareTo((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.LocalDate localDate11 = localDate7.minusDays(292278993);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (short) 1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.date();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("100", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"100\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("minuteOfHour", (int) 'a');
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("+00:00:00.052", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeField[] dateTimeFieldArray4 = localDate1.getFields();
        java.util.Date date5 = localDate1.toDate();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFieldArray4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        java.util.Locale locale6 = null;
        java.util.Calendar calendar7 = dateTime5.toCalendar(locale6);
        org.joda.time.DateTime dateTime8 = dateTime5.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
        org.joda.time.DateTime dateTime11 = property9.setCopy("0");
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(calendar7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
//        org.joda.time.Instant instant15 = new org.joda.time.Instant();
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
//        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
//        org.joda.time.Chronology chronology19 = instant15.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime20 = null;
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
//        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
//        org.joda.time.Instant instant24 = new org.joda.time.Instant();
//        org.joda.time.Instant instant25 = new org.joda.time.Instant();
//        boolean boolean26 = instant24.isBefore((org.joda.time.ReadableInstant) instant25);
//        org.joda.time.Instant instant27 = new org.joda.time.Instant();
//        org.joda.time.Instant instant28 = new org.joda.time.Instant();
//        boolean boolean29 = instant27.isBefore((org.joda.time.ReadableInstant) instant28);
//        boolean boolean30 = instant25.isBefore((org.joda.time.ReadableInstant) instant27);
//        org.joda.time.Chronology chronology31 = instant27.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime32 = null;
//        org.joda.time.ReadableDateTime readableDateTime33 = null;
//        org.joda.time.chrono.LimitChronology limitChronology34 = org.joda.time.chrono.LimitChronology.getInstance(chronology31, readableDateTime32, readableDateTime33);
//        org.joda.time.Partial partial35 = new org.joda.time.Partial(chronology31);
//        boolean boolean36 = partial23.isMatch((org.joda.time.ReadablePartial) partial35);
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
//        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.clockhourOfHalfday();
//        org.joda.time.Partial partial41 = partial35.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology39);
//        boolean boolean42 = partial11.isMatch((org.joda.time.ReadablePartial) partial35);
//        java.lang.String str43 = partial11.toStringList();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(limitChronology22);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(limitChronology34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(partial41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "[]" + "'", str43.equals("[]"));
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        long long9 = skipDateTimeField7.roundHalfFloor(100L);
        org.joda.time.DurationField durationField10 = skipDateTimeField7.getRangeDurationField();
        java.lang.String str11 = skipDateTimeField7.getName();
        java.lang.String str12 = skipDateTimeField7.getName();
        org.joda.time.DateTimeField dateTimeField13 = skipDateTimeField7.getWrappedField();
        long long15 = skipDateTimeField7.roundCeiling((long) (-13));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-52L) + "'", long9 == (-52L));
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "minuteOfHour" + "'", str11.equals("minuteOfHour"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "minuteOfHour" + "'", str12.equals("minuteOfHour"));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 59948L + "'", long15 == 59948L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        long long11 = skipDateTimeField7.getDifferenceAsLong((long) 84480732, 43200000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 688L + "'", long11 == 688L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        boolean boolean7 = instant5.isBefore((org.joda.time.ReadableInstant) instant6);
        int int8 = property3.getDifference((org.joda.time.ReadableInstant) instant5);
        org.joda.time.LocalDate localDate9 = property3.roundHalfFloorCopy();
        try {
            org.joda.time.LocalDate localDate11 = localDate9.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-49) + "'", int8 == (-49));
        org.junit.Assert.assertNotNull(localDate9);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        int int10 = dateTime8.getEra();
//        int int11 = dateTime8.getDayOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
//        org.joda.time.DateTime.Property property13 = dateTime8.dayOfWeek();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime8.toTimeOfDay();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 166 + "'", int11 == 166);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        long long10 = skipDateTimeField7.set((-1L), (int) (byte) -1);
        long long12 = skipDateTimeField7.roundHalfEven((long) 100);
        int int14 = skipDateTimeField7.get((long) 100);
        long long16 = skipDateTimeField7.roundHalfFloor((-42L));
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, dateTimeFieldType17, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-52L) + "'", long12 == (-52L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-52L) + "'", long16 == (-52L));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMinutes((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime5.minus(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.DateTime dateTime11 = limitChronology10.getUpperLimit();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertNull(dateTime11);
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DurationField durationField4 = property3.getRangeDurationField();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNull(durationField4);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        int int14 = delegatedDateTimeField12.getMinimumValue((long) (short) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField12.getAsShortText(0L, locale16);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField12.getRangeDurationField();
        java.util.Locale locale19 = null;
        int int20 = delegatedDateTimeField12.getMaximumShortTextLength(locale19);
        java.lang.String str22 = delegatedDateTimeField12.getAsText((long) 35);
        long long25 = delegatedDateTimeField12.add((long) (byte) 10, 2440588L);
        java.lang.String str27 = delegatedDateTimeField12.getAsText((long) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "AM" + "'", str22.equals("AM"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 105433401600010L + "'", long25 == 105433401600010L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "AM" + "'", str27.equals("AM"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        try {
            java.lang.String str2 = dateTimeFormatter0.print((long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.era();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.DurationField durationField6 = iSOChronology2.seconds();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDate();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeFormatter3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str7 = jodaTimePermission6.getName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicDate();
        jodaTimePermission6.checkGuard((java.lang.Object) dateTimeFormatter8);
        org.joda.time.JodaTimePermission jodaTimePermission11 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str12 = jodaTimePermission11.getActions();
        boolean boolean13 = jodaTimePermission6.implies((java.security.Permission) jodaTimePermission11);
        boolean boolean14 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission6);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property17 = localDate16.monthOfYear();
        java.util.Locale locale18 = null;
        int int19 = property17.getMaximumTextLength(locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property17.getFieldType();
        boolean boolean21 = jodaTimePermission6.equals((java.lang.Object) property17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        long long10 = skipDateTimeField7.set((-1L), (int) (byte) -1);
        org.joda.time.DateTimeField dateTimeField11 = skipDateTimeField7.getWrappedField();
        long long14 = skipDateTimeField7.getDifferenceAsLong((long) 35, (long) 680);
        org.joda.time.DurationField durationField15 = skipDateTimeField7.getLeapDurationField();
        java.lang.String str16 = skipDateTimeField7.getName();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "minuteOfHour" + "'", str16.equals("minuteOfHour"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property8 = dateTime7.weekyear();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(82843301);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 0);
        boolean boolean4 = gJChronology0.equals((java.lang.Object) dateTimeFormatter3);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = buddhistChronology13.withZone(dateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.LocalDateTime localDateTime20 = null;
        boolean boolean21 = dateTimeZone18.isLocalDateTimeGap(localDateTime20);
        java.lang.String str23 = dateTimeZone18.getName((long) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter16.withZone(dateTimeZone18);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology13, dateTimeZone18);
        org.joda.time.Chronology chronology26 = buddhistChronology13.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray4 = gregorianChronology0.get(readablePeriod1, 2440588L, (long) 680);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology0.add(readablePeriod2, 100L, 57600010);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
        try {
            long long11 = iSOChronology0.getDateTimeMillis(0, 0, 1970, 78);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant3 = instant0.withDurationAdded(readableDuration1, (int) (short) 0);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) instant0);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plus(43200000L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumTextLength(locale8);
        int int10 = property7.getLeapAmount();
        org.joda.time.DateTime dateTime11 = property7.withMinimumValue();
        org.joda.time.DateTime dateTime12 = property7.getDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("halfdayOfDay", "AM", 18, 365);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.LocalDateTime localDateTime15 = null;
//        boolean boolean16 = dateTimeZone13.isLocalDateTimeGap(localDateTime15);
//        java.lang.String str18 = dateTimeZone13.getName((long) '#');
//        int int20 = dateTimeZone13.getOffsetFromLocal((long) 10);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone13.getShortName((long) 10, locale22);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) 2, dateTimeZone13);
//        org.joda.time.LocalDate.Property property25 = localDate24.weekyear();
//        long long27 = limitChronology10.set((org.joda.time.ReadablePartial) localDate24, 43200000L);
//        org.joda.time.DurationField durationField28 = limitChronology10.halfdays();
//        try {
//            long long33 = limitChronology10.getDateTimeMillis(292278993, 84480052, (int) (short) 0, 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 84480052 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.052" + "'", str18.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43200000L + "'", long27 == 43200000L);
//        org.junit.Assert.assertNotNull(durationField28);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField10.getAsText((long) (short) 100, locale13);
        int int16 = skipUndoDateTimeField10.getMaximumValue((long) (short) -1);
        long long19 = skipUndoDateTimeField10.add(105433401600097L, (int) (byte) 10);
        int int21 = skipUndoDateTimeField10.get(1560639635957L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 105433833600097L + "'", long19 == 105433833600097L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology3, dateTimeField9, (int) (byte) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.LocalDateTime localDateTime17 = null;
        boolean boolean18 = dateTimeZone15.isLocalDateTimeGap(localDateTime17);
        java.lang.String str20 = dateTimeZone15.getName((long) '#');
        int int22 = dateTimeZone15.getOffsetFromLocal((long) 10);
        java.util.Locale locale24 = null;
        java.lang.String str25 = dateTimeZone15.getShortName((long) 10, locale24);
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) 2, dateTimeZone15);
        org.joda.time.LocalDate.Property property27 = localDate26.monthOfYear();
        org.joda.time.LocalDate localDate29 = localDate26.minusYears(57600);
        java.util.Locale locale31 = null;
        try {
            java.lang.String str32 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDate26, 82841, locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 82841");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00:00.052" + "'", str20.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.052" + "'", str25.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(localDate29);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField10.getAsText((long) (short) 100, locale13);
        int int16 = skipUndoDateTimeField10.getMaximumValue((long) (short) -1);
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = skipUndoDateTimeField10.getAsShortText((-13), locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -13");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.dayOfYear();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
//        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
//        int int12 = offsetDateTimeField10.getMaximumValue(2458650L);
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        org.joda.time.Instant instant14 = new org.joda.time.Instant();
//        boolean boolean15 = instant13.isBefore((org.joda.time.ReadableInstant) instant14);
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        org.joda.time.Instant instant17 = new org.joda.time.Instant();
//        boolean boolean18 = instant16.isBefore((org.joda.time.ReadableInstant) instant17);
//        boolean boolean19 = instant14.isBefore((org.joda.time.ReadableInstant) instant16);
//        org.joda.time.Chronology chronology20 = instant16.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.ReadableDateTime readableDateTime22 = null;
//        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance(chronology20, readableDateTime21, readableDateTime22);
//        org.joda.time.Partial partial24 = new org.joda.time.Partial(chronology20);
//        org.joda.time.Instant instant25 = new org.joda.time.Instant();
//        org.joda.time.Instant instant26 = new org.joda.time.Instant();
//        boolean boolean27 = instant25.isBefore((org.joda.time.ReadableInstant) instant26);
//        org.joda.time.Instant instant28 = new org.joda.time.Instant();
//        org.joda.time.Instant instant29 = new org.joda.time.Instant();
//        boolean boolean30 = instant28.isBefore((org.joda.time.ReadableInstant) instant29);
//        boolean boolean31 = instant26.isBefore((org.joda.time.ReadableInstant) instant28);
//        org.joda.time.Chronology chronology32 = instant28.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime33 = null;
//        org.joda.time.ReadableDateTime readableDateTime34 = null;
//        org.joda.time.chrono.LimitChronology limitChronology35 = org.joda.time.chrono.LimitChronology.getInstance(chronology32, readableDateTime33, readableDateTime34);
//        org.joda.time.Partial partial36 = new org.joda.time.Partial(chronology32);
//        boolean boolean37 = partial24.isMatch((org.joda.time.ReadablePartial) partial36);
//        org.joda.time.Instant instant39 = new org.joda.time.Instant();
//        org.joda.time.Instant instant40 = new org.joda.time.Instant();
//        boolean boolean41 = instant39.isBefore((org.joda.time.ReadableInstant) instant40);
//        org.joda.time.Instant instant42 = new org.joda.time.Instant();
//        org.joda.time.Instant instant43 = new org.joda.time.Instant();
//        boolean boolean44 = instant42.isBefore((org.joda.time.ReadableInstant) instant43);
//        boolean boolean45 = instant40.isBefore((org.joda.time.ReadableInstant) instant42);
//        org.joda.time.Chronology chronology46 = instant42.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime47 = null;
//        org.joda.time.ReadableDateTime readableDateTime48 = null;
//        org.joda.time.chrono.LimitChronology limitChronology49 = org.joda.time.chrono.LimitChronology.getInstance(chronology46, readableDateTime47, readableDateTime48);
//        org.joda.time.Partial partial50 = new org.joda.time.Partial(chronology46);
//        org.joda.time.Instant instant51 = new org.joda.time.Instant();
//        org.joda.time.Instant instant52 = new org.joda.time.Instant();
//        boolean boolean53 = instant51.isBefore((org.joda.time.ReadableInstant) instant52);
//        org.joda.time.Instant instant54 = new org.joda.time.Instant();
//        org.joda.time.Instant instant55 = new org.joda.time.Instant();
//        boolean boolean56 = instant54.isBefore((org.joda.time.ReadableInstant) instant55);
//        boolean boolean57 = instant52.isBefore((org.joda.time.ReadableInstant) instant54);
//        org.joda.time.Chronology chronology58 = instant54.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime59 = null;
//        org.joda.time.ReadableDateTime readableDateTime60 = null;
//        org.joda.time.chrono.LimitChronology limitChronology61 = org.joda.time.chrono.LimitChronology.getInstance(chronology58, readableDateTime59, readableDateTime60);
//        org.joda.time.Partial partial62 = new org.joda.time.Partial(chronology58);
//        boolean boolean63 = partial50.isMatch((org.joda.time.ReadablePartial) partial62);
//        int[] intArray64 = partial62.getValues();
//        try {
//            int[] intArray66 = offsetDateTimeField10.add((org.joda.time.ReadablePartial) partial24, 82843301, intArray64, (-55630));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 82843301");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 78 + "'", int12 == 78);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(limitChronology23);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(limitChronology35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(limitChronology49);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(chronology58);
//        org.junit.Assert.assertNotNull(limitChronology61);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertNotNull(intArray64);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.052", "1970-01-01", 365, (int) (byte) 1);
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedDateTimeZone4.equals(obj5);
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) 100, (java.lang.Number) 57600010, (java.lang.Number) 100L);
        java.lang.String str12 = illegalFieldValueException11.getIllegalStringValue();
        boolean boolean13 = fixedDateTimeZone4.equals((java.lang.Object) str12);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(dateTimeZone3);
        int int5 = localDate4.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = buddhistChronology13.withZone(dateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.LocalDateTime localDateTime20 = null;
        boolean boolean21 = dateTimeZone18.isLocalDateTimeGap(localDateTime20);
        java.lang.String str23 = dateTimeZone18.getName((long) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter16.withZone(dateTimeZone18);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology13, dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone26 = zonedChronology25.getZone();
        java.lang.String str27 = zonedChronology25.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ZonedChronology[BuddhistChronology[UTC], +00:00:00.052]" + "'", str27.equals("ZonedChronology[BuddhistChronology[UTC], +00:00:00.052]"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        int int3 = localDate1.getYearOfCentury();
        int int4 = localDate1.getDayOfMonth();
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType6 = localDate1.getFieldType(680);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 680");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 70 + "'", int3 == 70);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property8 = dateTime7.weekyear();
        org.joda.time.DateTime dateTime10 = property8.addToCopy(365);
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = dateTime10.toString("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)", locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        int int10 = dateTime8.getEra();
//        int int11 = dateTime8.getDayOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
//        int int13 = dateTime8.getMillisOfDay();
//        org.joda.time.DateTime.Property property14 = dateTime8.yearOfCentury();
//        org.joda.time.DateTime dateTime16 = dateTime8.plusMinutes((int) '#');
//        org.joda.time.Chronology chronology17 = dateTime8.getChronology();
//        boolean boolean18 = dateTime8.isAfterNow();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 166 + "'", int11 == 166);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 82860362 + "'", int13 == 82860362);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        int int10 = dateTime8.getEra();
//        int int11 = dateTime8.getDayOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
//        int int13 = dateTime8.getMillisOfDay();
//        long long14 = dateTime8.getMillis();
//        org.joda.time.DateTime dateTime16 = dateTime8.withCenturyOfEra(2000);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        boolean boolean18 = dateTimeFormatter17.isParser();
//        java.lang.String str19 = dateTime8.toString(dateTimeFormatter17);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 166 + "'", int11 == 166);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 82860538 + "'", int13 == 82860538);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639660486L + "'", long14 == 1560639660486L);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019-06-15T23:01:00" + "'", str19.equals("2019-06-15T23:01:00"));
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumTextLength(locale8);
        int int10 = property7.getLeapAmount();
        org.joda.time.DateTime dateTime11 = property7.withMinimumValue();
        int int12 = dateTime11.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2922750 + "'", int12 == 2922750);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, 105433401600010L, 10);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 105433401600010L + "'", long4 == 105433401600010L);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(copticChronology6);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(166);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.year();
        org.joda.time.DurationField durationField5 = iSOChronology2.minutes();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
//        int int8 = skipDateTimeField7.getMinimumValue();
//        int int10 = skipDateTimeField7.getLeapAmount((long) 84480732);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.DurationField durationField15 = iSOChronology14.minutes();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology11, dateTimeField16, (int) (byte) 1);
//        org.joda.time.Instant instant19 = new org.joda.time.Instant();
//        org.joda.time.Instant instant20 = new org.joda.time.Instant();
//        boolean boolean21 = instant19.isBefore((org.joda.time.ReadableInstant) instant20);
//        org.joda.time.Instant instant22 = new org.joda.time.Instant();
//        org.joda.time.Instant instant23 = new org.joda.time.Instant();
//        boolean boolean24 = instant22.isBefore((org.joda.time.ReadableInstant) instant23);
//        boolean boolean25 = instant20.isBefore((org.joda.time.ReadableInstant) instant22);
//        org.joda.time.Chronology chronology26 = instant22.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime27 = null;
//        org.joda.time.ReadableDateTime readableDateTime28 = null;
//        org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance(chronology26, readableDateTime27, readableDateTime28);
//        org.joda.time.Partial partial30 = new org.joda.time.Partial(chronology26);
//        int[] intArray38 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
//        int[] intArray40 = skipDateTimeField18.addWrapPartial((org.joda.time.ReadablePartial) partial30, (int) (short) 0, intArray38, (int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod41 = null;
//        org.joda.time.Partial partial42 = partial30.plus(readablePeriod41);
//        java.util.Locale locale43 = null;
//        try {
//            java.lang.String str44 = skipDateTimeField7.getAsText((org.joda.time.ReadablePartial) partial30, locale43);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(limitChronology29);
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertNotNull(partial42);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.DateTime dateTime2 = localDate1.toDateTimeAtCurrentTime();
        int int3 = localDate1.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 0);
        boolean boolean4 = gJChronology0.equals((java.lang.Object) dateTimeFormatter3);
        java.io.Writer writer5 = null;
        try {
            dateTimeFormatter3.printTo(writer5, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        long long10 = skipDateTimeField7.set((-1L), (int) (byte) -1);
        long long12 = skipDateTimeField7.roundHalfEven((long) 100);
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        org.joda.time.Instant instant14 = new org.joda.time.Instant();
        boolean boolean15 = instant13.isBefore((org.joda.time.ReadableInstant) instant14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        boolean boolean17 = instant14.isSupported(dateTimeFieldType16);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property20 = localDate19.monthOfYear();
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property23 = localDate22.monthOfYear();
        java.util.Locale locale24 = null;
        int int25 = property23.getMaximumTextLength(locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property23.getFieldType();
        int int27 = localDate19.get(dateTimeFieldType26);
        boolean boolean28 = instant14.isSupported(dateTimeFieldType26);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, dateTimeFieldType26, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-52L) + "'", long12 == (-52L));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (short) 10);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone4.isLocalDateTimeGap(localDateTime6);
        java.lang.String str9 = dateTimeZone4.getName((long) '#');
        int int11 = dateTimeZone4.getOffsetFromLocal((long) 10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = dateTimeZone4.getShortName((long) 10, locale13);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) 2, dateTimeZone4);
        org.joda.time.LocalDate.Property property16 = localDate15.monthOfYear();
        int int17 = localDate15.getDayOfMonth();
        org.joda.time.Chronology chronology18 = localDate15.getChronology();
        org.joda.time.LocalDate.Property property19 = localDate15.era();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.052" + "'", str9.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.052" + "'", str14.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.LocalDateTime localDateTime15 = null;
        boolean boolean16 = dateTimeZone13.isLocalDateTimeGap(localDateTime15);
        java.lang.String str18 = dateTimeZone13.getName((long) '#');
        int int20 = dateTimeZone13.getOffsetFromLocal((long) 10);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone13.getShortName((long) 10, locale22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) 2, dateTimeZone13);
        org.joda.time.LocalDate.Property property25 = localDate24.weekyear();
        long long27 = limitChronology10.set((org.joda.time.ReadablePartial) localDate24, 43200000L);
        org.joda.time.DateTimeField dateTimeField28 = limitChronology10.yearOfEra();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.052" + "'", str18.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43200000L + "'", long27 == 43200000L);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMillis((int) (byte) 0);
        java.util.Locale locale3 = null;
        java.util.Calendar calendar4 = dateTime2.toCalendar(locale3);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(calendar4);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = buddhistChronology13.withZone(dateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.LocalDateTime localDateTime20 = null;
        boolean boolean21 = dateTimeZone18.isLocalDateTimeGap(localDateTime20);
        java.lang.String str23 = dateTimeZone18.getName((long) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter16.withZone(dateTimeZone18);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology13, dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField26 = zonedChronology25.era();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.secondOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DurationField durationField11 = copticChronology10.millis();
        int int12 = copticChronology10.getMinimumDaysInFirstWeek();
        try {
            long long20 = copticChronology10.getDateTimeMillis((-13), 20, 100, 20, 0, 18, 332);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        int int12 = offsetDateTimeField10.getMaximumValue(2458650L);
        long long15 = offsetDateTimeField10.add((-42L), (int) ' ');
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField10.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 78 + "'", int12 == 78);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1919958L + "'", long15 == 1919958L);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.DateMidnight dateMidnight2 = localDate1.toDateMidnight();
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        org.joda.time.Instant instant6 = new org.joda.time.Instant();
//        org.joda.time.Instant instant7 = new org.joda.time.Instant();
//        boolean boolean8 = instant6.isBefore((org.joda.time.ReadableInstant) instant7);
//        boolean boolean9 = instant4.isBefore((org.joda.time.ReadableInstant) instant6);
//        org.joda.time.Chronology chronology10 = instant6.getChronology();
//        org.joda.time.DateTime dateTime11 = dateMidnight2.toDateTime(chronology10);
//        java.lang.String str12 = dateMidnight2.toString();
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-01T00:00:00.000+00:00:00.052" + "'", str12.equals("1970-01-01T00:00:00.000+00:00:00.052"));
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = buddhistChronology13.withZone(dateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.LocalDateTime localDateTime20 = null;
        boolean boolean21 = dateTimeZone18.isLocalDateTimeGap(localDateTime20);
        java.lang.String str23 = dateTimeZone18.getName((long) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter16.withZone(dateTimeZone18);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology13, dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone26 = zonedChronology25.getZone();
        org.joda.time.DurationField durationField27 = zonedChronology25.weekyears();
        org.joda.time.DateTimeZone dateTimeZone28 = zonedChronology25.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.LocalDateTime localDateTime15 = null;
//        boolean boolean16 = dateTimeZone13.isLocalDateTimeGap(localDateTime15);
//        java.lang.String str18 = dateTimeZone13.getName((long) '#');
//        int int20 = dateTimeZone13.getOffsetFromLocal((long) 10);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone13.getShortName((long) 10, locale22);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) 2, dateTimeZone13);
//        org.joda.time.LocalDate.Property property25 = localDate24.weekyear();
//        long long27 = limitChronology10.set((org.joda.time.ReadablePartial) localDate24, 43200000L);
//        org.joda.time.LocalDate localDate29 = localDate24.plusWeeks(1);
//        java.lang.String str30 = localDate24.toString();
//        org.joda.time.LocalDate localDate32 = localDate24.withYearOfEra((int) '#');
//        org.joda.time.LocalDate.Property property33 = localDate32.centuryOfEra();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.052" + "'", str18.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43200000L + "'", long27 == 43200000L);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970-01-01" + "'", str30.equals("1970-01-01"));
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(property33);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.joda.time.Instant instant5 = instant0.withDurationAdded((long) 82843301, 292278993);
        org.joda.time.DateTime dateTime6 = instant0.toDateTime();
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = null;
        int[] intArray6 = new int[] { 100, 2, 82841, (byte) 1, (short) 100 };
        org.joda.time.Chronology chronology7 = null;
        try {
            org.joda.time.Partial partial8 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray6, chronology7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        int int14 = localDate13.getYearOfCentury();
        org.joda.time.LocalDate.Property property15 = localDate13.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        int int12 = offsetDateTimeField10.getMaximumValue(100L);
        boolean boolean13 = offsetDateTimeField10.isSupported();
        java.lang.String str15 = offsetDateTimeField10.getAsShortText((long) 'a');
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField10.getAsShortText(2, locale17);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 78 + "'", int12 == 78);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "18" + "'", str15.equals("18"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2" + "'", str18.equals("2"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-1L), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        long long15 = skipUndoDateTimeField10.add(0L, (long) (short) 10);
        boolean boolean16 = skipUndoDateTimeField10.isLenient();
        int int17 = skipUndoDateTimeField10.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 432000000L + "'", long15 == 432000000L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.052", "1970-01-01", 365, (int) (byte) 1);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedDateTimeZone5.equals(obj6);
        org.joda.time.Chronology chronology8 = gJChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chronology8);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
//        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.DateTime dateTime7 = dateTime5.minusMinutes((int) ' ');
//        org.joda.time.DateTime dateTime9 = dateTime7.plus((long) (byte) 0);
//        int int10 = dateTime9.getDayOfWeek();
//        boolean boolean12 = dateTime9.isBefore(59948L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.weekyear();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.hourOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = iSOChronology20.minutes();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology17, dateTimeField22, (int) (byte) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField22, (int) (short) 0);
        java.lang.Object obj27 = null;
        boolean boolean28 = gJChronology14.equals(obj27);
        org.joda.time.Instant instant29 = gJChronology14.getGregorianCutover();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(instant29);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long5 = julianChronology0.getDateTimeMillis(365, (-49), 2, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -49 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        int int10 = dateTime8.getEra();
//        int int11 = dateTime8.getDayOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
//        org.joda.time.DateTime.Property property13 = dateTime8.dayOfWeek();
//        org.joda.time.DateTime.Property property14 = dateTime8.yearOfCentury();
//        org.joda.time.DateTime.Property property15 = dateTime8.millisOfSecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 166 + "'", int11 == 166);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = buddhistChronology13.withZone(dateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.LocalDateTime localDateTime20 = null;
        boolean boolean21 = dateTimeZone18.isLocalDateTimeGap(localDateTime20);
        java.lang.String str23 = dateTimeZone18.getName((long) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter16.withZone(dateTimeZone18);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology13, dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone26 = zonedChronology25.getZone();
        org.joda.time.DurationField durationField27 = zonedChronology25.weekyears();
        org.joda.time.DateTimeField dateTimeField28 = zonedChronology25.weekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
//        long long10 = skipDateTimeField7.set((-1L), (int) (byte) -1);
//        long long12 = skipDateTimeField7.roundHalfEven((long) 100);
//        int int14 = skipDateTimeField7.get((long) 100);
//        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property17 = localDate16.monthOfYear();
//        org.joda.time.LocalDate localDate19 = localDate16.withDayOfYear((int) (short) 1);
//        org.joda.time.Chronology chronology20 = localDate19.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
//        org.joda.time.LocalDateTime localDateTime27 = null;
//        boolean boolean28 = dateTimeZone25.isLocalDateTimeGap(localDateTime27);
//        java.lang.String str30 = dateTimeZone25.getName((long) '#');
//        int int32 = dateTimeZone25.getOffsetFromLocal((long) 10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone25);
//        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone33);
//        org.joda.time.Instant instant35 = new org.joda.time.Instant();
//        org.joda.time.Instant instant36 = new org.joda.time.Instant();
//        boolean boolean37 = instant35.isBefore((org.joda.time.ReadableInstant) instant36);
//        org.joda.time.Instant instant38 = new org.joda.time.Instant();
//        org.joda.time.Instant instant39 = new org.joda.time.Instant();
//        boolean boolean40 = instant38.isBefore((org.joda.time.ReadableInstant) instant39);
//        boolean boolean41 = instant36.isBefore((org.joda.time.ReadableInstant) instant38);
//        org.joda.time.Chronology chronology42 = instant38.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime43 = null;
//        org.joda.time.ReadableDateTime readableDateTime44 = null;
//        org.joda.time.chrono.LimitChronology limitChronology45 = org.joda.time.chrono.LimitChronology.getInstance(chronology42, readableDateTime43, readableDateTime44);
//        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone48);
//        org.joda.time.LocalDateTime localDateTime50 = null;
//        boolean boolean51 = dateTimeZone48.isLocalDateTimeGap(localDateTime50);
//        java.lang.String str53 = dateTimeZone48.getName((long) '#');
//        int int55 = dateTimeZone48.getOffsetFromLocal((long) 10);
//        java.util.Locale locale57 = null;
//        java.lang.String str58 = dateTimeZone48.getShortName((long) 10, locale57);
//        org.joda.time.LocalDate localDate59 = new org.joda.time.LocalDate((long) 2, dateTimeZone48);
//        org.joda.time.LocalDate.Property property60 = localDate59.weekyear();
//        long long62 = limitChronology45.set((org.joda.time.ReadablePartial) localDate59, 43200000L);
//        org.joda.time.LocalDate localDate64 = localDate59.plusWeeks(1);
//        boolean boolean65 = copticChronology34.equals((java.lang.Object) localDate59);
//        int[] intArray67 = iSOChronology23.get((org.joda.time.ReadablePartial) localDate59, (long) 4);
//        int int68 = skipDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) localDate19, intArray67);
//        int int70 = skipDateTimeField7.getLeapAmount((-315534719268L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-52L) + "'", long12 == (-52L));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(iSOChronology26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+00:00:00.052" + "'", str30.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 52 + "'", int32 == 52);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
//        org.junit.Assert.assertNotNull(copticChronology34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertNotNull(limitChronology45);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "+00:00:00.052" + "'", str53.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 52 + "'", int55 == 52);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "+00:00:00.052" + "'", str58.equals("+00:00:00.052"));
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 43200000L + "'", long62 == 43200000L);
//        org.junit.Assert.assertNotNull(localDate64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(intArray67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
//        org.joda.time.Instant instant8 = new org.joda.time.Instant();
//        org.joda.time.Instant instant9 = new org.joda.time.Instant();
//        boolean boolean10 = instant8.isBefore((org.joda.time.ReadableInstant) instant9);
//        org.joda.time.Instant instant11 = new org.joda.time.Instant();
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
//        boolean boolean14 = instant9.isBefore((org.joda.time.ReadableInstant) instant11);
//        org.joda.time.Chronology chronology15 = instant11.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime16 = null;
//        org.joda.time.ReadableDateTime readableDateTime17 = null;
//        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance(chronology15, readableDateTime16, readableDateTime17);
//        org.joda.time.Partial partial19 = new org.joda.time.Partial(chronology15);
//        int[] intArray27 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
//        int[] intArray29 = skipDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) partial19, (int) (short) 0, intArray27, (int) (short) 1);
//        org.joda.time.Instant instant30 = new org.joda.time.Instant();
//        org.joda.time.Instant instant31 = new org.joda.time.Instant();
//        boolean boolean32 = instant30.isBefore((org.joda.time.ReadableInstant) instant31);
//        org.joda.time.Instant instant33 = new org.joda.time.Instant();
//        org.joda.time.Instant instant34 = new org.joda.time.Instant();
//        boolean boolean35 = instant33.isBefore((org.joda.time.ReadableInstant) instant34);
//        boolean boolean36 = instant31.isBefore((org.joda.time.ReadableInstant) instant33);
//        org.joda.time.Chronology chronology37 = instant33.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime38 = null;
//        org.joda.time.ReadableDateTime readableDateTime39 = null;
//        org.joda.time.chrono.LimitChronology limitChronology40 = org.joda.time.chrono.LimitChronology.getInstance(chronology37, readableDateTime38, readableDateTime39);
//        org.joda.time.Partial partial41 = new org.joda.time.Partial(chronology37);
//        org.joda.time.Instant instant42 = new org.joda.time.Instant();
//        org.joda.time.Instant instant43 = new org.joda.time.Instant();
//        boolean boolean44 = instant42.isBefore((org.joda.time.ReadableInstant) instant43);
//        org.joda.time.Instant instant45 = new org.joda.time.Instant();
//        org.joda.time.Instant instant46 = new org.joda.time.Instant();
//        boolean boolean47 = instant45.isBefore((org.joda.time.ReadableInstant) instant46);
//        boolean boolean48 = instant43.isBefore((org.joda.time.ReadableInstant) instant45);
//        org.joda.time.Chronology chronology49 = instant45.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime50 = null;
//        org.joda.time.ReadableDateTime readableDateTime51 = null;
//        org.joda.time.chrono.LimitChronology limitChronology52 = org.joda.time.chrono.LimitChronology.getInstance(chronology49, readableDateTime50, readableDateTime51);
//        org.joda.time.Partial partial53 = new org.joda.time.Partial(chronology49);
//        org.joda.time.Instant instant54 = new org.joda.time.Instant();
//        org.joda.time.Instant instant55 = new org.joda.time.Instant();
//        boolean boolean56 = instant54.isBefore((org.joda.time.ReadableInstant) instant55);
//        org.joda.time.Instant instant57 = new org.joda.time.Instant();
//        org.joda.time.Instant instant58 = new org.joda.time.Instant();
//        boolean boolean59 = instant57.isBefore((org.joda.time.ReadableInstant) instant58);
//        boolean boolean60 = instant55.isBefore((org.joda.time.ReadableInstant) instant57);
//        org.joda.time.Chronology chronology61 = instant57.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime62 = null;
//        org.joda.time.ReadableDateTime readableDateTime63 = null;
//        org.joda.time.chrono.LimitChronology limitChronology64 = org.joda.time.chrono.LimitChronology.getInstance(chronology61, readableDateTime62, readableDateTime63);
//        org.joda.time.Partial partial65 = new org.joda.time.Partial(chronology61);
//        boolean boolean66 = partial53.isMatch((org.joda.time.ReadablePartial) partial65);
//        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone68);
//        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.clockhourOfHalfday();
//        org.joda.time.Partial partial71 = partial65.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology69);
//        boolean boolean72 = partial41.isMatch((org.joda.time.ReadablePartial) partial65);
//        int[] intArray75 = new int[] { (byte) -1 };
//        int[] intArray77 = skipDateTimeField7.add((org.joda.time.ReadablePartial) partial41, (int) (byte) 100, intArray75, (int) (byte) 0);
//        int int79 = skipDateTimeField7.getLeapAmount((long) 129);
//        int int80 = skipDateTimeField7.getMaximumValue();
//        int int83 = skipDateTimeField7.getDifference((long) 57600010, (long) 57600);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(limitChronology18);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertNotNull(intArray29);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(limitChronology40);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(limitChronology52);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertNotNull(chronology61);
//        org.junit.Assert.assertNotNull(limitChronology64);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertNotNull(iSOChronology69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(partial71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
//        org.junit.Assert.assertNotNull(intArray75);
//        org.junit.Assert.assertNotNull(intArray77);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 59 + "'", int80 == 59);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 959 + "'", int83 == 959);
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = iSOChronology6.add(readablePeriod8, 100L, 57600010);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.LocalDateTime localDateTime15 = null;
        boolean boolean16 = dateTimeZone13.isLocalDateTimeGap(localDateTime15);
        java.lang.String str18 = dateTimeZone13.getName((long) '#');
        int int20 = dateTimeZone13.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime21 = null;
        boolean boolean22 = dateTimeZone13.isLocalDateTimeGap(localDateTime21);
        long long24 = dateTimeZone13.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
        org.joda.time.Chronology chronology26 = iSOChronology6.withZone(dateTimeZone13);
        try {
            org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(4, 0, 0, 84480052, 2000, (int) '4', dateTimeZone13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 84480052 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.052" + "'", str18.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 53L + "'", long24 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(chronology26);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime dateTime10 = dateTime8.plusHours(10);
//        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfDay();
//        int int12 = dateTime8.getWeekOfWeekyear();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = instant1.isSupported(dateTimeFieldType3);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property7 = localDate6.monthOfYear();
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.monthOfYear();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
        int int14 = localDate6.get(dateTimeFieldType13);
        boolean boolean15 = instant1.isSupported(dateTimeFieldType13);
        try {
            org.joda.time.Partial partial17 = new org.joda.time.Partial(dateTimeFieldType13, 82841);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82841 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        int int14 = localDate13.getYearOfCentury();
        org.joda.time.LocalDate localDate16 = localDate13.withDayOfYear(129);
        org.joda.time.LocalDate localDate18 = localDate16.withDayOfWeek(3);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        int int12 = offsetDateTimeField10.getMaximumValue(2458650L);
        int int13 = offsetDateTimeField10.getMinimumValue();
        java.util.Locale locale14 = null;
        int int15 = offsetDateTimeField10.getMaximumShortTextLength(locale14);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 78 + "'", int12 == 78);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 18 + "'", int13 == 18);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.minutes();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField6, (int) (byte) 1);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) skipDateTimeField8, (int) (short) 1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 59);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }
}

