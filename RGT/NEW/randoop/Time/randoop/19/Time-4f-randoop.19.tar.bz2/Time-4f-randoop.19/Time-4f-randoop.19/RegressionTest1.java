import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.year();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone4.isLocalDateTimeGap(localDateTime6);
        java.lang.String str9 = dateTimeZone4.getName((long) '#');
        int int11 = dateTimeZone4.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.DateTime dateTime13 = localDate1.toDateTimeAtMidnight(dateTimeZone4);
        org.joda.time.DateTime dateTime15 = dateTime13.minus(43200000L);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.052" + "'", str9.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        int int14 = delegatedDateTimeField12.getMinimumValue((long) (short) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField12.getAsShortText(0L, locale16);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField12.getRangeDurationField();
        java.util.Locale locale19 = null;
        int int20 = delegatedDateTimeField12.getMaximumShortTextLength(locale19);
        java.util.Locale locale22 = null;
        try {
            java.lang.String str23 = delegatedDateTimeField12.getAsShortText(78, locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 78");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = julianChronology0.withZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone2);
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTimeZone2.getShortName((long) 57600010, locale7);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.052" + "'", str8.equals("+00:00:00.052"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.TimeZone timeZone3 = dateTimeZone1.toTimeZone();
        long long6 = dateTimeZone1.adjustOffset((long) '4', true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("00", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(57600010);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addCutover(82834373, '#', 4, (int) (short) 0, (-13), true, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        int int12 = offsetDateTimeField10.getMaximumValue(100L);
        boolean boolean13 = offsetDateTimeField10.isSupported();
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField10.getAsShortText(52, locale15);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 78 + "'", int12 == 78);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology2.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        org.joda.time.LocalDate localDate16 = localDate13.minusYears(57600);
        org.joda.time.ReadablePartial readablePartial17 = null;
        try {
            boolean boolean18 = localDate13.isEqual(readablePartial17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        long long9 = skipDateTimeField7.roundHalfFloor(100L);
        int int10 = skipDateTimeField7.getMinimumValue();
        try {
            long long13 = skipDateTimeField7.set((long) 1, 82841726);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82841726 for minuteOfHour must be in the range [-1,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-52L) + "'", long9 == (-52L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        boolean boolean9 = skipDateTimeField7.isSupported();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfMinute(57);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendTimeZoneOffset("82841", true, 1970, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay((int) 'a', 23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField10.getAsText((long) (short) 100, locale13);
        int int16 = skipUndoDateTimeField10.get((long) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        try {
            org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(copticChronology14);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
//        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
//        java.util.Locale locale6 = null;
//        java.util.Calendar calendar7 = dateTime5.toCalendar(locale6);
//        org.joda.time.DateTime dateTime8 = dateTime5.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property9.getAsShortText(locale10);
//        org.joda.time.DateTime dateTime13 = property9.setCopy(129);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(calendar7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "82866" + "'", str11.equals("82866"));
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("minuteOfHour", "129");
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
//        org.joda.time.Instant instant8 = new org.joda.time.Instant();
//        org.joda.time.Instant instant9 = new org.joda.time.Instant();
//        boolean boolean10 = instant8.isBefore((org.joda.time.ReadableInstant) instant9);
//        org.joda.time.Instant instant11 = new org.joda.time.Instant();
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
//        boolean boolean14 = instant9.isBefore((org.joda.time.ReadableInstant) instant11);
//        org.joda.time.Chronology chronology15 = instant11.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime16 = null;
//        org.joda.time.ReadableDateTime readableDateTime17 = null;
//        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance(chronology15, readableDateTime16, readableDateTime17);
//        org.joda.time.Partial partial19 = new org.joda.time.Partial(chronology15);
//        int[] intArray27 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
//        int[] intArray29 = skipDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) partial19, (int) (short) 0, intArray27, (int) (short) 1);
//        int int32 = skipDateTimeField7.getDifference((long) 52, (long) (byte) 100);
//        org.joda.time.DurationField durationField33 = skipDateTimeField7.getRangeDurationField();
//        try {
//            long long36 = skipDateTimeField7.set(6800L, 57600010);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600010 for minuteOfHour must be in the range [-1,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(limitChronology18);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertNotNull(intArray29);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(durationField33);
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
//        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
//        java.util.Locale locale6 = null;
//        java.util.Calendar calendar7 = dateTime5.toCalendar(locale6);
//        org.joda.time.DateTime dateTime8 = dateTime5.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime.Property property9 = dateTime8.secondOfDay();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = property9.getAsShortText(locale10);
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
//        org.joda.time.Instant instant15 = new org.joda.time.Instant();
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
//        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
//        org.joda.time.Chronology chronology19 = instant15.getChronology();
//        org.joda.time.DateTime dateTime20 = instant15.toDateTimeISO();
//        org.joda.time.DateTime.Property property21 = dateTime20.year();
//        int int22 = dateTime20.getEra();
//        int int23 = dateTime20.getDayOfYear();
//        org.joda.time.DateTime.Property property24 = dateTime20.yearOfEra();
//        int int25 = dateTime20.getMillisOfDay();
//        long long26 = dateTime20.getMillis();
//        org.joda.time.DateTime dateTime28 = dateTime20.withCenturyOfEra(2000);
//        int int29 = dateTime20.getSecondOfMinute();
//        long long30 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(calendar7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "82867" + "'", str11.equals("82867"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 166 + "'", int23 == 166);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 82867100 + "'", int25 == 82867100);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560639667048L + "'", long26 == 1560639667048L);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 7 + "'", int29 == 7);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        int int10 = dateTime8.getEra();
//        org.joda.time.DateTime dateTime12 = dateTime8.plusHours(82841726);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        org.joda.time.LocalDate localDate16 = localDate13.minusYears(57600);
        java.lang.String str17 = localDate16.toString();
        org.joda.time.Instant instant18 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.clockhourOfHalfday();
        org.joda.time.DurationField durationField23 = iSOChronology21.seconds();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.MutableDateTime mutableDateTime25 = instant18.toMutableDateTime((org.joda.time.Chronology) iSOChronology21);
        boolean boolean26 = localDate16.equals((java.lang.Object) instant18);
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Instant instant29 = instant18.withDurationAdded(readableDuration27, 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-55630-01-01" + "'", str17.equals("-55630-01-01"));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(instant29);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray4 = gregorianChronology0.get(readablePeriod2, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        long long7 = dateTimeZone4.convertLocalToUTC(0L, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-52L) + "'", long7 == (-52L));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (-57529L), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        int int11 = skipUndoDateTimeField10.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        java.lang.String str15 = copticChronology14.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "CopticChronology[+00:00:00.052]" + "'", str15.equals("CopticChronology[+00:00:00.052]"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField10.getAsText((long) (short) 100, locale13);
        java.util.Locale locale15 = null;
        int int16 = skipUndoDateTimeField10.getMaximumTextLength(locale15);
        org.joda.time.DurationField durationField17 = skipUndoDateTimeField10.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = dateTimeZone3.isLocalDateTimeGap(localDateTime5);
        java.lang.String str8 = dateTimeZone3.getName((long) '#');
        int int10 = dateTimeZone3.getOffsetFromLocal((long) 10);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone3.getShortName((long) 10, locale12);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) 2, dateTimeZone3);
        org.joda.time.LocalDate.Property property15 = localDate14.monthOfYear();
        int int16 = localDate14.getDayOfMonth();
        org.joda.time.Chronology chronology17 = localDate14.getChronology();
        int int18 = localDate14.getYearOfEra();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.LocalDateTime localDateTime23 = null;
        boolean boolean24 = dateTimeZone21.isLocalDateTimeGap(localDateTime23);
        java.lang.String str26 = dateTimeZone21.getName((long) '#');
        int int28 = dateTimeZone21.getOffsetFromLocal((long) 10);
        java.util.Locale locale30 = null;
        java.lang.String str31 = dateTimeZone21.getShortName((long) 10, locale30);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) 2, dateTimeZone21);
        int int33 = localDate32.getYearOfCentury();
        int int34 = localDate32.getDayOfYear();
        int int35 = localDate14.compareTo((org.joda.time.ReadablePartial) localDate32);
        boolean boolean36 = julianChronology0.equals((java.lang.Object) int35);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology37.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        long long42 = iSOChronology37.add(readablePeriod39, 100L, 57600010);
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
        org.joda.time.LocalDateTime localDateTime46 = null;
        boolean boolean47 = dateTimeZone44.isLocalDateTimeGap(localDateTime46);
        java.lang.String str49 = dateTimeZone44.getName((long) '#');
        int int51 = dateTimeZone44.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime52 = null;
        boolean boolean53 = dateTimeZone44.isLocalDateTimeGap(localDateTime52);
        long long55 = dateTimeZone44.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology56 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone44);
        org.joda.time.Chronology chronology57 = iSOChronology37.withZone(dateTimeZone44);
        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeZone dateTimeZone59 = julianChronology58.getZone();
        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 1);
        org.joda.time.LocalDate localDate62 = org.joda.time.LocalDate.now(dateTimeZone61);
        long long64 = dateTimeZone59.getMillisKeepLocal(dateTimeZone61, (long) 57600010);
        org.joda.time.Chronology chronology65 = julianChronology0.withZone(dateTimeZone61);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.052" + "'", str8.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00:00.052" + "'", str13.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1970 + "'", int18 == 1970);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00:00.052" + "'", str26.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00:00.052" + "'", str31.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 70 + "'", int33 == 70);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100L + "'", long42 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "+00:00:00.052" + "'", str49.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 52 + "'", int51 == 52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 53L + "'", long55 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology56);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(julianChronology58);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertNotNull(localDate62);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 57600061L + "'", long64 == 57600061L);
        org.junit.Assert.assertNotNull(chronology65);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        java.io.Writer writer1 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology4.getZone();
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(dateTimeZone5);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray7 = localDate6.getFieldTypes();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        org.joda.time.DurationField durationField12 = iSOChronology11.minutes();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology8, dateTimeField13, (int) (byte) 1);
//        long long18 = skipDateTimeField15.set((-1L), (int) (byte) -1);
//        long long20 = skipDateTimeField15.roundHalfEven((long) 100);
//        int int22 = skipDateTimeField15.get((long) 100);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property25 = localDate24.monthOfYear();
//        org.joda.time.LocalDate localDate27 = localDate24.withDayOfYear((int) (short) 1);
//        org.joda.time.Chronology chronology28 = localDate27.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
//        org.joda.time.LocalDateTime localDateTime35 = null;
//        boolean boolean36 = dateTimeZone33.isLocalDateTimeGap(localDateTime35);
//        java.lang.String str38 = dateTimeZone33.getName((long) '#');
//        int int40 = dateTimeZone33.getOffsetFromLocal((long) 10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone41 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone33);
//        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone41);
//        org.joda.time.Instant instant43 = new org.joda.time.Instant();
//        org.joda.time.Instant instant44 = new org.joda.time.Instant();
//        boolean boolean45 = instant43.isBefore((org.joda.time.ReadableInstant) instant44);
//        org.joda.time.Instant instant46 = new org.joda.time.Instant();
//        org.joda.time.Instant instant47 = new org.joda.time.Instant();
//        boolean boolean48 = instant46.isBefore((org.joda.time.ReadableInstant) instant47);
//        boolean boolean49 = instant44.isBefore((org.joda.time.ReadableInstant) instant46);
//        org.joda.time.Chronology chronology50 = instant46.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime51 = null;
//        org.joda.time.ReadableDateTime readableDateTime52 = null;
//        org.joda.time.chrono.LimitChronology limitChronology53 = org.joda.time.chrono.LimitChronology.getInstance(chronology50, readableDateTime51, readableDateTime52);
//        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology57 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone56);
//        org.joda.time.LocalDateTime localDateTime58 = null;
//        boolean boolean59 = dateTimeZone56.isLocalDateTimeGap(localDateTime58);
//        java.lang.String str61 = dateTimeZone56.getName((long) '#');
//        int int63 = dateTimeZone56.getOffsetFromLocal((long) 10);
//        java.util.Locale locale65 = null;
//        java.lang.String str66 = dateTimeZone56.getShortName((long) 10, locale65);
//        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((long) 2, dateTimeZone56);
//        org.joda.time.LocalDate.Property property68 = localDate67.weekyear();
//        long long70 = limitChronology53.set((org.joda.time.ReadablePartial) localDate67, 43200000L);
//        org.joda.time.LocalDate localDate72 = localDate67.plusWeeks(1);
//        boolean boolean73 = copticChronology42.equals((java.lang.Object) localDate67);
//        int[] intArray75 = iSOChronology31.get((org.joda.time.ReadablePartial) localDate67, (long) 4);
//        int int76 = skipDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate27, intArray75);
//        org.joda.time.chrono.ISOChronology iSOChronology77 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField78 = iSOChronology77.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField79 = iSOChronology77.hourOfHalfday();
//        org.joda.time.Partial partial80 = new org.joda.time.Partial(dateTimeFieldTypeArray7, intArray75, (org.joda.time.Chronology) iSOChronology77);
//        org.joda.time.ReadablePeriod readablePeriod81 = null;
//        org.joda.time.Partial partial83 = partial80.withPeriodAdded(readablePeriod81, 10);
//        org.joda.time.Instant instant84 = new org.joda.time.Instant();
//        org.joda.time.Instant instant85 = new org.joda.time.Instant();
//        boolean boolean86 = instant84.isBefore((org.joda.time.ReadableInstant) instant85);
//        org.joda.time.Instant instant87 = new org.joda.time.Instant();
//        org.joda.time.Instant instant88 = new org.joda.time.Instant();
//        boolean boolean89 = instant87.isBefore((org.joda.time.ReadableInstant) instant88);
//        boolean boolean90 = instant85.isBefore((org.joda.time.ReadableInstant) instant87);
//        org.joda.time.Chronology chronology91 = instant87.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime92 = null;
//        org.joda.time.ReadableDateTime readableDateTime93 = null;
//        org.joda.time.chrono.LimitChronology limitChronology94 = org.joda.time.chrono.LimitChronology.getInstance(chronology91, readableDateTime92, readableDateTime93);
//        org.joda.time.Chronology chronology95 = limitChronology94.withUTC();
//        org.joda.time.Partial partial96 = partial83.withChronologyRetainFields((org.joda.time.Chronology) limitChronology94);
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) partial83);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-52L) + "'", long20 == (-52L));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "+00:00:00.052" + "'", str38.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 52 + "'", int40 == 52);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone41);
//        org.junit.Assert.assertNotNull(copticChronology42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(limitChronology53);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertNotNull(iSOChronology57);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "+00:00:00.052" + "'", str61.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 52 + "'", int63 == 52);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "+00:00:00.052" + "'", str66.equals("+00:00:00.052"));
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 43200000L + "'", long70 == 43200000L);
//        org.junit.Assert.assertNotNull(localDate72);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNotNull(intArray75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology77);
//        org.junit.Assert.assertNotNull(dateTimeField78);
//        org.junit.Assert.assertNotNull(dateTimeField79);
//        org.junit.Assert.assertNotNull(partial83);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
//        org.junit.Assert.assertNotNull(chronology91);
//        org.junit.Assert.assertNotNull(limitChronology94);
//        org.junit.Assert.assertNotNull(chronology95);
//        org.junit.Assert.assertNotNull(partial96);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 2019");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfMinute(57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMillisOfDay((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusMonths(680);
//        org.joda.time.DateTime.Property property12 = dateTime8.centuryOfEra();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        int int10 = dateTime8.getEra();
//        int int11 = dateTime8.getDayOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
//        org.joda.time.DateTime.Property property13 = dateTime8.dayOfWeek();
//        int int14 = dateTime8.getEra();
//        org.joda.time.DateTime dateTime16 = dateTime8.withYear((int) (short) 0);
//        org.joda.time.DateTime.Property property17 = dateTime8.weekyear();
//        org.joda.time.DateTime dateTime19 = dateTime8.withWeekyear((int) (byte) 10);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 166 + "'", int11 == 166);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        int int12 = offsetDateTimeField10.getMaximumValue(2458650L);
        int int15 = offsetDateTimeField10.getDifference((long) 725, (long) 365);
        java.lang.String str16 = offsetDateTimeField10.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 78 + "'", int12 == 78);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str16.equals("DateTimeField[minuteOfHour]"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        boolean boolean3 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate1);
        int int4 = localDate1.getCenturyOfEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.year();
        org.joda.time.LocalDate.Property property3 = localDate1.centuryOfEra();
        org.joda.time.LocalDate localDate4 = property3.roundCeilingCopy();
        org.joda.time.LocalDate.Property property5 = localDate4.era();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMinutes((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plus((long) (byte) 0);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks(18);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("82867");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = buddhistChronology13.withZone(dateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.LocalDateTime localDateTime20 = null;
        boolean boolean21 = dateTimeZone18.isLocalDateTimeGap(localDateTime20);
        java.lang.String str23 = dateTimeZone18.getName((long) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter16.withZone(dateTimeZone18);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology13, dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone26 = zonedChronology25.getZone();
        org.joda.time.DurationField durationField27 = zonedChronology25.weekyears();
        java.lang.String str28 = zonedChronology25.toString();
        try {
            long long33 = zonedChronology25.getDateTimeMillis((int) (byte) 1, 82860538, 0, 105);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82860538 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ZonedChronology[BuddhistChronology[UTC], +00:00:00.052]" + "'", str28.equals("ZonedChronology[BuddhistChronology[UTC], +00:00:00.052]"));
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.LocalDateTime localDateTime4 = null;
//        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
//        java.lang.String str7 = dateTimeZone2.getName((long) '#');
//        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
//        org.joda.time.LocalDate.Property property14 = localDate13.weekyear();
//        org.joda.time.LocalDate localDate16 = localDate13.plusYears((int) (byte) 100);
//        org.joda.time.LocalDate localDate18 = localDate16.withWeekOfWeekyear((int) '4');
//        org.joda.time.Instant instant19 = new org.joda.time.Instant();
//        org.joda.time.Instant instant20 = new org.joda.time.Instant();
//        boolean boolean21 = instant19.isBefore((org.joda.time.ReadableInstant) instant20);
//        org.joda.time.Instant instant22 = new org.joda.time.Instant();
//        org.joda.time.Instant instant23 = new org.joda.time.Instant();
//        boolean boolean24 = instant22.isBefore((org.joda.time.ReadableInstant) instant23);
//        boolean boolean25 = instant20.isBefore((org.joda.time.ReadableInstant) instant22);
//        org.joda.time.Chronology chronology26 = instant22.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime27 = null;
//        org.joda.time.ReadableDateTime readableDateTime28 = null;
//        org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance(chronology26, readableDateTime27, readableDateTime28);
//        org.joda.time.Partial partial30 = new org.joda.time.Partial(chronology26);
//        org.joda.time.Instant instant31 = new org.joda.time.Instant();
//        org.joda.time.Instant instant32 = new org.joda.time.Instant();
//        boolean boolean33 = instant31.isBefore((org.joda.time.ReadableInstant) instant32);
//        org.joda.time.Instant instant34 = new org.joda.time.Instant();
//        org.joda.time.Instant instant35 = new org.joda.time.Instant();
//        boolean boolean36 = instant34.isBefore((org.joda.time.ReadableInstant) instant35);
//        boolean boolean37 = instant32.isBefore((org.joda.time.ReadableInstant) instant34);
//        org.joda.time.Chronology chronology38 = instant34.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime39 = null;
//        org.joda.time.ReadableDateTime readableDateTime40 = null;
//        org.joda.time.chrono.LimitChronology limitChronology41 = org.joda.time.chrono.LimitChronology.getInstance(chronology38, readableDateTime39, readableDateTime40);
//        org.joda.time.Partial partial42 = new org.joda.time.Partial(chronology38);
//        boolean boolean43 = partial30.isMatch((org.joda.time.ReadablePartial) partial42);
//        org.joda.time.ReadablePeriod readablePeriod44 = null;
//        org.joda.time.Partial partial45 = partial30.minus(readablePeriod44);
//        try {
//            boolean boolean46 = localDate16.isAfter((org.joda.time.ReadablePartial) partial45);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(limitChronology29);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(limitChronology41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertNotNull(partial45);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.LocalDateTime localDateTime15 = null;
        boolean boolean16 = dateTimeZone13.isLocalDateTimeGap(localDateTime15);
        java.lang.String str18 = dateTimeZone13.getName((long) '#');
        int int20 = dateTimeZone13.getOffsetFromLocal((long) 10);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone13.getShortName((long) 10, locale22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) 2, dateTimeZone13);
        org.joda.time.LocalDate.Property property25 = localDate24.weekyear();
        long long27 = limitChronology10.set((org.joda.time.ReadablePartial) localDate24, 43200000L);
        org.joda.time.LocalDate localDate29 = localDate24.plusWeeks(1);
        org.joda.time.LocalDate localDate31 = localDate24.withDayOfMonth(19);
        org.joda.time.LocalDate localDate33 = localDate31.plusYears(82841726);
        org.joda.time.LocalDate localDate35 = localDate33.withWeekyear(129);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.052" + "'", str18.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43200000L + "'", long27 == 43200000L);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(localDate35);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("00", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(57600010);
        java.io.OutputStream outputStream7 = null;
        try {
            dateTimeZoneBuilder5.writeTo("129", outputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        int int3 = property2.getMinimumValue();
        int int4 = property2.getMinimumValueOverall();
        org.joda.time.LocalDate localDate5 = property2.withMinimumValue();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = dateTimeZone5.isLocalDateTimeGap(localDateTime7);
        java.lang.String str10 = dateTimeZone5.getName((long) '#');
        int int12 = dateTimeZone5.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime13 = null;
        boolean boolean14 = dateTimeZone5.isLocalDateTimeGap(localDateTime13);
        long long16 = dateTimeZone5.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        try {
            org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((java.lang.Object) iSOChronology2, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.052" + "'", str10.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 53L + "'", long16 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology17);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("DateTimeField[minuteOfHour]", "1970-01-01");
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, 105433401600010L, 10);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 105433401600010L + "'", long4 == 105433401600010L);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        try {
            org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(copticChronology14);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        org.joda.time.LocalDate.Property property15 = localDate13.dayOfWeek();
        java.lang.String str16 = property15.getAsText();
        try {
            org.joda.time.LocalDate localDate18 = property15.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Thursday" + "'", str16.equals("Thursday"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.weekyear();
        java.lang.String str16 = gJChronology14.toString();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.LocalDateTime localDateTime20 = null;
        boolean boolean21 = dateTimeZone18.isLocalDateTimeGap(localDateTime20);
        java.lang.String str23 = dateTimeZone18.getName((long) '#');
        int int25 = dateTimeZone18.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone18.isLocalDateTimeGap(localDateTime26);
        boolean boolean29 = dateTimeZone18.isStandardOffset(1L);
        org.joda.time.Chronology chronology30 = gJChronology14.withZone(dateTimeZone18);
        java.lang.String str31 = dateTimeZone18.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "GJChronology[+00:00:00.052]" + "'", str16.equals("GJChronology[+00:00:00.052]"));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00:00.052" + "'", str31.equals("+00:00:00.052"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.weekyear();
        org.joda.time.DateTimeField dateTimeField15 = property14.getField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime8.withDurationAdded(readableDuration10, (int) ' ');
        java.util.Locale locale14 = null;
        try {
            java.lang.String str15 = dateTime12.toString("", locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.weekyear();
        java.lang.String str16 = gJChronology14.toString();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.LocalDateTime localDateTime21 = null;
        boolean boolean22 = dateTimeZone19.isLocalDateTimeGap(localDateTime21);
        java.lang.String str24 = dateTimeZone19.getName((long) '#');
        int int26 = dateTimeZone19.getOffsetFromLocal((long) 10);
        java.util.Locale locale28 = null;
        java.lang.String str29 = dateTimeZone19.getShortName((long) 10, locale28);
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) 2, dateTimeZone19);
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19);
        long long33 = dateTimeZone19.convertUTCToLocal(105433401600010L);
        org.joda.time.Chronology chronology34 = gJChronology14.withZone(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "GJChronology[+00:00:00.052]" + "'", str16.equals("GJChronology[+00:00:00.052]"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.052" + "'", str24.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+00:00:00.052" + "'", str29.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 105433401600062L + "'", long33 == 105433401600062L);
        org.junit.Assert.assertNotNull(chronology34);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfHalfday();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) 'a', (int) (short) 1, 680);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField4, 1970);
        try {
            long long15 = gregorianChronology0.getDateTimeMillis((int) ' ', (int) (byte) 0, 2922750, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("LimitChronology[ISOChronology[UTC], NoLimit, NoLimit]", 18, (-13), 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 18 for LimitChronology[ISOChronology[UTC], NoLimit, NoLimit] must be in the range [-13,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField10.getAsText((long) (short) 100, locale13);
        org.joda.time.DateTimeField dateTimeField15 = skipUndoDateTimeField10.getWrappedField();
        int int16 = skipUndoDateTimeField10.getMinimumValue();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, 52);
        int int20 = skipUndoDateTimeField10.get(7312048L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.LocalDate localDate6 = property3.setCopy(3);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes(70);
        org.joda.time.DateTime dateTime9 = dateTime5.withYearOfEra(52);
        org.joda.time.DateTime dateTime11 = dateTime5.plusDays(9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        int int14 = localDate13.getCenturyOfEra();
        org.joda.time.Interval interval15 = localDate13.toInterval();
        int int16 = localDate13.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
        org.junit.Assert.assertNotNull(interval15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
//        org.joda.time.Instant instant8 = new org.joda.time.Instant();
//        org.joda.time.Instant instant9 = new org.joda.time.Instant();
//        boolean boolean10 = instant8.isBefore((org.joda.time.ReadableInstant) instant9);
//        org.joda.time.Instant instant11 = new org.joda.time.Instant();
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
//        boolean boolean14 = instant9.isBefore((org.joda.time.ReadableInstant) instant11);
//        org.joda.time.Chronology chronology15 = instant11.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime16 = null;
//        org.joda.time.ReadableDateTime readableDateTime17 = null;
//        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance(chronology15, readableDateTime16, readableDateTime17);
//        org.joda.time.Partial partial19 = new org.joda.time.Partial(chronology15);
//        int[] intArray27 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
//        int[] intArray29 = skipDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) partial19, (int) (short) 0, intArray27, (int) (short) 1);
//        org.joda.time.Instant instant30 = new org.joda.time.Instant();
//        org.joda.time.Instant instant31 = new org.joda.time.Instant();
//        boolean boolean32 = instant30.isBefore((org.joda.time.ReadableInstant) instant31);
//        org.joda.time.Instant instant33 = new org.joda.time.Instant();
//        org.joda.time.Instant instant34 = new org.joda.time.Instant();
//        boolean boolean35 = instant33.isBefore((org.joda.time.ReadableInstant) instant34);
//        boolean boolean36 = instant31.isBefore((org.joda.time.ReadableInstant) instant33);
//        org.joda.time.Chronology chronology37 = instant33.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime38 = null;
//        org.joda.time.ReadableDateTime readableDateTime39 = null;
//        org.joda.time.chrono.LimitChronology limitChronology40 = org.joda.time.chrono.LimitChronology.getInstance(chronology37, readableDateTime38, readableDateTime39);
//        org.joda.time.Partial partial41 = new org.joda.time.Partial(chronology37);
//        org.joda.time.Instant instant42 = new org.joda.time.Instant();
//        org.joda.time.Instant instant43 = new org.joda.time.Instant();
//        boolean boolean44 = instant42.isBefore((org.joda.time.ReadableInstant) instant43);
//        org.joda.time.Instant instant45 = new org.joda.time.Instant();
//        org.joda.time.Instant instant46 = new org.joda.time.Instant();
//        boolean boolean47 = instant45.isBefore((org.joda.time.ReadableInstant) instant46);
//        boolean boolean48 = instant43.isBefore((org.joda.time.ReadableInstant) instant45);
//        org.joda.time.Chronology chronology49 = instant45.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime50 = null;
//        org.joda.time.ReadableDateTime readableDateTime51 = null;
//        org.joda.time.chrono.LimitChronology limitChronology52 = org.joda.time.chrono.LimitChronology.getInstance(chronology49, readableDateTime50, readableDateTime51);
//        org.joda.time.Partial partial53 = new org.joda.time.Partial(chronology49);
//        org.joda.time.Instant instant54 = new org.joda.time.Instant();
//        org.joda.time.Instant instant55 = new org.joda.time.Instant();
//        boolean boolean56 = instant54.isBefore((org.joda.time.ReadableInstant) instant55);
//        org.joda.time.Instant instant57 = new org.joda.time.Instant();
//        org.joda.time.Instant instant58 = new org.joda.time.Instant();
//        boolean boolean59 = instant57.isBefore((org.joda.time.ReadableInstant) instant58);
//        boolean boolean60 = instant55.isBefore((org.joda.time.ReadableInstant) instant57);
//        org.joda.time.Chronology chronology61 = instant57.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime62 = null;
//        org.joda.time.ReadableDateTime readableDateTime63 = null;
//        org.joda.time.chrono.LimitChronology limitChronology64 = org.joda.time.chrono.LimitChronology.getInstance(chronology61, readableDateTime62, readableDateTime63);
//        org.joda.time.Partial partial65 = new org.joda.time.Partial(chronology61);
//        boolean boolean66 = partial53.isMatch((org.joda.time.ReadablePartial) partial65);
//        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone68);
//        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.clockhourOfHalfday();
//        org.joda.time.Partial partial71 = partial65.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology69);
//        boolean boolean72 = partial41.isMatch((org.joda.time.ReadablePartial) partial65);
//        int[] intArray75 = new int[] { (byte) -1 };
//        int[] intArray77 = skipDateTimeField7.add((org.joda.time.ReadablePartial) partial41, (int) (byte) 100, intArray75, (int) (byte) 0);
//        int int79 = skipDateTimeField7.get(0L);
//        java.util.Locale locale81 = null;
//        java.lang.String str82 = skipDateTimeField7.getAsShortText(82841, locale81);
//        org.joda.time.DateTimeZone dateTimeZone84 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology85 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone84);
//        org.joda.time.DateTimeField dateTimeField86 = iSOChronology85.clockhourOfHalfday();
//        org.joda.time.DurationField durationField87 = iSOChronology85.seconds();
//        org.joda.time.DateTime dateTime88 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology85);
//        org.joda.time.DateTime.Property property89 = dateTime88.weekOfWeekyear();
//        org.joda.time.DateTime.Property property90 = dateTime88.year();
//        org.joda.time.DateTime dateTime92 = dateTime88.withMillis((long) 52);
//        org.joda.time.DateTime.Property property93 = dateTime88.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType94 = property93.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField98 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, dateTimeFieldType94, 1970, 82867100, 2);
//        org.joda.time.DateTimeField dateTimeField99 = offsetDateTimeField98.getWrappedField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(limitChronology18);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertNotNull(intArray29);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(limitChronology40);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology49);
//        org.junit.Assert.assertNotNull(limitChronology52);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertNotNull(chronology61);
//        org.junit.Assert.assertNotNull(limitChronology64);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertNotNull(iSOChronology69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(partial71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
//        org.junit.Assert.assertNotNull(intArray75);
//        org.junit.Assert.assertNotNull(intArray77);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "82841" + "'", str82.equals("82841"));
//        org.junit.Assert.assertNotNull(dateTimeZone84);
//        org.junit.Assert.assertNotNull(iSOChronology85);
//        org.junit.Assert.assertNotNull(dateTimeField86);
//        org.junit.Assert.assertNotNull(durationField87);
//        org.junit.Assert.assertNotNull(property89);
//        org.junit.Assert.assertNotNull(property90);
//        org.junit.Assert.assertNotNull(dateTime92);
//        org.junit.Assert.assertNotNull(property93);
//        org.junit.Assert.assertNotNull(dateTimeFieldType94);
//        org.junit.Assert.assertNotNull(dateTimeField99);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology2.yearOfEra();
        org.joda.time.DurationField durationField12 = iSOChronology2.eras();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        try {
            int[] intArray16 = iSOChronology2.get(readablePeriod13, (long) 129, (long) 20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.Partial partial0 = new org.joda.time.Partial();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        org.joda.time.Instant instant2 = new org.joda.time.Instant();
//        boolean boolean3 = instant1.isBefore((org.joda.time.ReadableInstant) instant2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        boolean boolean5 = instant2.isSupported(dateTimeFieldType4);
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property8 = localDate7.monthOfYear();
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property11 = localDate10.monthOfYear();
//        java.util.Locale locale12 = null;
//        int int13 = property11.getMaximumTextLength(locale12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        int int15 = localDate7.get(dateTimeFieldType14);
//        boolean boolean16 = instant2.isSupported(dateTimeFieldType14);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 39641045L, "ISOChronology[+00:00:00.052]");
//        try {
//            org.joda.time.Partial partial21 = partial0.withField(dateTimeFieldType14, 2019);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'monthOfYear' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
        org.joda.time.Partial partial25 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial23);
        java.lang.String str26 = partial23.toStringList();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "[]" + "'", str26.equals("[]"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("52", (java.lang.Number) 1.0f, (java.lang.Number) 35, (java.lang.Number) (short) 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField10.getRangeDurationField();
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField14 = new org.joda.time.field.DecoratedDurationField(durationField12, durationFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property2 = localDate1.year();
//        org.joda.time.LocalDate.Property property3 = localDate1.centuryOfEra();
//        org.joda.time.LocalDate localDate4 = property3.roundCeilingCopy();
//        org.joda.time.Instant instant5 = new org.joda.time.Instant();
//        org.joda.time.Instant instant6 = new org.joda.time.Instant();
//        boolean boolean7 = instant5.isBefore((org.joda.time.ReadableInstant) instant6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        boolean boolean9 = instant6.isSupported(dateTimeFieldType8);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property12 = localDate11.monthOfYear();
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property15 = localDate14.monthOfYear();
//        java.util.Locale locale16 = null;
//        int int17 = property15.getMaximumTextLength(locale16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property15.getFieldType();
//        int int19 = localDate11.get(dateTimeFieldType18);
//        boolean boolean20 = instant6.isSupported(dateTimeFieldType18);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 39641045L, "ISOChronology[+00:00:00.052]");
//        try {
//            org.joda.time.LocalDate localDate25 = localDate4.withField(dateTimeFieldType18, 332);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 332 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        int int10 = dateTime8.getEra();
//        int int11 = dateTime8.getDayOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
//        org.joda.time.DateTime.Property property13 = dateTime8.dayOfWeek();
//        org.joda.time.DateTime dateTime15 = dateTime8.withCenturyOfEra(57600);
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property18 = localDate17.monthOfYear();
//        java.util.Locale locale19 = null;
//        int int20 = property18.getMaximumTextLength(locale19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property18.getFieldType();
//        int int22 = dateTime8.get(dateTimeFieldType21);
//        try {
//            org.joda.time.Partial partial24 = new org.joda.time.Partial(dateTimeFieldType21, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must not be larger than 12");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 166 + "'", int11 == 166);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9 + "'", int20 == 9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.era();
        int int16 = gJChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.LocalDateTime localDateTime15 = null;
//        boolean boolean16 = dateTimeZone13.isLocalDateTimeGap(localDateTime15);
//        java.lang.String str18 = dateTimeZone13.getName((long) '#');
//        int int20 = dateTimeZone13.getOffsetFromLocal((long) 10);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone13.getShortName((long) 10, locale22);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) 2, dateTimeZone13);
//        org.joda.time.LocalDate.Property property25 = localDate24.weekyear();
//        long long27 = limitChronology10.set((org.joda.time.ReadablePartial) localDate24, 43200000L);
//        org.joda.time.LocalDate localDate29 = localDate24.plusWeeks(1);
//        org.joda.time.LocalDate localDate31 = localDate24.withDayOfMonth(19);
//        org.joda.time.LocalDate.Property property32 = localDate24.year();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.052" + "'", str18.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43200000L + "'", long27 == 43200000L);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(property32);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField10 = iSOChronology0.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        int int10 = dateTime8.getEra();
//        int int11 = dateTime8.getDayOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
//        org.joda.time.DateTime.Property property13 = dateTime8.dayOfWeek();
//        org.joda.time.DateTime dateTime15 = dateTime8.withCenturyOfEra(57600);
//        org.joda.time.MutableDateTime mutableDateTime16 = dateTime8.toMutableDateTimeISO();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 166 + "'", int11 == 166);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronology();
        try {
            org.joda.time.LocalTime localTime5 = dateTimeFormatter2.parseLocalTime("+00:00:00.052");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00:00.052\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property2 = localDate1.year();
//        org.joda.time.LocalDate.Property property3 = localDate1.centuryOfEra();
//        int int4 = localDate1.getYear();
//        org.joda.time.Instant instant5 = new org.joda.time.Instant();
//        org.joda.time.Instant instant6 = new org.joda.time.Instant();
//        boolean boolean7 = instant5.isBefore((org.joda.time.ReadableInstant) instant6);
//        org.joda.time.Instant instant8 = new org.joda.time.Instant();
//        org.joda.time.Instant instant9 = new org.joda.time.Instant();
//        boolean boolean10 = instant8.isBefore((org.joda.time.ReadableInstant) instant9);
//        boolean boolean11 = instant6.isBefore((org.joda.time.ReadableInstant) instant8);
//        org.joda.time.Chronology chronology12 = instant8.getChronology();
//        org.joda.time.DateTime dateTime13 = instant8.toDateTimeISO();
//        org.joda.time.DateTime.Property property14 = dateTime13.year();
//        int int15 = dateTime13.getEra();
//        int int16 = dateTime13.getDayOfYear();
//        org.joda.time.DateTime.Property property17 = dateTime13.yearOfEra();
//        org.joda.time.DateTime.Property property18 = dateTime13.dayOfWeek();
//        org.joda.time.DateTime dateTime20 = dateTime13.withCenturyOfEra(57600);
//        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property23 = localDate22.monthOfYear();
//        java.util.Locale locale24 = null;
//        int int25 = property23.getMaximumTextLength(locale24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property23.getFieldType();
//        int int27 = dateTime13.get(dateTimeFieldType26);
//        try {
//            org.joda.time.LocalDate localDate29 = localDate1.withField(dateTimeFieldType26, 2000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 166 + "'", int16 == 166);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.DateTime dateTime2 = localDate1.toDateTimeAtCurrentTime();
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.LocalDate localDate4 = localDate1.minus(readablePeriod3);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.052", "1970-01-01", 365, (int) (byte) 1);
//        org.joda.time.DateTime dateTime10 = localDate4.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) fixedDateTimeZone9);
//        int int11 = localDate4.getYear();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.LocalDate localDate13 = localDate4.plus(readablePeriod12);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
//        org.junit.Assert.assertNotNull(localDate13);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds((int) (byte) 1);
//        int int12 = dateTime8.getDayOfYear();
//        java.util.Date date13 = dateTime8.toDate();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
//        org.joda.time.LocalDateTime localDateTime18 = null;
//        boolean boolean19 = dateTimeZone16.isLocalDateTimeGap(localDateTime18);
//        java.lang.String str21 = dateTimeZone16.getName((long) '#');
//        int int23 = dateTimeZone16.getOffsetFromLocal((long) 10);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone16.getShortName((long) 10, locale25);
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((long) 2, dateTimeZone16);
//        org.joda.time.LocalDate.Property property28 = localDate27.monthOfYear();
//        org.joda.time.LocalDate.Property property29 = localDate27.dayOfWeek();
//        org.joda.time.DateTime dateTime30 = dateTime8.withFields((org.joda.time.ReadablePartial) localDate27);
//        int int31 = dateTime8.getSecondOfDay();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 166 + "'", int12 == 166);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.052" + "'", str21.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00:00.052" + "'", str26.equals("+00:00:00.052"));
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 82875 + "'", int31 == 82875);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.String str1 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
//        org.joda.time.Instant instant8 = new org.joda.time.Instant();
//        org.joda.time.Instant instant9 = new org.joda.time.Instant();
//        boolean boolean10 = instant8.isBefore((org.joda.time.ReadableInstant) instant9);
//        org.joda.time.Instant instant11 = new org.joda.time.Instant();
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
//        boolean boolean14 = instant9.isBefore((org.joda.time.ReadableInstant) instant11);
//        org.joda.time.Chronology chronology15 = instant11.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime16 = null;
//        org.joda.time.ReadableDateTime readableDateTime17 = null;
//        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance(chronology15, readableDateTime16, readableDateTime17);
//        org.joda.time.Partial partial19 = new org.joda.time.Partial(chronology15);
//        int[] intArray27 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
//        int[] intArray29 = skipDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) partial19, (int) (short) 0, intArray27, (int) (short) 1);
//        int int32 = skipDateTimeField7.getDifference((long) 52, (long) (byte) 100);
//        long long35 = skipDateTimeField7.set((long) 24, 52);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(limitChronology18);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertNotNull(intArray29);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 3120024L + "'", long35 == 3120024L);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.LocalDateTime localDateTime5 = null;
//        boolean boolean6 = dateTimeZone3.isLocalDateTimeGap(localDateTime5);
//        java.lang.String str8 = dateTimeZone3.getName((long) '#');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter1.withZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.parse("0", dateTimeFormatter1);
//        org.joda.time.Instant instant11 = new org.joda.time.Instant();
//        org.joda.time.Instant instant12 = new org.joda.time.Instant();
//        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
//        org.joda.time.Instant instant14 = new org.joda.time.Instant();
//        org.joda.time.Instant instant15 = new org.joda.time.Instant();
//        boolean boolean16 = instant14.isBefore((org.joda.time.ReadableInstant) instant15);
//        boolean boolean17 = instant12.isBefore((org.joda.time.ReadableInstant) instant14);
//        org.joda.time.Chronology chronology18 = instant14.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime19 = null;
//        org.joda.time.ReadableDateTime readableDateTime20 = null;
//        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance(chronology18, readableDateTime19, readableDateTime20);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
//        org.joda.time.LocalDateTime localDateTime26 = null;
//        boolean boolean27 = dateTimeZone24.isLocalDateTimeGap(localDateTime26);
//        java.lang.String str29 = dateTimeZone24.getName((long) '#');
//        int int31 = dateTimeZone24.getOffsetFromLocal((long) 10);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = dateTimeZone24.getShortName((long) 10, locale33);
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) 2, dateTimeZone24);
//        org.joda.time.LocalDate.Property property36 = localDate35.weekyear();
//        long long38 = limitChronology21.set((org.joda.time.ReadablePartial) localDate35, 43200000L);
//        org.joda.time.LocalDate localDate40 = localDate35.plusWeeks(1);
//        org.joda.time.LocalDate localDate42 = localDate35.withDayOfMonth(19);
//        org.joda.time.ReadablePeriod readablePeriod43 = null;
//        org.joda.time.LocalDate localDate44 = localDate42.plus(readablePeriod43);
//        java.lang.String str45 = dateTimeFormatter1.print((org.joda.time.ReadablePartial) localDate44);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.052" + "'", str8.equals("+00:00:00.052"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(limitChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+00:00:00.052" + "'", str29.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 52 + "'", int31 == 52);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "+00:00:00.052" + "'", str34.equals("+00:00:00.052"));
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43200000L + "'", long38 == 43200000L);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "��" + "'", str45.equals("��"));
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((long) 'a');
        org.joda.time.DateTime dateTime9 = property6.roundFloorCopy();
        org.joda.time.DateTime dateTime11 = property6.addToCopy((-1));
        java.util.Date date12 = dateTime11.toDate();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date12);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
//        boolean boolean1 = dateTimeFormatter0.isParser();
//        java.lang.String str3 = dateTimeFormatter0.print(10L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01" + "'", str3.equals("1970-01"));
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        org.joda.time.LocalDate localDate16 = localDate13.minusYears(57600);
        java.lang.String str17 = localDate16.toString();
        try {
            org.joda.time.DateTimeField dateTimeField19 = localDate16.getField(82867100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 82867100");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-55630-01-01" + "'", str17.equals("-55630-01-01"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        long long13 = offsetDateTimeField10.add((long) 680, 9L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 540680L + "'", long13 == 540680L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) 100, (java.lang.Number) 57600010, (java.lang.Number) 100L);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 57600010 + "'", number6.equals(57600010));
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = partial11.getFormatter();
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property15 = localDate14.monthOfYear();
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property18 = localDate17.monthOfYear();
//        java.util.Locale locale19 = null;
//        int int20 = property18.getMaximumTextLength(locale19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property18.getFieldType();
//        int int22 = localDate14.get(dateTimeFieldType21);
//        try {
//            org.joda.time.Partial partial24 = partial11.withField(dateTimeFieldType21, 680);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'monthOfYear' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9 + "'", int20 == 9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        illegalFieldValueException2.prependMessage("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException8.getDurationFieldType();
        illegalFieldValueException8.prependMessage("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException8);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Number number14 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(durationFieldType9);
        org.junit.Assert.assertNull(dateTimeFieldType13);
        org.junit.Assert.assertNull(number14);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.052", "+00:00:00.052", 35, 84480732);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey(39641045L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 82867100, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey((long) 673);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("00", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(57600010);
        java.io.DataOutput dataOutput7 = null;
        try {
            dateTimeZoneBuilder5.writeTo("00", dataOutput7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(680, (int) (byte) 100, (int) '#', 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.monthOfYear();
        boolean boolean3 = instant0.equals((java.lang.Object) dateTimeField2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant0.plus(readableDuration4);
        org.joda.time.MutableDateTime mutableDateTime6 = instant5.toMutableDateTime();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DurationField durationField11 = iSOChronology2.weeks();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.DurationField durationField5 = property3.getRangeDurationField();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property8 = localDate7.monthOfYear();
        int int9 = property3.compareTo((org.joda.time.ReadablePartial) localDate7);
        java.util.Locale locale10 = null;
        int int11 = property3.getMaximumShortTextLength(locale10);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.DurationField durationField5 = property3.getRangeDurationField();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property8 = localDate7.monthOfYear();
        int int9 = property3.compareTo((org.joda.time.ReadablePartial) localDate7);
        int int10 = property3.getMaximumValueOverall();
        int int11 = property3.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292278993 + "'", int10 == 292278993);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 292278993 + "'", int11 == 292278993);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        java.lang.String str12 = cachedDateTimeZone9.getNameKey((long) 35);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNull(str12);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime dateTime10 = dateTime8.plusHours(10);
//        org.joda.time.DateTime dateTime11 = dateTime8.toDateTimeISO();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 1);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) 82841045);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds((int) (byte) 1);
//        int int12 = dateTime8.getDayOfYear();
//        java.util.Date date13 = dateTime8.toDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear(0);
//        try {
//            java.lang.String str17 = dateTime8.toString(dateTimeFormatter16);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 166 + "'", int12 == 166);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        boolean boolean4 = instant1.isSupported(dateTimeFieldType3);
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property7 = localDate6.monthOfYear();
//        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
//        org.joda.time.LocalDate.Property property10 = localDate9.monthOfYear();
//        java.util.Locale locale11 = null;
//        int int12 = property10.getMaximumTextLength(locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
//        int int14 = localDate6.get(dateTimeFieldType13);
//        boolean boolean15 = instant1.isSupported(dateTimeFieldType13);
//        org.joda.time.Instant instant16 = new org.joda.time.Instant();
//        org.joda.time.Instant instant17 = new org.joda.time.Instant();
//        boolean boolean18 = instant16.isBefore((org.joda.time.ReadableInstant) instant17);
//        org.joda.time.Instant instant19 = new org.joda.time.Instant();
//        org.joda.time.Instant instant20 = new org.joda.time.Instant();
//        boolean boolean21 = instant19.isBefore((org.joda.time.ReadableInstant) instant20);
//        boolean boolean22 = instant17.isBefore((org.joda.time.ReadableInstant) instant19);
//        org.joda.time.Chronology chronology23 = instant19.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime24 = null;
//        org.joda.time.ReadableDateTime readableDateTime25 = null;
//        org.joda.time.chrono.LimitChronology limitChronology26 = org.joda.time.chrono.LimitChronology.getInstance(chronology23, readableDateTime24, readableDateTime25);
//        org.joda.time.Chronology chronology27 = limitChronology26.withUTC();
//        org.joda.time.DurationField durationField28 = limitChronology26.millis();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int30 = gregorianChronology29.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField31 = gregorianChronology29.eras();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField32 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType13, durationField28, durationField31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The effective range must be at least 2");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(limitChronology26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
//        org.junit.Assert.assertNotNull(durationField31);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.io.Writer writer3 = null;
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            dateTimeFormatter0.printTo(writer3, readablePartial4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DurationField durationField16 = iSOChronology15.minutes();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField17, (int) (byte) 1);
//        org.joda.time.Instant instant20 = new org.joda.time.Instant();
//        org.joda.time.Instant instant21 = new org.joda.time.Instant();
//        boolean boolean22 = instant20.isBefore((org.joda.time.ReadableInstant) instant21);
//        org.joda.time.Instant instant23 = new org.joda.time.Instant();
//        org.joda.time.Instant instant24 = new org.joda.time.Instant();
//        boolean boolean25 = instant23.isBefore((org.joda.time.ReadableInstant) instant24);
//        boolean boolean26 = instant21.isBefore((org.joda.time.ReadableInstant) instant23);
//        org.joda.time.Chronology chronology27 = instant23.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime28 = null;
//        org.joda.time.ReadableDateTime readableDateTime29 = null;
//        org.joda.time.chrono.LimitChronology limitChronology30 = org.joda.time.chrono.LimitChronology.getInstance(chronology27, readableDateTime28, readableDateTime29);
//        org.joda.time.Partial partial31 = new org.joda.time.Partial(chronology27);
//        int[] intArray39 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
//        int[] intArray41 = skipDateTimeField19.addWrapPartial((org.joda.time.ReadablePartial) partial31, (int) (short) 0, intArray39, (int) (short) 1);
//        int int44 = skipDateTimeField19.getDifference((long) 52, (long) (byte) 100);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField(chronology7, (org.joda.time.DateTimeField) skipDateTimeField19);
//        int int48 = skipDateTimeField19.getDifference(0L, (long) (byte) -1);
//        int int50 = skipDateTimeField19.get(0L);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(limitChronology30);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertNotNull(intArray41);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfMinute(57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendDayOfMonth(20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
        org.joda.time.Instant instant14 = new org.joda.time.Instant();
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        boolean boolean16 = instant14.isBefore((org.joda.time.ReadableInstant) instant15);
        boolean boolean17 = instant12.isBefore((org.joda.time.ReadableInstant) instant14);
        org.joda.time.Chronology chronology18 = instant14.getChronology();
        org.joda.time.ReadableDateTime readableDateTime19 = null;
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance(chronology18, readableDateTime19, readableDateTime20);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone24.isLocalDateTimeGap(localDateTime26);
        java.lang.String str29 = dateTimeZone24.getName((long) '#');
        int int31 = dateTimeZone24.getOffsetFromLocal((long) 10);
        java.util.Locale locale33 = null;
        java.lang.String str34 = dateTimeZone24.getShortName((long) 10, locale33);
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) 2, dateTimeZone24);
        org.joda.time.LocalDate.Property property36 = localDate35.weekyear();
        long long38 = limitChronology21.set((org.joda.time.ReadablePartial) localDate35, 43200000L);
        org.joda.time.LocalDate localDate40 = localDate35.plusWeeks(1);
        boolean boolean41 = copticChronology10.equals((java.lang.Object) localDate35);
        org.joda.time.LocalDate.Property property42 = localDate35.centuryOfEra();
        org.joda.time.LocalDate localDate43 = property42.roundHalfCeilingCopy();
        try {
            org.joda.time.LocalDate localDate45 = localDate43.withDayOfMonth((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(limitChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+00:00:00.052" + "'", str29.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 52 + "'", int31 == 52);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "+00:00:00.052" + "'", str34.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43200000L + "'", long38 == 43200000L);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(localDate43);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        java.util.Locale locale3 = null;
        int int4 = property2.getMaximumTextLength(locale3);
        org.joda.time.DurationField durationField5 = property2.getLeapDurationField();
        long long8 = durationField5.subtract(105433401600062L, 2000);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 105260601600062L + "'", long8 == 105260601600062L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        boolean boolean4 = instant2.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        boolean boolean7 = instant5.isBefore((org.joda.time.ReadableInstant) instant6);
        boolean boolean8 = instant3.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Chronology chronology9 = instant5.getChronology();
        org.joda.time.ReadableDateTime readableDateTime10 = null;
        org.joda.time.ReadableDateTime readableDateTime11 = null;
        org.joda.time.chrono.LimitChronology limitChronology12 = org.joda.time.chrono.LimitChronology.getInstance(chronology9, readableDateTime10, readableDateTime11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.LocalDateTime localDateTime17 = null;
        boolean boolean18 = dateTimeZone15.isLocalDateTimeGap(localDateTime17);
        java.lang.String str20 = dateTimeZone15.getName((long) '#');
        int int22 = dateTimeZone15.getOffsetFromLocal((long) 10);
        java.util.Locale locale24 = null;
        java.lang.String str25 = dateTimeZone15.getShortName((long) 10, locale24);
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) 2, dateTimeZone15);
        org.joda.time.LocalDate.Property property27 = localDate26.weekyear();
        long long29 = limitChronology12.set((org.joda.time.ReadablePartial) localDate26, 43200000L);
        org.joda.time.LocalDate localDate31 = localDate26.plusWeeks(1);
        java.lang.String str32 = localDate26.toString();
        java.lang.String str33 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate26);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(limitChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00:00.052" + "'", str20.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.052" + "'", str25.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43200000L + "'", long29 == 43200000L);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1970-01-01" + "'", str32.equals("1970-01-01"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1970-01-01T��" + "'", str33.equals("1970-01-01T��"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField16 = iSOChronology15.minutes();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField17, (int) (byte) 1);
        org.joda.time.Instant instant20 = new org.joda.time.Instant();
        org.joda.time.Instant instant21 = new org.joda.time.Instant();
        boolean boolean22 = instant20.isBefore((org.joda.time.ReadableInstant) instant21);
        org.joda.time.Instant instant23 = new org.joda.time.Instant();
        org.joda.time.Instant instant24 = new org.joda.time.Instant();
        boolean boolean25 = instant23.isBefore((org.joda.time.ReadableInstant) instant24);
        boolean boolean26 = instant21.isBefore((org.joda.time.ReadableInstant) instant23);
        org.joda.time.Chronology chronology27 = instant23.getChronology();
        org.joda.time.ReadableDateTime readableDateTime28 = null;
        org.joda.time.ReadableDateTime readableDateTime29 = null;
        org.joda.time.chrono.LimitChronology limitChronology30 = org.joda.time.chrono.LimitChronology.getInstance(chronology27, readableDateTime28, readableDateTime29);
        org.joda.time.Partial partial31 = new org.joda.time.Partial(chronology27);
        int[] intArray39 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
        int[] intArray41 = skipDateTimeField19.addWrapPartial((org.joda.time.ReadablePartial) partial31, (int) (short) 0, intArray39, (int) (short) 1);
        int int44 = skipDateTimeField19.getDifference((long) 52, (long) (byte) 100);
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField(chronology7, (org.joda.time.DateTimeField) skipDateTimeField19);
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone48);
        org.joda.time.DurationField durationField50 = iSOChronology49.minutes();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology46, dateTimeField51, (int) (byte) 1);
        int int54 = skipDateTimeField53.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, (org.joda.time.DateTimeField) skipDateTimeField53, (int) ' ');
        java.util.Locale locale58 = null;
        java.lang.String str59 = skipUndoDateTimeField56.getAsText((-55630), locale58);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(limitChronology30);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "-55630" + "'", str59.equals("-55630"));
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
//        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        org.joda.time.DateTime dateTime9 = dateTime5.withMillis((long) 52);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = iSOChronology13.minutes();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.minuteOfHour();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology10, dateTimeField15, (int) (byte) 1);
//        org.joda.time.Instant instant18 = new org.joda.time.Instant();
//        org.joda.time.Instant instant19 = new org.joda.time.Instant();
//        boolean boolean20 = instant18.isBefore((org.joda.time.ReadableInstant) instant19);
//        org.joda.time.Instant instant21 = new org.joda.time.Instant();
//        org.joda.time.Instant instant22 = new org.joda.time.Instant();
//        boolean boolean23 = instant21.isBefore((org.joda.time.ReadableInstant) instant22);
//        boolean boolean24 = instant19.isBefore((org.joda.time.ReadableInstant) instant21);
//        org.joda.time.Chronology chronology25 = instant21.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime26 = null;
//        org.joda.time.ReadableDateTime readableDateTime27 = null;
//        org.joda.time.chrono.LimitChronology limitChronology28 = org.joda.time.chrono.LimitChronology.getInstance(chronology25, readableDateTime26, readableDateTime27);
//        org.joda.time.Partial partial29 = new org.joda.time.Partial(chronology25);
//        int[] intArray37 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
//        int[] intArray39 = skipDateTimeField17.addWrapPartial((org.joda.time.ReadablePartial) partial29, (int) (short) 0, intArray37, (int) (short) 1);
//        org.joda.time.Instant instant40 = new org.joda.time.Instant();
//        org.joda.time.Instant instant41 = new org.joda.time.Instant();
//        boolean boolean42 = instant40.isBefore((org.joda.time.ReadableInstant) instant41);
//        org.joda.time.Instant instant43 = new org.joda.time.Instant();
//        org.joda.time.Instant instant44 = new org.joda.time.Instant();
//        boolean boolean45 = instant43.isBefore((org.joda.time.ReadableInstant) instant44);
//        boolean boolean46 = instant41.isBefore((org.joda.time.ReadableInstant) instant43);
//        org.joda.time.Chronology chronology47 = instant43.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime48 = null;
//        org.joda.time.ReadableDateTime readableDateTime49 = null;
//        org.joda.time.chrono.LimitChronology limitChronology50 = org.joda.time.chrono.LimitChronology.getInstance(chronology47, readableDateTime48, readableDateTime49);
//        org.joda.time.Partial partial51 = new org.joda.time.Partial(chronology47);
//        org.joda.time.Instant instant52 = new org.joda.time.Instant();
//        org.joda.time.Instant instant53 = new org.joda.time.Instant();
//        boolean boolean54 = instant52.isBefore((org.joda.time.ReadableInstant) instant53);
//        org.joda.time.Instant instant55 = new org.joda.time.Instant();
//        org.joda.time.Instant instant56 = new org.joda.time.Instant();
//        boolean boolean57 = instant55.isBefore((org.joda.time.ReadableInstant) instant56);
//        boolean boolean58 = instant53.isBefore((org.joda.time.ReadableInstant) instant55);
//        org.joda.time.Chronology chronology59 = instant55.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime60 = null;
//        org.joda.time.ReadableDateTime readableDateTime61 = null;
//        org.joda.time.chrono.LimitChronology limitChronology62 = org.joda.time.chrono.LimitChronology.getInstance(chronology59, readableDateTime60, readableDateTime61);
//        org.joda.time.Partial partial63 = new org.joda.time.Partial(chronology59);
//        org.joda.time.Instant instant64 = new org.joda.time.Instant();
//        org.joda.time.Instant instant65 = new org.joda.time.Instant();
//        boolean boolean66 = instant64.isBefore((org.joda.time.ReadableInstant) instant65);
//        org.joda.time.Instant instant67 = new org.joda.time.Instant();
//        org.joda.time.Instant instant68 = new org.joda.time.Instant();
//        boolean boolean69 = instant67.isBefore((org.joda.time.ReadableInstant) instant68);
//        boolean boolean70 = instant65.isBefore((org.joda.time.ReadableInstant) instant67);
//        org.joda.time.Chronology chronology71 = instant67.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime72 = null;
//        org.joda.time.ReadableDateTime readableDateTime73 = null;
//        org.joda.time.chrono.LimitChronology limitChronology74 = org.joda.time.chrono.LimitChronology.getInstance(chronology71, readableDateTime72, readableDateTime73);
//        org.joda.time.Partial partial75 = new org.joda.time.Partial(chronology71);
//        boolean boolean76 = partial63.isMatch((org.joda.time.ReadablePartial) partial75);
//        org.joda.time.DateTimeZone dateTimeZone78 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology79 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone78);
//        org.joda.time.DateTimeField dateTimeField80 = iSOChronology79.clockhourOfHalfday();
//        org.joda.time.Partial partial81 = partial75.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology79);
//        boolean boolean82 = partial51.isMatch((org.joda.time.ReadablePartial) partial75);
//        int[] intArray85 = new int[] { (byte) -1 };
//        int[] intArray87 = skipDateTimeField17.add((org.joda.time.ReadablePartial) partial51, (int) (byte) 100, intArray85, (int) (byte) 0);
//        org.joda.time.DateTime dateTime88 = dateTime9.withFields((org.joda.time.ReadablePartial) partial51);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(limitChronology28);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(chronology47);
//        org.junit.Assert.assertNotNull(limitChronology50);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertNotNull(chronology59);
//        org.junit.Assert.assertNotNull(limitChronology62);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertNotNull(chronology71);
//        org.junit.Assert.assertNotNull(limitChronology74);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone78);
//        org.junit.Assert.assertNotNull(iSOChronology79);
//        org.junit.Assert.assertNotNull(dateTimeField80);
//        org.junit.Assert.assertNotNull(partial81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
//        org.junit.Assert.assertNotNull(intArray85);
//        org.junit.Assert.assertNotNull(intArray87);
//        org.junit.Assert.assertNotNull(dateTime88);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        java.util.Locale locale6 = null;
        java.util.Calendar calendar7 = dateTime5.toCalendar(locale6);
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.fromCalendarFields(calendar7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(calendar7);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
        org.joda.time.Instant instant14 = new org.joda.time.Instant();
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        boolean boolean16 = instant14.isBefore((org.joda.time.ReadableInstant) instant15);
        boolean boolean17 = instant12.isBefore((org.joda.time.ReadableInstant) instant14);
        org.joda.time.Chronology chronology18 = instant14.getChronology();
        org.joda.time.ReadableDateTime readableDateTime19 = null;
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance(chronology18, readableDateTime19, readableDateTime20);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone24.isLocalDateTimeGap(localDateTime26);
        java.lang.String str29 = dateTimeZone24.getName((long) '#');
        int int31 = dateTimeZone24.getOffsetFromLocal((long) 10);
        java.util.Locale locale33 = null;
        java.lang.String str34 = dateTimeZone24.getShortName((long) 10, locale33);
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) 2, dateTimeZone24);
        org.joda.time.LocalDate.Property property36 = localDate35.weekyear();
        long long38 = limitChronology21.set((org.joda.time.ReadablePartial) localDate35, 43200000L);
        org.joda.time.LocalDate localDate40 = localDate35.plusWeeks(1);
        boolean boolean41 = copticChronology10.equals((java.lang.Object) localDate35);
        org.joda.time.LocalDate.Property property42 = localDate35.centuryOfEra();
        org.joda.time.LocalDate.Property property43 = localDate35.dayOfYear();
        org.joda.time.LocalDate localDate44 = property43.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(limitChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+00:00:00.052" + "'", str29.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 52 + "'", int31 == 52);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "+00:00:00.052" + "'", str34.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43200000L + "'", long38 == 43200000L);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(localDate44);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField10.getAsText((long) (short) 100, locale13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField10.getAsText(0, locale16);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(1970);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        boolean boolean3 = instant1.isBefore((org.joda.time.ReadableInstant) instant2);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        boolean boolean5 = instant2.isSupported(dateTimeFieldType4);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property8 = localDate7.monthOfYear();
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property11 = localDate10.monthOfYear();
        java.util.Locale locale12 = null;
        int int13 = property11.getMaximumTextLength(locale12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
        int int15 = localDate7.get(dateTimeFieldType14);
        boolean boolean16 = instant2.isSupported(dateTimeFieldType14);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 39641045L, "ISOChronology[+00:00:00.052]");
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.DateTime dateTime11 = dateTime8.plusSeconds((int) (byte) 1);
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime8.toYearMonthDay();
        org.joda.time.DateTime dateTime14 = dateTime8.minusWeeks(4);
        try {
            org.joda.time.DateTime dateTime16 = dateTime8.withDayOfYear((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        long long15 = skipUndoDateTimeField10.add(0L, (long) (short) 10);
        int int17 = skipUndoDateTimeField10.getMinimumValue((long) 82860362);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 432000000L + "'", long15 == 432000000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfDay();
        org.joda.time.DurationField durationField5 = iSOChronology2.millis();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.monthOfYear();
        org.joda.time.Instant instant7 = new org.joda.time.Instant();
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        boolean boolean9 = instant7.isBefore((org.joda.time.ReadableInstant) instant8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        boolean boolean11 = instant8.isSupported(dateTimeFieldType10);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property17 = localDate16.monthOfYear();
        java.util.Locale locale18 = null;
        int int19 = property17.getMaximumTextLength(locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property17.getFieldType();
        int int21 = localDate13.get(dateTimeFieldType20);
        boolean boolean22 = instant8.isSupported(dateTimeFieldType20);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType20, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        int int14 = delegatedDateTimeField12.getMinimumValue((long) (short) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField12.getAsShortText(0L, locale16);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField12.getRangeDurationField();
        java.util.Locale locale19 = null;
        int int20 = delegatedDateTimeField12.getMaximumShortTextLength(locale19);
        try {
            long long23 = delegatedDateTimeField12.set((long) 59, 82841045);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82841045 for halfdayOfDay must be in the range [1,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        org.joda.time.DateTime.Property property8 = dateTime5.secondOfDay();
        org.joda.time.DurationField durationField9 = property8.getRangeDurationField();
        org.joda.time.DateTime dateTime10 = property8.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        int int12 = offsetDateTimeField10.getMaximumValue(2458650L);
        int int13 = offsetDateTimeField10.getMinimumValue();
        long long15 = offsetDateTimeField10.roundHalfCeiling((long) 4);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int[] intArray21 = new int[] { 82841, 166, 2019 };
        try {
            int[] intArray23 = offsetDateTimeField10.set(readablePartial16, 292278993, intArray21, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for minuteOfHour must be in the range [18,78]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 78 + "'", int12 == 78);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 18 + "'", int13 == 18);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-52L) + "'", long15 == (-52L));
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.LocalDateTime localDateTime15 = null;
//        boolean boolean16 = dateTimeZone13.isLocalDateTimeGap(localDateTime15);
//        java.lang.String str18 = dateTimeZone13.getName((long) '#');
//        int int20 = dateTimeZone13.getOffsetFromLocal((long) 10);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone13.getShortName((long) 10, locale22);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) 2, dateTimeZone13);
//        org.joda.time.LocalDate.Property property25 = localDate24.weekyear();
//        long long27 = limitChronology10.set((org.joda.time.ReadablePartial) localDate24, 43200000L);
//        org.joda.time.LocalDate localDate29 = localDate24.plusWeeks(1);
//        org.joda.time.LocalDate localDate31 = localDate24.withDayOfMonth(19);
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.LocalDate localDate33 = localDate31.plus(readablePeriod32);
//        org.joda.time.DurationFieldType durationFieldType34 = null;
//        boolean boolean35 = localDate31.isSupported(durationFieldType34);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = null;
//        java.lang.String str37 = localDate31.toString(dateTimeFormatter36);
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone40);
//        org.joda.time.LocalDateTime localDateTime42 = null;
//        boolean boolean43 = dateTimeZone40.isLocalDateTimeGap(localDateTime42);
//        java.lang.String str45 = dateTimeZone40.getName((long) '#');
//        int int47 = dateTimeZone40.getOffsetFromLocal((long) 10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone48 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
//        org.joda.time.LocalDateTime localDateTime49 = null;
//        boolean boolean50 = cachedDateTimeZone48.isLocalDateTimeGap(localDateTime49);
//        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone48);
//        org.joda.time.DateTimeZone dateTimeZone52 = cachedDateTimeZone48.getUncachedZone();
//        long long55 = dateTimeZone52.adjustOffset((long) 2000, false);
//        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate((long) 105, dateTimeZone52);
//        int int57 = localDate31.compareTo((org.joda.time.ReadablePartial) localDate56);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.052" + "'", str18.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43200000L + "'", long27 == 43200000L);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1970-01-19" + "'", str37.equals("1970-01-19"));
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(iSOChronology41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "+00:00:00.052" + "'", str45.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 52 + "'", int47 == 52);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone48);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(julianChronology51);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2000L + "'", long55 == 2000L);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = iSOChronology9.minutes();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(1970, (int) (short) 100, (int) (byte) -1, 2019, (int) '4', 7, (int) (byte) 1, (org.joda.time.Chronology) iSOChronology9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        int int11 = offsetDateTimeField10.getMinimumValue();
        int int13 = offsetDateTimeField10.getLeapAmount(57600061L);
        try {
            long long16 = offsetDateTimeField10.set(0L, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for minuteOfHour must be in the range [18,78]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 18 + "'", int11 == 18);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Instant instant1 = new org.joda.time.Instant();
//        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
//        org.joda.time.Instant instant3 = new org.joda.time.Instant();
//        org.joda.time.Instant instant4 = new org.joda.time.Instant();
//        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
//        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
//        org.joda.time.Chronology chronology7 = instant3.getChronology();
//        org.joda.time.ReadableDateTime readableDateTime8 = null;
//        org.joda.time.ReadableDateTime readableDateTime9 = null;
//        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        org.joda.time.LocalDateTime localDateTime15 = null;
//        boolean boolean16 = dateTimeZone13.isLocalDateTimeGap(localDateTime15);
//        java.lang.String str18 = dateTimeZone13.getName((long) '#');
//        int int20 = dateTimeZone13.getOffsetFromLocal((long) 10);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = dateTimeZone13.getShortName((long) 10, locale22);
//        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) 2, dateTimeZone13);
//        org.joda.time.LocalDate.Property property25 = localDate24.weekyear();
//        long long27 = limitChronology10.set((org.joda.time.ReadablePartial) localDate24, 43200000L);
//        org.joda.time.LocalDate localDate29 = localDate24.plusWeeks(1);
//        org.joda.time.LocalDate localDate31 = localDate24.withDayOfMonth(19);
//        org.joda.time.LocalDate localDate33 = localDate31.plusYears(82841726);
//        org.joda.time.LocalDate localDate35 = localDate31.minusYears(82843301);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(limitChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.052" + "'", str18.equals("+00:00:00.052"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43200000L + "'", long27 == 43200000L);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(localDate35);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        int int15 = gJChronology14.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        org.joda.time.LocalDate localDate16 = localDate13.minusYears(57600);
        org.joda.time.LocalDate.Property property17 = localDate16.year();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(property17);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
//        org.joda.time.Chronology chronology2 = instant0.getChronology();
//        long long3 = instant0.getMillis();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560639682284L + "'", long3 == 1560639682284L);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField10.getAsText((long) (short) 100, locale13);
        org.joda.time.DateTimeField dateTimeField15 = skipUndoDateTimeField10.getWrappedField();
        int int17 = skipUndoDateTimeField10.get(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = iSOChronology9.minutes();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology9, dateTimeField15, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, dateTimeFieldType18);
        int int21 = delegatedDateTimeField19.getMinimumValue((long) (short) 100);
        long long24 = delegatedDateTimeField19.addWrapField(0L, 365);
        int int25 = dateTime5.get((org.joda.time.DateTimeField) delegatedDateTimeField19);
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime5.getZone();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        org.joda.time.LocalDateTime localDateTime30 = null;
        boolean boolean31 = dateTimeZone28.isLocalDateTimeGap(localDateTime30);
        java.lang.String str33 = dateTimeZone28.getName((long) '#');
        int int35 = dateTimeZone28.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime36 = null;
        boolean boolean37 = dateTimeZone28.isLocalDateTimeGap(localDateTime36);
        long long39 = dateTimeZone28.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.Chronology chronology42 = buddhistChronology40.withZone(dateTimeZone41);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone45);
        org.joda.time.LocalDateTime localDateTime47 = null;
        boolean boolean48 = dateTimeZone45.isLocalDateTimeGap(localDateTime47);
        java.lang.String str50 = dateTimeZone45.getName((long) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = dateTimeFormatter43.withZone(dateTimeZone45);
        org.joda.time.chrono.ZonedChronology zonedChronology52 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology40, dateTimeZone45);
        org.joda.time.DateTimeZone dateTimeZone53 = zonedChronology52.getZone();
        org.joda.time.DateTime dateTime54 = dateTime5.toDateTime(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43200000L + "'", long24 == 43200000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00:00.052" + "'", str33.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 52 + "'", int35 == 52);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 53L + "'", long39 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "+00:00:00.052" + "'", str50.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(zonedChronology52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTime54);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 8452048L, (java.lang.Number) 576000100L, (java.lang.Number) 4);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.DateMidnight dateMidnight2 = localDate1.toDateMidnight();
        org.joda.time.LocalDate localDate4 = localDate1.withCenturyOfEra(680);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField10.getAsText((long) (short) 100, locale13);
        org.joda.time.DateTimeField dateTimeField15 = skipUndoDateTimeField10.getWrappedField();
        int int16 = skipUndoDateTimeField10.getMinimumValue();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, 52);
        java.lang.String str19 = offsetDateTimeField18.getName();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "halfdayOfDay" + "'", str19.equals("halfdayOfDay"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-49));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        long long10 = skipDateTimeField7.set((-1L), (int) (byte) -1);
        long long12 = skipDateTimeField7.roundHalfEven((long) 100);
        int int14 = skipDateTimeField7.get((long) 100);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property17 = localDate16.monthOfYear();
        org.joda.time.LocalDate localDate19 = localDate16.withDayOfYear((int) (short) 1);
        org.joda.time.Chronology chronology20 = localDate19.getChronology();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.LocalDateTime localDateTime27 = null;
        boolean boolean28 = dateTimeZone25.isLocalDateTimeGap(localDateTime27);
        java.lang.String str30 = dateTimeZone25.getName((long) '#');
        int int32 = dateTimeZone25.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone25);
        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone33);
        org.joda.time.Instant instant35 = new org.joda.time.Instant();
        org.joda.time.Instant instant36 = new org.joda.time.Instant();
        boolean boolean37 = instant35.isBefore((org.joda.time.ReadableInstant) instant36);
        org.joda.time.Instant instant38 = new org.joda.time.Instant();
        org.joda.time.Instant instant39 = new org.joda.time.Instant();
        boolean boolean40 = instant38.isBefore((org.joda.time.ReadableInstant) instant39);
        boolean boolean41 = instant36.isBefore((org.joda.time.ReadableInstant) instant38);
        org.joda.time.Chronology chronology42 = instant38.getChronology();
        org.joda.time.ReadableDateTime readableDateTime43 = null;
        org.joda.time.ReadableDateTime readableDateTime44 = null;
        org.joda.time.chrono.LimitChronology limitChronology45 = org.joda.time.chrono.LimitChronology.getInstance(chronology42, readableDateTime43, readableDateTime44);
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone48);
        org.joda.time.LocalDateTime localDateTime50 = null;
        boolean boolean51 = dateTimeZone48.isLocalDateTimeGap(localDateTime50);
        java.lang.String str53 = dateTimeZone48.getName((long) '#');
        int int55 = dateTimeZone48.getOffsetFromLocal((long) 10);
        java.util.Locale locale57 = null;
        java.lang.String str58 = dateTimeZone48.getShortName((long) 10, locale57);
        org.joda.time.LocalDate localDate59 = new org.joda.time.LocalDate((long) 2, dateTimeZone48);
        org.joda.time.LocalDate.Property property60 = localDate59.weekyear();
        long long62 = limitChronology45.set((org.joda.time.ReadablePartial) localDate59, 43200000L);
        org.joda.time.LocalDate localDate64 = localDate59.plusWeeks(1);
        boolean boolean65 = copticChronology34.equals((java.lang.Object) localDate59);
        int[] intArray67 = iSOChronology23.get((org.joda.time.ReadablePartial) localDate59, (long) 4);
        int int68 = skipDateTimeField7.getMinimumValue((org.joda.time.ReadablePartial) localDate19, intArray67);
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology71 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone70);
        org.joda.time.LocalDateTime localDateTime72 = null;
        boolean boolean73 = dateTimeZone70.isLocalDateTimeGap(localDateTime72);
        java.lang.String str75 = dateTimeZone70.getName((long) '#');
        int int77 = dateTimeZone70.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime78 = null;
        boolean boolean79 = dateTimeZone70.isLocalDateTimeGap(localDateTime78);
        boolean boolean81 = dateTimeZone70.isStandardOffset(1L);
        org.joda.time.DateTime dateTime82 = localDate19.toDateTimeAtStartOfDay(dateTimeZone70);
        int int83 = dateTime82.getDayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-52L) + "'", long12 == (-52L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+00:00:00.052" + "'", str30.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 52 + "'", int32 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertNotNull(copticChronology34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(limitChronology45);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "+00:00:00.052" + "'", str53.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 52 + "'", int55 == 52);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "+00:00:00.052" + "'", str58.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 43200000L + "'", long62 == 43200000L);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertNotNull(iSOChronology71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "+00:00:00.052" + "'", str75.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 52 + "'", int77 == 52);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(dateTime82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.DurationField durationField5 = property3.getRangeDurationField();
        java.util.Locale locale7 = null;
        try {
            org.joda.time.LocalDate localDate8 = property3.setCopy("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNull(durationField5);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.052", "1970-01-01", 365, (int) (byte) 1);
        java.lang.Object obj7 = null;
        boolean boolean8 = fixedDateTimeZone6.equals(obj7);
        long long10 = dateTimeZone1.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone6, (long) 1970);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1605L + "'", long10 == 1605L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.LocalDateTime localDateTime15 = null;
        boolean boolean16 = dateTimeZone13.isLocalDateTimeGap(localDateTime15);
        java.lang.String str18 = dateTimeZone13.getName((long) '#');
        int int20 = dateTimeZone13.getOffsetFromLocal((long) 10);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone13.getShortName((long) 10, locale22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) 2, dateTimeZone13);
        org.joda.time.LocalDate.Property property25 = localDate24.weekyear();
        long long27 = limitChronology10.set((org.joda.time.ReadablePartial) localDate24, 43200000L);
        org.joda.time.DateTimeField dateTimeField28 = limitChronology10.era();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.052" + "'", str18.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43200000L + "'", long27 == 43200000L);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = partial23.getFormatter();
        org.joda.time.Partial partial26 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = partial26.getFormatter();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(dateTimeFormatter25);
        org.junit.Assert.assertNull(dateTimeFormatter27);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = buddhistChronology13.withZone(dateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.LocalDateTime localDateTime20 = null;
        boolean boolean21 = dateTimeZone18.isLocalDateTimeGap(localDateTime20);
        java.lang.String str23 = dateTimeZone18.getName((long) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter16.withZone(dateTimeZone18);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology13, dateTimeZone18);
        long long29 = zonedChronology25.add((long) 2922750, 0L, (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2922750L + "'", long29 == 2922750L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
        long long14 = durationField11.subtract((long) 2922750, 6);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-515477250L) + "'", long14 == (-515477250L));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DurationField durationField11 = copticChronology10.millis();
        int int12 = copticChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        long long16 = copticChronology10.add(readablePeriod13, 1560639667048L, 673);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560639667048L + "'", long16 == 1560639667048L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        java.util.Locale locale6 = null;
        java.util.Calendar calendar7 = dateTime5.toCalendar(locale6);
        org.joda.time.DateTime dateTime8 = dateTime5.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime5.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(calendar7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        boolean boolean3 = instant1.isBefore((org.joda.time.ReadableInstant) instant2);
        org.joda.time.MutableDateTime mutableDateTime4 = instant2.toMutableDateTimeISO();
        int int7 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "ZonedChronology[BuddhistChronology[UTC], +00:00:00.052]", 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = buddhistChronology13.withZone(dateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.LocalDateTime localDateTime20 = null;
        boolean boolean21 = dateTimeZone18.isLocalDateTimeGap(localDateTime20);
        java.lang.String str23 = dateTimeZone18.getName((long) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter16.withZone(dateTimeZone18);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology13, dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone26 = zonedChronology25.getZone();
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology25.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Instant instant9 = instant3.plus(readableDuration8);
        org.joda.time.Instant instant12 = instant9.withDurationAdded((long) 35, 2000);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant12);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMillis((int) (byte) 0);
        org.joda.time.DateTime dateTime4 = dateTime2.minusYears(57600);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        try {
            org.joda.time.DateTime dateTime4 = dateTime0.withDate(0, 2000, (-55630));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = dateTimeZone3.isLocalDateTimeGap(localDateTime5);
        java.lang.String str8 = dateTimeZone3.getName((long) '#');
        int int10 = dateTimeZone3.getOffsetFromLocal((long) 10);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone3.getShortName((long) 10, locale12);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) 2, dateTimeZone3);
        org.joda.time.LocalDate.Property property15 = localDate14.monthOfYear();
        org.joda.time.LocalDate localDate17 = localDate14.minusYears(57600);
        java.lang.String str18 = localDate17.toString();
        int int19 = localDate17.getEra();
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property22 = localDate21.monthOfYear();
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property25 = localDate24.monthOfYear();
        java.util.Locale locale26 = null;
        int int27 = property25.getMaximumTextLength(locale26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
        int int29 = localDate21.get(dateTimeFieldType28);
        int int30 = localDate17.get(dateTimeFieldType28);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType28, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.052" + "'", str8.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00:00.052" + "'", str13.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-55630-01-01" + "'", str18.equals("-55630-01-01"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 9 + "'", int27 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        boolean boolean10 = instant8.isBefore((org.joda.time.ReadableInstant) instant9);
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
        boolean boolean14 = instant9.isBefore((org.joda.time.ReadableInstant) instant11);
        org.joda.time.Chronology chronology15 = instant11.getChronology();
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance(chronology15, readableDateTime16, readableDateTime17);
        org.joda.time.Partial partial19 = new org.joda.time.Partial(chronology15);
        int[] intArray27 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
        int[] intArray29 = skipDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) partial19, (int) (short) 0, intArray27, (int) (short) 1);
        org.joda.time.Instant instant30 = new org.joda.time.Instant();
        org.joda.time.Instant instant31 = new org.joda.time.Instant();
        boolean boolean32 = instant30.isBefore((org.joda.time.ReadableInstant) instant31);
        org.joda.time.Instant instant33 = new org.joda.time.Instant();
        org.joda.time.Instant instant34 = new org.joda.time.Instant();
        boolean boolean35 = instant33.isBefore((org.joda.time.ReadableInstant) instant34);
        boolean boolean36 = instant31.isBefore((org.joda.time.ReadableInstant) instant33);
        org.joda.time.Chronology chronology37 = instant33.getChronology();
        org.joda.time.ReadableDateTime readableDateTime38 = null;
        org.joda.time.ReadableDateTime readableDateTime39 = null;
        org.joda.time.chrono.LimitChronology limitChronology40 = org.joda.time.chrono.LimitChronology.getInstance(chronology37, readableDateTime38, readableDateTime39);
        org.joda.time.Partial partial41 = new org.joda.time.Partial(chronology37);
        org.joda.time.Instant instant42 = new org.joda.time.Instant();
        org.joda.time.Instant instant43 = new org.joda.time.Instant();
        boolean boolean44 = instant42.isBefore((org.joda.time.ReadableInstant) instant43);
        org.joda.time.Instant instant45 = new org.joda.time.Instant();
        org.joda.time.Instant instant46 = new org.joda.time.Instant();
        boolean boolean47 = instant45.isBefore((org.joda.time.ReadableInstant) instant46);
        boolean boolean48 = instant43.isBefore((org.joda.time.ReadableInstant) instant45);
        org.joda.time.Chronology chronology49 = instant45.getChronology();
        org.joda.time.ReadableDateTime readableDateTime50 = null;
        org.joda.time.ReadableDateTime readableDateTime51 = null;
        org.joda.time.chrono.LimitChronology limitChronology52 = org.joda.time.chrono.LimitChronology.getInstance(chronology49, readableDateTime50, readableDateTime51);
        org.joda.time.Partial partial53 = new org.joda.time.Partial(chronology49);
        org.joda.time.Instant instant54 = new org.joda.time.Instant();
        org.joda.time.Instant instant55 = new org.joda.time.Instant();
        boolean boolean56 = instant54.isBefore((org.joda.time.ReadableInstant) instant55);
        org.joda.time.Instant instant57 = new org.joda.time.Instant();
        org.joda.time.Instant instant58 = new org.joda.time.Instant();
        boolean boolean59 = instant57.isBefore((org.joda.time.ReadableInstant) instant58);
        boolean boolean60 = instant55.isBefore((org.joda.time.ReadableInstant) instant57);
        org.joda.time.Chronology chronology61 = instant57.getChronology();
        org.joda.time.ReadableDateTime readableDateTime62 = null;
        org.joda.time.ReadableDateTime readableDateTime63 = null;
        org.joda.time.chrono.LimitChronology limitChronology64 = org.joda.time.chrono.LimitChronology.getInstance(chronology61, readableDateTime62, readableDateTime63);
        org.joda.time.Partial partial65 = new org.joda.time.Partial(chronology61);
        boolean boolean66 = partial53.isMatch((org.joda.time.ReadablePartial) partial65);
        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone68);
        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.clockhourOfHalfday();
        org.joda.time.Partial partial71 = partial65.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology69);
        boolean boolean72 = partial41.isMatch((org.joda.time.ReadablePartial) partial65);
        int[] intArray75 = new int[] { (byte) -1 };
        int[] intArray77 = skipDateTimeField7.add((org.joda.time.ReadablePartial) partial41, (int) (byte) 100, intArray75, (int) (byte) 0);
        int int79 = skipDateTimeField7.getLeapAmount((long) 129);
        long long82 = skipDateTimeField7.addWrapField((long) 23, 35);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(limitChronology40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(limitChronology52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(chronology61);
        org.junit.Assert.assertNotNull(limitChronology64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertNotNull(iSOChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(partial71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 2100023L + "'", long82 == 2100023L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        int int14 = delegatedDateTimeField12.getMinimumValue((long) (short) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField12.getAsShortText(0L, locale16);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField12.getRangeDurationField();
        java.lang.String str19 = delegatedDateTimeField12.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AM" + "'", str17.equals("AM"));
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[halfdayOfDay]" + "'", str19.equals("DateTimeField[halfdayOfDay]"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property8 = dateTime7.weekyear();
        org.joda.time.DateTime dateTime10 = property8.addToCopy(365);
        org.joda.time.DateTime dateTime12 = property8.setCopy(7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.yearOfEra();
        long long13 = iSOChronology0.add(0L, (long) 365, 82841726);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 30237229990L + "'", long13 == 30237229990L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        int int12 = offsetDateTimeField10.getMaximumValue(100L);
        long long15 = offsetDateTimeField10.add((long) 57, (long) 82875);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 78 + "'", int12 == 78);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 4972500057L + "'", long15 == 4972500057L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        int int14 = delegatedDateTimeField12.getMinimumValue((long) (short) 100);
        long long17 = delegatedDateTimeField12.addWrapField(0L, 365);
        int int19 = delegatedDateTimeField12.get((long) 82841045);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43200000L + "'", long17 == 43200000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.era();
        int int16 = gJChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology14);
        org.joda.time.DurationField durationField18 = gJChronology14.months();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField23 = iSOChronology22.minutes();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology19, dateTimeField24, (int) (byte) 1);
        java.util.Locale locale28 = null;
        java.lang.String str29 = skipDateTimeField26.getAsText((long) (byte) 100, locale28);
        boolean boolean30 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField18, (java.lang.Object) locale28);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 24");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = instant1.isSupported(dateTimeFieldType3);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property7 = localDate6.monthOfYear();
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.monthOfYear();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
        int int14 = localDate6.get(dateTimeFieldType13);
        boolean boolean15 = instant1.isSupported(dateTimeFieldType13);
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, (java.lang.Number) 39641045L, "ISOChronology[+00:00:00.052]");
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.monthOfYear();
        org.joda.time.DurationField durationField21 = iSOChronology19.millis();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone24.isLocalDateTimeGap(localDateTime26);
        java.lang.String str29 = dateTimeZone24.getName((long) '#');
        int int31 = dateTimeZone24.getOffsetFromLocal((long) 10);
        java.util.Locale locale33 = null;
        java.lang.String str34 = dateTimeZone24.getShortName((long) 10, locale33);
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) 2, dateTimeZone24);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.era();
        int int38 = gJChronology36.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology36);
        org.joda.time.DurationField durationField40 = gJChronology36.months();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField41 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType13, durationField21, durationField40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+00:00:00.052" + "'", str29.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 52 + "'", int31 == 52);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "+00:00:00.052" + "'", str34.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(durationField40);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("minuteOfHour", (int) 'a');
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder3.addRecurringSavings("Thursday", 82843301, 0, 52, 'a', (int) (short) 1, (-1), 0, false, 59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("halfdayOfDay");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"halfdayOfDay\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("AM", "-55630-01-01", (int) (short) 1, 78);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((long) 105);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        int int3 = localDate1.getYearOfCentury();
        org.joda.time.LocalTime localTime4 = null;
        org.joda.time.DateTime dateTime5 = localDate1.toDateTime(localTime4);
        org.joda.time.Chronology chronology6 = localDate1.getChronology();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 70 + "'", int3 == 70);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfMinute(57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.clockhourOfHalfday();
        org.joda.time.DurationField durationField12 = iSOChronology10.seconds();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime.Property property15 = dateTime13.year();
        org.joda.time.DateTime dateTime17 = dateTime13.withMillis((long) 52);
        org.joda.time.DateTime.Property property18 = dateTime13.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder7.appendShortText(dateTimeFieldType19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendHourOfDay(82834373);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = dateTimeZone3.isLocalDateTimeGap(localDateTime5);
        java.lang.String str8 = dateTimeZone3.getName((long) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.parse("0", dateTimeFormatter1);
        org.joda.time.DateTime dateTime12 = dateTime10.withMinuteOfHour((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.052" + "'", str8.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = julianChronology0.minutes();
        int int3 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        int int14 = localDate13.getYearOfCentury();
        org.joda.time.LocalDate localDate16 = localDate13.withDayOfYear(129);
        org.joda.time.LocalDate.Property property17 = localDate16.monthOfYear();
        org.joda.time.LocalDate localDate19 = localDate16.withYear(57);
        java.util.Date date20 = localDate19.toDate();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes(70);
        org.joda.time.DateTime dateTime9 = dateTime5.withYearOfEra(52);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTimeISO();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property13 = localDate12.monthOfYear();
        int int14 = localDate12.getYearOfCentury();
        org.joda.time.LocalTime localTime15 = null;
        org.joda.time.DateTime dateTime16 = localDate12.toDateTime(localTime15);
        int int17 = dateTime10.compareTo((org.joda.time.ReadableInstant) dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes(70);
        org.joda.time.DateTime dateTime9 = dateTime5.withYearOfEra(52);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTimeISO();
        org.joda.time.LocalDateTime localDateTime11 = dateTime9.toLocalDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDateTime11);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withZone(dateTimeZone2);
        java.lang.String str10 = dateTimeFormatter8.print(0L);
        try {
            org.joda.time.LocalDate localDate12 = dateTimeFormatter8.parseLocalDate("DateTimeField[halfdayOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[halfdayOfDay]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "00" + "'", str10.equals("00"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("1970-01");
        org.junit.Assert.assertNotNull(localDate1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMillis((int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone4.isLocalDateTimeGap(localDateTime6);
        java.lang.String str9 = dateTimeZone4.getName((long) '#');
        int int11 = dateTimeZone4.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.DateTime dateTime13 = dateTime0.toDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        int int15 = cachedDateTimeZone12.getOffset((long) 82843301);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.052" + "'", str9.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withPivotYear((java.lang.Integer) (-1));
        boolean boolean6 = dateTimeFormatter3.isPrinter();
        boolean boolean7 = gregorianChronology0.equals((java.lang.Object) boolean6);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.LocalDate localDate5 = property3.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate6 = property3.roundHalfEvenCopy();
        try {
            org.joda.time.LocalDate localDate8 = localDate6.withWeekOfWeekyear(57600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        org.joda.time.Instant instant24 = new org.joda.time.Instant();
        org.joda.time.Instant instant25 = new org.joda.time.Instant();
        boolean boolean26 = instant24.isBefore((org.joda.time.ReadableInstant) instant25);
        org.joda.time.Instant instant27 = new org.joda.time.Instant();
        org.joda.time.Instant instant28 = new org.joda.time.Instant();
        boolean boolean29 = instant27.isBefore((org.joda.time.ReadableInstant) instant28);
        boolean boolean30 = instant25.isBefore((org.joda.time.ReadableInstant) instant27);
        org.joda.time.Chronology chronology31 = instant27.getChronology();
        org.joda.time.ReadableDateTime readableDateTime32 = null;
        org.joda.time.ReadableDateTime readableDateTime33 = null;
        org.joda.time.chrono.LimitChronology limitChronology34 = org.joda.time.chrono.LimitChronology.getInstance(chronology31, readableDateTime32, readableDateTime33);
        org.joda.time.Partial partial35 = new org.joda.time.Partial(chronology31);
        boolean boolean36 = partial23.isMatch((org.joda.time.ReadablePartial) partial35);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.clockhourOfHalfday();
        org.joda.time.Partial partial41 = partial35.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology39);
        boolean boolean42 = partial11.isMatch((org.joda.time.ReadablePartial) partial35);
        try {
            int int44 = partial35.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(limitChronology34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(partial41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 10, 82834373);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(82841);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        java.util.Locale locale5 = null;
        int int6 = property3.getMaximumShortTextLength(locale5);
        java.util.Locale locale7 = null;
        int int8 = property3.getMaximumTextLength(locale7);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("LimitChronology[ISOChronology[UTC], NoLimit, NoLimit]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"LimitChronology[ISOChronology[UTC], NoLimit, NoLimit]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(8452048L, 57600061L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 66052109L + "'", long2 == 66052109L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.weekyear();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology14.getZone();
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(copticChronology18);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfDay();
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        boolean boolean7 = instant5.isBefore((org.joda.time.ReadableInstant) instant6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        boolean boolean9 = instant6.isSupported(dateTimeFieldType8);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property12 = localDate11.monthOfYear();
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property15 = localDate14.monthOfYear();
        java.util.Locale locale16 = null;
        int int17 = property15.getMaximumTextLength(locale16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property15.getFieldType();
        int int19 = localDate11.get(dateTimeFieldType18);
        boolean boolean20 = instant6.isSupported(dateTimeFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 39641045L, "ISOChronology[+00:00:00.052]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "0");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField27 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType18, 35);
        long long29 = dividedDateTimeField27.remainder((long) (-13));
        org.joda.time.DurationField durationField30 = dividedDateTimeField27.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-13L) + "'", long29 == (-13L));
        org.junit.Assert.assertNotNull(durationField30);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Instant instant9 = instant3.withDurationAdded((long) 2000, 9);
        java.lang.String str10 = instant9.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970-01-01T00:00:18.000Z" + "'", str10.equals("1970-01-01T00:00:18.000Z"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMillis((int) (byte) 0);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(82841045);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime4);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-82841045L) + "'", long6 == (-82841045L));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 82843301, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str5 = jodaTimePermission4.getName();
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.Instant instant7 = new org.joda.time.Instant();
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        boolean boolean9 = instant7.isBefore((org.joda.time.ReadableInstant) instant8);
        org.joda.time.Instant instant10 = new org.joda.time.Instant();
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        boolean boolean12 = instant10.isBefore((org.joda.time.ReadableInstant) instant11);
        boolean boolean13 = instant8.isBefore((org.joda.time.ReadableInstant) instant10);
        org.joda.time.Chronology chronology14 = instant10.getChronology();
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance(chronology14, readableDateTime15, readableDateTime16);
        org.joda.time.Partial partial18 = new org.joda.time.Partial(chronology14);
        org.joda.time.Instant instant19 = new org.joda.time.Instant();
        org.joda.time.Instant instant20 = new org.joda.time.Instant();
        boolean boolean21 = instant19.isBefore((org.joda.time.ReadableInstant) instant20);
        org.joda.time.Instant instant22 = new org.joda.time.Instant();
        org.joda.time.Instant instant23 = new org.joda.time.Instant();
        boolean boolean24 = instant22.isBefore((org.joda.time.ReadableInstant) instant23);
        boolean boolean25 = instant20.isBefore((org.joda.time.ReadableInstant) instant22);
        org.joda.time.Chronology chronology26 = instant22.getChronology();
        org.joda.time.ReadableDateTime readableDateTime27 = null;
        org.joda.time.ReadableDateTime readableDateTime28 = null;
        org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance(chronology26, readableDateTime27, readableDateTime28);
        org.joda.time.Partial partial30 = new org.joda.time.Partial(chronology26);
        boolean boolean31 = partial18.isMatch((org.joda.time.ReadablePartial) partial30);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.clockhourOfHalfday();
        org.joda.time.Partial partial36 = partial30.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology34);
        boolean boolean37 = jodaTimePermission4.equals((java.lang.Object) partial30);
        boolean boolean38 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) partial30);
        java.lang.String str39 = partial30.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(limitChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "[]" + "'", str39.equals("[]"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfMinute(57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendWeekOfWeekyear(725);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = copticChronology0.get(readablePeriod2, (long) '4', 1560639660486L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfMinute(57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendYearOfCentury(2922750, (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfHalfday();
        org.joda.time.DurationField durationField5 = iSOChronology3.seconds();
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) "GJChronology[+00:00:00.052]", (java.lang.Object) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology3.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        org.joda.time.DurationField durationField11 = offsetDateTimeField10.getDurationField();
        java.lang.String str12 = offsetDateTimeField10.getName();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "minuteOfHour" + "'", str12.equals("minuteOfHour"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfMinute(57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendHourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear((int) ' ', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfYear(82875);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("00", false);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("1970-01-01", false);
        java.lang.String str7 = dateTimeZone6.getID();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01" + "'", str7.equals("1970-01-01"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        int int11 = offsetDateTimeField10.getMinimumValue();
        int int13 = offsetDateTimeField10.getLeapAmount(57600061L);
        java.lang.String str15 = offsetDateTimeField10.getAsShortText((long) 23);
        boolean boolean17 = offsetDateTimeField10.isLeap((long) 4);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 18 + "'", int11 == 18);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "18" + "'", str15.equals("18"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        int int10 = dateTime8.getEra();
        int int11 = dateTime8.getDayOfYear();
        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
        org.joda.time.DateTime.Property property13 = dateTime8.dayOfWeek();
        int int14 = dateTime8.getEra();
        org.joda.time.DateTime dateTime16 = dateTime8.withYear((int) (short) 0);
        org.joda.time.DateTime.Property property17 = dateTime8.weekyear();
        try {
            org.joda.time.DateTime dateTime19 = dateTime8.withMonthOfYear((-55630));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -55630 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        int int15 = localDate13.getDayOfMonth();
        org.joda.time.Chronology chronology16 = localDate13.getChronology();
        org.joda.time.LocalDate.Property property17 = localDate13.era();
        org.joda.time.DurationField durationField18 = property17.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        int int14 = localDate13.getYearOfCentury();
        org.joda.time.LocalDate localDate16 = localDate13.withDayOfYear(129);
        org.joda.time.LocalDate localDate18 = localDate13.withWeekyear(82834373);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 70 + "'", int14 == 70);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.era();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.weekyearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.clockhourOfHalfday();
        org.joda.time.Partial partial29 = partial23.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology27);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology27.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology27.dayOfYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(partial29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        try {
            long long13 = skipUndoDateTimeField10.set(0L, 84480052);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 84480052 for halfdayOfDay must be in the range [1,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        int int10 = dateTime8.getEra();
        int int11 = dateTime8.getDayOfYear();
        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
        org.joda.time.DateTime.Property property13 = dateTime8.dayOfWeek();
        org.joda.time.DateTime dateTime15 = dateTime8.withCenturyOfEra(57600);
        org.joda.time.DateTime dateTime17 = dateTime8.plusWeeks(4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        int int11 = offsetDateTimeField10.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField10.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 18 + "'", int11 == 18);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        org.joda.time.Instant instant24 = new org.joda.time.Instant();
        org.joda.time.Instant instant25 = new org.joda.time.Instant();
        boolean boolean26 = instant24.isBefore((org.joda.time.ReadableInstant) instant25);
        org.joda.time.Instant instant27 = new org.joda.time.Instant();
        org.joda.time.Instant instant28 = new org.joda.time.Instant();
        boolean boolean29 = instant27.isBefore((org.joda.time.ReadableInstant) instant28);
        boolean boolean30 = instant25.isBefore((org.joda.time.ReadableInstant) instant27);
        org.joda.time.Chronology chronology31 = instant27.getChronology();
        org.joda.time.ReadableDateTime readableDateTime32 = null;
        org.joda.time.ReadableDateTime readableDateTime33 = null;
        org.joda.time.chrono.LimitChronology limitChronology34 = org.joda.time.chrono.LimitChronology.getInstance(chronology31, readableDateTime32, readableDateTime33);
        org.joda.time.Partial partial35 = new org.joda.time.Partial(chronology31);
        boolean boolean36 = partial23.isMatch((org.joda.time.ReadablePartial) partial35);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.clockhourOfHalfday();
        org.joda.time.Partial partial41 = partial35.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology39);
        boolean boolean42 = partial11.isMatch((org.joda.time.ReadablePartial) partial35);
        java.lang.String str44 = partial35.toString("0");
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType46 = partial35.getFieldType(70);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 70");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(limitChronology34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(partial41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "0" + "'", str44.equals("0"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.052", "+00:00:00.052", 35, 84480732);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) 82841726, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        long long8 = fixedDateTimeZone5.previousTransition(43200000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43200000L + "'", long8 == 43200000L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.TimeZone timeZone3 = dateTimeZone1.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '+00:00:00.052' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime10 = null;
        boolean boolean11 = cachedDateTimeZone9.isLocalDateTimeGap(localDateTime10);
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology12.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.weekyear();
        org.joda.time.LocalDate localDate16 = localDate13.plusYears((int) (byte) 100);
        org.joda.time.LocalDate localDate18 = localDate16.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.LocalDateTime localDateTime23 = null;
        boolean boolean24 = dateTimeZone21.isLocalDateTimeGap(localDateTime23);
        java.lang.String str26 = dateTimeZone21.getName((long) '#');
        int int28 = dateTimeZone21.getOffsetFromLocal((long) 10);
        java.util.Locale locale30 = null;
        java.lang.String str31 = dateTimeZone21.getShortName((long) 10, locale30);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) 2, dateTimeZone21);
        org.joda.time.DateMidnight dateMidnight33 = localDate16.toDateMidnight(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00:00.052" + "'", str26.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00:00.052" + "'", str31.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateMidnight33);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfHalfday();
        org.joda.time.DurationField durationField5 = iSOChronology3.seconds();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property9 = dateTime8.weekyear();
        org.joda.time.DateTime dateTime11 = property9.addToCopy(365);
        boolean boolean12 = julianChronology0.equals((java.lang.Object) property9);
        int int13 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter0.printTo(writer3, (long) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        int int10 = dateTime8.getEra();
        int int11 = dateTime8.getDayOfYear();
        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
        int int13 = dateTime8.getMillisOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.util.Locale locale15 = dateTimeFormatter14.getLocale();
        java.util.Locale locale16 = dateTimeFormatter14.getLocale();
        org.joda.time.Instant instant17 = new org.joda.time.Instant();
        org.joda.time.Instant instant18 = new org.joda.time.Instant();
        boolean boolean19 = instant17.isBefore((org.joda.time.ReadableInstant) instant18);
        org.joda.time.Instant instant20 = new org.joda.time.Instant();
        org.joda.time.Instant instant21 = new org.joda.time.Instant();
        boolean boolean22 = instant20.isBefore((org.joda.time.ReadableInstant) instant21);
        boolean boolean23 = instant18.isBefore((org.joda.time.ReadableInstant) instant20);
        org.joda.time.Chronology chronology24 = instant20.getChronology();
        org.joda.time.ReadableDateTime readableDateTime25 = null;
        org.joda.time.ReadableDateTime readableDateTime26 = null;
        org.joda.time.chrono.LimitChronology limitChronology27 = org.joda.time.chrono.LimitChronology.getInstance(chronology24, readableDateTime25, readableDateTime26);
        org.joda.time.Partial partial28 = new org.joda.time.Partial(chronology24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter14.withChronology(chronology24);
        org.joda.time.DateTime dateTime30 = dateTime8.toDateTime(chronology24);
        org.joda.time.DateTime dateTime32 = dateTime8.withYearOfEra(57);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNull(locale15);
        org.junit.Assert.assertNull(locale16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(limitChronology27);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.LocalDateTime localDateTime15 = null;
        boolean boolean16 = dateTimeZone13.isLocalDateTimeGap(localDateTime15);
        java.lang.String str18 = dateTimeZone13.getName((long) '#');
        int int20 = dateTimeZone13.getOffsetFromLocal((long) 10);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone13.getShortName((long) 10, locale22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) 2, dateTimeZone13);
        org.joda.time.LocalDate.Property property25 = localDate24.weekyear();
        long long27 = limitChronology10.set((org.joda.time.ReadablePartial) localDate24, 43200000L);
        org.joda.time.DurationField durationField28 = limitChronology10.halfdays();
        org.joda.time.DateTime dateTime29 = limitChronology10.getUpperLimit();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.052" + "'", str18.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43200000L + "'", long27 == 43200000L);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNull(dateTime29);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMillis((int) (byte) 0);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(0);
        org.joda.time.Chronology chronology5 = dateTime2.getChronology();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfMinute(57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.clockhourOfHalfday();
        org.joda.time.DurationField durationField12 = iSOChronology10.seconds();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime.Property property15 = dateTime13.year();
        org.joda.time.DateTime dateTime17 = dateTime13.withMillis((long) 52);
        org.joda.time.DateTime.Property property18 = dateTime13.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder7.appendShortText(dateTimeFieldType19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendYearOfEra(52, 82834373);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = partial23.getFormatter();
        java.lang.String str27 = partial23.toString("+00:00:00.052");
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.Partial partial29 = partial23.minus(readablePeriod28);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(dateTimeFormatter25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00:00.052" + "'", str27.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(partial29);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfMinute(57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendSecondOfDay(84480732);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = iSOChronology4.minutes();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology1, dateTimeField6, (int) (byte) 1);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 82860538, (org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gregorianChronology0.add(readablePeriod1, 105433401600010L, 10);
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis(57600);
        long long9 = dateTimeZone5.getMillisKeepLocal(dateTimeZone7, (long) 19);
        long long12 = dateTimeZone5.adjustOffset((long) 82834373, true);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 105433401600010L + "'", long4 == 105433401600010L);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-57529L) + "'", long9 == (-57529L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 82834373L + "'", long12 == 82834373L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfHalfday();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) 'a', (int) (short) 1, 680);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField4, 1970);
        int int12 = skipUndoDateTimeField10.get((long) ' ');
        long long15 = skipUndoDateTimeField10.getDifferenceAsLong(0L, (long) 57);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone4.isLocalDateTimeGap(localDateTime6);
        java.lang.String str9 = dateTimeZone4.getName((long) '#');
        int int11 = dateTimeZone4.getOffsetFromLocal((long) 10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = dateTimeZone4.getShortName((long) 10, locale13);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) 2, dateTimeZone4);
        org.joda.time.LocalDate.Property property16 = localDate15.monthOfYear();
        org.joda.time.LocalDate localDate18 = localDate15.minusYears(57600);
        java.lang.String str19 = localDate18.toString();
        int int20 = localDate18.getEra();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.052" + "'", str9.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.052" + "'", str14.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-55630-01-01" + "'", str19.equals("-55630-01-01"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        org.joda.time.Instant instant24 = new org.joda.time.Instant();
        org.joda.time.Instant instant25 = new org.joda.time.Instant();
        boolean boolean26 = instant24.isBefore((org.joda.time.ReadableInstant) instant25);
        org.joda.time.Instant instant27 = new org.joda.time.Instant();
        org.joda.time.Instant instant28 = new org.joda.time.Instant();
        boolean boolean29 = instant27.isBefore((org.joda.time.ReadableInstant) instant28);
        boolean boolean30 = instant25.isBefore((org.joda.time.ReadableInstant) instant27);
        org.joda.time.Chronology chronology31 = instant27.getChronology();
        org.joda.time.ReadableDateTime readableDateTime32 = null;
        org.joda.time.ReadableDateTime readableDateTime33 = null;
        org.joda.time.chrono.LimitChronology limitChronology34 = org.joda.time.chrono.LimitChronology.getInstance(chronology31, readableDateTime32, readableDateTime33);
        org.joda.time.Partial partial35 = new org.joda.time.Partial(chronology31);
        boolean boolean36 = partial23.isMatch((org.joda.time.ReadablePartial) partial35);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.clockhourOfHalfday();
        org.joda.time.Partial partial41 = partial35.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology39);
        boolean boolean42 = partial11.isMatch((org.joda.time.ReadablePartial) partial35);
        java.lang.String str44 = partial35.toString("0");
        org.joda.time.Instant instant45 = new org.joda.time.Instant();
        boolean boolean46 = partial35.isMatch((org.joda.time.ReadableInstant) instant45);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(limitChronology34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(partial41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "0" + "'", str44.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        int int14 = localDate13.getCenturyOfEra();
        org.joda.time.Interval interval15 = localDate13.toInterval();
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval15);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
        org.junit.Assert.assertNotNull(interval15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(673);
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronology();
        java.lang.Appendable appendable4 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone7.isLocalDateTimeGap(localDateTime9);
        java.lang.String str12 = dateTimeZone7.getName((long) '#');
        int int14 = dateTimeZone7.getOffsetFromLocal((long) 10);
        java.util.Locale locale16 = null;
        java.lang.String str17 = dateTimeZone7.getShortName((long) 10, locale16);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) 2, dateTimeZone7);
        org.joda.time.LocalDate.Property property19 = localDate18.weekyear();
        org.joda.time.LocalDate localDate21 = localDate18.plusYears((int) (byte) 100);
        try {
            dateTimeFormatter0.printTo(appendable4, (org.joda.time.ReadablePartial) localDate18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.052" + "'", str17.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDate21);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = dateTimeZone3.isLocalDateTimeGap(localDateTime5);
        java.lang.String str8 = dateTimeZone3.getName((long) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.parse("0", dateTimeFormatter1);
        boolean boolean12 = dateTime10.isBefore(0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.052" + "'", str8.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        boolean boolean7 = instant5.isBefore((org.joda.time.ReadableInstant) instant6);
        int int8 = property3.getDifference((org.joda.time.ReadableInstant) instant5);
        org.joda.time.LocalDate localDate9 = property3.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate11 = property3.addWrapFieldToCopy(0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumTextLength(locale8);
        int int10 = property7.getLeapAmount();
        int int11 = property7.get();
        org.joda.time.DateTime dateTime12 = property7.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.IllegalInstantException illegalInstantException5 = new org.joda.time.IllegalInstantException(1L, "hi!");
        java.lang.String str6 = illegalInstantException5.toString();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalInstantException5);
        java.lang.Number number8 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)" + "'", str6.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)"));
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        int int11 = offsetDateTimeField10.getMinimumValue();
        int int13 = offsetDateTimeField10.getLeapAmount(57600061L);
        java.lang.String str15 = offsetDateTimeField10.getAsShortText((long) 23);
        long long17 = offsetDateTimeField10.roundCeiling((long) 1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 18 + "'", int11 == 18);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "18" + "'", str15.equals("18"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 59948L + "'", long17 == 59948L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property15 = localDate14.monthOfYear();
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property18 = localDate17.monthOfYear();
        java.util.Locale locale19 = null;
        int int20 = property18.getMaximumTextLength(locale19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property18.getFieldType();
        int int22 = localDate14.get(dateTimeFieldType21);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9 + "'", int20 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMinutes((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plus((long) (byte) 0);
        int int10 = dateTime7.getEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfMinute(57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearText();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatterBuilder7.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendPattern("2");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        boolean boolean7 = instant5.isBefore((org.joda.time.ReadableInstant) instant6);
        int int8 = property3.getDifference((org.joda.time.ReadableInstant) instant5);
        org.joda.time.LocalDate localDate9 = property3.roundHalfFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.LocalDateTime localDateTime13 = null;
        boolean boolean14 = dateTimeZone11.isLocalDateTimeGap(localDateTime13);
        java.lang.String str16 = dateTimeZone11.getName((long) '#');
        int int18 = dateTimeZone11.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime19 = null;
        boolean boolean20 = dateTimeZone11.isLocalDateTimeGap(localDateTime19);
        long long23 = dateTimeZone11.adjustOffset(53L, false);
        org.joda.time.DateTime dateTime24 = localDate9.toDateTimeAtCurrentTime(dateTimeZone11);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00:00.052" + "'", str16.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 53L + "'", long23 == 53L);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        long long9 = skipDateTimeField7.roundHalfFloor(100L);
        int int10 = skipDateTimeField7.getMinimumValue();
        long long13 = skipDateTimeField7.set((long) 59, 9);
        try {
            long long16 = skipDateTimeField7.set(2440588L, 105);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 105 for minuteOfHour must be in the range [-1,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-52L) + "'", long9 == (-52L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 540059L + "'", long13 == 540059L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        org.joda.time.LocalDate.Property property15 = localDate13.dayOfWeek();
        java.lang.String str16 = property15.getAsText();
        int int17 = property15.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Thursday" + "'", str16.equals("Thursday"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey((long) 84480732);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.weekyear();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.hourOfDay();
        org.joda.time.DurationField durationField17 = gJChronology14.millis();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours(10);
        java.lang.Class<?> wildcardClass11 = dateTime8.getClass();
        try {
            org.joda.time.DateTime dateTime13 = dateTime8.withHourOfDay(959);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 959 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        int int12 = offsetDateTimeField10.getMaximumValue(100L);
        boolean boolean13 = offsetDateTimeField10.isSupported();
        long long16 = offsetDateTimeField10.add(7312048L, 19);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField10.getAsShortText(6800L, locale18);
        org.joda.time.JodaTimePermission jodaTimePermission21 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str22 = jodaTimePermission21.getName();
        org.joda.time.JodaTimePermission jodaTimePermission24 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str25 = jodaTimePermission24.getName();
        boolean boolean26 = jodaTimePermission21.implies((java.security.Permission) jodaTimePermission24);
        org.joda.time.Instant instant27 = new org.joda.time.Instant();
        org.joda.time.Instant instant28 = new org.joda.time.Instant();
        boolean boolean29 = instant27.isBefore((org.joda.time.ReadableInstant) instant28);
        org.joda.time.Instant instant30 = new org.joda.time.Instant();
        org.joda.time.Instant instant31 = new org.joda.time.Instant();
        boolean boolean32 = instant30.isBefore((org.joda.time.ReadableInstant) instant31);
        boolean boolean33 = instant28.isBefore((org.joda.time.ReadableInstant) instant30);
        org.joda.time.Chronology chronology34 = instant30.getChronology();
        org.joda.time.ReadableDateTime readableDateTime35 = null;
        org.joda.time.ReadableDateTime readableDateTime36 = null;
        org.joda.time.chrono.LimitChronology limitChronology37 = org.joda.time.chrono.LimitChronology.getInstance(chronology34, readableDateTime35, readableDateTime36);
        org.joda.time.Partial partial38 = new org.joda.time.Partial(chronology34);
        org.joda.time.Instant instant39 = new org.joda.time.Instant();
        org.joda.time.Instant instant40 = new org.joda.time.Instant();
        boolean boolean41 = instant39.isBefore((org.joda.time.ReadableInstant) instant40);
        org.joda.time.Instant instant42 = new org.joda.time.Instant();
        org.joda.time.Instant instant43 = new org.joda.time.Instant();
        boolean boolean44 = instant42.isBefore((org.joda.time.ReadableInstant) instant43);
        boolean boolean45 = instant40.isBefore((org.joda.time.ReadableInstant) instant42);
        org.joda.time.Chronology chronology46 = instant42.getChronology();
        org.joda.time.ReadableDateTime readableDateTime47 = null;
        org.joda.time.ReadableDateTime readableDateTime48 = null;
        org.joda.time.chrono.LimitChronology limitChronology49 = org.joda.time.chrono.LimitChronology.getInstance(chronology46, readableDateTime47, readableDateTime48);
        org.joda.time.Partial partial50 = new org.joda.time.Partial(chronology46);
        boolean boolean51 = partial38.isMatch((org.joda.time.ReadablePartial) partial50);
        int[] intArray52 = partial38.getValues();
        jodaTimePermission24.checkGuard((java.lang.Object) partial38);
        java.util.Locale locale54 = null;
        try {
            java.lang.String str55 = offsetDateTimeField10.getAsText((org.joda.time.ReadablePartial) partial38, locale54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 78 + "'", int12 == 78);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 8452048L + "'", long16 == 8452048L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "18" + "'", str19.equals("18"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(limitChronology37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertNotNull(limitChronology49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(intArray52);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        int int15 = localDate13.getDayOfMonth();
        org.joda.time.Chronology chronology16 = localDate13.getChronology();
        org.joda.time.LocalDate.Property property17 = localDate13.era();
        try {
            org.joda.time.LocalDate localDate19 = property17.setCopy(52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMinutes((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plus((long) (byte) 0);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        try {
            java.lang.String str12 = dateTime9.toString("1970-01-01T��");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 166);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.DateTime dateTime2 = localDate1.toDateTimeAtCurrentTime();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.LocalDate localDate4 = localDate1.minus(readablePeriod3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.052", "1970-01-01", 365, (int) (byte) 1);
        org.joda.time.DateTime dateTime10 = localDate4.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        int int11 = localDate4.getYear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfDay((int) ' ', 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder12.appendSecondOfMinute(57);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder12.appendLiteral("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.clockhourOfHalfday();
        org.joda.time.DurationField durationField24 = iSOChronology22.seconds();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTime.Property property26 = dateTime25.weekOfWeekyear();
        org.joda.time.DateTime.Property property27 = dateTime25.year();
        org.joda.time.DateTime dateTime29 = dateTime25.withMillis((long) 52);
        org.joda.time.DateTime.Property property30 = dateTime25.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder19.appendShortText(dateTimeFieldType31);
        try {
            int int33 = localDate4.get(dateTimeFieldType31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withZone(dateTimeZone2);
        java.io.Writer writer9 = null;
        try {
            dateTimeFormatter0.printTo(writer9, 2440588L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendDayOfWeek(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendClockhourOfHalfday(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.DateTime dateTime2 = localDate1.toDateTimeAtCurrentTime();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.LocalDate localDate4 = localDate1.minus(readablePeriod3);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.052", "1970-01-01", 365, (int) (byte) 1);
        org.joda.time.DateTime dateTime10 = localDate4.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = dateTime10.isSupported(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("+00:00:00.052", "1970-01-01", 365, (int) (byte) 1);
        org.joda.time.Chronology chronology19 = buddhistChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        long long21 = fixedDateTimeZone18.nextTransition((long) 9);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        long long24 = fixedDateTimeZone18.nextTransition((long) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9L + "'", long21 == 9L);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        int int15 = localDate13.getDayOfMonth();
        org.joda.time.Chronology chronology16 = localDate13.getChronology();
        java.lang.String str18 = localDate13.toString("1970-01-19");
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-01-19" + "'", str18.equals("1970-01-19"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendCenturyOfEra(3, 84480732);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField16 = iSOChronology15.minutes();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology12, dateTimeField17, (int) (byte) 1);
        org.joda.time.Instant instant20 = new org.joda.time.Instant();
        org.joda.time.Instant instant21 = new org.joda.time.Instant();
        boolean boolean22 = instant20.isBefore((org.joda.time.ReadableInstant) instant21);
        org.joda.time.Instant instant23 = new org.joda.time.Instant();
        org.joda.time.Instant instant24 = new org.joda.time.Instant();
        boolean boolean25 = instant23.isBefore((org.joda.time.ReadableInstant) instant24);
        boolean boolean26 = instant21.isBefore((org.joda.time.ReadableInstant) instant23);
        org.joda.time.Chronology chronology27 = instant23.getChronology();
        org.joda.time.ReadableDateTime readableDateTime28 = null;
        org.joda.time.ReadableDateTime readableDateTime29 = null;
        org.joda.time.chrono.LimitChronology limitChronology30 = org.joda.time.chrono.LimitChronology.getInstance(chronology27, readableDateTime28, readableDateTime29);
        org.joda.time.Partial partial31 = new org.joda.time.Partial(chronology27);
        int[] intArray39 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
        int[] intArray41 = skipDateTimeField19.addWrapPartial((org.joda.time.ReadablePartial) partial31, (int) (short) 0, intArray39, (int) (short) 1);
        int int44 = skipDateTimeField19.getDifference((long) 52, (long) (byte) 100);
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField(chronology7, (org.joda.time.DateTimeField) skipDateTimeField19);
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone48);
        org.joda.time.DurationField durationField50 = iSOChronology49.minutes();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology46, dateTimeField51, (int) (byte) 1);
        int int54 = skipDateTimeField53.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, (org.joda.time.DateTimeField) skipDateTimeField53, (int) ' ');
        java.util.Locale locale57 = null;
        int int58 = skipDateTimeField53.getMaximumShortTextLength(locale57);
        java.util.Locale locale60 = null;
        java.lang.String str61 = skipDateTimeField53.getAsText((long) (byte) 0, locale60);
        try {
            long long64 = skipDateTimeField53.set(0L, "82866");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82866 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(limitChronology30);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2 + "'", int58 == 2);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "0" + "'", str61.equals("0"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        try {
            long long4 = dateTimeFormatter2.parseMillis("129");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"129\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        boolean boolean7 = instant5.isBefore((org.joda.time.ReadableInstant) instant6);
        int int8 = property3.getDifference((org.joda.time.ReadableInstant) instant5);
        org.joda.time.LocalDate localDate9 = property3.roundHalfEvenCopy();
        org.joda.time.DateTimeField dateTimeField10 = property3.getField();
        org.joda.time.LocalDate localDate11 = property3.withMinimumValue();
        int int12 = property3.getLeapAmount();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.util.Locale locale3 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.Partial partial26 = partial11.minus(readablePeriod25);
        org.joda.time.Instant instant27 = new org.joda.time.Instant();
        org.joda.time.Instant instant28 = new org.joda.time.Instant();
        boolean boolean29 = instant27.isBefore((org.joda.time.ReadableInstant) instant28);
        org.joda.time.Instant instant30 = new org.joda.time.Instant();
        org.joda.time.Instant instant31 = new org.joda.time.Instant();
        boolean boolean32 = instant30.isBefore((org.joda.time.ReadableInstant) instant31);
        boolean boolean33 = instant28.isBefore((org.joda.time.ReadableInstant) instant30);
        org.joda.time.Chronology chronology34 = instant30.getChronology();
        org.joda.time.DateTime dateTime35 = instant30.toDateTimeISO();
        org.joda.time.DateTime.Property property36 = dateTime35.year();
        int int37 = dateTime35.getEra();
        int int38 = dateTime35.getDayOfYear();
        org.joda.time.DateTime.Property property39 = dateTime35.yearOfEra();
        org.joda.time.DateTime.Property property40 = dateTime35.centuryOfEra();
        org.joda.time.DateTime.Property property41 = dateTime35.yearOfEra();
        boolean boolean42 = partial11.isMatch((org.joda.time.ReadableInstant) dateTime35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(partial26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        boolean boolean10 = instant8.isBefore((org.joda.time.ReadableInstant) instant9);
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
        boolean boolean14 = instant9.isBefore((org.joda.time.ReadableInstant) instant11);
        org.joda.time.Chronology chronology15 = instant11.getChronology();
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance(chronology15, readableDateTime16, readableDateTime17);
        org.joda.time.Partial partial19 = new org.joda.time.Partial(chronology15);
        int[] intArray27 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
        int[] intArray29 = skipDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) partial19, (int) (short) 0, intArray27, (int) (short) 1);
        int int32 = skipDateTimeField7.getDifference((long) 52, (long) (byte) 100);
        long long35 = skipDateTimeField7.set((long) 105, 2);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 120105L + "'", long35 == 120105L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology2.getZone();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        org.joda.time.DurationField durationField11 = offsetDateTimeField10.getDurationField();
        long long14 = offsetDateTimeField10.addWrapField(35L, 0);
        boolean boolean16 = offsetDateTimeField10.isLeap((long) 1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        org.joda.time.DurationField durationField11 = offsetDateTimeField10.getDurationField();
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField10.getMaximumTextLength(locale12);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        boolean boolean7 = instant5.isBefore((org.joda.time.ReadableInstant) instant6);
        int int8 = property3.getDifference((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Instant instant10 = instant5.withMillis((long) (byte) -1);
        java.util.Date date11 = instant10.toDate();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property5 = localDate4.monthOfYear();
        java.util.Locale locale6 = null;
        int int7 = property5.getMaximumTextLength(locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
        int int9 = localDate1.get(dateTimeFieldType8);
        org.joda.time.LocalDate.Property property10 = localDate1.yearOfEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        try {
            org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.parse("AM", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"AM\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        int int11 = offsetDateTimeField10.getMinimumValue();
        int int13 = offsetDateTimeField10.getLeapAmount(57600061L);
        java.lang.String str15 = offsetDateTimeField10.getAsShortText((long) 23);
        org.joda.time.DurationField durationField16 = offsetDateTimeField10.getDurationField();
        long long19 = durationField16.subtract((long) 84480052, (long) 84480732);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 18 + "'", int11 == 18);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "18" + "'", str15.equals("18"));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-5068759439948L) + "'", long19 == (-5068759439948L));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1970-01-01T00:00:18.000Z", (java.lang.Number) 4972500057L, (java.lang.Number) 30237229990L, (java.lang.Number) (short) 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Instant instant9 = instant3.withDurationAdded((long) 2000, 9);
        org.joda.time.DateTime dateTime10 = instant9.toDateTimeISO();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.DateMidnight dateMidnight2 = localDate1.toDateMidnight();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate1);
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        boolean boolean6 = instant4.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.Instant instant7 = new org.joda.time.Instant();
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        boolean boolean9 = instant7.isBefore((org.joda.time.ReadableInstant) instant8);
        boolean boolean10 = instant5.isBefore((org.joda.time.ReadableInstant) instant7);
        org.joda.time.Chronology chronology11 = instant7.getChronology();
        org.joda.time.ReadableDateTime readableDateTime12 = null;
        org.joda.time.ReadableDateTime readableDateTime13 = null;
        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance(chronology11, readableDateTime12, readableDateTime13);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.LocalDateTime localDateTime19 = null;
        boolean boolean20 = dateTimeZone17.isLocalDateTimeGap(localDateTime19);
        java.lang.String str22 = dateTimeZone17.getName((long) '#');
        int int24 = dateTimeZone17.getOffsetFromLocal((long) 10);
        java.util.Locale locale26 = null;
        java.lang.String str27 = dateTimeZone17.getShortName((long) 10, locale26);
        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate((long) 2, dateTimeZone17);
        org.joda.time.LocalDate.Property property29 = localDate28.weekyear();
        long long31 = limitChronology14.set((org.joda.time.ReadablePartial) localDate28, 43200000L);
        org.joda.time.LocalDate localDate33 = localDate28.plusWeeks(1);
        java.lang.String str34 = localDate28.toString();
        org.joda.time.LocalDate localDate36 = localDate28.withYearOfEra((int) '#');
        int int37 = localDate1.compareTo((org.joda.time.ReadablePartial) localDate36);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(limitChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00:00.052" + "'", str22.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00:00.052" + "'", str27.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43200000L + "'", long31 == 43200000L);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970-01-01" + "'", str34.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.year();
        int int3 = localDate1.getYearOfEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DurationField durationField11 = copticChronology10.millis();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        org.joda.time.LocalDate localDate16 = localDate13.minusYears(57600);
        java.lang.String str17 = localDate16.toString();
        org.joda.time.LocalDate localDate19 = localDate16.withYearOfCentury(0);
        org.joda.time.Instant instant20 = new org.joda.time.Instant();
        org.joda.time.Instant instant21 = new org.joda.time.Instant();
        boolean boolean22 = instant20.isBefore((org.joda.time.ReadableInstant) instant21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        boolean boolean24 = instant21.isSupported(dateTimeFieldType23);
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property27 = localDate26.monthOfYear();
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property30 = localDate29.monthOfYear();
        java.util.Locale locale31 = null;
        int int32 = property30.getMaximumTextLength(locale31);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property30.getFieldType();
        int int34 = localDate26.get(dateTimeFieldType33);
        boolean boolean35 = instant21.isSupported(dateTimeFieldType33);
        org.joda.time.IllegalFieldValueException illegalFieldValueException38 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 39641045L, "ISOChronology[+00:00:00.052]");
        boolean boolean39 = localDate16.isSupported(dateTimeFieldType33);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = null;
        try {
            int int41 = localDate16.get(dateTimeFieldType40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-55630-01-01" + "'", str17.equals("-55630-01-01"));
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipDateTimeField7, 84480052, (int) (short) 100, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 84480052 for minuteOfHour must be in the range [100,3]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.Partial partial11 = new org.joda.time.Partial(chronology7);
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        org.joda.time.Instant instant13 = new org.joda.time.Instant();
        boolean boolean14 = instant12.isBefore((org.joda.time.ReadableInstant) instant13);
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        boolean boolean17 = instant15.isBefore((org.joda.time.ReadableInstant) instant16);
        boolean boolean18 = instant13.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Chronology chronology19 = instant15.getChronology();
        org.joda.time.ReadableDateTime readableDateTime20 = null;
        org.joda.time.ReadableDateTime readableDateTime21 = null;
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance(chronology19, readableDateTime20, readableDateTime21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(chronology19);
        boolean boolean24 = partial11.isMatch((org.joda.time.ReadablePartial) partial23);
        java.lang.String str25 = partial11.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "[]" + "'", str25.equals("[]"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.Instant instant14 = new org.joda.time.Instant();
        org.joda.time.Instant instant15 = new org.joda.time.Instant();
        boolean boolean16 = instant14.isBefore((org.joda.time.ReadableInstant) instant15);
        org.joda.time.Instant instant17 = new org.joda.time.Instant();
        org.joda.time.Instant instant18 = new org.joda.time.Instant();
        boolean boolean19 = instant17.isBefore((org.joda.time.ReadableInstant) instant18);
        boolean boolean20 = instant15.isBefore((org.joda.time.ReadableInstant) instant17);
        org.joda.time.Chronology chronology21 = instant17.getChronology();
        org.joda.time.DateTime dateTime22 = instant17.toDateTimeISO();
        org.joda.time.DateTime.Property property23 = dateTime22.year();
        int int24 = dateTime22.getEra();
        int int25 = dateTime22.getDayOfYear();
        org.joda.time.DateTime.Property property26 = dateTime22.yearOfEra();
        int int27 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime22);
        int int28 = dateTime22.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 52 + "'", int27 == 52);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 70 + "'", int28 == 70);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField10.getRangeDurationField();
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField10.getAsText((long) (short) 100, locale13);
        org.joda.time.DateTimeField dateTimeField15 = skipUndoDateTimeField10.getWrappedField();
        int int16 = skipUndoDateTimeField10.getMinimumValue();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, 52);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone22 = iSOChronology21.getZone();
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone22);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray24 = localDate23.getFieldTypes();
        int[] intArray26 = null;
        try {
            int[] intArray28 = offsetDateTimeField18.set((org.joda.time.ReadablePartial) localDate23, 70, intArray26, 332);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 332 for halfdayOfDay must be in the range [53,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AM" + "'", str14.equals("AM"));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray24);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
        long long12 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = buddhistChronology13.withZone(dateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.LocalDateTime localDateTime20 = null;
        boolean boolean21 = dateTimeZone18.isLocalDateTimeGap(localDateTime20);
        java.lang.String str23 = dateTimeZone18.getName((long) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter16.withZone(dateTimeZone18);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology13, dateTimeZone18);
        org.joda.time.DurationField durationField26 = buddhistChronology13.centuries();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 53L + "'", long12 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(durationField26);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 57, "19700101T000000.105+0000");
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        boolean boolean7 = instant4.isSupported(dateTimeFieldType6);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property10 = localDate9.monthOfYear();
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property13 = localDate12.monthOfYear();
        java.util.Locale locale14 = null;
        int int15 = property13.getMaximumTextLength(locale14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property13.getFieldType();
        int int17 = localDate9.get(dateTimeFieldType16);
        boolean boolean18 = instant4.isSupported(dateTimeFieldType16);
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, (java.lang.Number) 39641045L, "ISOChronology[+00:00:00.052]");
        illegalInstantException2.addSuppressed((java.lang.Throwable) illegalFieldValueException21);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.era();
        int int16 = gJChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = iSOChronology17.add(readablePeriod19, 100L, 57600010);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone24.isLocalDateTimeGap(localDateTime26);
        java.lang.String str29 = dateTimeZone24.getName((long) '#');
        int int31 = dateTimeZone24.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime32 = null;
        boolean boolean33 = dateTimeZone24.isLocalDateTimeGap(localDateTime32);
        long long35 = dateTimeZone24.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone24);
        org.joda.time.Chronology chronology37 = iSOChronology17.withZone(dateTimeZone24);
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        java.lang.String str40 = dateTimeZone24.getShortName((long) (byte) 0);
        org.joda.time.Chronology chronology41 = gJChronology14.withZone(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+00:00:00.052" + "'", str29.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 52 + "'", int31 == 52);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 53L + "'", long35 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "+00:00:00.052" + "'", str40.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(chronology41);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.ReadableDateTime readableDateTime8 = null;
        org.joda.time.ReadableDateTime readableDateTime9 = null;
        org.joda.time.chrono.LimitChronology limitChronology10 = org.joda.time.chrono.LimitChronology.getInstance(chronology7, readableDateTime8, readableDateTime9);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.LocalDateTime localDateTime15 = null;
        boolean boolean16 = dateTimeZone13.isLocalDateTimeGap(localDateTime15);
        java.lang.String str18 = dateTimeZone13.getName((long) '#');
        int int20 = dateTimeZone13.getOffsetFromLocal((long) 10);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone13.getShortName((long) 10, locale22);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) 2, dateTimeZone13);
        org.joda.time.LocalDate.Property property25 = localDate24.weekyear();
        long long27 = limitChronology10.set((org.joda.time.ReadablePartial) localDate24, 43200000L);
        org.joda.time.LocalDate localDate29 = localDate24.plusWeeks(1);
        java.lang.String str30 = localDate24.toString();
        org.joda.time.LocalDate.Property property31 = localDate24.dayOfMonth();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray32 = localDate24.getFieldTypes();
        org.joda.time.Instant instant33 = new org.joda.time.Instant();
        org.joda.time.Instant instant34 = new org.joda.time.Instant();
        boolean boolean35 = instant33.isBefore((org.joda.time.ReadableInstant) instant34);
        org.joda.time.Instant instant36 = new org.joda.time.Instant();
        org.joda.time.Instant instant37 = new org.joda.time.Instant();
        boolean boolean38 = instant36.isBefore((org.joda.time.ReadableInstant) instant37);
        boolean boolean39 = instant34.isBefore((org.joda.time.ReadableInstant) instant36);
        org.joda.time.Chronology chronology40 = instant36.getChronology();
        org.joda.time.ReadableDateTime readableDateTime41 = null;
        org.joda.time.ReadableDateTime readableDateTime42 = null;
        org.joda.time.chrono.LimitChronology limitChronology43 = org.joda.time.chrono.LimitChronology.getInstance(chronology40, readableDateTime41, readableDateTime42);
        org.joda.time.Partial partial44 = new org.joda.time.Partial(chronology40);
        org.joda.time.Instant instant45 = new org.joda.time.Instant();
        org.joda.time.Instant instant46 = new org.joda.time.Instant();
        boolean boolean47 = instant45.isBefore((org.joda.time.ReadableInstant) instant46);
        org.joda.time.Instant instant48 = new org.joda.time.Instant();
        org.joda.time.Instant instant49 = new org.joda.time.Instant();
        boolean boolean50 = instant48.isBefore((org.joda.time.ReadableInstant) instant49);
        boolean boolean51 = instant46.isBefore((org.joda.time.ReadableInstant) instant48);
        org.joda.time.Chronology chronology52 = instant48.getChronology();
        org.joda.time.ReadableDateTime readableDateTime53 = null;
        org.joda.time.ReadableDateTime readableDateTime54 = null;
        org.joda.time.chrono.LimitChronology limitChronology55 = org.joda.time.chrono.LimitChronology.getInstance(chronology52, readableDateTime53, readableDateTime54);
        org.joda.time.Partial partial56 = new org.joda.time.Partial(chronology52);
        boolean boolean57 = partial44.isMatch((org.joda.time.ReadablePartial) partial56);
        int[] intArray58 = partial44.getValues();
        try {
            org.joda.time.Partial partial59 = new org.joda.time.Partial(dateTimeFieldTypeArray32, intArray58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(limitChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.052" + "'", str18.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.052" + "'", str23.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43200000L + "'", long27 == 43200000L);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1970-01-01" + "'", str30.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(limitChronology43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertNotNull(limitChronology55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(intArray58);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        boolean boolean7 = instant5.isBefore((org.joda.time.ReadableInstant) instant6);
        int int8 = property3.getDifference((org.joda.time.ReadableInstant) instant5);
        org.joda.time.LocalDate localDate9 = property3.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate10 = property3.withMinimumValue();
        org.joda.time.LocalDate localDate12 = localDate10.plusDays(129);
        org.joda.time.LocalDate localDate14 = localDate10.minusMonths(57);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        illegalFieldValueException2.prependMessage("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException8.getDurationFieldType();
        illegalFieldValueException8.prependMessage("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.001 (hi!)");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException8);
        java.lang.String str13 = illegalFieldValueException8.getIllegalValueAsString();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfDay();
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        boolean boolean7 = instant5.isBefore((org.joda.time.ReadableInstant) instant6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        boolean boolean9 = instant6.isSupported(dateTimeFieldType8);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property12 = localDate11.monthOfYear();
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property15 = localDate14.monthOfYear();
        java.util.Locale locale16 = null;
        int int17 = property15.getMaximumTextLength(locale16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property15.getFieldType();
        int int19 = localDate11.get(dateTimeFieldType18);
        boolean boolean20 = instant6.isSupported(dateTimeFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 39641045L, "ISOChronology[+00:00:00.052]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "0");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField27 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType18, 35);
        long long29 = dividedDateTimeField27.remainder((long) (-13));
        long long32 = dividedDateTimeField27.getDifferenceAsLong((-515477250L), (long) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-13L) + "'", long29 == (-13L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-4L) + "'", long32 == (-4L));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField8, (int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField10, dateTimeFieldType11);
        int int14 = delegatedDateTimeField12.getMinimumValue((long) (short) 100);
        long long17 = delegatedDateTimeField12.addWrapField(0L, 365);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.LocalDateTime localDateTime22 = null;
        boolean boolean23 = dateTimeZone20.isLocalDateTimeGap(localDateTime22);
        java.lang.String str25 = dateTimeZone20.getName((long) '#');
        int int27 = dateTimeZone20.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime28 = null;
        boolean boolean29 = dateTimeZone20.isLocalDateTimeGap(localDateTime28);
        long long31 = dateTimeZone20.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone20);
        org.joda.time.LocalDateTime localDateTime33 = null;
        boolean boolean34 = dateTimeZone20.isLocalDateTimeGap(localDateTime33);
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(576000100L, (org.joda.time.Chronology) gJChronology35);
        org.joda.time.Instant instant38 = new org.joda.time.Instant();
        org.joda.time.Instant instant39 = new org.joda.time.Instant();
        boolean boolean40 = instant38.isBefore((org.joda.time.ReadableInstant) instant39);
        org.joda.time.Instant instant41 = new org.joda.time.Instant();
        org.joda.time.Instant instant42 = new org.joda.time.Instant();
        boolean boolean43 = instant41.isBefore((org.joda.time.ReadableInstant) instant42);
        boolean boolean44 = instant39.isBefore((org.joda.time.ReadableInstant) instant41);
        org.joda.time.Chronology chronology45 = instant41.getChronology();
        org.joda.time.ReadableDateTime readableDateTime46 = null;
        org.joda.time.ReadableDateTime readableDateTime47 = null;
        org.joda.time.chrono.LimitChronology limitChronology48 = org.joda.time.chrono.LimitChronology.getInstance(chronology45, readableDateTime46, readableDateTime47);
        org.joda.time.Partial partial49 = new org.joda.time.Partial(chronology45);
        org.joda.time.Instant instant50 = new org.joda.time.Instant();
        org.joda.time.Instant instant51 = new org.joda.time.Instant();
        boolean boolean52 = instant50.isBefore((org.joda.time.ReadableInstant) instant51);
        org.joda.time.Instant instant53 = new org.joda.time.Instant();
        org.joda.time.Instant instant54 = new org.joda.time.Instant();
        boolean boolean55 = instant53.isBefore((org.joda.time.ReadableInstant) instant54);
        boolean boolean56 = instant51.isBefore((org.joda.time.ReadableInstant) instant53);
        org.joda.time.Chronology chronology57 = instant53.getChronology();
        org.joda.time.ReadableDateTime readableDateTime58 = null;
        org.joda.time.ReadableDateTime readableDateTime59 = null;
        org.joda.time.chrono.LimitChronology limitChronology60 = org.joda.time.chrono.LimitChronology.getInstance(chronology57, readableDateTime58, readableDateTime59);
        org.joda.time.Partial partial61 = new org.joda.time.Partial(chronology57);
        boolean boolean62 = partial49.isMatch((org.joda.time.ReadablePartial) partial61);
        int[] intArray63 = partial61.getValues();
        try {
            int[] intArray65 = delegatedDateTimeField12.addWrapPartial((org.joda.time.ReadablePartial) localDate36, 24, intArray63, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 24");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43200000L + "'", long17 == 43200000L);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.052" + "'", str25.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 52 + "'", int27 == 52);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 53L + "'", long31 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(limitChronology48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(limitChronology60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(intArray63);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone4.isLocalDateTimeGap(localDateTime6);
        java.lang.String str9 = dateTimeZone4.getName((long) '#');
        int int11 = dateTimeZone4.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime12 = null;
        boolean boolean13 = dateTimeZone4.isLocalDateTimeGap(localDateTime12);
        long long15 = dateTimeZone4.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withZone(dateTimeZone4);
        java.util.Locale locale18 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter17.withLocale(locale18);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.052" + "'", str9.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 53L + "'", long15 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        java.lang.String str7 = dateTimeZone2.getName((long) '#');
        int int9 = dateTimeZone2.getOffsetFromLocal((long) 10);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone2.getShortName((long) 10, locale11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) 2, dateTimeZone2);
        org.joda.time.LocalDate.Property property14 = localDate13.weekyear();
        org.joda.time.LocalDate localDate15 = property14.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.052" + "'", str7.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate15);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours(10);
        java.lang.Class<?> wildcardClass11 = dateTime8.getClass();
        org.joda.time.DateTime dateTime13 = dateTime8.minusDays(24);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str5 = jodaTimePermission4.getName();
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.Instant instant7 = new org.joda.time.Instant();
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        boolean boolean9 = instant7.isBefore((org.joda.time.ReadableInstant) instant8);
        org.joda.time.Instant instant10 = new org.joda.time.Instant();
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        boolean boolean12 = instant10.isBefore((org.joda.time.ReadableInstant) instant11);
        boolean boolean13 = instant8.isBefore((org.joda.time.ReadableInstant) instant10);
        org.joda.time.Chronology chronology14 = instant10.getChronology();
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance(chronology14, readableDateTime15, readableDateTime16);
        org.joda.time.Partial partial18 = new org.joda.time.Partial(chronology14);
        org.joda.time.Instant instant19 = new org.joda.time.Instant();
        org.joda.time.Instant instant20 = new org.joda.time.Instant();
        boolean boolean21 = instant19.isBefore((org.joda.time.ReadableInstant) instant20);
        org.joda.time.Instant instant22 = new org.joda.time.Instant();
        org.joda.time.Instant instant23 = new org.joda.time.Instant();
        boolean boolean24 = instant22.isBefore((org.joda.time.ReadableInstant) instant23);
        boolean boolean25 = instant20.isBefore((org.joda.time.ReadableInstant) instant22);
        org.joda.time.Chronology chronology26 = instant22.getChronology();
        org.joda.time.ReadableDateTime readableDateTime27 = null;
        org.joda.time.ReadableDateTime readableDateTime28 = null;
        org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance(chronology26, readableDateTime27, readableDateTime28);
        org.joda.time.Partial partial30 = new org.joda.time.Partial(chronology26);
        boolean boolean31 = partial18.isMatch((org.joda.time.ReadablePartial) partial30);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.clockhourOfHalfday();
        org.joda.time.Partial partial36 = partial30.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology34);
        boolean boolean37 = jodaTimePermission4.equals((java.lang.Object) partial30);
        boolean boolean38 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) partial30);
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.LocalDateTime localDateTime43 = null;
        boolean boolean44 = dateTimeZone41.isLocalDateTimeGap(localDateTime43);
        java.lang.String str46 = dateTimeZone41.getName((long) '#');
        int int48 = dateTimeZone41.getOffsetFromLocal((long) 10);
        java.util.Locale locale50 = null;
        java.lang.String str51 = dateTimeZone41.getShortName((long) 10, locale50);
        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate((long) 2, dateTimeZone41);
        org.joda.time.LocalDate.Property property53 = localDate52.monthOfYear();
        org.joda.time.LocalDate localDate55 = localDate52.minusYears(57600);
        java.lang.String str56 = localDate55.toString();
        org.joda.time.LocalDate localDate58 = localDate55.withYearOfCentury(0);
        org.joda.time.Instant instant59 = new org.joda.time.Instant();
        org.joda.time.Instant instant60 = new org.joda.time.Instant();
        boolean boolean61 = instant59.isBefore((org.joda.time.ReadableInstant) instant60);
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = null;
        boolean boolean63 = instant60.isSupported(dateTimeFieldType62);
        org.joda.time.LocalDate localDate65 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property66 = localDate65.monthOfYear();
        org.joda.time.LocalDate localDate68 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property69 = localDate68.monthOfYear();
        java.util.Locale locale70 = null;
        int int71 = property69.getMaximumTextLength(locale70);
        org.joda.time.DateTimeFieldType dateTimeFieldType72 = property69.getFieldType();
        int int73 = localDate65.get(dateTimeFieldType72);
        boolean boolean74 = instant60.isSupported(dateTimeFieldType72);
        org.joda.time.IllegalFieldValueException illegalFieldValueException77 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType72, (java.lang.Number) 39641045L, "ISOChronology[+00:00:00.052]");
        boolean boolean78 = localDate55.isSupported(dateTimeFieldType72);
        try {
            org.joda.time.Partial.Property property79 = partial30.property(dateTimeFieldType72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'monthOfYear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(limitChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(partial36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+00:00:00.052" + "'", str46.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 52 + "'", int48 == 52);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "+00:00:00.052" + "'", str51.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "-55630-01-01" + "'", str56.equals("-55630-01-01"));
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 9 + "'", int71 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        java.lang.String str12 = cachedDateTimeZone9.getNameKey((long) 35);
        long long14 = cachedDateTimeZone9.convertUTCToLocal(105433401600097L);
        long long17 = cachedDateTimeZone9.convertLocalToUTC((long) (byte) -1, true);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 105433401600149L + "'", long14 == 105433401600149L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-53L) + "'", long17 == (-53L));
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = dateTimeZone3.isLocalDateTimeGap(localDateTime5);
        java.lang.String str8 = dateTimeZone3.getName((long) '#');
        int int10 = dateTimeZone3.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.LocalDateTime localDateTime12 = null;
        boolean boolean13 = cachedDateTimeZone11.isLocalDateTimeGap(localDateTime12);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone11);
        org.joda.time.Chronology chronology15 = copticChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone11);
        org.joda.time.Instant instant16 = new org.joda.time.Instant();
        org.joda.time.Instant instant17 = new org.joda.time.Instant();
        boolean boolean18 = instant16.isBefore((org.joda.time.ReadableInstant) instant17);
        org.joda.time.Instant instant19 = new org.joda.time.Instant();
        org.joda.time.Instant instant20 = new org.joda.time.Instant();
        boolean boolean21 = instant19.isBefore((org.joda.time.ReadableInstant) instant20);
        boolean boolean22 = instant17.isBefore((org.joda.time.ReadableInstant) instant19);
        org.joda.time.Chronology chronology23 = instant19.getChronology();
        org.joda.time.ReadableDateTime readableDateTime24 = null;
        org.joda.time.ReadableDateTime readableDateTime25 = null;
        org.joda.time.chrono.LimitChronology limitChronology26 = org.joda.time.chrono.LimitChronology.getInstance(chronology23, readableDateTime24, readableDateTime25);
        org.joda.time.Chronology chronology27 = limitChronology26.withUTC();
        org.joda.time.DurationField durationField28 = limitChronology26.millis();
        boolean boolean29 = copticChronology0.equals((java.lang.Object) durationField28);
        try {
            long long34 = copticChronology0.getDateTimeMillis(100, (int) '4', 0, 82875);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.052" + "'", str8.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(limitChronology26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = dateTimeZone3.isLocalDateTimeGap(localDateTime5);
        java.lang.String str8 = dateTimeZone3.getName((long) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.parse("0", dateTimeFormatter1);
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = dateTimeFormatter1.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.052" + "'", str8.equals("+00:00:00.052"));
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimePrinter11);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.year();
        long long3 = property2.remainder();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        int int12 = offsetDateTimeField10.getMaximumValue(100L);
        int int13 = offsetDateTimeField10.getMaximumValue();
        long long15 = offsetDateTimeField10.roundHalfCeiling((long) (byte) 1);
        long long18 = offsetDateTimeField10.add((-315534719268L), (long) 100);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 78 + "'", int12 == 78);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 78 + "'", int13 == 78);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-52L) + "'", long15 == (-52L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-315528719268L) + "'", long18 == (-315528719268L));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', 24);
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        boolean boolean6 = instant4.isBefore((org.joda.time.ReadableInstant) instant5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = instant5.isSupported(dateTimeFieldType7);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property11 = localDate10.monthOfYear();
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        java.util.Locale locale15 = null;
        int int16 = property14.getMaximumTextLength(locale15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property14.getFieldType();
        int int18 = localDate10.get(dateTimeFieldType17);
        boolean boolean19 = instant5.isSupported(dateTimeFieldType17);
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) 39641045L, "ISOChronology[+00:00:00.052]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        long long9 = skipDateTimeField7.roundHalfFloor(100L);
        org.joda.time.DurationField durationField10 = skipDateTimeField7.getRangeDurationField();
        int int12 = skipDateTimeField7.get(100L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField7.getMaximumShortTextLength(locale13);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-52L) + "'", long9 == (-52L));
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((long) (-1));
        org.joda.time.LocalDate.Property property2 = localDate1.monthOfYear();
        org.joda.time.LocalDate.Property property3 = localDate1.weekyear();
        org.joda.time.DateTimeField[] dateTimeFieldArray4 = localDate1.getFields();
        org.joda.time.LocalDate.Property property5 = localDate1.dayOfYear();
        int int6 = localDate1.getYearOfCentury();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFieldArray4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 70 + "'", int6 == 70);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMillis((int) (byte) 0);
        org.joda.time.DateTime dateTime4 = dateTime2.minusMillis(82841045);
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfDay();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology0.add(readablePeriod2, 100L, 57600010);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone7.isLocalDateTimeGap(localDateTime9);
        java.lang.String str12 = dateTimeZone7.getName((long) '#');
        int int14 = dateTimeZone7.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime15 = null;
        boolean boolean16 = dateTimeZone7.isLocalDateTimeGap(localDateTime15);
        long long18 = dateTimeZone7.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology20 = iSOChronology0.withZone(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.Instant instant22 = new org.joda.time.Instant();
        org.joda.time.Instant instant23 = new org.joda.time.Instant();
        boolean boolean24 = instant22.isBefore((org.joda.time.ReadableInstant) instant23);
        org.joda.time.Instant instant25 = new org.joda.time.Instant();
        org.joda.time.Instant instant26 = new org.joda.time.Instant();
        boolean boolean27 = instant25.isBefore((org.joda.time.ReadableInstant) instant26);
        boolean boolean28 = instant23.isBefore((org.joda.time.ReadableInstant) instant25);
        org.joda.time.Chronology chronology29 = instant25.getChronology();
        org.joda.time.ReadableDateTime readableDateTime30 = null;
        org.joda.time.ReadableDateTime readableDateTime31 = null;
        org.joda.time.chrono.LimitChronology limitChronology32 = org.joda.time.chrono.LimitChronology.getInstance(chronology29, readableDateTime30, readableDateTime31);
        java.lang.String str33 = limitChronology32.toString();
        org.joda.time.DurationField durationField34 = limitChronology32.months();
        org.joda.time.DateTimeZone dateTimeZone35 = limitChronology32.getZone();
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35);
        org.joda.time.Chronology chronology37 = julianChronology21.withZone(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 53L + "'", long18 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(limitChronology32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "LimitChronology[ISOChronology[UTC], NoLimit, NoLimit]" + "'", str33.equals("LimitChronology[ISOChronology[UTC], NoLimit, NoLimit]"));
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(chronology37);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField8 = skipDateTimeField7.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 19);
        int int12 = offsetDateTimeField10.getMaximumValue(100L);
        boolean boolean13 = offsetDateTimeField10.isSupported();
        long long15 = offsetDateTimeField10.roundHalfEven(1560639635957L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 78 + "'", int12 == 78);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560639659948L + "'", long15 == 1560639659948L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        boolean boolean10 = instant8.isBefore((org.joda.time.ReadableInstant) instant9);
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
        boolean boolean14 = instant9.isBefore((org.joda.time.ReadableInstant) instant11);
        org.joda.time.Chronology chronology15 = instant11.getChronology();
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance(chronology15, readableDateTime16, readableDateTime17);
        org.joda.time.Partial partial19 = new org.joda.time.Partial(chronology15);
        int[] intArray27 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
        int[] intArray29 = skipDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) partial19, (int) (short) 0, intArray27, (int) (short) 1);
        org.joda.time.Instant instant30 = new org.joda.time.Instant();
        org.joda.time.Instant instant31 = new org.joda.time.Instant();
        boolean boolean32 = instant30.isBefore((org.joda.time.ReadableInstant) instant31);
        org.joda.time.Instant instant33 = new org.joda.time.Instant();
        org.joda.time.Instant instant34 = new org.joda.time.Instant();
        boolean boolean35 = instant33.isBefore((org.joda.time.ReadableInstant) instant34);
        boolean boolean36 = instant31.isBefore((org.joda.time.ReadableInstant) instant33);
        org.joda.time.Chronology chronology37 = instant33.getChronology();
        org.joda.time.ReadableDateTime readableDateTime38 = null;
        org.joda.time.ReadableDateTime readableDateTime39 = null;
        org.joda.time.chrono.LimitChronology limitChronology40 = org.joda.time.chrono.LimitChronology.getInstance(chronology37, readableDateTime38, readableDateTime39);
        org.joda.time.Partial partial41 = new org.joda.time.Partial(chronology37);
        org.joda.time.Instant instant42 = new org.joda.time.Instant();
        org.joda.time.Instant instant43 = new org.joda.time.Instant();
        boolean boolean44 = instant42.isBefore((org.joda.time.ReadableInstant) instant43);
        org.joda.time.Instant instant45 = new org.joda.time.Instant();
        org.joda.time.Instant instant46 = new org.joda.time.Instant();
        boolean boolean47 = instant45.isBefore((org.joda.time.ReadableInstant) instant46);
        boolean boolean48 = instant43.isBefore((org.joda.time.ReadableInstant) instant45);
        org.joda.time.Chronology chronology49 = instant45.getChronology();
        org.joda.time.ReadableDateTime readableDateTime50 = null;
        org.joda.time.ReadableDateTime readableDateTime51 = null;
        org.joda.time.chrono.LimitChronology limitChronology52 = org.joda.time.chrono.LimitChronology.getInstance(chronology49, readableDateTime50, readableDateTime51);
        org.joda.time.Partial partial53 = new org.joda.time.Partial(chronology49);
        org.joda.time.Instant instant54 = new org.joda.time.Instant();
        org.joda.time.Instant instant55 = new org.joda.time.Instant();
        boolean boolean56 = instant54.isBefore((org.joda.time.ReadableInstant) instant55);
        org.joda.time.Instant instant57 = new org.joda.time.Instant();
        org.joda.time.Instant instant58 = new org.joda.time.Instant();
        boolean boolean59 = instant57.isBefore((org.joda.time.ReadableInstant) instant58);
        boolean boolean60 = instant55.isBefore((org.joda.time.ReadableInstant) instant57);
        org.joda.time.Chronology chronology61 = instant57.getChronology();
        org.joda.time.ReadableDateTime readableDateTime62 = null;
        org.joda.time.ReadableDateTime readableDateTime63 = null;
        org.joda.time.chrono.LimitChronology limitChronology64 = org.joda.time.chrono.LimitChronology.getInstance(chronology61, readableDateTime62, readableDateTime63);
        org.joda.time.Partial partial65 = new org.joda.time.Partial(chronology61);
        boolean boolean66 = partial53.isMatch((org.joda.time.ReadablePartial) partial65);
        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone68);
        org.joda.time.DateTimeField dateTimeField70 = iSOChronology69.clockhourOfHalfday();
        org.joda.time.Partial partial71 = partial65.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology69);
        boolean boolean72 = partial41.isMatch((org.joda.time.ReadablePartial) partial65);
        int[] intArray75 = new int[] { (byte) -1 };
        int[] intArray77 = skipDateTimeField7.add((org.joda.time.ReadablePartial) partial41, (int) (byte) 100, intArray75, (int) (byte) 0);
        int int78 = skipDateTimeField7.getMaximumValue();
        try {
            long long81 = skipDateTimeField7.set((long) 82843301, 57600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for minuteOfHour must be in the range [-1,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(limitChronology40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(limitChronology52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(chronology61);
        org.junit.Assert.assertNotNull(limitChronology64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertNotNull(iSOChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(partial71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 59 + "'", int78 == 59);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMillis((int) (byte) 0);
        org.joda.time.DateTime.Property property3 = dateTime0.yearOfCentury();
        int int4 = property3.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 99 + "'", int4 == 99);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        int int10 = dateTime8.getEra();
        int int11 = dateTime8.getDayOfYear();
        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
        int int13 = dateTime8.getMillisOfDay();
        long long14 = dateTime8.getMillis();
        org.joda.time.DateTime dateTime16 = dateTime8.withCenturyOfEra(2000);
        int int17 = dateTime8.getSecondOfMinute();
        org.joda.time.DateTime dateTime18 = dateTime8.toDateTime();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.year();
        org.joda.time.Chronology chronology5 = iSOChronology2.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        java.lang.String str6 = dateTimeZone1.getName((long) '#');
        int int8 = dateTimeZone1.getOffsetFromLocal((long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime10 = null;
        boolean boolean11 = cachedDateTimeZone9.isLocalDateTimeGap(localDateTime10);
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = gregorianChronology13.add(readablePeriod14, 105433401600010L, 10);
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology13.getZone();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis(57600);
        long long22 = dateTimeZone18.getMillisKeepLocal(dateTimeZone20, (long) 19);
        org.joda.time.Chronology chronology23 = julianChronology12.withZone(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.052" + "'", str6.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 105433401600010L + "'", long17 == 105433401600010L);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-57529L) + "'", long22 == (-57529L));
        org.junit.Assert.assertNotNull(chronology23);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = iSOChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField5, (int) (byte) 1);
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        boolean boolean10 = instant8.isBefore((org.joda.time.ReadableInstant) instant9);
        org.joda.time.Instant instant11 = new org.joda.time.Instant();
        org.joda.time.Instant instant12 = new org.joda.time.Instant();
        boolean boolean13 = instant11.isBefore((org.joda.time.ReadableInstant) instant12);
        boolean boolean14 = instant9.isBefore((org.joda.time.ReadableInstant) instant11);
        org.joda.time.Chronology chronology15 = instant11.getChronology();
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        org.joda.time.ReadableDateTime readableDateTime17 = null;
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance(chronology15, readableDateTime16, readableDateTime17);
        org.joda.time.Partial partial19 = new org.joda.time.Partial(chronology15);
        int[] intArray27 = new int[] { ' ', 100, 'a', (byte) 0, (byte) -1, (short) 1 };
        int[] intArray29 = skipDateTimeField7.addWrapPartial((org.joda.time.ReadablePartial) partial19, (int) (short) 0, intArray27, (int) (short) 1);
        int[] intArray30 = partial19.getValues();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMillis((int) (byte) 0);
        org.joda.time.DateTime.Property property3 = dateTime0.weekOfWeekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology0.add(readablePeriod2, 100L, 57600010);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone7.isLocalDateTimeGap(localDateTime9);
        java.lang.String str12 = dateTimeZone7.getName((long) '#');
        int int14 = dateTimeZone7.getOffsetFromLocal((long) 10);
        org.joda.time.LocalDateTime localDateTime15 = null;
        boolean boolean16 = dateTimeZone7.isLocalDateTimeGap(localDateTime15);
        long long18 = dateTimeZone7.convertUTCToLocal((long) (byte) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology20 = iSOChronology0.withZone(dateTimeZone7);
        boolean boolean22 = dateTimeZone7.isStandardOffset((long) 84480052);
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone7);
        try {
            long long31 = copticChronology23.getDateTimeMillis(100, 57600010, 82867100, 82860538, (int) (short) -1, 1970, 725);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82860538 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.052" + "'", str12.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 53L + "'", long18 == 53L);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(copticChronology23);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.ReadableInstant readableInstant1 = null;
        java.lang.String str2 = dateTimeFormatter0.print(readableInstant1);
        try {
            org.joda.time.DateTime dateTime4 = dateTimeFormatter0.parseDateTime("GJChronology[+00:00:00.052]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[+00:00:00.052]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "19700101T000000.052+0000" + "'", str2.equals("19700101T000000.052+0000"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        boolean boolean2 = instant0.isBefore((org.joda.time.ReadableInstant) instant1);
        org.joda.time.Instant instant3 = new org.joda.time.Instant();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        boolean boolean5 = instant3.isBefore((org.joda.time.ReadableInstant) instant4);
        boolean boolean6 = instant1.isBefore((org.joda.time.ReadableInstant) instant3);
        org.joda.time.Chronology chronology7 = instant3.getChronology();
        org.joda.time.DateTime dateTime8 = instant3.toDateTimeISO();
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
    }
}

