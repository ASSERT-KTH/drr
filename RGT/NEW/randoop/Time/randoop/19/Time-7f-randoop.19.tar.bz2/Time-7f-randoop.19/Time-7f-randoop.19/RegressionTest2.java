import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

//    @Test
//    public void test01() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test01");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        mutableDateTime0.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime7 = property3.add((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.dayOfWeek();
//        java.lang.String str11 = iSOChronology9.toString();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology9.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now();
//        mutableDateTime13.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime13.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime18 = property16.set((int) '4');
//        java.lang.String str19 = property16.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property16.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, dateTimeFieldType20, (int) '4');
//        int int23 = mutableDateTime7.get(dateTimeFieldType20);
//        org.joda.time.ReadableDuration readableDuration24 = null;
//        mutableDateTime7.add(readableDuration24, 21042164);
//        boolean boolean28 = mutableDateTime7.isEqual((-990L));
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str11.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "millisOfDay" + "'", str19.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 42158982 + "'", int23 == 42158982);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = julianChronology2.seconds();
        int int4 = julianChronology2.getMinimumDaysInFirstWeek();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology2, locale5, (java.lang.Integer) 0);
        long long9 = dateTimeParserBucket7.computeMillis(true);
        java.lang.Integer int10 = dateTimeParserBucket7.getPivotYear();
        dateTimeParserBucket7.setPivotYear((java.lang.Integer) 3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10.equals(0));
    }

//    @Test
//    public void test03() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test03");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        java.lang.String str3 = iSOChronology1.toString();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
//        mutableDateTime5.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
//        java.lang.String str11 = property8.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
//        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
//        int int18 = offsetDateTimeField14.get((long) 0);
//        boolean boolean19 = offsetDateTimeField14.isLenient();
//        boolean boolean21 = offsetDateTimeField14.isLeap(350L);
//        long long24 = offsetDateTimeField14.add((-5820000L), (long) 0);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, 2103531200);
//        int int28 = offsetDateTimeField26.get(21042164L);
//        boolean boolean30 = offsetDateTimeField26.isLeap((long) 52);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
//        org.joda.time.ReadableDuration readableDuration34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime33.plus(readableDuration34);
//        int int36 = dateTime35.getHourOfDay();
//        org.joda.time.DateTime dateTime38 = dateTime35.withYear((int) (short) -1);
//        org.joda.time.LocalDate localDate39 = dateTime38.toLocalDate();
//        java.lang.String str40 = dateTimeFormatter31.print((org.joda.time.ReadablePartial) localDate39);
//        int[] intArray44 = new int[] { '4', 21087616 };
//        try {
//            int[] intArray46 = offsetDateTimeField26.addWrapField((org.joda.time.ReadablePartial) localDate39, 163, intArray44, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 163");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 64 + "'", int18 == 64);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-5820000L) + "'", long24 == (-5820000L));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2103531264 + "'", int28 == 2103531264);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 11 + "'", int36 == 11);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "-0001-06-12T��:��:��.000" + "'", str40.equals("-0001-06-12T��:��:��.000"));
//        org.junit.Assert.assertNotNull(intArray44);
//    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test04");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadableDuration readableDuration2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
//        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
//        org.joda.time.Chronology chronology6 = dateTime1.getChronology();
//        org.joda.time.DateTime dateTime8 = dateTime1.withYear(0);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime1.minus(readablePeriod9);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.dayOfWeek();
//        java.lang.String str15 = iSOChronology13.toString();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now();
//        mutableDateTime17.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property20 = mutableDateTime17.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime22 = property20.set((int) '4');
//        java.lang.String str23 = property20.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property20.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, dateTimeFieldType24, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField16);
//        java.lang.String str28 = skipDateTimeField27.getName();
//        long long30 = skipDateTimeField27.roundFloor((long) 163);
//        int int31 = dateTime1.get((org.joda.time.DateTimeField) skipDateTimeField27);
//        org.joda.time.DateTime dateTime33 = dateTime1.plus((long) 19);
//        java.util.Locale locale35 = null;
//        try {
//            java.lang.String str36 = dateTime33.toString("", locale35);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str15.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "millisOfDay" + "'", str23.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "monthOfYear" + "'", str28.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-2649600000L) + "'", long30 == (-2649600000L));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
//        org.junit.Assert.assertNotNull(dateTime33);
//    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime9 = property6.roundCeilingCopy();
        org.joda.time.DateTime dateTime10 = property6.getDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        mutableDateTime0.addMinutes(1000);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readableDuration5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusMonths((int) (byte) -1);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMonths((int) (byte) 1);
        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        mutableDateTime0.setMillisOfSecond(100);
        mutableDateTime0.addMonths(1439);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.lang.String str2 = dateTimeFormatter0.print((-62135568422000L));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0001-01-01" + "'", str2.equals("0001-01-01"));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        java.lang.Class<?> wildcardClass3 = mutableDateTime1.getClass();
        mutableDateTime1.setDayOfYear(2);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime7 = mutableDateTime1.toDateTimeISO();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.addWrapField(10);
        org.joda.time.Interval interval11 = property8.toInterval();
        org.joda.time.DateTimeField dateTimeField12 = property8.getField();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(interval11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("ISOChronology[America/Los_Angeles]", "2019-06-12T12:51:26.242Z");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Number number5 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019-06-12T12:51:26.242Z" + "'", str6.equals("2019-06-12T12:51:26.242Z"));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.setWeekyear((int) '#');
        mutableDateTime1.setSecondOfDay(6);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test12() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test12");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.Chronology chronology3 = julianChronology0.withZone(dateTimeZone1);
//        java.lang.String str5 = dateTimeZone1.getName((-60027L));
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pacific Standard Time" + "'", str5.equals("Pacific Standard Time"));
//    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = julianChronology2.seconds();
        int int4 = julianChronology2.getMinimumDaysInFirstWeek();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology2, locale5, (java.lang.Integer) 0);
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology2.getZone();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.Instant instant12 = instant10.minus((-62135568422000L));
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Instant instant14 = instant10.minus(readableDuration13);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(instant14);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.dayOfMonth();
        org.joda.time.Chronology chronology6 = iSOChronology1.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("ISOChronology[America/Los_Angeles]", "2019-06-12T12:51:26.242Z");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-12T12:51:26.242Z" + "'", str4.equals("2019-06-12T12:51:26.242Z"));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test16() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test16");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.Chronology chronology3 = julianChronology1.withZone(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
//        mutableDateTime8.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime13 = property11.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime15 = property11.add((int) ' ');
//        int int16 = mutableDateTime15.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) mutableDateTime15);
//        java.util.TimeZone timeZone18 = dateTimeZone6.toTimeZone();
//        java.lang.String str19 = dateTimeZone6.toString();
//        org.joda.time.DateTime dateTime20 = dateTime5.withZone(dateTimeZone6);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.YearMonthDay yearMonthDay22 = dateTime21.toYearMonthDay();
//        boolean boolean23 = julianChronology1.equals((java.lang.Object) yearMonthDay22);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 163 + "'", int16 == 163);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "America/Los_Angeles" + "'", str19.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(yearMonthDay22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology2, locale3, (java.lang.Integer) 0);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 1000);
        java.lang.Integer int8 = dateTimeParserBucket5.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8.equals(0));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minus(28800000L);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, (int) (byte) 1);
        org.joda.time.DateTime.Property property6 = dateTime5.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test19() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test19");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.Chronology chronology12 = gJChronology11.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology11);
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology11.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField15 = gJChronology11.hourOfHalfday();
//        org.joda.time.DurationField durationField16 = gJChronology11.millis();
//        org.joda.time.DurationField durationField17 = gJChronology11.centuries();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(durationField17);
//    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 1, dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, 12);
        org.joda.time.DateTime dateTime10 = dateTime5.minusYears(16);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime5.plus(readableDuration11);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfSecond();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.clockhourOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("2019-06-12T12:51:28.729Z", "", (int) (byte) 1, 0);
        java.lang.String str8 = fixedDateTimeZone6.getNameKey(28800000L);
        boolean boolean9 = buddhistChronology0.equals((java.lang.Object) fixedDateTimeZone6);
        int int11 = fixedDateTimeZone6.getOffsetFromLocal((long) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology15, locale16, (java.lang.Integer) 0);
        boolean boolean20 = dateTimeParserBucket18.restoreState((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        java.util.Locale locale24 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology23, locale24, (java.lang.Integer) 0);
        dateTimeParserBucket26.setOffset((java.lang.Integer) 1000);
        org.joda.time.DateTimeZone dateTimeZone29 = dateTimeParserBucket26.getZone();
        dateTimeParserBucket18.setZone(dateTimeZone29);
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime(0L, dateTimeZone29);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6, (org.joda.time.ReadableInstant) mutableDateTime31, 3);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(gJChronology33);
    }
}

