import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (byte) 0, (int) (byte) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 10, (int) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 350L + "'", long2 == 350L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) instant2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(10, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1000 + "'", int2 == 1000);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (short) 1, (int) (byte) 0, 0, (int) '#', (int) (short) 100, 0, (int) (byte) 10, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter0.parseMutableDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        try {
            org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1), (java.lang.Number) 1, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.field.FieldUtils.verifyValueBounds("", (int) (byte) 1, (int) (byte) -1, (int) (byte) 10);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology3, locale4, (java.lang.Integer) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology3);
        java.lang.Appendable appendable8 = null;
        org.joda.time.ReadablePartial readablePartial9 = null;
        try {
            dateTimeFormatter0.printTo(appendable8, readablePartial9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime1.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime1.toMutableDateTime(dateTimeZone5);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) gJChronology0, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GJChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField5 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100.0f, (java.lang.Number) (byte) 10, (java.lang.Number) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime0.toMutableDateTime(dateTimeZone4);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime4.setDate((org.joda.time.ReadableInstant) mutableDateTime5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.monthOfYear();
        mutableDateTime5.setRounding(dateTimeField9);
        mutableDateTime5.add((long) (short) -1);
        org.joda.time.DateTime dateTime13 = mutableDateTime5.toDateTime();
        try {
            int int14 = property3.getDifference((org.joda.time.ReadableInstant) dateTime13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 3649826043");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            java.lang.String str3 = dateTimeFormatter1.print(readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test029");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.joda.time.MutableDateTime.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime0.toMutableDateTime(dateTimeZone4);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 8");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.add((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime7 = property3.add((int) ' ');
        mutableDateTime7.addMonths((int) '4');
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test034");
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
//        mutableDateTime9.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime14 = property12.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime16 = property12.add((int) ' ');
//        int int17 = mutableDateTime16.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) mutableDateTime16);
//        try {
//            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((-1), (int) (short) 1, (int) (byte) 0, 0, (int) (byte) -1, (int) (short) -1, 100, dateTimeZone7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(julianChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 163 + "'", int17 == 163);
//        org.junit.Assert.assertNotNull(gJChronology18);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.lang.Object obj1 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 10, obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.monthOfYear();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, (int) (short) -1, (int) '4', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [52,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType3, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.joda.time.MutableDateTime.ROUND_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[America/Los_Angeles]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) '#', 5, (int) ' ', 2, 5, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        try {
            org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadableDuration readableDuration2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
//        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime1.withZone(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
//        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now();
//        mutableDateTime10.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime10.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime15 = property13.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime17 = property13.add((int) ' ');
//        int int18 = mutableDateTime17.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime17);
//        boolean boolean20 = dateTime7.isBefore((org.joda.time.ReadableInstant) mutableDateTime17);
//        java.util.Locale locale22 = null;
//        try {
//            java.lang.String str23 = mutableDateTime17.toString("America/Los_Angeles", locale22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(julianChronology9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 163 + "'", int18 == 163);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField6 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("20190612");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"20190612/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@77d80e9");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 1969);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000227895d + "'", double1 == 2440587.5000227895d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(100L);
        mutableDateTime1.addWeekyears((int) '4');
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        int int3 = mutableDateTime0.getWeekyear();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.set((int) '4');
        java.lang.String str6 = property3.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = julianChronology9.seconds();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology13, locale14, (java.lang.Integer) 0);
        org.joda.time.DurationField durationField17 = iSOChronology13.years();
        long long20 = durationField17.subtract((long) (byte) 100, 100);
        long long23 = durationField17.subtract((long) '#', (int) (byte) -1);
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField24 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType7, durationField10, durationField17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "millisOfDay" + "'", str6.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-3155674021900L) + "'", long20 == (-3155674021900L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 31536000035L + "'", long23 == 31536000035L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology3 = julianChronology0.withZone(dateTimeZone1);
        try {
            long long8 = julianChronology0.getDateTimeMillis((-1), (int) 'a', (int) (byte) -1, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology2, locale3, (java.lang.Integer) 0);
        org.joda.time.DurationField durationField6 = iSOChronology2.years();
        long long9 = durationField6.subtract((long) (byte) 100, 100);
        long long12 = durationField6.subtract((long) '#', (int) (byte) -1);
        long long15 = durationField6.subtract(31536000035L, (int) (short) 100);
        try {
            long long18 = durationField6.subtract((long) (byte) 100, (-3155674021900L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 3155674021900");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-3155674021900L) + "'", long9 == (-3155674021900L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31536000035L + "'", long12 == 31536000035L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-3124138021965L) + "'", long15 == (-3124138021965L));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology2, locale3, (java.lang.Integer) 0);
        org.joda.time.DurationField durationField6 = iSOChronology2.years();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.secondOfMinute();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, 5, 2, 21029837);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        try {
            org.joda.time.DateTime dateTime9 = property6.setCopy(163);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 163 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.roundHalfCeilingCopy();
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
//        mutableDateTime9.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime14 = property12.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime16 = property12.add((int) ' ');
//        int int17 = mutableDateTime16.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) mutableDateTime16);
//        java.util.TimeZone timeZone19 = dateTimeZone7.toTimeZone();
//        java.lang.String str20 = dateTimeZone7.toString();
//        try {
//            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(8, 1, 163, (int) (byte) 10, 21029837, 8, 0, dateTimeZone7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21029837 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(julianChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 163 + "'", int17 == 163);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "America/Los_Angeles" + "'", str20.equals("America/Los_Angeles"));
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.add((long) (short) -1);
        org.joda.time.DateTime dateTime9 = mutableDateTime1.toDateTime();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withFields(readablePartial10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime(dateTimeZone12);
        try {
            org.joda.time.DateTime dateTime15 = dateTime9.withMillisOfSecond(21029837);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21029837 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        try {
            org.joda.time.DateTime dateTime8 = dateTime1.withTime(0, (int) (byte) 1, (int) (short) -1, 64);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = iSOChronology9.getZone();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 1, dateTimeZone11);
        java.lang.String str13 = dateTimeZone11.getID();
        try {
            org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((int) (short) 100, 0, 5, 0, 0, (int) (short) -1, 163, dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "America/Los_Angeles" + "'", str13.equals("America/Los_Angeles"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.add((long) (short) -1);
        org.joda.time.DateTime dateTime9 = mutableDateTime1.toDateTime();
        try {
            mutableDateTime1.setDate(2, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField4 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.add((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime6 = property3.roundHalfFloor();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            mutableDateTime6.add(durationFieldType7, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        java.lang.String str3 = iSOChronology1.toString();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
//        mutableDateTime5.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
//        java.lang.String str11 = property8.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
//        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime17.plus(readableDuration18);
//        int int20 = dateTime19.getHourOfDay();
//        org.joda.time.DateTime dateTime22 = dateTime19.withYear((int) (short) -1);
//        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
//        int[] intArray31 = new int[] { 21029837, 1000, (-1), 2019, 2, (short) 100 };
//        java.util.Locale locale33 = null;
//        try {
//            int[] intArray34 = offsetDateTimeField14.set((org.joda.time.ReadablePartial) localDate23, 21029837, intArray31, "2019-06-12T05:50:29.087-07:00", locale33);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T05:50:29.087-07:00\" for millisOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(intArray31);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        mutableDateTime9.addMinutes(5);
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime9.weekyear();
//        mutableDateTime9.addMillis(4);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(property14);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
//        mutableDateTime5.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime12 = property8.add((int) ' ');
//        int int13 = mutableDateTime12.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime12);
//        java.util.TimeZone timeZone15 = dateTimeZone3.toTimeZone();
//        java.lang.String str16 = dateTimeZone3.toString();
//        org.joda.time.Chronology chronology17 = buddhistChronology1.withZone(dateTimeZone3);
//        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime(10L, dateTimeZone3);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 163 + "'", int13 == 163);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "America/Los_Angeles" + "'", str16.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology17);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.add((long) (short) -1);
        int int9 = mutableDateTime1.getDayOfMonth();
        int int10 = mutableDateTime1.getSecondOfMinute();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.Chronology chronology12 = gJChronology11.withUTC();
//        try {
//            long long17 = gJChronology11.getDateTimeMillis(4, (int) (short) 100, (int) '#', (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = julianChronology2.seconds();
        int int4 = julianChronology2.getMinimumDaysInFirstWeek();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology2, locale5, (java.lang.Integer) 0);
        org.joda.time.DateTimeField dateTimeField8 = julianChronology2.hourOfDay();
        try {
            long long16 = julianChronology2.getDateTimeMillis(4, 0, (int) (short) -1, 0, 0, 1000, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property6 = dateTime5.millisOfSecond();
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withYearOfCentury(21088);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21088 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology3, locale4, (java.lang.Integer) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology3);
        java.io.Writer writer8 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField12 = julianChronology11.seconds();
        int int13 = julianChronology11.getMinimumDaysInFirstWeek();
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology11, locale14, (java.lang.Integer) 0);
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now();
        mutableDateTime17.setDate((org.joda.time.ReadableInstant) mutableDateTime18);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.monthOfYear();
        mutableDateTime18.setRounding(dateTimeField22);
        mutableDateTime18.add((long) (short) -1);
        org.joda.time.DateTime dateTime26 = mutableDateTime18.toDateTime();
        org.joda.time.ReadablePartial readablePartial27 = null;
        org.joda.time.DateTime dateTime28 = dateTime26.withFields(readablePartial27);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime26.toDateTime(dateTimeZone29);
        org.joda.time.LocalDate localDate31 = dateTime26.toLocalDate();
        int[] intArray33 = julianChronology11.get((org.joda.time.ReadablePartial) localDate31, 0L);
        try {
            dateTimeFormatter7.printTo(writer8, (org.joda.time.ReadablePartial) localDate31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(21031798, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 21031798");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(21088);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 21088");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.monthOfYear();
        try {
            org.joda.time.Instant instant3 = new org.joda.time.Instant((java.lang.Object) dateTimeField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyear();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("2019-05-01T00:00:00.000-07:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-05-01T00:00:00.000-07:00\" is malformed at \"-05-01T00:00:00.000-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hour();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withLocale(locale2);
        try {
            org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("monthOfYear", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"monthOfYear\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("2019-06-12T05:50:29.087-07:00", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 2019-06-12T05:50:29.087-07:00");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(4, 21031798, 2, (int) (byte) -1, (int) (byte) 100, 64, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        int int18 = offsetDateTimeField14.get((long) 0);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = julianChronology21.seconds();
        int int23 = julianChronology21.getMinimumDaysInFirstWeek();
        java.util.Locale locale24 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology21, locale24, (java.lang.Integer) 0);
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        mutableDateTime27.setDate((org.joda.time.ReadableInstant) mutableDateTime28);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.monthOfYear();
        mutableDateTime28.setRounding(dateTimeField32);
        mutableDateTime28.add((long) (short) -1);
        org.joda.time.DateTime dateTime36 = mutableDateTime28.toDateTime();
        org.joda.time.ReadablePartial readablePartial37 = null;
        org.joda.time.DateTime dateTime38 = dateTime36.withFields(readablePartial37);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.DateTime dateTime40 = dateTime36.toDateTime(dateTimeZone39);
        org.joda.time.LocalDate localDate41 = dateTime36.toLocalDate();
        int[] intArray43 = julianChronology21.get((org.joda.time.ReadablePartial) localDate41, 0L);
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField48 = julianChronology47.seconds();
        int int49 = julianChronology47.getMinimumDaysInFirstWeek();
        java.util.Locale locale50 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket52 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology47, locale50, (java.lang.Integer) 0);
        org.joda.time.MutableDateTime mutableDateTime53 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime54 = org.joda.time.MutableDateTime.now();
        mutableDateTime53.setDate((org.joda.time.ReadableInstant) mutableDateTime54);
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology57 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone56);
        org.joda.time.DateTimeField dateTimeField58 = iSOChronology57.monthOfYear();
        mutableDateTime54.setRounding(dateTimeField58);
        mutableDateTime54.add((long) (short) -1);
        org.joda.time.DateTime dateTime62 = mutableDateTime54.toDateTime();
        org.joda.time.ReadablePartial readablePartial63 = null;
        org.joda.time.DateTime dateTime64 = dateTime62.withFields(readablePartial63);
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.DateTime dateTime66 = dateTime62.toDateTime(dateTimeZone65);
        org.joda.time.LocalDate localDate67 = dateTime62.toLocalDate();
        int[] intArray69 = julianChronology47.get((org.joda.time.ReadablePartial) localDate67, 0L);
        try {
            int[] intArray71 = offsetDateTimeField14.addWrapField((org.joda.time.ReadablePartial) localDate41, 1969, intArray69, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1969");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 64 + "'", int18 == 64);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime53);
        org.junit.Assert.assertNotNull(mutableDateTime54);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(iSOChronology57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(localDate67);
        org.junit.Assert.assertNotNull(intArray69);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("2019-06-12T12:51:28.729Z", "", (int) (byte) 1, 0);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(1, 2, (int) '#', 0, (int) (byte) 0, (int) (byte) -1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        java.lang.String str4 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        mutableDateTime6.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
        java.lang.String str12 = property9.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now();
        mutableDateTime17.setDate((org.joda.time.ReadableInstant) mutableDateTime18);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.monthOfYear();
        mutableDateTime18.setRounding(dateTimeField22);
        mutableDateTime18.add((long) (short) -1);
        org.joda.time.DateTime dateTime26 = mutableDateTime18.toDateTime();
        org.joda.time.ReadablePartial readablePartial27 = null;
        org.joda.time.DateTime dateTime28 = dateTime26.withFields(readablePartial27);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime26.toDateTime(dateTimeZone29);
        org.joda.time.LocalDate localDate31 = dateTime26.toLocalDate();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone34);
        org.joda.time.DurationField durationField36 = julianChronology35.seconds();
        int int37 = julianChronology35.getMinimumDaysInFirstWeek();
        java.util.Locale locale38 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket40 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology35, locale38, (java.lang.Integer) 0);
        org.joda.time.MutableDateTime mutableDateTime41 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime42 = org.joda.time.MutableDateTime.now();
        mutableDateTime41.setDate((org.joda.time.ReadableInstant) mutableDateTime42);
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology45.monthOfYear();
        mutableDateTime42.setRounding(dateTimeField46);
        mutableDateTime42.add((long) (short) -1);
        org.joda.time.DateTime dateTime50 = mutableDateTime42.toDateTime();
        org.joda.time.ReadablePartial readablePartial51 = null;
        org.joda.time.DateTime dateTime52 = dateTime50.withFields(readablePartial51);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTime dateTime54 = dateTime50.toDateTime(dateTimeZone53);
        org.joda.time.LocalDate localDate55 = dateTime50.toLocalDate();
        int[] intArray57 = julianChronology35.get((org.joda.time.ReadablePartial) localDate55, 0L);
        java.util.Locale locale59 = null;
        try {
            int[] intArray60 = skipDateTimeField16.set((org.joda.time.ReadablePartial) localDate31, 21031798, intArray57, "2019-06-12T05:50:33.782-07:00", locale59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T05:50:33.782-07:00\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertNotNull(mutableDateTime42);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(localDate55);
        org.junit.Assert.assertNotNull(intArray57);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("December", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"December/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("Dec");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Dec\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        java.lang.String str4 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        mutableDateTime6.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
        java.lang.String str12 = property9.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        java.lang.String str17 = skipDateTimeField16.getName();
        boolean boolean19 = skipDateTimeField16.isLeap((long) '#');
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "monthOfYear" + "'", str17.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        long long18 = offsetDateTimeField14.roundHalfEven((long) 1969);
        long long20 = offsetDateTimeField14.roundHalfFloor(100L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28800000L + "'", long20 == 28800000L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(64, (int) (short) 0, 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        mutableDateTime9.addMinutes(5);
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime9.weekyear();
//        org.joda.time.MutableDateTime mutableDateTime15 = property14.roundHalfFloor();
//        org.joda.time.DateTimeZone dateTimeZone16 = mutableDateTime15.getZone();
//        try {
//            mutableDateTime15.setDayOfYear(2019);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for dayOfYear must be in the range [1,365]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology2, locale3, (java.lang.Integer) 0);
        java.lang.Integer int6 = dateTimeParserBucket5.getOffsetInteger();
        long long7 = dateTimeParserBucket5.computeMillis();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800010L + "'", long7 == 28800010L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology2, locale3, (java.lang.Integer) 0);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 1000);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeParserBucket5.getZone();
        long long11 = dateTimeParserBucket5.computeMillis(true, "2019-05-01T00:00:00.000-07:00");
        java.lang.Integer int12 = dateTimeParserBucket5.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-990L) + "'", long11 == (-990L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12.equals(0));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.set((int) '4');
        try {
            mutableDateTime5.setDayOfMonth((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.minutes();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField3 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(64, (int) (short) 1, 5, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        try {
            org.joda.time.DateTime dateTime5 = dateTime1.withWeekOfWeekyear(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        mutableDateTime0.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime6 = property3.roundHalfFloor();
//        org.joda.time.MutableDateTime mutableDateTime7 = property3.roundHalfCeiling();
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
//        mutableDateTime8.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime13 = property11.set((int) '4');
//        java.lang.String str14 = property11.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property11.getFieldType();
//        int int16 = mutableDateTime7.get(dateTimeFieldType15);
//        org.joda.time.ReadableDuration readableDuration17 = null;
//        mutableDateTime7.add(readableDuration17);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "millisOfDay" + "'", str14.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 21036537 + "'", int16 == 21036537);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("Dec", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Dec\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.add((long) (short) -1);
        org.joda.time.DateTime dateTime9 = mutableDateTime1.toDateTime();
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond((int) '#');
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now();
        mutableDateTime12.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime12.millisOfDay();
        mutableDateTime12.setHourOfDay(0);
        mutableDateTime12.setMillis(0L);
        boolean boolean20 = dateTime9.isBefore((org.joda.time.ReadableInstant) mutableDateTime12);
        try {
            java.lang.String str22 = mutableDateTime12.toString("2019-06-12T12:51:34.804Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.Chronology chronology12 = gJChronology11.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology11);
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology11.weekOfWeekyear();
//        try {
//            long long19 = gJChronology11.getDateTimeMillis(0, 8, 1969, 21029837);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        java.lang.String str4 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        mutableDateTime6.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
        java.lang.String str12 = property9.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime20 = org.joda.time.MutableDateTime.now();
        mutableDateTime19.setDate((org.joda.time.ReadableInstant) mutableDateTime20);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.monthOfYear();
        mutableDateTime20.setRounding(dateTimeField24);
        mutableDateTime20.add((long) (short) -1);
        org.joda.time.DateTime dateTime28 = mutableDateTime20.toDateTime();
        org.joda.time.ReadablePartial readablePartial29 = null;
        org.joda.time.DateTime dateTime30 = dateTime28.withFields(readablePartial29);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = dateTime28.toDateTime(dateTimeZone31);
        org.joda.time.LocalDate localDate33 = dateTime28.toLocalDate();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
        org.joda.time.DurationField durationField38 = julianChronology37.seconds();
        int int39 = julianChronology37.getMinimumDaysInFirstWeek();
        java.util.Locale locale40 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket42 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology37, locale40, (java.lang.Integer) 0);
        org.joda.time.MutableDateTime mutableDateTime43 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime44 = org.joda.time.MutableDateTime.now();
        mutableDateTime43.setDate((org.joda.time.ReadableInstant) mutableDateTime44);
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology47.monthOfYear();
        mutableDateTime44.setRounding(dateTimeField48);
        mutableDateTime44.add((long) (short) -1);
        org.joda.time.DateTime dateTime52 = mutableDateTime44.toDateTime();
        org.joda.time.ReadablePartial readablePartial53 = null;
        org.joda.time.DateTime dateTime54 = dateTime52.withFields(readablePartial53);
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.DateTime dateTime56 = dateTime52.toDateTime(dateTimeZone55);
        org.joda.time.LocalDate localDate57 = dateTime52.toLocalDate();
        int[] intArray59 = julianChronology37.get((org.joda.time.ReadablePartial) localDate57, 0L);
        java.util.Locale locale61 = null;
        try {
            int[] intArray62 = skipDateTimeField16.set((org.joda.time.ReadablePartial) localDate33, (-1), intArray59, "org.joda.time.IllegalFieldValueException: Value \"2019-06-12T12:51:26.242Z\" for ISOChronology[America/Los_Angeles] is not supported", locale61);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value \"2019-06-12T12:51:26.242Z\" for ISOChronology[America/Los_Angeles] is not supported\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Dec" + "'", str18.equals("Dec"));
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(mutableDateTime43);
        org.junit.Assert.assertNotNull(mutableDateTime44);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(localDate57);
        org.junit.Assert.assertNotNull(intArray59);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        java.lang.String str4 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        mutableDateTime6.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
        java.lang.String str12 = property9.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        try {
            long long19 = skipDateTimeField16.set((long) (short) 100, "millisOfDay");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"millisOfDay\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(21031798);
        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.append(dateTimeParser3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
//        java.lang.String str4 = iSOChronology2.toString();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
//        mutableDateTime6.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
//        java.lang.String str12 = property9.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) (byte) 100);
//        java.util.Locale locale19 = null;
//        int int20 = skipDateTimeField16.getMaximumTextLength(locale19);
//        int int22 = skipDateTimeField16.get((long) 5);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
//        org.joda.time.ReadableDuration readableDuration25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.plus(readableDuration25);
//        int int27 = dateTime26.getHourOfDay();
//        org.joda.time.DateTime dateTime29 = dateTime26.withYear((int) (short) -1);
//        org.joda.time.LocalDate localDate30 = dateTime29.toLocalDate();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone32);
//        org.joda.time.DurationField durationField34 = julianChronology33.seconds();
//        int int35 = julianChronology33.getMinimumDaysInFirstWeek();
//        java.util.Locale locale36 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket38 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology33, locale36, (java.lang.Integer) 0);
//        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime mutableDateTime40 = org.joda.time.MutableDateTime.now();
//        mutableDateTime39.setDate((org.joda.time.ReadableInstant) mutableDateTime40);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone42);
//        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.monthOfYear();
//        mutableDateTime40.setRounding(dateTimeField44);
//        mutableDateTime40.add((long) (short) -1);
//        org.joda.time.DateTime dateTime48 = mutableDateTime40.toDateTime();
//        org.joda.time.ReadablePartial readablePartial49 = null;
//        org.joda.time.DateTime dateTime50 = dateTime48.withFields(readablePartial49);
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.DateTime dateTime52 = dateTime48.toDateTime(dateTimeZone51);
//        org.joda.time.LocalDate localDate53 = dateTime48.toLocalDate();
//        int[] intArray55 = julianChronology33.get((org.joda.time.ReadablePartial) localDate53, 0L);
//        int int56 = skipDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) localDate30, intArray55);
//        java.util.Locale locale58 = null;
//        java.lang.String str59 = skipDateTimeField16.getAsText(9, locale58);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Dec" + "'", str18.equals("Dec"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9 + "'", int20 == 9);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 5 + "'", int27 == 5);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(julianChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(mutableDateTime40);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(localDate53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 12 + "'", int56 == 12);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "September" + "'", str59.equals("September"));
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.addHours(1969);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(20991600000L, 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 209916000000L + "'", long2 == 209916000000L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.add((long) (short) -1);
        org.joda.time.DateTime dateTime9 = mutableDateTime1.toDateTime();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withFields(readablePartial10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime(dateTimeZone12);
        org.joda.time.LocalDate localDate14 = dateTime9.toLocalDate();
        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now();
        mutableDateTime15.setDate((org.joda.time.ReadableInstant) mutableDateTime16);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.monthOfYear();
        mutableDateTime16.setRounding(dateTimeField20);
        mutableDateTime16.add((long) (short) -1);
        org.joda.time.DateTime dateTime24 = mutableDateTime16.toDateTime();
        int int25 = dateTime9.compareTo((org.joda.time.ReadableInstant) mutableDateTime16);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "2019-06-12T12:51:28.729Z", "2019-06-12T12:51:37.439Z");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("ISOChronology[America/Los_Angeles]", "2019-06-12T12:51:26.242Z");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        java.lang.String str5 = illegalFieldValueException2.toString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str7 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"2019-06-12T12:51:26.242Z\" for ISOChronology[America/Los_Angeles] is not supported" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value \"2019-06-12T12:51:26.242Z\" for ISOChronology[America/Los_Angeles] is not supported"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019-06-12T12:51:26.242Z" + "'", str6.equals("2019-06-12T12:51:26.242Z"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str7.equals("ISOChronology[America/Los_Angeles]"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.dayOfWeek();
        java.lang.String str5 = iSOChronology3.toString();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        mutableDateTime7.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime7.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime12 = property10.set((int) '4');
        java.lang.String str13 = property10.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property10.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType14, (int) '4');
        org.joda.time.DurationField durationField17 = offsetDateTimeField16.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField16.getType();
        int int20 = offsetDateTimeField16.get((long) 0);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.plus(readableDuration23);
        org.joda.time.DateTime dateTime26 = dateTime22.withDayOfYear((int) ' ');
        org.joda.time.Chronology chronology27 = dateTime22.getChronology();
        org.joda.time.DateTime dateTime29 = dateTime22.withHourOfDay((int) (byte) 10);
        org.joda.time.LocalTime localTime30 = dateTime29.toLocalTime();
        int[] intArray32 = null;
        int[] intArray34 = offsetDateTimeField16.addWrapPartial((org.joda.time.ReadablePartial) localTime30, (int) (short) 100, intArray32, 0);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localTime30);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str5.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "millisOfDay" + "'", str13.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 64 + "'", int20 == 64);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localTime30);
        org.junit.Assert.assertNull(intArray34);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
//        mutableDateTime1.addMinutes((-1));
//        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime1);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime1.era();
//        org.joda.time.ReadableInstant readableInstant6 = null;
//        boolean boolean7 = mutableDateTime1.isEqual(readableInstant6);
//        try {
//            mutableDateTime1.setSecondOfDay(21036537);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21036537 for secondOfDay must be in the range [0,86399]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(mutableDateTime1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "20190612" + "'", str4.equals("20190612"));
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        java.lang.String str4 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        mutableDateTime6.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
        java.lang.String str12 = property9.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) (byte) 100);
        java.util.Locale locale20 = null;
        try {
            java.lang.String str21 = skipDateTimeField16.getAsShortText(163, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 163");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Dec" + "'", str18.equals("Dec"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, (long) 21036537);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-21036537L) + "'", long2 == (-21036537L));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property9 = dateTime8.hourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.yearOfEra();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.dayOfWeek();
//        java.lang.String str17 = iSOChronology15.toString();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
//        mutableDateTime19.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime24 = property22.set((int) '4');
//        java.lang.String str25 = property22.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType26, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField18);
//        java.lang.String str31 = skipDateTimeField29.getAsShortText((long) (byte) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, (org.joda.time.DateTimeField) skipDateTimeField29);
//        org.joda.time.DateTimeField dateTimeField33 = gJChronology11.minuteOfHour();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "millisOfDay" + "'", str25.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Dec" + "'", str31.equals("Dec"));
//        org.junit.Assert.assertNotNull(dateTimeField33);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        java.lang.String str4 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        mutableDateTime6.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
        java.lang.String str12 = property9.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipDateTimeField16.getAsText((long) 1, locale18);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.dayOfWeek();
        java.lang.String str23 = iSOChronology21.toString();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology21.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        mutableDateTime25.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime25.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime30 = property28.set((int) '4');
        java.lang.String str31 = property28.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property28.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, dateTimeFieldType32, (int) '4');
        org.joda.time.DurationField durationField35 = offsetDateTimeField34.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField34.getType();
        int int38 = offsetDateTimeField34.get((long) 0);
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime42 = dateTime40.plus(readableDuration41);
        org.joda.time.DateTime dateTime44 = dateTime40.withDayOfYear((int) ' ');
        org.joda.time.Chronology chronology45 = dateTime40.getChronology();
        org.joda.time.DateTime dateTime47 = dateTime40.withHourOfDay((int) (byte) 10);
        org.joda.time.LocalTime localTime48 = dateTime47.toLocalTime();
        int[] intArray50 = null;
        int[] intArray52 = offsetDateTimeField34.addWrapPartial((org.joda.time.ReadablePartial) localTime48, (int) (short) 100, intArray50, 0);
        java.util.Locale locale53 = null;
        try {
            java.lang.String str54 = skipDateTimeField16.getAsText((org.joda.time.ReadablePartial) localTime48, locale53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'monthOfYear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "December" + "'", str19.equals("December"));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str23.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "millisOfDay" + "'", str31.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 64 + "'", int38 == 64);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(localTime48);
        org.junit.Assert.assertNull(intArray52);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        try {
            long long9 = iSOChronology1.getDateTimeMillis(4, (int) (byte) 1, 1969, 163);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        long long15 = dateTimeZone0.convertLocalToUTC((-60001L), false, (long) 21031798);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28739999L + "'", long15 == 28739999L);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
//        mutableDateTime1.addMinutes((-1));
//        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime1);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime1.era();
//        org.joda.time.ReadableInstant readableInstant6 = null;
//        boolean boolean7 = mutableDateTime1.isEqual(readableInstant6);
//        mutableDateTime1.addWeekyears(12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(mutableDateTime1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "20190612" + "'", str4.equals("20190612"));
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        int int3 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology4 = julianChronology1.withUTC();
        try {
            long long9 = julianChronology1.getDateTimeMillis(2019, 10, 1439, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1439 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology2, locale3, (java.lang.Integer) 0);
        org.joda.time.DurationField durationField6 = iSOChronology2.years();
        long long9 = durationField6.subtract((long) (byte) 100, 100);
        long long12 = durationField6.subtract((long) '#', (int) (byte) -1);
        long long15 = durationField6.subtract(31536000035L, (int) (short) 100);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField18 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType16, 21037186);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-3155674021900L) + "'", long9 == (-3155674021900L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31536000035L + "'", long12 == 31536000035L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-3124138021965L) + "'", long15 == (-3124138021965L));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        java.lang.String str4 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        mutableDateTime6.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
        java.lang.String str12 = property9.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        java.lang.String str17 = skipDateTimeField16.getName();
        long long19 = skipDateTimeField16.roundFloor((long) 163);
        java.util.Locale locale22 = null;
        try {
            long long23 = skipDateTimeField16.set((long) (short) 0, "America/Los_Angeles", locale22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "monthOfYear" + "'", str17.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-2649600000L) + "'", long19 == (-2649600000L));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology2, locale3, (java.lang.Integer) 0);
        org.joda.time.DurationField durationField6 = iSOChronology2.years();
        long long9 = durationField6.subtract((long) (byte) 100, 100);
        try {
            org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((java.lang.Object) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-3155674021900L) + "'", long9 == (-3155674021900L));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        java.lang.Class<?> wildcardClass3 = mutableDateTime1.getClass();
        try {
            mutableDateTime1.setSecondOfMinute((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("org.joda.time.IllegalFieldValueException: Value \"2019-06-12T12:51:26.242Z\" for ISOChronology[America/Los_Angeles] is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
//        java.lang.String str4 = iSOChronology2.toString();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
//        mutableDateTime6.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
//        java.lang.String str12 = property9.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
//        java.lang.String str17 = skipDateTimeField16.getName();
//        long long19 = skipDateTimeField16.roundFloor((long) 163);
//        org.joda.time.ReadablePartial readablePartial20 = null;
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.dayOfWeek();
//        java.lang.String str26 = iSOChronology24.toString();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology24.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
//        mutableDateTime28.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property31 = mutableDateTime28.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime33 = property31.set((int) '4');
//        java.lang.String str34 = property31.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property31.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology22, dateTimeField27);
//        java.lang.String str40 = skipDateTimeField38.getAsShortText((long) (byte) 100);
//        java.util.Locale locale41 = null;
//        int int42 = skipDateTimeField38.getMaximumTextLength(locale41);
//        int int44 = skipDateTimeField38.get((long) 5);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(dateTimeZone45);
//        org.joda.time.ReadableDuration readableDuration47 = null;
//        org.joda.time.DateTime dateTime48 = dateTime46.plus(readableDuration47);
//        int int49 = dateTime48.getHourOfDay();
//        org.joda.time.DateTime dateTime51 = dateTime48.withYear((int) (short) -1);
//        org.joda.time.LocalDate localDate52 = dateTime51.toLocalDate();
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone54);
//        org.joda.time.DurationField durationField56 = julianChronology55.seconds();
//        int int57 = julianChronology55.getMinimumDaysInFirstWeek();
//        java.util.Locale locale58 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket60 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology55, locale58, (java.lang.Integer) 0);
//        org.joda.time.MutableDateTime mutableDateTime61 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime mutableDateTime62 = org.joda.time.MutableDateTime.now();
//        mutableDateTime61.setDate((org.joda.time.ReadableInstant) mutableDateTime62);
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology65 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone64);
//        org.joda.time.DateTimeField dateTimeField66 = iSOChronology65.monthOfYear();
//        mutableDateTime62.setRounding(dateTimeField66);
//        mutableDateTime62.add((long) (short) -1);
//        org.joda.time.DateTime dateTime70 = mutableDateTime62.toDateTime();
//        org.joda.time.ReadablePartial readablePartial71 = null;
//        org.joda.time.DateTime dateTime72 = dateTime70.withFields(readablePartial71);
//        org.joda.time.DateTimeZone dateTimeZone73 = null;
//        org.joda.time.DateTime dateTime74 = dateTime70.toDateTime(dateTimeZone73);
//        org.joda.time.LocalDate localDate75 = dateTime70.toLocalDate();
//        int[] intArray77 = julianChronology55.get((org.joda.time.ReadablePartial) localDate75, 0L);
//        int int78 = skipDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate52, intArray77);
//        try {
//            int[] intArray80 = skipDateTimeField16.addWrapField(readablePartial20, 1969, intArray77, 163);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1969");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "monthOfYear" + "'", str17.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-2649600000L) + "'", long19 == (-2649600000L));
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str26.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(mutableDateTime33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "millisOfDay" + "'", str34.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Dec" + "'", str40.equals("Dec"));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 12 + "'", int44 == 12);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 5 + "'", int49 == 5);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertNotNull(julianChronology55);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime61);
//        org.junit.Assert.assertNotNull(mutableDateTime62);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertNotNull(iSOChronology65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(localDate75);
//        org.junit.Assert.assertNotNull(intArray77);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 12 + "'", int78 == 12);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.add((long) (short) -1);
        org.joda.time.DateTime dateTime9 = mutableDateTime1.toDateTime();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withFields(readablePartial10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime(dateTimeZone12);
        org.joda.time.LocalDate localDate14 = dateTime9.toLocalDate();
        org.joda.time.DateTime.Property property15 = dateTime9.millisOfSecond();
        org.joda.time.Instant instant16 = dateTime9.toInstant();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(instant16);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(100L);
        int int2 = mutableDateTime1.getYearOfEra();
        mutableDateTime1.setMillis((long) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusWeeks((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 21088);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMonths((int) (byte) 10);
        org.junit.Assert.assertNotNull(mutableDateTime0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType4, 1439, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        mutableDateTime0.setHourOfDay(0);
        mutableDateTime0.setMillis(0L);
        try {
            mutableDateTime0.setHourOfDay(21036537);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21036537 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        int int16 = offsetDateTimeField14.get(0L);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField14.getWrappedField();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, dateTimeFieldType18, 21088);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 64 + "'", int16 == 64);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "350");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType16, 5, 64, 21041450);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5 for millisOfDay must be in the range [64,21041450]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
//        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
//        java.lang.Class<?> wildcardClass3 = mutableDateTime1.getClass();
//        int int4 = mutableDateTime1.getDayOfMonth();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(mutableDateTime1);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.Chronology chronology12 = gJChronology11.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology11);
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology11.yearOfCentury();
//        int int15 = gJChronology11.getMinimumDaysInFirstWeek();
//        try {
//            long long20 = gJChronology11.getDateTimeMillis(10, (int) (byte) -1, (int) ' ', 12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(0L);
        try {
            mutableDateTime1.setTime((int) (byte) 0, 1000, 1000, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((java.lang.Object) (-3124138021965L));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "350");
        java.lang.Number number19 = illegalFieldValueException18.getLowerBound();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNull(number19);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.set((int) '4');
        java.lang.String str6 = property3.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property3.getAsText(locale8);
        java.util.Locale locale11 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime12 = property3.set("Pacific Standard Time", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Pacific Standard Time\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "millisOfDay" + "'", str6.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "52" + "'", str9.equals("52"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        try {
            mutableDateTime0.setTime(21041450, 5, 2019, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21041450 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.add((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime6 = property3.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime7 = property3.roundHalfCeiling();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.Chronology chronology11 = buddhistChronology8.withZone(dateTimeZone9);
        java.lang.String str12 = dateTimeZone9.getID();
        org.joda.time.DateTime dateTime13 = mutableDateTime7.toDateTime(dateTimeZone9);
        mutableDateTime7.add((long) (short) 100);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.add((long) (short) -1);
        org.joda.time.DateTime dateTime9 = mutableDateTime1.toDateTime();
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond((int) '#');
        org.joda.time.DateTime dateTime13 = dateTime9.withMillisOfDay(1);
        org.joda.time.LocalDate localDate14 = dateTime13.toLocalDate();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDate14);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        mutableDateTime0.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.add((int) (short) 10);
//        java.util.Locale locale6 = null;
//        int int7 = property3.getMaximumTextLength(locale6);
//        java.lang.String str8 = property3.getAsText();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "21043645" + "'", str8.equals("21043645"));
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("2019-06-12T05:50:40.024-07:00", (int) '4', (int) (short) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for 2019-06-12T05:50:40.024-07:00 must be in the range [-1,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology3 = julianChronology0.withZone(dateTimeZone1);
        try {
            long long11 = julianChronology0.getDateTimeMillis(21088, (int) (byte) 10, 12, 21042530, 0, 163, 1439);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21042530 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        java.lang.String str1 = instant0.toString();
//        org.joda.time.Instant instant4 = instant0.withDurationAdded((long) 'a', (int) (byte) 100);
//        org.joda.time.Instant instant5 = instant0.toInstant();
//        org.joda.time.DateTime dateTime6 = instant0.toDateTime();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-12T12:51:43.909Z" + "'", str1.equals("2019-06-12T12:51:43.909Z"));
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        java.lang.String str4 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        mutableDateTime6.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
        java.lang.String str12 = property9.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField15.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withYearOfCentury((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = iSOChronology9.weeks();
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTime.Property property12 = dateTime7.era();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now();
        mutableDateTime13.setDate((org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.monthOfYear();
        mutableDateTime14.setRounding(dateTimeField18);
        mutableDateTime14.add((long) (short) -1);
        org.joda.time.DateTime dateTime22 = mutableDateTime14.toDateTime();
        org.joda.time.ReadablePartial readablePartial23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.withFields(readablePartial23);
        try {
            int int25 = property12.getDifference((org.joda.time.ReadableInstant) dateTime24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDayOfYear((int) (byte) 100);
        int int3 = mutableDateTime0.getMonthOfYear();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(35483L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = iSOChronology9.weeks();
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology9.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = julianChronology16.seconds();
        int int18 = julianChronology16.getMinimumDaysInFirstWeek();
        java.util.Locale locale19 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket21 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology16, locale19, (java.lang.Integer) 0);
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTimeField dateTimeField23 = julianChronology16.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology9, dateTimeField23, 1969);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 21029837);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        try {
            mutableDateTime0.setWeekOfWeekyear((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hour();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withLocale(locale2);
        try {
            org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.parse("52", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Cannot parse \"52\": Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        int int6 = dateTime5.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 10, (int) (byte) 100, 163);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 138 + "'", int3 == 138);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.eras();
        boolean boolean3 = buddhistChronology0.equals((java.lang.Object) "America/Los_Angeles");
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        java.lang.String str4 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        mutableDateTime6.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
        java.lang.String str12 = property9.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        java.lang.String str17 = skipDateTimeField16.getName();
        java.lang.String str19 = skipDateTimeField16.getAsText((long) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime20 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now();
        mutableDateTime20.setDate((org.joda.time.ReadableInstant) mutableDateTime21);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.monthOfYear();
        mutableDateTime21.setRounding(dateTimeField25);
        mutableDateTime21.add((long) (short) -1);
        org.joda.time.DateTime dateTime29 = mutableDateTime21.toDateTime();
        org.joda.time.ReadablePartial readablePartial30 = null;
        org.joda.time.DateTime dateTime31 = dateTime29.withFields(readablePartial30);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = dateTime29.toDateTime(dateTimeZone32);
        org.joda.time.LocalDate localDate34 = dateTime29.toLocalDate();
        int[] intArray40 = new int[] { (byte) 100, (byte) 100, 21029837, '#' };
        try {
            int[] intArray42 = skipDateTimeField16.addWrapField((org.joda.time.ReadablePartial) localDate34, (int) '4', intArray40, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "monthOfYear" + "'", str17.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "December" + "'", str19.equals("December"));
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(intArray40);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("monthOfYear");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"monthOfYear\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(21031798);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime0.toMutableDateTime(dateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        int int8 = julianChronology7.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        mutableDateTime0.setHourOfDay(0);
        int int6 = mutableDateTime0.getCenturyOfEra();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 20 + "'", int6 == 20);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
//        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
//        boolean boolean3 = mutableDateTime1.isBeforeNow();
//        int int4 = mutableDateTime1.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime1.millisOfSecond();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(mutableDateTime1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 21142 + "'", int4 == 21142);
//        org.junit.Assert.assertNotNull(property5);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
//        java.lang.Appendable appendable2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.plus(readableDuration5);
//        int int7 = dateTime6.getHourOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime6.withYear((int) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.plus(readableDuration12);
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.minus(readablePeriod15);
//        try {
//            dateTimeFormatter1.printTo(appendable2, (org.joda.time.ReadableInstant) dateTime13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone10 = iSOChronology8.getZone();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 1, dateTimeZone10);
        java.lang.String str12 = dateTimeZone10.getID();
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(21035312, 0, 8, 21041450, 0, 1969, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21041450 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
//        java.lang.String str4 = iSOChronology2.toString();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
//        mutableDateTime6.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
//        java.lang.String str12 = property9.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) (byte) 100);
//        java.util.Locale locale19 = null;
//        int int20 = skipDateTimeField16.getMaximumTextLength(locale19);
//        int int22 = skipDateTimeField16.get((long) 5);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
//        org.joda.time.ReadableDuration readableDuration25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.plus(readableDuration25);
//        int int27 = dateTime26.getHourOfDay();
//        org.joda.time.DateTime dateTime29 = dateTime26.withYear((int) (short) -1);
//        org.joda.time.LocalDate localDate30 = dateTime29.toLocalDate();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone32);
//        org.joda.time.DurationField durationField34 = julianChronology33.seconds();
//        int int35 = julianChronology33.getMinimumDaysInFirstWeek();
//        java.util.Locale locale36 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket38 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology33, locale36, (java.lang.Integer) 0);
//        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime mutableDateTime40 = org.joda.time.MutableDateTime.now();
//        mutableDateTime39.setDate((org.joda.time.ReadableInstant) mutableDateTime40);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone42);
//        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.monthOfYear();
//        mutableDateTime40.setRounding(dateTimeField44);
//        mutableDateTime40.add((long) (short) -1);
//        org.joda.time.DateTime dateTime48 = mutableDateTime40.toDateTime();
//        org.joda.time.ReadablePartial readablePartial49 = null;
//        org.joda.time.DateTime dateTime50 = dateTime48.withFields(readablePartial49);
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.DateTime dateTime52 = dateTime48.toDateTime(dateTimeZone51);
//        org.joda.time.LocalDate localDate53 = dateTime48.toLocalDate();
//        int[] intArray55 = julianChronology33.get((org.joda.time.ReadablePartial) localDate53, 0L);
//        int int56 = skipDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) localDate30, intArray55);
//        int int57 = skipDateTimeField16.getMinimumValue();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Dec" + "'", str18.equals("Dec"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9 + "'", int20 == 9);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 5 + "'", int27 == 5);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(julianChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(mutableDateTime40);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(localDate53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 12 + "'", int56 == 12);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gJChronology0.minutes();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.plus(readableDuration4);
//        org.joda.time.DateTime dateTime7 = dateTime3.withDayOfYear((int) ' ');
//        org.joda.time.Chronology chronology8 = dateTime3.getChronology();
//        org.joda.time.DateTime dateTime10 = dateTime3.withYear(0);
//        org.joda.time.DateTime dateTime12 = dateTime3.withSecondOfMinute((int) (short) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now();
//        mutableDateTime14.addMinutes((-1));
//        java.lang.String str17 = dateTimeFormatter13.print((org.joda.time.ReadableInstant) mutableDateTime14);
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) dateTime3, (org.joda.time.ReadableDateTime) mutableDateTime14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "20190612" + "'", str17.equals("20190612"));
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        long long17 = offsetDateTimeField14.roundCeiling(35L);
        long long20 = offsetDateTimeField14.add((long) '#', 12);
        java.util.Locale locale23 = null;
        try {
            long long24 = offsetDateTimeField14.set(209916000000L, "monthOfYear", locale23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"monthOfYear\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 31536000035L + "'", long20 == 31536000035L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology2, locale3, (java.lang.Integer) 0);
        boolean boolean7 = dateTimeParserBucket5.restoreState((java.lang.Object) (byte) 100);
        org.joda.time.Chronology chronology8 = dateTimeParserBucket5.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.plusMonths((int) (byte) -1);
        org.joda.time.Chronology chronology6 = dateTime5.getChronology();
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withDayOfYear(21038483);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21038483 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        mutableDateTime0.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.minuteOfDay();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsText(locale5);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime8 = property4.set("2019-06-12T05:50:32.113-07:00");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T05:50:32.113-07:00\" for minuteOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "351" + "'", str6.equals("351"));
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = julianChronology2.seconds();
        int int4 = julianChronology2.getMinimumDaysInFirstWeek();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology2, locale5, (java.lang.Integer) 0);
        org.joda.time.DateTimeField dateTimeField8 = julianChronology2.hourOfDay();
        org.joda.time.DurationField durationField9 = julianChronology2.days();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 5, 10, 4, (int) (short) 0, 1969, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime7 = dateTime4.withWeekyear((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
        mutableDateTime7.setDate((org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.monthOfYear();
        mutableDateTime8.setRounding(dateTimeField12);
        mutableDateTime8.add((long) (short) -1);
        org.joda.time.DateTime dateTime16 = mutableDateTime8.toDateTime();
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.withFields(readablePartial17);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis(64);
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((-21036537L), dateTimeZone21);
        long long24 = dateTimeZone21.convertUTCToLocal((-28857564470L));
        org.joda.time.DateTime dateTime25 = dateTime16.withZoneRetainFields(dateTimeZone21);
        try {
            org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime(1439, 1439, (int) (short) 0, (int) (short) -1, 4, (int) (short) 100, 52, dateTimeZone21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-28857564406L) + "'", long24 == (-28857564406L));
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("20190612", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 20190612");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        mutableDateTime0.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime7 = property3.add((int) ' ');
//        int int8 = mutableDateTime7.getDayOfYear();
//        java.lang.String str9 = mutableDateTime7.toString();
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime7.secondOfDay();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 163 + "'", int8 == 163);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019-06-12T05:51:23.990-07:00" + "'", str9.equals("2019-06-12T05:51:23.990-07:00"));
//        org.junit.Assert.assertNotNull(property10);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        try {
            long long17 = offsetDateTimeField14.set((long) 21031798, "monthOfYear");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"monthOfYear\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(iSOChronology2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addSeconds(8);
        org.junit.Assert.assertNotNull(mutableDateTime0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendCenturyOfEra(9, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendLiteral("2019-06-12T05:50:32.113-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder7.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.dayOfWeek();
        java.lang.String str24 = iSOChronology22.toString();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime26 = org.joda.time.MutableDateTime.now();
        mutableDateTime26.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime26.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime31 = property29.set((int) '4');
        java.lang.String str32 = property29.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property29.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, dateTimeFieldType33, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder17.appendDecimal(dateTimeFieldType36, 21037186, 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder16.appendFixedDecimal(dateTimeFieldType36, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType36, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology45.dayOfWeek();
        java.lang.String str47 = iSOChronology45.toString();
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology45.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime49 = org.joda.time.MutableDateTime.now();
        mutableDateTime49.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property52 = mutableDateTime49.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime54 = property52.set((int) '4');
        java.lang.String str55 = property52.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property52.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, dateTimeFieldType56, (int) '4');
        org.joda.time.DurationField durationField59 = offsetDateTimeField58.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = offsetDateTimeField58.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType60, "350");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder43.appendSignedDecimal(dateTimeFieldType60, (-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str24.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "millisOfDay" + "'", str32.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str47.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(mutableDateTime54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "millisOfDay" + "'", str55.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        java.lang.String str1 = instant0.toString();
//        org.joda.time.Instant instant4 = instant0.withDurationAdded((long) 'a', (int) (byte) 100);
//        org.joda.time.Instant instant5 = instant0.toInstant();
//        org.joda.time.Instant instant7 = instant0.minus(0L);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-12T12:52:25.262Z" + "'", str1.equals("2019-06-12T12:52:25.262Z"));
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(instant7);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property9 = dateTime8.hourOfDay();
        org.joda.time.DateTime dateTime11 = property9.setCopy(10);
        org.joda.time.DateTime dateTime13 = property9.addToCopy(0L);
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.DateTime dateTime15 = property9.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(21042530, 1, (int) (short) -1, (int) (byte) 0, 19, 0, 5, (org.joda.time.Chronology) julianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(julianChronology8);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2019-06-12T12:51:43.909Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendCenturyOfEra(9, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendLiteral("2019-06-12T05:50:32.113-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder7.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.dayOfWeek();
        java.lang.String str24 = iSOChronology22.toString();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime26 = org.joda.time.MutableDateTime.now();
        mutableDateTime26.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime26.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime31 = property29.set((int) '4');
        java.lang.String str32 = property29.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property29.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, dateTimeFieldType33, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder17.appendDecimal(dateTimeFieldType36, 21037186, 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder16.appendFixedDecimal(dateTimeFieldType36, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType36, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder43.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str24.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "millisOfDay" + "'", str32.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 1, dateTimeZone4);
        java.lang.String str6 = dateTimeZone4.getID();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "America/Los_Angeles" + "'", str6.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(julianChronology7);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(9);
//        java.lang.StringBuffer stringBuffer3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime5.plus(readableDuration6);
//        int int8 = dateTime7.getHourOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withYear((int) (short) -1);
//        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
//        try {
//            dateTimeFormatter2.printTo(stringBuffer3, (org.joda.time.ReadablePartial) localDate11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        mutableDateTime0.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.add((int) (short) 10);
//        java.util.Locale locale6 = null;
//        int int7 = property3.getMaximumTextLength(locale6);
//        int int8 = property3.get();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 21085980 + "'", int8 == 21085980);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology2, locale3, (java.lang.Integer) 0);
        boolean boolean7 = dateTimeParserBucket5.restoreState((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology10, locale11, (java.lang.Integer) 0);
        dateTimeParserBucket13.setOffset((java.lang.Integer) 1000);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeParserBucket13.getZone();
        dateTimeParserBucket5.setZone(dateTimeZone16);
        java.lang.String str18 = dateTimeZone16.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "America/Los_Angeles" + "'", str18.equals("America/Los_Angeles"));
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now();
//        mutableDateTime3.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime10 = property6.add((int) ' ');
//        int int11 = mutableDateTime10.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime10);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeFormatter0, dateTimeZone1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 163 + "'", int11 == 163);
//        org.junit.Assert.assertNotNull(gJChronology12);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology3, locale4, (java.lang.Integer) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.Chronology chronology8 = iSOChronology3.withUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology2, locale3, (java.lang.Integer) 0);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 1000);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeParserBucket5.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = iSOChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.secondOfDay();
        dateTimeParserBucket5.saveField(dateTimeField12, 4);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone19 = iSOChronology17.getZone();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 1, dateTimeZone19);
        dateTimeParserBucket5.setZone(dateTimeZone19);
        org.joda.time.Chronology chronology22 = dateTimeParserBucket5.getChronology();
        java.lang.Object obj23 = dateTimeParserBucket5.saveState();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 209916000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.Chronology chronology12 = gJChronology11.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology11);
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology11.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField15 = gJChronology11.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime16 = org.joda.time.MutableDateTime.now();
//        mutableDateTime16.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property19 = mutableDateTime16.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime21 = property19.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime22 = property19.roundHalfFloor();
//        org.joda.time.MutableDateTime mutableDateTime23 = property19.roundHalfCeiling();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
//        org.joda.time.Chronology chronology27 = buddhistChronology24.withZone(dateTimeZone25);
//        java.lang.String str28 = dateTimeZone25.getID();
//        org.joda.time.DateTime dateTime29 = mutableDateTime23.toDateTime(dateTimeZone25);
//        try {
//            org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((java.lang.Object) gJChronology11, dateTimeZone25);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GJChronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "America/Los_Angeles" + "'", str28.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime29);
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.yearOfEra();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.dayOfWeek();
//        java.lang.String str17 = iSOChronology15.toString();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
//        mutableDateTime19.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime24 = property22.set((int) '4');
//        java.lang.String str25 = property22.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType26, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField18);
//        java.lang.String str31 = skipDateTimeField29.getAsShortText((long) (byte) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, (org.joda.time.DateTimeField) skipDateTimeField29);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology34.dayOfWeek();
//        java.lang.String str36 = iSOChronology34.toString();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology34.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime38 = org.joda.time.MutableDateTime.now();
//        mutableDateTime38.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property41 = mutableDateTime38.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime43 = property41.set((int) '4');
//        java.lang.String str44 = property41.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property41.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, dateTimeFieldType45, (int) '4');
//        int int49 = offsetDateTimeField47.get(0L);
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
//        org.joda.time.ReadableDuration readableDuration52 = null;
//        org.joda.time.DateTime dateTime53 = dateTime51.plus(readableDuration52);
//        org.joda.time.DateTime dateTime55 = dateTime51.withDayOfYear((int) ' ');
//        org.joda.time.Chronology chronology56 = dateTime51.getChronology();
//        org.joda.time.DateTime dateTime58 = dateTime51.withHourOfDay((int) (byte) 10);
//        org.joda.time.LocalTime localTime59 = dateTime58.toLocalTime();
//        int int60 = offsetDateTimeField47.getMinimumValue((org.joda.time.ReadablePartial) localTime59);
//        java.util.Locale locale62 = null;
//        try {
//            java.lang.String str63 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) localTime59, 21042164, locale62);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 21042164");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "millisOfDay" + "'", str25.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Dec" + "'", str31.equals("Dec"));
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str36.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(mutableDateTime43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "millisOfDay" + "'", str44.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 64 + "'", int49 == 64);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(chronology56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(localTime59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 53 + "'", int60 == 53);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        mutableDateTime0.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime0.toMutableDateTime(dateTimeZone4);
//        int int7 = mutableDateTime6.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 51 + "'", int7 == 51);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.io.Writer writer2 = null;
        try {
            dateTimeFormatter0.printTo(writer2, 350L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now();
//        mutableDateTime3.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime10 = property6.add((int) ' ');
//        int int11 = mutableDateTime10.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime10);
//        org.joda.time.Chronology chronology13 = gJChronology12.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology12);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone19 = iSOChronology17.getZone();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 1, dateTimeZone19);
//        java.lang.String str21 = dateTimeZone19.getID();
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
//        mutableDateTime14.setZoneRetainFields(dateTimeZone19);
//        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime(obj0, dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 163 + "'", int11 == 163);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "America/Los_Angeles" + "'", str21.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(julianChronology22);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 138, "2019-06-12T12:51:26.242Z");
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property9 = dateTime8.hourOfDay();
        org.joda.time.DateTime dateTime11 = property9.setCopy(10);
        org.joda.time.DateTime dateTime13 = property9.addToCopy(0L);
        org.joda.time.DateTimeField dateTimeField14 = property9.getField();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.millisOfSecond();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology16);
        boolean boolean19 = property9.equals((java.lang.Object) dateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendCenturyOfEra(9, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendLiteral("2019-06-12T05:50:32.113-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder7.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.dayOfWeek();
        java.lang.String str24 = iSOChronology22.toString();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime26 = org.joda.time.MutableDateTime.now();
        mutableDateTime26.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime26.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime31 = property29.set((int) '4');
        java.lang.String str32 = property29.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property29.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, dateTimeFieldType33, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder17.appendDecimal(dateTimeFieldType36, 21037186, 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder16.appendFixedDecimal(dateTimeFieldType36, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType36, (int) '#');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder3.appendPattern("2019-06-12T05:51:23.990-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str24.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "millisOfDay" + "'", str32.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.clockhourOfDay();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology6);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) 'a', (int) (byte) 0, 9, (int) (short) 100, 21142, 100, (org.joda.time.Chronology) buddhistChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = iSOChronology9.weeks();
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTime dateTime13 = dateTime11.plusWeeks(0);
        org.joda.time.DateTime dateTime15 = dateTime11.plusWeeks(21085980);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        boolean boolean3 = gJChronology0.equals((java.lang.Object) dateTimeZone2);
        try {
            org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) 163, 1000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendCenturyOfEra(9, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendClockhourOfDay(21036537);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfDay(138);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.minus(readableDuration1);
        org.joda.time.MutableDateTime mutableDateTime3 = instant0.toMutableDateTime();
        int int4 = mutableDateTime3.getRoundingMode();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.dayOfWeek();
        java.lang.String str7 = iSOChronology5.toString();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
        mutableDateTime9.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime14 = property12.set((int) '4');
        java.lang.String str15 = property12.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property12.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType16, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField18.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder0.appendDecimal(dateTimeFieldType19, 21037186, 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMillisOfDay((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str7.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "millisOfDay" + "'", str15.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.yearOfEra();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.dayOfWeek();
//        java.lang.String str17 = iSOChronology15.toString();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
//        mutableDateTime19.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime24 = property22.set((int) '4');
//        java.lang.String str25 = property22.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType26, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField18);
//        java.lang.String str31 = skipDateTimeField29.getAsShortText((long) (byte) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, (org.joda.time.DateTimeField) skipDateTimeField29);
//        long long35 = skipUndoDateTimeField32.set(35530L, 1);
//        try {
//            long long38 = skipUndoDateTimeField32.set((long) 21042530, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "millisOfDay" + "'", str25.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Dec" + "'", str31.equals("Dec"));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-28857564470L) + "'", long35 == (-28857564470L));
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
//        java.lang.String str4 = iSOChronology2.toString();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
//        mutableDateTime6.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
//        java.lang.String str12 = property9.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) (byte) 100);
//        java.util.Locale locale19 = null;
//        int int20 = skipDateTimeField16.getMaximumTextLength(locale19);
//        int int22 = skipDateTimeField16.get((long) 5);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
//        org.joda.time.ReadableDuration readableDuration25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.plus(readableDuration25);
//        int int27 = dateTime26.getHourOfDay();
//        org.joda.time.DateTime dateTime29 = dateTime26.withYear((int) (short) -1);
//        org.joda.time.LocalDate localDate30 = dateTime29.toLocalDate();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone32);
//        org.joda.time.DurationField durationField34 = julianChronology33.seconds();
//        int int35 = julianChronology33.getMinimumDaysInFirstWeek();
//        java.util.Locale locale36 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket38 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology33, locale36, (java.lang.Integer) 0);
//        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime mutableDateTime40 = org.joda.time.MutableDateTime.now();
//        mutableDateTime39.setDate((org.joda.time.ReadableInstant) mutableDateTime40);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone42);
//        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.monthOfYear();
//        mutableDateTime40.setRounding(dateTimeField44);
//        mutableDateTime40.add((long) (short) -1);
//        org.joda.time.DateTime dateTime48 = mutableDateTime40.toDateTime();
//        org.joda.time.ReadablePartial readablePartial49 = null;
//        org.joda.time.DateTime dateTime50 = dateTime48.withFields(readablePartial49);
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.DateTime dateTime52 = dateTime48.toDateTime(dateTimeZone51);
//        org.joda.time.LocalDate localDate53 = dateTime48.toLocalDate();
//        int[] intArray55 = julianChronology33.get((org.joda.time.ReadablePartial) localDate53, 0L);
//        int int56 = skipDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) localDate30, intArray55);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
//        java.util.Locale locale60 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket62 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology59, locale60, (java.lang.Integer) 0);
//        boolean boolean64 = dateTimeParserBucket62.restoreState((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone66);
//        java.util.Locale locale68 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket70 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology67, locale68, (java.lang.Integer) 0);
//        dateTimeParserBucket70.setOffset((java.lang.Integer) 1000);
//        org.joda.time.DateTimeZone dateTimeZone73 = dateTimeParserBucket70.getZone();
//        dateTimeParserBucket62.setZone(dateTimeZone73);
//        org.joda.time.MutableDateTime mutableDateTime75 = org.joda.time.MutableDateTime.now();
//        mutableDateTime75.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property78 = mutableDateTime75.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime80 = property78.set((int) '4');
//        java.lang.String str81 = property78.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType82 = property78.getFieldType();
//        dateTimeParserBucket62.saveField(dateTimeFieldType82, 0);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField86 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField16, dateTimeFieldType82, 21036537);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType82, 8, 19, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 8 for millisOfDay must be in the range [19,0]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Dec" + "'", str18.equals("Dec"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9 + "'", int20 == 9);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 5 + "'", int27 == 5);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(julianChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(mutableDateTime40);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(localDate53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 12 + "'", int56 == 12);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(iSOChronology59);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone66);
//        org.junit.Assert.assertNotNull(iSOChronology67);
//        org.junit.Assert.assertNotNull(dateTimeZone73);
//        org.junit.Assert.assertNotNull(mutableDateTime75);
//        org.junit.Assert.assertNotNull(property78);
//        org.junit.Assert.assertNotNull(mutableDateTime80);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "millisOfDay" + "'", str81.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType82);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.minuteOfHour();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 1, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        long long10 = dateTimeZone4.convertLocalToUTC((long) (byte) 10, true, (long) 2019);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800010L + "'", long10 == 28800010L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.add((long) (short) -1);
        int int9 = mutableDateTime1.getDayOfMonth();
        org.joda.time.Instant instant10 = mutableDateTime1.toInstant();
        mutableDateTime1.addSeconds((int) ' ');
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(64);
        long long4 = dateTimeZone1.adjustOffset(1303L, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1303L + "'", long4 == 1303L);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
//        mutableDateTime5.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime12 = property8.add((int) ' ');
//        int int13 = mutableDateTime12.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime12);
//        java.util.TimeZone timeZone15 = dateTimeZone3.toTimeZone();
//        java.lang.String str16 = dateTimeZone3.toString();
//        org.joda.time.Chronology chronology17 = buddhistChronology1.withZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((-990L), dateTimeZone3);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 163 + "'", int13 == 163);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "America/Los_Angeles" + "'", str16.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology17);
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadableDuration readableDuration2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        boolean boolean5 = dateTime1.isEqual((org.joda.time.ReadableInstant) mutableDateTime4);
//        int int6 = mutableDateTime4.getDayOfMonth();
//        mutableDateTime4.addDays(64);
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        mutableDateTime4.add(readableDuration9);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = julianChronology3.seconds();
        int int5 = julianChronology3.getMinimumDaysInFirstWeek();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology3, locale6, (java.lang.Integer) 0);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.Chronology) julianChronology3);
        mutableDateTime9.setSecondOfDay(4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        long long14 = dateTimeZone0.adjustOffset((long) (short) 1, false);
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        try {
//            org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant15, 19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 19");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.add((long) (short) -1);
        org.joda.time.DateTime dateTime9 = mutableDateTime1.toDateTime();
        mutableDateTime1.addDays((int) 'a');
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        mutableDateTime0.add(readableDuration4, 8);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        mutableDateTime0.setDayOfYear((int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.plus(readableDuration5);
//        org.joda.time.DateTime dateTime8 = dateTime4.withDayOfYear((int) ' ');
//        org.joda.time.DateTime.Property property9 = dateTime4.weekOfWeekyear();
//        org.joda.time.DateTime dateTime10 = property9.roundHalfCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
//        org.joda.time.DurationField durationField13 = iSOChronology12.weeks();
//        org.joda.time.DateTime dateTime14 = dateTime10.toDateTime((org.joda.time.Chronology) iSOChronology12);
//        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks(0);
//        org.joda.time.DateTime dateTime18 = dateTime14.withYearOfCentury(0);
//        boolean boolean19 = mutableDateTime0.isAfter((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime14.plus(readablePeriod20);
//        int int22 = dateTime21.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 24 + "'", int22 == 24);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.dayOfWeek();
        java.lang.String str5 = iSOChronology3.toString();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        mutableDateTime7.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime7.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime12 = property10.set((int) '4');
        java.lang.String str13 = property10.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property10.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType14, (int) '4');
        int int18 = offsetDateTimeField16.get(0L);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.dayOfWeek();
        java.lang.String str23 = iSOChronology21.toString();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology21.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        mutableDateTime25.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime25.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime30 = property28.set((int) '4');
        java.lang.String str31 = property28.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property28.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, dateTimeFieldType32, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology19, dateTimeField24);
        org.joda.time.MutableDateTime mutableDateTime36 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime37 = org.joda.time.MutableDateTime.now();
        mutableDateTime36.setDate((org.joda.time.ReadableInstant) mutableDateTime37);
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.monthOfYear();
        mutableDateTime37.setRounding(dateTimeField41);
        mutableDateTime37.add((long) (short) -1);
        org.joda.time.DateTime dateTime45 = mutableDateTime37.toDateTime();
        org.joda.time.ReadablePartial readablePartial46 = null;
        org.joda.time.DateTime dateTime47 = dateTime45.withFields(readablePartial46);
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.DateTime dateTime49 = dateTime45.toDateTime(dateTimeZone48);
        org.joda.time.LocalDate localDate50 = dateTime45.toLocalDate();
        int[] intArray53 = new int[] { 21041450, 0 };
        int int54 = skipDateTimeField35.getMaximumValue((org.joda.time.ReadablePartial) localDate50, intArray53);
        int int55 = offsetDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) localDate50);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str5.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "millisOfDay" + "'", str13.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 64 + "'", int18 == 64);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str23.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "millisOfDay" + "'", str31.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(mutableDateTime36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 12 + "'", int54 == 12);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 64 + "'", int55 == 64);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.year();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology2, locale3, (java.lang.Integer) 0);
        boolean boolean7 = dateTimeParserBucket5.restoreState((java.lang.Object) (byte) 100);
        java.lang.Object obj8 = dateTimeParserBucket5.saveState();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        java.lang.String str1 = instant0.toString();
//        org.joda.time.DateTime dateTime2 = instant0.toDateTime();
//        org.joda.time.DateTime dateTime3 = instant0.toDateTime();
//        org.joda.time.DateTime dateTime4 = instant0.toDateTimeISO();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-12T12:52:31.131Z" + "'", str1.equals("2019-06-12T12:52:31.131Z"));
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("ISOChronology[America/Los_Angeles]", "2019-06-12T12:51:26.242Z");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.yearOfEra();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.dayOfWeek();
//        java.lang.String str17 = iSOChronology15.toString();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
//        mutableDateTime19.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime24 = property22.set((int) '4');
//        java.lang.String str25 = property22.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType26, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField18);
//        java.lang.String str31 = skipDateTimeField29.getAsShortText((long) (byte) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, (org.joda.time.DateTimeField) skipDateTimeField29);
//        org.joda.time.DurationField durationField33 = skipDateTimeField29.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = skipDateTimeField29.getType();
//        int int36 = skipDateTimeField29.getLeapAmount((long) 1439);
//        long long39 = skipDateTimeField29.addWrapField((long) 'a', (int) (byte) 1);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "millisOfDay" + "'", str25.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Dec" + "'", str31.equals("Dec"));
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-28857599903L) + "'", long39 == (-28857599903L));
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        mutableDateTime6.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.add((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime12 = property9.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime13 = property9.roundHalfCeiling();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        org.joda.time.Chronology chronology17 = buddhistChronology14.withZone(dateTimeZone15);
        java.lang.String str18 = dateTimeZone15.getID();
        org.joda.time.DateTime dateTime19 = mutableDateTime13.toDateTime(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone20 = mutableDateTime13.getZone();
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(1439, 2, 100, 19, 0, (int) (byte) -1, dateTimeZone20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "America/Los_Angeles" + "'", str18.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        int int16 = offsetDateTimeField14.get(0L);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readableDuration19);
        org.joda.time.DateTime dateTime22 = dateTime18.withDayOfYear((int) ' ');
        org.joda.time.Chronology chronology23 = dateTime18.getChronology();
        org.joda.time.DateTime dateTime25 = dateTime18.withHourOfDay((int) (byte) 10);
        org.joda.time.LocalTime localTime26 = dateTime25.toLocalTime();
        int int27 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localTime26);
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField14.getAsText((long) 21037186, locale29);
        java.util.Locale locale31 = null;
        int int32 = offsetDateTimeField14.getMaximumShortTextLength(locale31);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 64 + "'", int16 == 64);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 53 + "'", int27 == 53);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "64" + "'", str30.equals("64"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
//        mutableDateTime1.addMinutes((-1));
//        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime1);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime1.era();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.dayOfYear();
//        org.joda.time.DurationField durationField7 = property6.getDurationField();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(mutableDateTime1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "20190612" + "'", str4.equals("20190612"));
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(durationField7);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.dayOfWeek();
        java.lang.String str6 = iSOChronology4.toString();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
        mutableDateTime8.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime13 = property11.set((int) '4');
        java.lang.String str14 = property11.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property11.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType15, (int) '4');
        int int19 = offsetDateTimeField17.get(0L);
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField17.getWrappedField();
        java.lang.String str21 = offsetDateTimeField17.getName();
        try {
            mutableDateTime1.setRounding((org.joda.time.DateTimeField) offsetDateTimeField17, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 19");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str6.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "millisOfDay" + "'", str14.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 64 + "'", int19 == 64);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "millisOfDay" + "'", str21.equals("millisOfDay"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(35616L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        int int15 = offsetDateTimeField14.getOffset();
        long long18 = offsetDateTimeField14.add((long) 21042164, 0);
        int int20 = offsetDateTimeField14.getLeapAmount((-21036537L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 21042164L + "'", long18 == 21042164L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        int int18 = offsetDateTimeField14.get((long) 0);
        long long21 = offsetDateTimeField14.add(0L, (long) 8);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField14.getAsText(138, locale23);
        try {
            long long27 = offsetDateTimeField14.add((long) ' ', (-28857564406L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Magnitude of add amount is too large: -28857564406");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 64 + "'", int18 == 64);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 20991600000L + "'", long21 == 20991600000L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "138" + "'", str24.equals("138"));
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        java.util.Locale locale1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
//        boolean boolean4 = dateTimeFormatter2.isPrinter();
//        java.lang.Appendable appendable5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
//        mutableDateTime8.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime13 = property11.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime15 = property11.add((int) ' ');
//        int int16 = mutableDateTime15.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) mutableDateTime15);
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.yearOfEra();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.dayOfWeek();
//        java.lang.String str23 = iSOChronology21.toString();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology21.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
//        mutableDateTime25.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property28 = mutableDateTime25.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime30 = property28.set((int) '4');
//        java.lang.String str31 = property28.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property28.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, dateTimeFieldType32, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology19, dateTimeField24);
//        java.lang.String str37 = skipDateTimeField35.getAsShortText((long) (byte) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField38 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology17, (org.joda.time.DateTimeField) skipDateTimeField35);
//        long long41 = skipUndoDateTimeField38.set(35530L, 1);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone42);
//        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.dayOfWeek();
//        java.lang.String str45 = iSOChronology43.toString();
//        org.joda.time.DateTimeField dateTimeField46 = iSOChronology43.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime47 = org.joda.time.MutableDateTime.now();
//        mutableDateTime47.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property50 = mutableDateTime47.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime52 = property50.set((int) '4');
//        java.lang.String str53 = property50.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property50.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, dateTimeFieldType54, (int) '4');
//        org.joda.time.DurationField durationField57 = offsetDateTimeField56.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = offsetDateTimeField56.getType();
//        int int60 = offsetDateTimeField56.get((long) 0);
//        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(dateTimeZone61);
//        org.joda.time.ReadableDuration readableDuration63 = null;
//        org.joda.time.DateTime dateTime64 = dateTime62.plus(readableDuration63);
//        org.joda.time.DateTime dateTime66 = dateTime62.withDayOfYear((int) ' ');
//        org.joda.time.Chronology chronology67 = dateTime62.getChronology();
//        org.joda.time.DateTime dateTime69 = dateTime62.withHourOfDay((int) (byte) 10);
//        org.joda.time.LocalTime localTime70 = dateTime69.toLocalTime();
//        int[] intArray72 = null;
//        int[] intArray74 = offsetDateTimeField56.addWrapPartial((org.joda.time.ReadablePartial) localTime70, (int) (short) 100, intArray72, 0);
//        int[] intArray81 = new int[] { 0, 'a', (byte) 10, 10, 138, (byte) 10 };
//        int int82 = skipUndoDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) localTime70, intArray81);
//        try {
//            dateTimeFormatter2.printTo(appendable5, (org.joda.time.ReadablePartial) localTime70);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 163 + "'", int16 == 163);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str23.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "millisOfDay" + "'", str31.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Dec" + "'", str37.equals("Dec"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-28857564470L) + "'", long41 == (-28857564470L));
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str45.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(mutableDateTime47);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(mutableDateTime52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "millisOfDay" + "'", str53.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 64 + "'", int60 == 64);
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(chronology67);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(localTime70);
//        org.junit.Assert.assertNull(intArray74);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        boolean boolean3 = gJChronology0.equals((java.lang.Object) dateTimeZone2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime4.withMillisOfSecond((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("2019-06-12T12:52:27.117Z");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2019-06-12T12:52:27.117Z/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@77d80e9");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        int int16 = offsetDateTimeField14.get(0L);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readableDuration19);
        org.joda.time.DateTime dateTime22 = dateTime18.withDayOfYear((int) ' ');
        org.joda.time.Chronology chronology23 = dateTime18.getChronology();
        org.joda.time.DateTime dateTime25 = dateTime18.withHourOfDay((int) (byte) 10);
        org.joda.time.LocalTime localTime26 = dateTime25.toLocalTime();
        int int27 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localTime26);
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField14.getAsText((long) 21037186, locale29);
        long long33 = offsetDateTimeField14.getDifferenceAsLong((long) (byte) 100, 0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 64 + "'", int16 == 64);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 53 + "'", int27 == 53);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "64" + "'", str30.equals("64"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadableDuration readableDuration2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
//        int int4 = dateTime3.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime3.withYear((int) (short) -1);
//        org.joda.time.DateTime dateTime8 = dateTime3.plus((-665460885917222000L));
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 0.0d, (java.lang.Number) 8L, (java.lang.Number) 53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(21031798);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendLiteral("2019-06-12T05:50:32.113-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendTwoDigitWeekyear(4);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap13 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendTimeZoneShortName(strMap13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.append(dateTimeFormatter16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No formatter supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(strMap13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.hourOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = gJChronology0.get(readablePeriod2, (long) 'a', (long) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology2, locale3, (java.lang.Integer) 0);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 1000);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeParserBucket5.getZone();
        long long11 = dateTimeParserBucket5.computeMillis(true, "2019-05-01T00:00:00.000-07:00");
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readableDuration14);
        org.joda.time.DateTime dateTime17 = dateTime13.withDayOfYear((int) ' ');
        org.joda.time.Chronology chronology18 = dateTime13.getChronology();
        boolean boolean19 = dateTimeParserBucket5.restoreState((java.lang.Object) dateTime13);
        java.lang.Integer int20 = dateTimeParserBucket5.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-990L) + "'", long11 == (-990L));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20.equals(0));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        int int4 = property3.getMinimumValue();
        java.util.Locale locale5 = null;
        int int6 = property3.getMaximumShortTextLength(locale5);
        boolean boolean7 = property3.isLeap();
        java.lang.String str8 = property3.getName();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "millisOfDay" + "'", str8.equals("millisOfDay"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(0L);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.junit.Assert.assertNotNull(property2);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
//        java.lang.String str4 = iSOChronology2.toString();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
//        mutableDateTime6.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
//        java.lang.String str12 = property9.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
//        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) (byte) 100);
//        java.util.Locale locale19 = null;
//        int int20 = skipDateTimeField16.getMaximumTextLength(locale19);
//        int int22 = skipDateTimeField16.get((long) 5);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
//        org.joda.time.ReadableDuration readableDuration25 = null;
//        org.joda.time.DateTime dateTime26 = dateTime24.plus(readableDuration25);
//        int int27 = dateTime26.getHourOfDay();
//        org.joda.time.DateTime dateTime29 = dateTime26.withYear((int) (short) -1);
//        org.joda.time.LocalDate localDate30 = dateTime29.toLocalDate();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone32);
//        org.joda.time.DurationField durationField34 = julianChronology33.seconds();
//        int int35 = julianChronology33.getMinimumDaysInFirstWeek();
//        java.util.Locale locale36 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket38 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology33, locale36, (java.lang.Integer) 0);
//        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime mutableDateTime40 = org.joda.time.MutableDateTime.now();
//        mutableDateTime39.setDate((org.joda.time.ReadableInstant) mutableDateTime40);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone42);
//        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.monthOfYear();
//        mutableDateTime40.setRounding(dateTimeField44);
//        mutableDateTime40.add((long) (short) -1);
//        org.joda.time.DateTime dateTime48 = mutableDateTime40.toDateTime();
//        org.joda.time.ReadablePartial readablePartial49 = null;
//        org.joda.time.DateTime dateTime50 = dateTime48.withFields(readablePartial49);
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.DateTime dateTime52 = dateTime48.toDateTime(dateTimeZone51);
//        org.joda.time.LocalDate localDate53 = dateTime48.toLocalDate();
//        int[] intArray55 = julianChronology33.get((org.joda.time.ReadablePartial) localDate53, 0L);
//        int int56 = skipDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) localDate30, intArray55);
//        long long58 = skipDateTimeField16.roundHalfFloor(0L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Dec" + "'", str18.equals("Dec"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9 + "'", int20 == 9);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 5 + "'", int27 == 5);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(julianChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(mutableDateTime40);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(localDate53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 12 + "'", int56 == 12);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 28800000L + "'", long58 == 28800000L);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.weeks();
        org.joda.time.Chronology chronology3 = iSOChronology1.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setMillis(209916000000L);
        try {
            mutableDateTime0.setTime(19, 1439, 52, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1439 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime4 = mutableDateTime0.copy();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime0.minuteOfDay();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime0.dayOfMonth();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        mutableDateTime0.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime6 = property3.roundHalfFloor();
//        org.joda.time.MutableDateTime mutableDateTime7 = property3.roundHalfCeiling();
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
//        mutableDateTime8.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime13 = property11.set((int) '4');
//        java.lang.String str14 = property11.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property11.getFieldType();
//        int int16 = mutableDateTime7.get(dateTimeFieldType15);
//        mutableDateTime7.setSecondOfMinute((int) '#');
//        org.joda.time.MutableDateTime.Property property19 = mutableDateTime7.minuteOfDay();
//        long long20 = property19.remainder();
//        java.lang.String str21 = property19.getAsShortText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property19.getFieldType();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "millisOfDay" + "'", str14.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 21057734 + "'", int16 == 21057734);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 35734L + "'", long20 == 35734L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "350" + "'", str21.equals("350"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.String str2 = dateTimeFormatter0.print(10L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31T16:00:00.010-08:00" + "'", str2.equals("1969-12-31T16:00:00.010-08:00"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property9 = dateTime8.hourOfDay();
        try {
            org.joda.time.DateTime dateTime11 = property9.setCopy("monthOfYear");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"monthOfYear\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("ISOChronology[America/Los_Angeles]", "2019-06-12T12:51:26.242Z");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
//        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
//        boolean boolean3 = mutableDateTime1.isBeforeNow();
//        int int4 = mutableDateTime1.getSecondOfDay();
//        mutableDateTime1.setHourOfDay(20);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(mutableDateTime1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 21118 + "'", int4 == 21118);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket(42478309116L, (org.joda.time.Chronology) iSOChronology2, locale4);
        java.lang.Object obj6 = dateTimeParserBucket5.saveState();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(obj6);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now();
//        mutableDateTime3.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime8 = property6.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property6.roundHalfFloor();
//        org.joda.time.MutableDateTime mutableDateTime10 = property6.roundHalfCeiling();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        org.joda.time.Chronology chronology14 = buddhistChronology11.withZone(dateTimeZone12);
//        java.lang.String str15 = dateTimeZone12.getID();
//        org.joda.time.DateTime dateTime16 = mutableDateTime10.toDateTime(dateTimeZone12);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now();
//        mutableDateTime18.addMinutes((-1));
//        java.lang.String str21 = dateTimeFormatter17.print((org.joda.time.ReadableInstant) mutableDateTime18);
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime18.era();
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.ReadableDateTime) dateTime16, (org.joda.time.ReadableDateTime) mutableDateTime18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "America/Los_Angeles" + "'", str15.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "20190612" + "'", str21.equals("20190612"));
//        org.junit.Assert.assertNotNull(property22);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.Chronology chronology6 = dateTime1.getChronology();
        org.joda.time.DateTime dateTime8 = dateTime1.withYear(0);
        java.util.GregorianCalendar gregorianCalendar9 = dateTime8.toGregorianCalendar();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 100, 21035312);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2103531200 + "'", int2 == 2103531200);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.set((int) '4');
        java.lang.String str6 = property3.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property3.getFieldType();
        org.joda.time.MutableDateTime mutableDateTime8 = property3.roundCeiling();
        java.lang.String str9 = property3.getName();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "millisOfDay" + "'", str6.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "millisOfDay" + "'", str9.equals("millisOfDay"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        int int18 = offsetDateTimeField14.get((long) 0);
        long long21 = offsetDateTimeField14.add(0L, (long) 8);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField14.getAsText(138, locale23);
        try {
            long long27 = offsetDateTimeField14.set((long) 21029837, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5 for millisOfDay must be in the range [53,64]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 64 + "'", int18 == 64);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 20991600000L + "'", long21 == 20991600000L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "138" + "'", str24.equals("138"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("September", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: September");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2019-06-12T12:51:28.729Z", "", (int) (byte) 1, 0);
        long long6 = fixedDateTimeZone4.previousTransition((long) 8);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
        mutableDateTime7.setDate((org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.monthOfYear();
        mutableDateTime8.setRounding(dateTimeField12);
        mutableDateTime8.add((long) (short) -1);
        org.joda.time.DateTime dateTime16 = mutableDateTime8.toDateTime();
        org.joda.time.DateTime dateTime18 = dateTime16.withMillisOfSecond((int) '#');
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
        mutableDateTime19.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.millisOfDay();
        mutableDateTime19.setHourOfDay(0);
        mutableDateTime19.setMillis(0L);
        boolean boolean27 = dateTime16.isBefore((org.joda.time.ReadableInstant) mutableDateTime19);
        try {
            org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime19, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 8L + "'", long6 == 8L);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        java.util.Locale locale10 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology9, locale10, (java.lang.Integer) 0);
        try {
            org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((int) (short) 100, 0, 21042164, 1969, 21085980, 0, (int) (short) 100, (org.joda.time.Chronology) iSOChronology9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2019-06-12T12:51:28.729Z", "", (int) (byte) 1, 0);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '2019-06-12T12:51:28.729Z' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology2, locale3, (java.lang.Integer) 0);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 1000);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeParserBucket5.getZone();
        long long11 = dateTimeParserBucket5.computeMillis(true, "2019-05-01T00:00:00.000-07:00");
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readableDuration14);
        org.joda.time.DateTime dateTime17 = dateTime13.withDayOfYear((int) ' ');
        org.joda.time.Chronology chronology18 = dateTime13.getChronology();
        boolean boolean19 = dateTimeParserBucket5.restoreState((java.lang.Object) dateTime13);
        org.joda.time.DateTime dateTime21 = dateTime13.minusHours(10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-990L) + "'", long11 == (-990L));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getWeekyear();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        boolean boolean5 = dateTime1.isEqual((org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        mutableDateTime4.setZoneRetainFields(dateTimeZone6);
        java.lang.Class<?> wildcardClass9 = dateTimeZone6.getClass();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear(21041450);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21041450 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        mutableDateTime0.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime6 = property3.roundHalfFloor();
//        org.joda.time.MutableDateTime mutableDateTime7 = property3.roundHalfCeiling();
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
//        mutableDateTime8.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime13 = property11.set((int) '4');
//        java.lang.String str14 = property11.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property11.getFieldType();
//        int int16 = mutableDateTime7.get(dateTimeFieldType15);
//        mutableDateTime7.setSecondOfMinute((int) '#');
//        org.joda.time.MutableDateTime.Property property19 = mutableDateTime7.minuteOfDay();
//        long long20 = property19.remainder();
//        org.joda.time.Interval interval21 = property19.toInterval();
//        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval21);
//        org.joda.time.ReadableInterval readableInterval23 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval21);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "millisOfDay" + "'", str14.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 21061644 + "'", int16 == 21061644);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 35644L + "'", long20 == 35644L);
//        org.junit.Assert.assertNotNull(interval21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(readableInterval23);
//    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadableDuration readableDuration2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
//        int int4 = dateTime3.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime3.withYear((int) (short) -1);
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime3.withDate(8, 21057734, 21061326);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21057734 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.set((int) '4');
        java.lang.String str6 = property3.getName();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property3.getAsShortText(locale7);
        int int9 = property3.getMinimumValue();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "millisOfDay" + "'", str6.equals("millisOfDay"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52" + "'", str8.equals("52"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        int int17 = offsetDateTimeField14.getLeapAmount((-3124138021965L));
        long long19 = offsetDateTimeField14.roundHalfCeiling((long) (short) 0);
        long long21 = offsetDateTimeField14.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800000L + "'", long19 == 28800000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800000L + "'", long21 == 28800000L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology3, locale4, (java.lang.Integer) 0);
        boolean boolean8 = dateTimeParserBucket6.restoreState((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology11, locale12, (java.lang.Integer) 0);
        dateTimeParserBucket14.setOffset((java.lang.Integer) 1000);
        org.joda.time.DateTimeZone dateTimeZone17 = dateTimeParserBucket14.getZone();
        dateTimeParserBucket6.setZone(dateTimeZone17);
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime(0L, dateTimeZone17);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime21 = mutableDateTime19.toDateTime((org.joda.time.Chronology) gJChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.plusMonths((int) (byte) -1);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfYear();
        org.joda.time.DateTime dateTime7 = property6.withMinimumValue();
        org.joda.time.DateTime.Property property8 = dateTime7.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        java.lang.String str4 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        mutableDateTime6.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
        java.lang.String str12 = property9.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipDateTimeField16.getAsText((long) 1, locale18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = skipDateTimeField16.getAsText((long) (short) 0, locale21);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "December" + "'", str19.equals("December"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "December" + "'", str22.equals("December"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = julianChronology2.seconds();
        int int4 = julianChronology2.getMinimumDaysInFirstWeek();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology2, locale5, (java.lang.Integer) 0);
        org.joda.time.DateTimeField dateTimeField8 = julianChronology2.hourOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        try {
            int[] intArray11 = julianChronology2.get(readablePeriod9, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        int int18 = offsetDateTimeField14.get((long) 0);
        boolean boolean19 = offsetDateTimeField14.isLenient();
        try {
            long long22 = offsetDateTimeField14.set((long) 21088, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for millisOfDay must be in the range [53,64]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 64 + "'", int18 == 64);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology3 = julianChronology0.withZone(dateTimeZone1);
        org.joda.time.DurationField durationField4 = julianChronology0.months();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.add((long) (short) -1);
        org.joda.time.DateTime dateTime9 = mutableDateTime1.toDateTime();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withFields(readablePartial10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.withZoneRetainFields(dateTimeZone14);
        int int16 = dateTime13.getHourOfDay();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.yearOfEra();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.dayOfWeek();
//        java.lang.String str17 = iSOChronology15.toString();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
//        mutableDateTime19.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime24 = property22.set((int) '4');
//        java.lang.String str25 = property22.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType26, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField18);
//        java.lang.String str31 = skipDateTimeField29.getAsShortText((long) (byte) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, (org.joda.time.DateTimeField) skipDateTimeField29);
//        org.joda.time.DurationField durationField33 = skipDateTimeField29.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = skipDateTimeField29.getType();
//        int int36 = skipDateTimeField29.getLeapAmount((long) 1439);
//        boolean boolean37 = skipDateTimeField29.isLenient();
//        java.util.Locale locale39 = null;
//        try {
//            java.lang.String str40 = skipDateTimeField29.getAsShortText(21036537, locale39);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 21036537");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "millisOfDay" + "'", str25.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Dec" + "'", str31.equals("Dec"));
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        mutableDateTime9.addSeconds(100);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        mutableDateTime9.add(readablePeriod14);
//        try {
//            mutableDateTime9.setSecondOfMinute((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadableDuration readableDuration2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
//        int int4 = dateTime3.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime3.withYear((int) (short) -1);
//        org.joda.time.DateMidnight dateMidnight7 = dateTime3.toDateMidnight();
//        org.joda.time.DateTime dateTime9 = dateTime3.minusMillis(5);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadableDuration readableDuration2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
//        int int4 = dateTime3.getHourOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime3.plus((long) (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 1, dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime5.toDateTime(dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readableDuration14);
        org.joda.time.DateTime dateTime17 = dateTime13.withDayOfYear((int) ' ');
        org.joda.time.Chronology chronology18 = dateTime13.getChronology();
        org.joda.time.DateTime dateTime20 = dateTime13.withYear(0);
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime10, (org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime10.withMillisOfDay(163);
        int int25 = dateTime24.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        java.lang.Appendable appendable1 = null;
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.MutableDateTime mutableDateTime3 = instant2.toMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime4 = mutableDateTime3.copy();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) mutableDateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((int) (short) 0);
        try {
            org.joda.time.DateTime dateTime10 = property6.setCopy(21142);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21142 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = mutableDateTime1.toDateTime(dateTimeZone7);
        int int9 = mutableDateTime1.getEra();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        mutableDateTime0.setHourOfDay(0);
        mutableDateTime0.setMillis(0L);
        mutableDateTime0.setMillisOfDay(21042164);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime4 = mutableDateTime0.copy();
        mutableDateTime0.setMillisOfSecond(0);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime0.year();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        try {
            org.joda.time.DateTime dateTime5 = dateTime3.withEra(53);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        java.lang.String str3 = iSOChronology1.toString();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
//        mutableDateTime5.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
//        java.lang.String str11 = property8.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
//        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
//        int int17 = offsetDateTimeField14.getLeapAmount((-3124138021965L));
//        long long19 = offsetDateTimeField14.roundHalfCeiling((long) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
//        org.joda.time.MutableDateTime mutableDateTime22 = org.joda.time.MutableDateTime.now();
//        mutableDateTime22.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property25 = mutableDateTime22.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime27 = property25.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime29 = property25.add((int) ' ');
//        int int30 = mutableDateTime29.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, (org.joda.time.ReadableInstant) mutableDateTime29);
//        org.joda.time.DateTimeField dateTimeField32 = gJChronology31.yearOfEra();
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.dayOfWeek();
//        java.lang.String str37 = iSOChronology35.toString();
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology35.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
//        mutableDateTime39.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property42 = mutableDateTime39.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime44 = property42.set((int) '4');
//        java.lang.String str45 = property42.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property42.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, dateTimeFieldType46, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField49 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology33, dateTimeField38);
//        java.lang.String str51 = skipDateTimeField49.getAsShortText((long) (byte) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology31, (org.joda.time.DateTimeField) skipDateTimeField49);
//        long long55 = skipUndoDateTimeField52.set(35530L, 1);
//        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology57 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone56);
//        org.joda.time.DateTimeField dateTimeField58 = iSOChronology57.dayOfWeek();
//        java.lang.String str59 = iSOChronology57.toString();
//        org.joda.time.DateTimeField dateTimeField60 = iSOChronology57.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime61 = org.joda.time.MutableDateTime.now();
//        mutableDateTime61.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property64 = mutableDateTime61.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime66 = property64.set((int) '4');
//        java.lang.String str67 = property64.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType68 = property64.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, dateTimeFieldType68, (int) '4');
//        org.joda.time.DurationField durationField71 = offsetDateTimeField70.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = offsetDateTimeField70.getType();
//        int int74 = offsetDateTimeField70.get((long) 0);
//        org.joda.time.DateTimeZone dateTimeZone75 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime(dateTimeZone75);
//        org.joda.time.ReadableDuration readableDuration77 = null;
//        org.joda.time.DateTime dateTime78 = dateTime76.plus(readableDuration77);
//        org.joda.time.DateTime dateTime80 = dateTime76.withDayOfYear((int) ' ');
//        org.joda.time.Chronology chronology81 = dateTime76.getChronology();
//        org.joda.time.DateTime dateTime83 = dateTime76.withHourOfDay((int) (byte) 10);
//        org.joda.time.LocalTime localTime84 = dateTime83.toLocalTime();
//        int[] intArray86 = null;
//        int[] intArray88 = offsetDateTimeField70.addWrapPartial((org.joda.time.ReadablePartial) localTime84, (int) (short) 100, intArray86, 0);
//        int[] intArray95 = new int[] { 0, 'a', (byte) 10, 10, 138, (byte) 10 };
//        int int96 = skipUndoDateTimeField52.getMinimumValue((org.joda.time.ReadablePartial) localTime84, intArray95);
//        int int97 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localTime84);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800000L + "'", long19 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(julianChronology21);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 163 + "'", int30 == 163);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str37.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(mutableDateTime44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "millisOfDay" + "'", str45.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Dec" + "'", str51.equals("Dec"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-28857564470L) + "'", long55 == (-28857564470L));
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertNotNull(iSOChronology57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str59.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(mutableDateTime61);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertNotNull(mutableDateTime66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "millisOfDay" + "'", str67.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType68);
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 64 + "'", int74 == 64);
//        org.junit.Assert.assertNotNull(dateTimeZone75);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertNotNull(chronology81);
//        org.junit.Assert.assertNotNull(dateTime83);
//        org.junit.Assert.assertNotNull(localTime84);
//        org.junit.Assert.assertNull(intArray88);
//        org.junit.Assert.assertNotNull(intArray95);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1 + "'", int96 == 1);
//        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 64 + "'", int97 == 64);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        int int15 = offsetDateTimeField14.getOffset();
        long long18 = offsetDateTimeField14.add((long) 21042164, 0);
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime20 = org.joda.time.MutableDateTime.now();
        mutableDateTime19.setDate((org.joda.time.ReadableInstant) mutableDateTime20);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.monthOfYear();
        mutableDateTime20.setRounding(dateTimeField24);
        mutableDateTime20.add((long) (short) -1);
        org.joda.time.DateTime dateTime28 = mutableDateTime20.toDateTime();
        org.joda.time.ReadablePartial readablePartial29 = null;
        org.joda.time.DateTime dateTime30 = dateTime28.withFields(readablePartial29);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = dateTime28.toDateTime(dateTimeZone31);
        org.joda.time.LocalDate localDate33 = dateTime28.toLocalDate();
        int[] intArray35 = null;
        java.util.Locale locale37 = null;
        try {
            int[] intArray38 = offsetDateTimeField14.set((org.joda.time.ReadablePartial) localDate33, (int) (short) 0, intArray35, "2019-06-12T05:51:26.225-07:00", locale37);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T05:51:26.225-07:00\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 21042164L + "'", long18 == 21042164L);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(21031798);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfWeek((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadableDuration readableDuration2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        boolean boolean5 = dateTime1.isEqual((org.joda.time.ReadableInstant) mutableDateTime4);
//        int int6 = mutableDateTime4.getDayOfMonth();
//        mutableDateTime4.setDayOfMonth(9);
//        boolean boolean9 = mutableDateTime4.isBeforeNow();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        int int18 = offsetDateTimeField14.get((long) 0);
        boolean boolean19 = offsetDateTimeField14.isLenient();
        int int21 = offsetDateTimeField14.getLeapAmount(1303L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 64 + "'", int18 == 64);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = julianChronology4.seconds();
        int int6 = julianChronology4.getMinimumDaysInFirstWeek();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology4, locale7, (java.lang.Integer) 0);
        org.joda.time.DateTimeField dateTimeField10 = julianChronology4.hourOfDay();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology4.yearOfEra();
        try {
            org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeZone0, (org.joda.time.Chronology) julianChronology4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.CachedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.yearOfEra();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.dayOfWeek();
//        java.lang.String str17 = iSOChronology15.toString();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
//        mutableDateTime19.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime24 = property22.set((int) '4');
//        java.lang.String str25 = property22.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType26, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField18);
//        java.lang.String str31 = skipDateTimeField29.getAsShortText((long) (byte) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, (org.joda.time.DateTimeField) skipDateTimeField29);
//        org.joda.time.DurationField durationField33 = skipDateTimeField29.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = skipDateTimeField29.getType();
//        org.joda.time.DurationField durationField35 = skipDateTimeField29.getLeapDurationField();
//        int int36 = skipDateTimeField29.getMaximumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "millisOfDay" + "'", str25.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Dec" + "'", str31.equals("Dec"));
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 12 + "'", int36 == 12);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.Chronology chronology6 = dateTime1.getChronology();
        org.joda.time.DateTime dateTime8 = dateTime1.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime1.toDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime1.minusHours(0);
        org.joda.time.DateTime dateTime13 = dateTime1.withDayOfYear(8);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(21088);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.append(dateTimePrinter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        int int15 = offsetDateTimeField14.getOffset();
        long long18 = offsetDateTimeField14.add((long) 21042164, 0);
        long long20 = offsetDateTimeField14.roundFloor((long) 21042530);
        int int22 = offsetDateTimeField14.getMinimumValue((long) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 21042164L + "'", long18 == 21042164L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2649600000L) + "'", long20 == (-2649600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 53 + "'", int22 == 53);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("Jun");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Jun\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime0.toMutableDateTime(dateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology7);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        long long17 = offsetDateTimeField14.roundHalfFloor(1303L);
        int int19 = offsetDateTimeField14.getMinimumValue((long) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 53 + "'", int19 == 53);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.seconds();
        long long5 = durationField2.subtract(42478309116L, 4);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 42478305116L + "'", long5 == 42478305116L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.weekyear();
        org.joda.time.DurationField durationField3 = gJChronology0.eras();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        int int4 = property3.getMinimumValue();
        java.util.Locale locale5 = null;
        int int6 = property3.getMaximumShortTextLength(locale5);
        boolean boolean7 = property3.isLeap();
        int int8 = property3.getMaximumValue();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 86399999 + "'", int8 == 86399999);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.addCutover(21037186, '#', 21035312, 53, 31, false, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekyearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        int int15 = offsetDateTimeField14.getOffset();
        long long18 = offsetDateTimeField14.add((long) 21042164, 0);
        long long20 = offsetDateTimeField14.roundFloor((long) 21042530);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology22.dayOfWeek();
        java.lang.String str24 = iSOChronology22.toString();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime26 = org.joda.time.MutableDateTime.now();
        mutableDateTime26.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime26.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime31 = property29.set((int) '4');
        java.lang.String str32 = property29.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property29.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, dateTimeFieldType33, (int) '4');
        int int37 = offsetDateTimeField35.get(0L);
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.dayOfWeek();
        java.lang.String str42 = iSOChronology40.toString();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology40.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime44 = org.joda.time.MutableDateTime.now();
        mutableDateTime44.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property47 = mutableDateTime44.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime49 = property47.set((int) '4');
        java.lang.String str50 = property47.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property47.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, dateTimeFieldType51, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField54 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology38, dateTimeField43);
        org.joda.time.MutableDateTime mutableDateTime55 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime56 = org.joda.time.MutableDateTime.now();
        mutableDateTime55.setDate((org.joda.time.ReadableInstant) mutableDateTime56);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.monthOfYear();
        mutableDateTime56.setRounding(dateTimeField60);
        mutableDateTime56.add((long) (short) -1);
        org.joda.time.DateTime dateTime64 = mutableDateTime56.toDateTime();
        org.joda.time.ReadablePartial readablePartial65 = null;
        org.joda.time.DateTime dateTime66 = dateTime64.withFields(readablePartial65);
        org.joda.time.DateTimeZone dateTimeZone67 = null;
        org.joda.time.DateTime dateTime68 = dateTime64.toDateTime(dateTimeZone67);
        org.joda.time.LocalDate localDate69 = dateTime64.toLocalDate();
        int[] intArray72 = new int[] { 21041450, 0 };
        int int73 = skipDateTimeField54.getMaximumValue((org.joda.time.ReadablePartial) localDate69, intArray72);
        int int74 = offsetDateTimeField35.getMaximumValue((org.joda.time.ReadablePartial) localDate69);
        int int75 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDate69);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 21042164L + "'", long18 == 21042164L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2649600000L) + "'", long20 == (-2649600000L));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str24.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "millisOfDay" + "'", str32.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 64 + "'", int37 == 64);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str42.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(mutableDateTime44);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "millisOfDay" + "'", str50.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(mutableDateTime55);
        org.junit.Assert.assertNotNull(mutableDateTime56);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(localDate69);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 12 + "'", int73 == 12);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 64 + "'", int74 == 64);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 64 + "'", int75 == 64);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("Jan", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Jan\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        java.io.Writer writer1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.dayOfWeek();
//        java.lang.String str5 = iSOChronology3.toString();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
//        mutableDateTime7.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime7.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime12 = property10.set((int) '4');
//        java.lang.String str13 = property10.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property10.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType14, (int) '4');
//        org.joda.time.DurationField durationField17 = offsetDateTimeField16.getRangeDurationField();
//        long long19 = offsetDateTimeField16.roundCeiling(35L);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.plus(readableDuration22);
//        int int24 = dateTime23.getHourOfDay();
//        org.joda.time.DateTime dateTime26 = dateTime23.withYear((int) (short) -1);
//        org.joda.time.LocalDate localDate27 = dateTime26.toLocalDate();
//        int int28 = offsetDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDate27);
//        try {
//            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str5.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "millisOfDay" + "'", str13.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800000L + "'", long19 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 53 + "'", int28 == 53);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hour();
        boolean boolean2 = dateTimeFormatter1.isOffsetParsed();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("2019-06-12T12:52:25.262Z", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-12T12:52:25.262Z\" is malformed at \"19-06-12T12:52:25.262Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear(8);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = dateTimeZone0.getID();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadableDuration readableDuration2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
//        boolean boolean5 = dateTime1.isEqual((org.joda.time.ReadableInstant) mutableDateTime4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        mutableDateTime4.setZoneRetainFields(dateTimeZone6);
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.dayOfWeek();
//        java.lang.String str13 = iSOChronology11.toString();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now();
//        mutableDateTime15.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime15.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime20 = property18.set((int) '4');
//        java.lang.String str21 = property18.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property18.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType22, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField14);
//        java.lang.String str27 = skipDateTimeField25.getAsShortText((long) (byte) 100);
//        java.util.Locale locale28 = null;
//        int int29 = skipDateTimeField25.getMaximumTextLength(locale28);
//        int int31 = skipDateTimeField25.get((long) 5);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
//        org.joda.time.ReadableDuration readableDuration34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime33.plus(readableDuration34);
//        int int36 = dateTime35.getHourOfDay();
//        org.joda.time.DateTime dateTime38 = dateTime35.withYear((int) (short) -1);
//        org.joda.time.LocalDate localDate39 = dateTime38.toLocalDate();
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
//        org.joda.time.DurationField durationField43 = julianChronology42.seconds();
//        int int44 = julianChronology42.getMinimumDaysInFirstWeek();
//        java.util.Locale locale45 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket47 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology42, locale45, (java.lang.Integer) 0);
//        org.joda.time.MutableDateTime mutableDateTime48 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime mutableDateTime49 = org.joda.time.MutableDateTime.now();
//        mutableDateTime48.setDate((org.joda.time.ReadableInstant) mutableDateTime49);
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DateTimeField dateTimeField53 = iSOChronology52.monthOfYear();
//        mutableDateTime49.setRounding(dateTimeField53);
//        mutableDateTime49.add((long) (short) -1);
//        org.joda.time.DateTime dateTime57 = mutableDateTime49.toDateTime();
//        org.joda.time.ReadablePartial readablePartial58 = null;
//        org.joda.time.DateTime dateTime59 = dateTime57.withFields(readablePartial58);
//        org.joda.time.DateTimeZone dateTimeZone60 = null;
//        org.joda.time.DateTime dateTime61 = dateTime57.toDateTime(dateTimeZone60);
//        org.joda.time.LocalDate localDate62 = dateTime57.toLocalDate();
//        int[] intArray64 = julianChronology42.get((org.joda.time.ReadablePartial) localDate62, 0L);
//        int int65 = skipDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) localDate39, intArray64);
//        org.joda.time.DateTimeZone dateTimeZone67 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology68 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone67);
//        java.util.Locale locale69 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket71 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology68, locale69, (java.lang.Integer) 0);
//        boolean boolean73 = dateTimeParserBucket71.restoreState((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone75 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology76 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone75);
//        java.util.Locale locale77 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket79 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology76, locale77, (java.lang.Integer) 0);
//        dateTimeParserBucket79.setOffset((java.lang.Integer) 1000);
//        org.joda.time.DateTimeZone dateTimeZone82 = dateTimeParserBucket79.getZone();
//        dateTimeParserBucket71.setZone(dateTimeZone82);
//        org.joda.time.MutableDateTime mutableDateTime84 = org.joda.time.MutableDateTime.now();
//        mutableDateTime84.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property87 = mutableDateTime84.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime89 = property87.set((int) '4');
//        java.lang.String str90 = property87.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType91 = property87.getFieldType();
//        dateTimeParserBucket71.saveField(dateTimeFieldType91, 0);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField95 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField25, dateTimeFieldType91, 21036537);
//        mutableDateTime4.set(dateTimeFieldType91, 21041450);
//        mutableDateTime4.setMillis(20991600000L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str13.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "millisOfDay" + "'", str21.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Dec" + "'", str27.equals("Dec"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 12 + "'", int31 == 12);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(julianChronology42);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
//        org.junit.Assert.assertNotNull(mutableDateTime48);
//        org.junit.Assert.assertNotNull(mutableDateTime49);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(iSOChronology52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 12 + "'", int65 == 12);
//        org.junit.Assert.assertNotNull(dateTimeZone67);
//        org.junit.Assert.assertNotNull(iSOChronology68);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone75);
//        org.junit.Assert.assertNotNull(iSOChronology76);
//        org.junit.Assert.assertNotNull(dateTimeZone82);
//        org.junit.Assert.assertNotNull(mutableDateTime84);
//        org.junit.Assert.assertNotNull(property87);
//        org.junit.Assert.assertNotNull(mutableDateTime89);
//        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "millisOfDay" + "'", str90.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType91);
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.yearOfEra();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.dayOfWeek();
//        java.lang.String str17 = iSOChronology15.toString();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
//        mutableDateTime19.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime24 = property22.set((int) '4');
//        java.lang.String str25 = property22.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType26, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField18);
//        java.lang.String str31 = skipDateTimeField29.getAsShortText((long) (byte) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, (org.joda.time.DateTimeField) skipDateTimeField29);
//        org.joda.time.DurationField durationField33 = skipDateTimeField29.getDurationField();
//        org.joda.time.DurationFieldType durationFieldType34 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField36 = new org.joda.time.field.ScaledDurationField(durationField33, durationFieldType34, 21038483);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "millisOfDay" + "'", str25.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Dec" + "'", str31.equals("Dec"));
//        org.junit.Assert.assertNotNull(durationField33);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = julianChronology2.seconds();
        int int4 = julianChronology2.getMinimumDaysInFirstWeek();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology2, locale5, (java.lang.Integer) 0);
        long long8 = dateTimeParserBucket7.computeMillis();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28800000L + "'", long8 == 28800000L);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
//        mutableDateTime1.addMinutes((-1));
//        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime1);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime1.era();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.dayOfYear();
//        mutableDateTime1.addWeeks(21041450);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(mutableDateTime1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "20190612" + "'", str4.equals("20190612"));
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.add((long) (short) -1);
        org.joda.time.DateTime dateTime9 = mutableDateTime1.toDateTime();
        try {
            mutableDateTime1.setDateTime(31, 2103531200, 138, 1000, (int) (short) 100, 24, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.Chronology chronology12 = gJChronology11.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology11);
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology11.yearOfCentury();
//        int int15 = gJChronology11.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.centuryOfEra();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField20);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
//        java.util.Locale locale25 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology24, locale25, (java.lang.Integer) 0);
//        dateTimeParserBucket27.setOffset((java.lang.Integer) 1000);
//        org.joda.time.DateTimeZone dateTimeZone30 = dateTimeParserBucket27.getZone();
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = dateTimeZone30.getName(0L, locale32);
//        java.lang.String str34 = dateTimeZone30.getID();
//        org.joda.time.Chronology chronology35 = gJChronology11.withZone(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(iSOChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Pacific Standard Time" + "'", str33.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "America/Los_Angeles" + "'", str34.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(chronology35);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendLiteral("2019-06-12T05:50:32.113-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendMillisOfSecond(64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        int int18 = offsetDateTimeField14.get((long) 0);
        long long21 = offsetDateTimeField14.add(0L, (long) 8);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField14.getAsText(138, locale23);
        long long27 = offsetDateTimeField14.add((long) 52, (long) 1969);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 64 + "'", int18 == 64);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 20991600000L + "'", long21 == 20991600000L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "138" + "'", str24.equals("138"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 5178038400052L + "'", long27 == 5178038400052L);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
//        java.lang.String str4 = iSOChronology2.toString();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
//        mutableDateTime6.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
//        java.lang.String str12 = property9.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
//        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now();
//        mutableDateTime17.setDate((org.joda.time.ReadableInstant) mutableDateTime18);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.monthOfYear();
//        mutableDateTime18.setRounding(dateTimeField22);
//        mutableDateTime18.add((long) (short) -1);
//        org.joda.time.DateTime dateTime26 = mutableDateTime18.toDateTime();
//        org.joda.time.ReadablePartial readablePartial27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime26.withFields(readablePartial27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime26.toDateTime(dateTimeZone29);
//        org.joda.time.LocalDate localDate31 = dateTime26.toLocalDate();
//        int[] intArray34 = new int[] { 21041450, 0 };
//        int int35 = skipDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) localDate31, intArray34);
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
//        org.joda.time.MutableDateTime mutableDateTime38 = org.joda.time.MutableDateTime.now();
//        mutableDateTime38.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property41 = mutableDateTime38.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime43 = property41.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime45 = property41.add((int) ' ');
//        int int46 = mutableDateTime45.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone36, (org.joda.time.ReadableInstant) mutableDateTime45);
//        org.joda.time.DateTimeField dateTimeField48 = gJChronology47.yearOfEra();
//        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone50);
//        org.joda.time.DateTimeField dateTimeField52 = iSOChronology51.dayOfWeek();
//        java.lang.String str53 = iSOChronology51.toString();
//        org.joda.time.DateTimeField dateTimeField54 = iSOChronology51.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime55 = org.joda.time.MutableDateTime.now();
//        mutableDateTime55.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property58 = mutableDateTime55.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime60 = property58.set((int) '4');
//        java.lang.String str61 = property58.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property58.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, dateTimeFieldType62, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField65 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology49, dateTimeField54);
//        java.lang.String str67 = skipDateTimeField65.getAsShortText((long) (byte) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField68 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology47, (org.joda.time.DateTimeField) skipDateTimeField65);
//        long long71 = skipUndoDateTimeField68.set(35530L, 1);
//        int int73 = skipUndoDateTimeField68.get((long) 1969);
//        org.joda.time.DateTimeZone dateTimeZone74 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime75 = new org.joda.time.DateTime(dateTimeZone74);
//        org.joda.time.ReadableDuration readableDuration76 = null;
//        org.joda.time.DateTime dateTime77 = dateTime75.plus(readableDuration76);
//        int int78 = dateTime77.getHourOfDay();
//        org.joda.time.DateTime dateTime80 = dateTime77.withYear((int) (short) -1);
//        org.joda.time.LocalDate localDate81 = dateTime80.toLocalDate();
//        int int82 = skipUndoDateTimeField68.getMaximumValue((org.joda.time.ReadablePartial) localDate81);
//        java.util.Locale locale83 = null;
//        java.lang.String str84 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDate81, locale83);
//        int int85 = skipDateTimeField16.getMinimumValue();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(intArray34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 12 + "'", int35 == 12);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(julianChronology37);
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(mutableDateTime43);
//        org.junit.Assert.assertNotNull(mutableDateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 163 + "'", int46 == 163);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(gJChronology49);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str53.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(mutableDateTime55);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(mutableDateTime60);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "millisOfDay" + "'", str61.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Dec" + "'", str67.equals("Dec"));
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-28857564470L) + "'", long71 == (-28857564470L));
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 12 + "'", int73 == 12);
//        org.junit.Assert.assertNotNull(dateTimeZone74);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 5 + "'", int78 == 5);
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertNotNull(localDate81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 12 + "'", int82 == 12);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "Jun" + "'", str84.equals("Jun"));
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
//    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadableDuration readableDuration2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
//        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime1.withZone(dateTimeZone6);
//        boolean boolean8 = dateTime7.isBeforeNow();
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime7.plus(readableDuration9);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        java.lang.String str4 = iSOChronology2.toString();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((-3124138021965L), (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = julianChronology7.seconds();
        int int9 = julianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology7.monthOfYear();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology2, dateTimeField10);
        try {
            long long14 = skipUndoDateTimeField11.set(0L, "2019-06-12T05:50:32.113-07:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T05:50:32.113-07:00\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = julianChronology4.seconds();
        int int6 = julianChronology4.getMinimumDaysInFirstWeek();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology4, locale7, (java.lang.Integer) 0);
        org.joda.time.DateTimeField dateTimeField10 = julianChronology4.hourOfDay();
        long long14 = julianChronology4.add((long) (short) -1, (long) 163, 8);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology4);
        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths((int) '#');
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.plus(readableDuration20);
        org.joda.time.DateTime dateTime23 = dateTime19.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
        try {
            org.joda.time.chrono.LimitChronology limitChronology25 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.ReadableDateTime) dateTime15, (org.joda.time.ReadableDateTime) dateTime23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1303L + "'", long14 == 1303L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(21031798);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("December");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: c");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        mutableDateTime0.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.minuteOfDay();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsText(locale5);
//        int int7 = property4.getMaximumValueOverall();
//        org.joda.time.MutableDateTime mutableDateTime8 = property4.roundHalfCeiling();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime10.plus(readableDuration11);
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
//        boolean boolean14 = dateTime10.isEqual((org.joda.time.ReadableInstant) mutableDateTime13);
//        mutableDateTime8.setTime((org.joda.time.ReadableInstant) dateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "351" + "'", str6.equals("351"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1439 + "'", int7 == 1439);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("2019-06-12T12:51:37.439Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-12T12:51:37.439Z\" is malformed at \"19-06-12T12:51:37.439Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.clockhourOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("2019-06-12T12:51:28.729Z", "", (int) (byte) 1, 0);
//        java.lang.String str8 = fixedDateTimeZone6.getNameKey(28800000L);
//        boolean boolean9 = buddhistChronology0.equals((java.lang.Object) fixedDateTimeZone6);
//        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now();
//        mutableDateTime10.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime10.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime15 = property13.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime17 = property13.add((int) ' ');
//        int int18 = mutableDateTime17.getDayOfYear();
//        java.lang.String str19 = mutableDateTime17.toString();
//        org.joda.time.MutableDateTime.Property property20 = mutableDateTime17.weekOfWeekyear();
//        boolean boolean21 = buddhistChronology0.equals((java.lang.Object) mutableDateTime17);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 163 + "'", int18 == 163);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019-06-12T05:51:11.139-07:00" + "'", str19.equals("2019-06-12T05:51:11.139-07:00"));
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(21031798);
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMinuteOfDay(64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfYear((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = mutableDateTime0.getZone();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendLiteral("2019-06-12T05:50:32.113-07:00");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField9 = julianChronology8.seconds();
        int int10 = julianChronology8.getMinimumDaysInFirstWeek();
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology8, locale11, (java.lang.Integer) 0);
        org.joda.time.DateTimeField dateTimeField14 = julianChronology8.hourOfDay();
        try {
            org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeFormatterBuilder5, (org.joda.time.Chronology) julianChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
//        java.lang.String str3 = iSOChronology1.toString();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
//        mutableDateTime5.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
//        java.lang.String str11 = property8.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
//        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
//        int int18 = offsetDateTimeField14.get((long) 0);
//        boolean boolean19 = offsetDateTimeField14.isLenient();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone20);
//        org.joda.time.MutableDateTime mutableDateTime22 = org.joda.time.MutableDateTime.now();
//        mutableDateTime22.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property25 = mutableDateTime22.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime27 = property25.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime29 = property25.add((int) ' ');
//        int int30 = mutableDateTime29.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, (org.joda.time.ReadableInstant) mutableDateTime29);
//        org.joda.time.DateTimeField dateTimeField32 = gJChronology31.yearOfEra();
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.dayOfWeek();
//        java.lang.String str37 = iSOChronology35.toString();
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology35.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
//        mutableDateTime39.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property42 = mutableDateTime39.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime44 = property42.set((int) '4');
//        java.lang.String str45 = property42.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property42.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, dateTimeFieldType46, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField49 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology33, dateTimeField38);
//        java.lang.String str51 = skipDateTimeField49.getAsShortText((long) (byte) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology31, (org.joda.time.DateTimeField) skipDateTimeField49);
//        long long55 = skipUndoDateTimeField52.set(35530L, 1);
//        int int57 = skipUndoDateTimeField52.get((long) 1969);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime(dateTimeZone58);
//        org.joda.time.ReadableDuration readableDuration60 = null;
//        org.joda.time.DateTime dateTime61 = dateTime59.plus(readableDuration60);
//        int int62 = dateTime61.getHourOfDay();
//        org.joda.time.DateTime dateTime64 = dateTime61.withYear((int) (short) -1);
//        org.joda.time.LocalDate localDate65 = dateTime64.toLocalDate();
//        int int66 = skipUndoDateTimeField52.getMaximumValue((org.joda.time.ReadablePartial) localDate65);
//        int[] intArray68 = new int[] {};
//        try {
//            int[] intArray70 = offsetDateTimeField14.set((org.joda.time.ReadablePartial) localDate65, 0, intArray68, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [53,64]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 64 + "'", int18 == 64);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(julianChronology21);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 163 + "'", int30 == 163);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str37.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(mutableDateTime44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "millisOfDay" + "'", str45.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Dec" + "'", str51.equals("Dec"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-28857564470L) + "'", long55 == (-28857564470L));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 12 + "'", int57 == 12);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 5 + "'", int62 == 5);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(localDate65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 12 + "'", int66 == 12);
//        org.junit.Assert.assertNotNull(intArray68);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        long long18 = offsetDateTimeField14.roundHalfEven((long) 1969);
        java.lang.String str19 = offsetDateTimeField14.getName();
        long long21 = offsetDateTimeField14.roundHalfEven((long) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "millisOfDay" + "'", str19.equals("millisOfDay"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800000L + "'", long21 == 28800000L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.clockhourOfDay();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.centuries();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(28739999L, (org.joda.time.Chronology) buddhistChronology1, locale5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.dayOfWeek();
        java.lang.String str10 = iSOChronology8.toString();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.monthOfYear();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology8.dayOfMonth();
        dateTimeParserBucket6.saveField(dateTimeField12, 12);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str10.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime8 = property6.addToCopy((int) (short) 0);
        org.joda.time.Chronology chronology9 = dateTime8.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        int int18 = offsetDateTimeField14.get((long) 0);
        boolean boolean19 = offsetDateTimeField14.isLenient();
        boolean boolean21 = offsetDateTimeField14.isLeap(350L);
        try {
            long long24 = offsetDateTimeField14.set((long) 21042530, 21029837);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21029837 for millisOfDay must be in the range [53,64]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 64 + "'", int18 == 64);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getWeekyear();
        mutableDateTime0.setMinuteOfDay((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        mutableDateTime4.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.add((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime10 = property7.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime11 = property7.roundHalfCeiling();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.Chronology chronology15 = buddhistChronology12.withZone(dateTimeZone13);
        java.lang.String str16 = dateTimeZone13.getID();
        org.joda.time.DateTime dateTime17 = mutableDateTime11.toDateTime(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone18 = mutableDateTime11.getZone();
        mutableDateTime0.setZone(dateTimeZone18);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "America/Los_Angeles" + "'", str16.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendCenturyOfEra(9, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendMillisOfDay(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendDayOfYear(10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendLiteral("2019-06-12T05:50:32.113-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.dayOfWeek();
        java.lang.String str17 = iSOChronology15.toString();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
        mutableDateTime19.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime24 = property22.set((int) '4');
        java.lang.String str25 = property22.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType26, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField28.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder10.appendDecimal(dateTimeFieldType29, 21037186, 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder9.appendFixedDecimal(dateTimeFieldType29, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder9.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder9.appendSecondOfDay(21031798);
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        mutableDateTime39.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property42 = mutableDateTime39.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime44 = property42.set((int) '4');
        java.lang.String str45 = property42.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property42.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder38.appendShortText(dateTimeFieldType46);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder38.appendDayOfYear(21038483);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "millisOfDay" + "'", str25.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(mutableDateTime44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "millisOfDay" + "'", str45.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        int int17 = offsetDateTimeField14.getLeapAmount((-3124138021965L));
        long long19 = offsetDateTimeField14.roundHalfCeiling((long) (short) 0);
        java.util.Locale locale20 = null;
        int int21 = offsetDateTimeField14.getMaximumShortTextLength(locale20);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.dayOfWeek();
        java.lang.String str25 = iSOChronology23.toString();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
        mutableDateTime27.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime27.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime32 = property30.set((int) '4');
        java.lang.String str33 = property30.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property30.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, dateTimeFieldType34, (int) '4');
        int int38 = offsetDateTimeField36.get(0L);
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone40);
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.dayOfWeek();
        java.lang.String str43 = iSOChronology41.toString();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology41.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime45 = org.joda.time.MutableDateTime.now();
        mutableDateTime45.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime45.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime50 = property48.set((int) '4');
        java.lang.String str51 = property48.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property48.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, dateTimeFieldType52, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField55 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology39, dateTimeField44);
        org.joda.time.MutableDateTime mutableDateTime56 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime57 = org.joda.time.MutableDateTime.now();
        mutableDateTime56.setDate((org.joda.time.ReadableInstant) mutableDateTime57);
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology60 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone59);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology60.monthOfYear();
        mutableDateTime57.setRounding(dateTimeField61);
        mutableDateTime57.add((long) (short) -1);
        org.joda.time.DateTime dateTime65 = mutableDateTime57.toDateTime();
        org.joda.time.ReadablePartial readablePartial66 = null;
        org.joda.time.DateTime dateTime67 = dateTime65.withFields(readablePartial66);
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.DateTime dateTime69 = dateTime65.toDateTime(dateTimeZone68);
        org.joda.time.LocalDate localDate70 = dateTime65.toLocalDate();
        int[] intArray73 = new int[] { 21041450, 0 };
        int int74 = skipDateTimeField55.getMaximumValue((org.joda.time.ReadablePartial) localDate70, intArray73);
        int int75 = offsetDateTimeField36.getMaximumValue((org.joda.time.ReadablePartial) localDate70);
        int[] intArray77 = null;
        java.util.Locale locale79 = null;
        try {
            int[] intArray80 = offsetDateTimeField14.set((org.joda.time.ReadablePartial) localDate70, 21118, intArray77, "millisOfDay", locale79);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"millisOfDay\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800000L + "'", long19 == 28800000L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str25.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(mutableDateTime32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "millisOfDay" + "'", str33.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 64 + "'", int38 == 64);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str43.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(mutableDateTime45);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(mutableDateTime50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "millisOfDay" + "'", str51.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(mutableDateTime56);
        org.junit.Assert.assertNotNull(mutableDateTime57);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(iSOChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(localDate70);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 12 + "'", int74 == 12);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 64 + "'", int75 == 64);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.plusMonths((int) (byte) -1);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfYear();
        org.joda.time.DateTime dateTime7 = property6.withMinimumValue();
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear(21038483);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        java.lang.String str4 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        mutableDateTime6.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
        java.lang.String str12 = property9.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        java.lang.String str18 = skipDateTimeField16.getAsShortText((long) (byte) 100);
        java.util.Locale locale19 = null;
        int int20 = skipDateTimeField16.getMaximumTextLength(locale19);
        long long22 = skipDateTimeField16.remainder(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Dec" + "'", str18.equals("Dec"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9 + "'", int20 == 9);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2649600000L + "'", long22 == 2649600000L);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 21037186);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        long long17 = offsetDateTimeField14.roundCeiling(35L);
        long long19 = offsetDateTimeField14.roundHalfFloor(21042164L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800000L + "'", long19 == 28800000L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime0.toMutableDateTime(dateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        try {
            long long15 = julianChronology7.getDateTimeMillis(1439, 6, 21042164, 21038483, 21061326, 0, 21029837);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21038483 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(julianChronology7);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime10 = dateTime8.withMillisOfSecond(4);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendCenturyOfEra(9, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendClockhourOfDay(21036537);
        dateTimeFormatterBuilder3.clear();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.dayOfWeek();
        java.lang.String str15 = iSOChronology13.toString();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now();
        mutableDateTime17.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime17.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime22 = property20.set((int) '4');
        java.lang.String str23 = property20.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, dateTimeFieldType24, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder3.appendShortText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder3.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str15.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "millisOfDay" + "'", str23.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        mutableDateTime0.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime7 = property3.add((int) ' ');
//        long long8 = property3.remainder();
//        org.joda.time.MutableDateTime mutableDateTime10 = property3.set((int) (short) 1);
//        java.lang.String str11 = mutableDateTime10.toString();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-06-12T00:00:00.001-07:00" + "'", str11.equals("2019-06-12T00:00:00.001-07:00"));
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("ISOChronology[America/Los_Angeles]", "2019-06-12T12:51:26.242Z");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.yearOfEra();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.dayOfWeek();
//        java.lang.String str17 = iSOChronology15.toString();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
//        mutableDateTime19.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime24 = property22.set((int) '4');
//        java.lang.String str25 = property22.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType26, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField18);
//        java.lang.String str31 = skipDateTimeField29.getAsShortText((long) (byte) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, (org.joda.time.DateTimeField) skipDateTimeField29);
//        boolean boolean33 = skipUndoDateTimeField32.isSupported();
//        try {
//            long long36 = skipUndoDateTimeField32.set((long) 100, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [0,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "millisOfDay" + "'", str25.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Dec" + "'", str31.equals("Dec"));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(21031798);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 1, dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime5.toDateTime(dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readableDuration14);
        org.joda.time.DateTime dateTime17 = dateTime13.withDayOfYear((int) ' ');
        org.joda.time.Chronology chronology18 = dateTime13.getChronology();
        org.joda.time.DateTime dateTime20 = dateTime13.withYear(0);
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime10, (org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime10.withMillisOfDay(163);
        org.joda.time.DateTime dateTime26 = dateTime10.withMillisOfDay(21118);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 1, dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime5.toDateTime(dateTimeZone8);
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readableDuration14);
        org.joda.time.DateTime dateTime17 = dateTime13.withDayOfYear((int) ' ');
        org.joda.time.Chronology chronology18 = dateTime13.getChronology();
        org.joda.time.DateTime dateTime20 = dateTime13.withYear(0);
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime10, (org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime10.withMillisOfDay(163);
        org.joda.time.DateTime.Property property25 = dateTime10.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        java.util.TimeZone timeZone12 = dateTimeZone0.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        mutableDateTime0.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.minuteOfDay();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsText(locale5);
//        int int7 = property4.getMaximumValueOverall();
//        org.joda.time.MutableDateTime mutableDateTime8 = property4.roundHalfCeiling();
//        org.joda.time.DateTimeField dateTimeField9 = null;
//        mutableDateTime8.setRounding(dateTimeField9);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "701" + "'", str6.equals("701"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1439 + "'", int7 == 1439);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(31, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 31");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = iSOChronology9.weeks();
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTime.Property property12 = dateTime7.era();
        org.joda.time.DateTime dateTime14 = dateTime7.plus((long) 21035312);
        org.joda.time.DateTime dateTime15 = dateTime7.toDateTime();
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds(10);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.toDateTime(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicDate();
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now();
//        mutableDateTime3.addMinutes((-1));
//        java.lang.String str6 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) mutableDateTime3);
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
//        mutableDateTime7.setDate((org.joda.time.ReadableInstant) mutableDateTime8);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.monthOfYear();
//        mutableDateTime8.setRounding(dateTimeField12);
//        mutableDateTime8.add((long) (short) -1);
//        org.joda.time.DateTime dateTime16 = mutableDateTime8.toDateTime();
//        org.joda.time.DateTime dateTime18 = dateTime16.withMillisOfSecond((int) '#');
//        mutableDateTime3.setDate((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime.Property property20 = dateTime16.millisOfDay();
//        boolean boolean21 = mutableDateTime1.isBefore((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime23 = dateTime16.plusDays((int) (short) -1);
//        long long24 = dateTime16.getMillis();
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "20190612" + "'", str6.equals("20190612"));
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1556694000000L + "'", long24 == 1556694000000L);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime4.withYearOfCentury((int) '4');
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.Chronology chronology12 = gJChronology11.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology11);
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology11.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone19 = iSOChronology17.getZone();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 1, dateTimeZone19);
//        org.joda.time.Chronology chronology21 = gJChronology11.withZone(dateTimeZone19);
//        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getChronology(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(chronology22);
//    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.yearOfEra();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.dayOfWeek();
//        java.lang.String str17 = iSOChronology15.toString();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
//        mutableDateTime19.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime24 = property22.set((int) '4');
//        java.lang.String str25 = property22.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType26, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField18);
//        java.lang.String str31 = skipDateTimeField29.getAsShortText((long) (byte) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, (org.joda.time.DateTimeField) skipDateTimeField29);
//        org.joda.time.DurationField durationField33 = skipDateTimeField29.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = skipDateTimeField29.getType();
//        int int36 = skipDateTimeField29.getLeapAmount((long) 1439);
//        long long39 = skipDateTimeField29.add(100L, (long) 21037186);
//        boolean boolean40 = skipDateTimeField29.isSupported();
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone42);
//        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.dayOfWeek();
//        java.lang.String str45 = iSOChronology43.toString();
//        org.joda.time.DateTimeField dateTimeField46 = iSOChronology43.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime47 = org.joda.time.MutableDateTime.now();
//        mutableDateTime47.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property50 = mutableDateTime47.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime52 = property50.set((int) '4');
//        java.lang.String str53 = property50.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property50.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, dateTimeFieldType54, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField57 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology41, dateTimeField46);
//        int int59 = skipDateTimeField57.get(0L);
//        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology61 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone60);
//        org.joda.time.DateTimeField dateTimeField62 = iSOChronology61.dayOfWeek();
//        java.lang.String str63 = iSOChronology61.toString();
//        org.joda.time.DateTimeField dateTimeField64 = iSOChronology61.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime65 = org.joda.time.MutableDateTime.now();
//        mutableDateTime65.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property68 = mutableDateTime65.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime70 = property68.set((int) '4');
//        java.lang.String str71 = property68.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType72 = property68.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField74 = new org.joda.time.field.OffsetDateTimeField(dateTimeField64, dateTimeFieldType72, (int) '4');
//        org.joda.time.DurationField durationField75 = offsetDateTimeField74.getRangeDurationField();
//        long long77 = offsetDateTimeField74.roundCeiling(35L);
//        org.joda.time.DateTimeZone dateTimeZone78 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime79 = new org.joda.time.DateTime(dateTimeZone78);
//        org.joda.time.ReadableDuration readableDuration80 = null;
//        org.joda.time.DateTime dateTime81 = dateTime79.plus(readableDuration80);
//        int int82 = dateTime81.getHourOfDay();
//        org.joda.time.DateTime dateTime84 = dateTime81.withYear((int) (short) -1);
//        org.joda.time.LocalDate localDate85 = dateTime84.toLocalDate();
//        int int86 = offsetDateTimeField74.getMinimumValue((org.joda.time.ReadablePartial) localDate85);
//        int int87 = skipDateTimeField57.getMinimumValue((org.joda.time.ReadablePartial) localDate85);
//        int int88 = skipDateTimeField29.getMinimumValue((org.joda.time.ReadablePartial) localDate85);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "millisOfDay" + "'", str25.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Dec" + "'", str31.equals("Dec"));
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 55322455762800100L + "'", long39 == 55322455762800100L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str45.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(mutableDateTime47);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(mutableDateTime52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "millisOfDay" + "'", str53.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 12 + "'", int59 == 12);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertNotNull(iSOChronology61);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str63.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(mutableDateTime65);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(mutableDateTime70);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "millisOfDay" + "'", str71.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType72);
//        org.junit.Assert.assertNotNull(durationField75);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 28800000L + "'", long77 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTimeZone78);
//        org.junit.Assert.assertNotNull(dateTime81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
//        org.junit.Assert.assertNotNull(dateTime84);
//        org.junit.Assert.assertNotNull(localDate85);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 53 + "'", int86 == 53);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 2019, (java.lang.Number) 2649600000L, (java.lang.Number) 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        java.lang.String str1 = instant0.toString();
//        org.joda.time.Instant instant4 = instant0.withDurationAdded((long) 'a', (int) (byte) 100);
//        org.joda.time.Instant instant5 = instant0.toInstant();
//        org.joda.time.DateTime dateTime6 = instant5.toDateTimeISO();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019-06-12T18:42:51.645Z" + "'", str1.equals("2019-06-12T18:42:51.645Z"));
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(55322455762800100L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        int int16 = offsetDateTimeField14.get(0L);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readableDuration19);
        org.joda.time.DateTime dateTime22 = dateTime18.withDayOfYear((int) ' ');
        org.joda.time.Chronology chronology23 = dateTime18.getChronology();
        org.joda.time.DateTime dateTime25 = dateTime18.withHourOfDay((int) (byte) 10);
        org.joda.time.LocalTime localTime26 = dateTime25.toLocalTime();
        int int27 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localTime26);
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField14.getAsText((long) 21037186, locale29);
        try {
            long long33 = offsetDateTimeField14.add((long) 21057734, (-28857599903L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Magnitude of add amount is too large: -28857599903");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 64 + "'", int16 == 64);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 53 + "'", int27 == 53);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "64" + "'", str30.equals("64"));
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.Chronology chronology12 = gJChronology11.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology11);
//        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology11.getZone();
//        java.lang.String str15 = gJChronology11.toString();
//        try {
//            long long20 = gJChronology11.getDateTimeMillis(21061326, 10, 21087616, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21087616 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GJChronology[America/Los_Angeles,cutover=2019-06-12T18:41:51.901Z]" + "'", str15.equals("GJChronology[America/Los_Angeles,cutover=2019-06-12T18:41:51.901Z]"));
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("ISOChronology[America/Los_Angeles]", "2019-06-12T12:51:26.242Z");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        mutableDateTime2.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
//        int int10 = mutableDateTime9.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.yearOfEra();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.dayOfWeek();
//        java.lang.String str17 = iSOChronology15.toString();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
//        mutableDateTime19.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime24 = property22.set((int) '4');
//        java.lang.String str25 = property22.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType26, (int) '4');
//        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField18);
//        java.lang.String str31 = skipDateTimeField29.getAsShortText((long) (byte) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, (org.joda.time.DateTimeField) skipDateTimeField29);
//        org.joda.time.DurationField durationField33 = skipDateTimeField29.getRangeDurationField();
//        java.util.Locale locale34 = null;
//        int int35 = skipDateTimeField29.getMaximumShortTextLength(locale34);
//        int int37 = skipDateTimeField29.get((-2649600000L));
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "millisOfDay" + "'", str25.equals("millisOfDay"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Dec" + "'", str31.equals("Dec"));
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 12 + "'", int37 == 12);
//    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.roundHalfEvenCopy();
        try {
            org.joda.time.DateTime dateTime10 = property6.addToCopy((-3124138021965L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -3124138021965 * 604800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology3 = julianChronology0.withZone(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now(chronology3);
        mutableDateTime4.addWeeks(12);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(21031798);
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMonthOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMinuteOfDay(64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.minutes();
        try {
            long long9 = iSOChronology0.getDateTimeMillis((-1), 0, 21041450, 2, 4, (int) (byte) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
//        mutableDateTime4.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime9 = property7.add((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime11 = property7.add((int) ' ');
//        int int12 = mutableDateTime11.getDayOfYear();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime11);
//        java.util.TimeZone timeZone14 = dateTimeZone2.toTimeZone();
//        java.lang.String str15 = dateTimeZone2.toString();
//        org.joda.time.DateTime dateTime16 = dateTime1.withZone(dateTimeZone2);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.clockhourOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("2019-06-12T12:51:28.729Z", "", (int) (byte) 1, 0);
//        java.lang.String str25 = fixedDateTimeZone23.getNameKey(28800000L);
//        boolean boolean26 = buddhistChronology17.equals((java.lang.Object) fixedDateTimeZone23);
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime16.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone23);
//        int int28 = mutableDateTime27.getHourOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 163 + "'", int12 == 163);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "America/Los_Angeles" + "'", str15.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 18 + "'", int28 == 18);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.lang.Integer int2 = dateTimeFormatter1.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(int2);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        mutableDateTime0.addMinutes((-1));
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
//        org.joda.time.MutableDateTime mutableDateTime4 = mutableDateTime0.copy();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime0.minuteOfDay();
//        java.lang.String str6 = mutableDateTime0.toString();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019-06-12T11:41:52.233-07:00" + "'", str6.equals("2019-06-12T11:41:52.233-07:00"));
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.years();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.hourOfHalfday();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.add((long) (short) -1);
        java.lang.String str9 = mutableDateTime1.toString();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime1.era();
        long long11 = property10.remainder();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019-05-01T00:00:00.000-07:00" + "'", str9.equals("2019-05-01T00:00:00.000-07:00"));
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 63692265600000L + "'", long11 == 63692265600000L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.Chronology chronology6 = dateTime1.getChronology();
        org.joda.time.DateTime dateTime8 = dateTime1.withHourOfDay((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = dateTime1.toDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime1.minusHours(0);
        org.joda.time.DateTime dateTime13 = dateTime1.minusMillis(138);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(21031798);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMonthOfYear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendLiteral("2019-06-12T05:50:32.113-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.dayOfWeek();
        java.lang.String str17 = iSOChronology15.toString();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
        mutableDateTime19.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime24 = property22.set((int) '4');
        java.lang.String str25 = property22.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType26, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField28.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder10.appendDecimal(dateTimeFieldType29, 21037186, 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder9.appendFixedDecimal(dateTimeFieldType29, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder9.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder9.appendSecondOfDay(21031798);
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        mutableDateTime39.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property42 = mutableDateTime39.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime44 = property42.set((int) '4');
        java.lang.String str45 = property42.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property42.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder38.appendShortText(dateTimeFieldType46);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder38.appendCenturyOfEra(42171668, 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "millisOfDay" + "'", str25.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(mutableDateTime44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "millisOfDay" + "'", str45.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        mutableDateTime4.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.add((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime11 = property7.add((int) ' ');
        int int12 = mutableDateTime11.getDayOfYear();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime11);
        java.util.TimeZone timeZone14 = dateTimeZone2.toTimeZone();
        java.lang.String str15 = dateTimeZone2.toString();
        org.joda.time.DateTime dateTime16 = dateTime1.withZone(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now();
        mutableDateTime17.setDate((org.joda.time.ReadableInstant) mutableDateTime18);
        java.lang.Class<?> wildcardClass20 = mutableDateTime18.getClass();
        mutableDateTime18.setDayOfYear(2);
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime18.centuryOfEra();
        org.joda.time.DateTime dateTime24 = mutableDateTime18.toDateTimeISO();
        int int25 = mutableDateTime18.getMillisOfDay();
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 365 + "'", int12 == 365);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "America/Los_Angeles" + "'", str15.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 57600000 + "'", int25 == 57600000);
        org.junit.Assert.assertNotNull(gJChronology26);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 24);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology5, locale6, (java.lang.Integer) 0);
        dateTimeParserBucket8.setOffset((java.lang.Integer) 1000);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeParserBucket8.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter2.withZone(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("Pacific Standard Time", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        int int18 = offsetDateTimeField14.get((long) 0);
        boolean boolean19 = offsetDateTimeField14.isLenient();
        boolean boolean21 = offsetDateTimeField14.isLeap(350L);
        long long24 = offsetDateTimeField14.add((-5820000L), (long) 0);
        java.lang.String str26 = offsetDateTimeField14.getAsText((long) 4);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 64 + "'", int18 == 64);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-5820000L) + "'", long24 == (-5820000L));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "64" + "'", str26.equals("64"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology2, locale3, (java.lang.Integer) 0);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 1000);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeParserBucket5.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = iSOChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.secondOfDay();
        dateTimeParserBucket5.saveField(dateTimeField12, 4);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone19 = iSOChronology17.getZone();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 1, dateTimeZone19);
        dateTimeParserBucket5.setZone(dateTimeZone19);
        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone19);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("2019-06-12T12:51:28.729Z", "", (int) (byte) 1, 0);
        java.util.TimeZone timeZone28 = fixedDateTimeZone27.toTimeZone();
        boolean boolean29 = buddhistChronology22.equals((java.lang.Object) fixedDateTimeZone27);
        long long31 = fixedDateTimeZone27.previousTransition(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(buddhistChronology22);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        boolean boolean3 = gJChronology0.equals((java.lang.Object) dateTimeZone2);
        org.joda.time.Chronology chronology4 = gJChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
        mutableDateTime7.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime7.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime12 = property10.add((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime14 = property10.add((int) ' ');
        int int15 = mutableDateTime14.getDayOfYear();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime14);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.yearOfEra();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.dayOfWeek();
        java.lang.String str22 = iSOChronology20.toString();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology20.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime24 = org.joda.time.MutableDateTime.now();
        mutableDateTime24.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime24.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime29 = property27.set((int) '4');
        java.lang.String str30 = property27.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property27.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, dateTimeFieldType31, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField23);
        java.lang.String str36 = skipDateTimeField34.getAsShortText((long) (byte) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, (org.joda.time.DateTimeField) skipDateTimeField34);
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.dayOfWeek();
        java.lang.String str42 = iSOChronology40.toString();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology40.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime44 = org.joda.time.MutableDateTime.now();
        mutableDateTime44.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property47 = mutableDateTime44.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime49 = property47.set((int) '4');
        java.lang.String str50 = property47.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property47.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, dateTimeFieldType51, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField54 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology38, dateTimeField43);
        org.joda.time.MutableDateTime mutableDateTime55 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime56 = org.joda.time.MutableDateTime.now();
        mutableDateTime55.setDate((org.joda.time.ReadableInstant) mutableDateTime56);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.monthOfYear();
        mutableDateTime56.setRounding(dateTimeField60);
        mutableDateTime56.add((long) (short) -1);
        org.joda.time.DateTime dateTime64 = mutableDateTime56.toDateTime();
        org.joda.time.ReadablePartial readablePartial65 = null;
        org.joda.time.DateTime dateTime66 = dateTime64.withFields(readablePartial65);
        org.joda.time.DateTimeZone dateTimeZone67 = null;
        org.joda.time.DateTime dateTime68 = dateTime64.toDateTime(dateTimeZone67);
        org.joda.time.LocalDate localDate69 = dateTime64.toLocalDate();
        int[] intArray72 = new int[] { 21041450, 0 };
        int int73 = skipDateTimeField54.getMaximumValue((org.joda.time.ReadablePartial) localDate69, intArray72);
        java.util.Locale locale75 = null;
        java.lang.String str76 = skipDateTimeField34.getAsShortText((org.joda.time.ReadablePartial) localDate69, (int) (short) 1, locale75);
        int[] intArray79 = new int[] { '#', (short) 10 };
        try {
            gJChronology0.validate((org.joda.time.ReadablePartial) localDate69, intArray79);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 365 + "'", int15 == 365);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str22.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "millisOfDay" + "'", str30.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Dec" + "'", str36.equals("Dec"));
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str42.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(mutableDateTime44);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "millisOfDay" + "'", str50.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(mutableDateTime55);
        org.junit.Assert.assertNotNull(mutableDateTime56);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(localDate69);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 12 + "'", int73 == 12);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "Jan" + "'", str76.equals("Jan"));
        org.junit.Assert.assertNotNull(intArray79);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property9 = dateTime8.hourOfDay();
        org.joda.time.DateTime dateTime11 = property9.setCopy(10);
        org.joda.time.DateTime dateTime13 = property9.addToCopy(0L);
        org.joda.time.DateTime dateTime14 = property9.withMaximumValue();
        java.lang.String str15 = property9.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Property[hourOfDay]" + "'", str15.equals("Property[hourOfDay]"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.add((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime7 = property3.add((int) ' ');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now();
        mutableDateTime9.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime9.toMutableDateTime(dateTimeZone13);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology16);
        org.joda.time.DateTime dateTime19 = dateTime17.plusMonths((int) '4');
        boolean boolean20 = mutableDateTime7.isEqual((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now();
        mutableDateTime21.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime21.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.MutableDateTime mutableDateTime27 = mutableDateTime21.toMutableDateTime(dateTimeZone25);
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone25);
        mutableDateTime7.setZoneRetainFields(dateTimeZone25);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertNotNull(julianChronology28);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = julianChronology2.seconds();
        int int4 = julianChronology2.getMinimumDaysInFirstWeek();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) julianChronology2, locale5, (java.lang.Integer) 0);
        org.joda.time.DateTimeField dateTimeField8 = julianChronology2.hourOfDay();
        long long12 = julianChronology2.add((long) (short) -1, (long) 163, 8);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology2);
        long long17 = julianChronology2.add(63692265600000L, (-1L), 31);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1303L + "'", long12 == 1303L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 63692265599969L + "'", long17 == 63692265599969L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        long long18 = offsetDateTimeField14.roundHalfEven((long) 1969);
        long long20 = offsetDateTimeField14.roundCeiling((long) 24);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800000L + "'", long18 == 28800000L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28800000L + "'", long20 == 28800000L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.year();
        boolean boolean4 = mutableDateTime0.isAfterNow();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(0L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withYear(19);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.add((long) (short) -1);
        org.joda.time.DateTime dateTime9 = mutableDateTime1.toDateTime();
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond((int) '#');
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime11);
        try {
            org.joda.time.DateTime dateTime14 = dateTime11.withMillisOfSecond(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2019-06-12T12:51:28.729Z", "", (int) (byte) 1, 0);
        long long6 = fixedDateTimeZone4.previousTransition((long) 8);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(28800000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            long long14 = gregorianChronology9.getDateTimeMillis(21088, (int) (byte) 100, 21042530, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 8L + "'", long6 == 8L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology9);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.minutes();
        try {
            long long9 = gJChronology0.getDateTimeMillis(3, 21088, 69, 0, (int) 'a', 0, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("350", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"350/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendLiteral("2019-06-12T05:50:32.113-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMonthOfYear(2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.dayOfWeek();
        java.lang.String str15 = iSOChronology13.toString();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now();
        mutableDateTime17.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime17.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime22 = property20.set((int) '4');
        java.lang.String str23 = property20.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property20.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, dateTimeFieldType24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder8.appendDecimal(dateTimeFieldType27, 21037186, 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType27);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder31.appendYearOfCentury(21142, 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str15.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "millisOfDay" + "'", str23.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime1.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.add((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime8 = property4.add((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.dayOfWeek();
        java.lang.String str12 = iSOChronology10.toString();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now();
        mutableDateTime14.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime14.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime19 = property17.set((int) '4');
        java.lang.String str20 = property17.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property17.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, dateTimeFieldType21, (int) '4');
        int int24 = mutableDateTime8.get(dateTimeFieldType21);
        int int27 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime8, "2019-06-12T12:51:36.483Z", (int) (byte) -1);
        try {
            mutableDateTime8.setDayOfWeek((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str12.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "millisOfDay" + "'", str20.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 57540042 + "'", int24 == 57540042);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField14.getType();
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField14.getAsShortText(35483L, locale17);
        boolean boolean20 = offsetDateTimeField14.isLeap(2678400000L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "64" + "'", str18.equals("64"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        try {
            long long8 = buddhistChronology0.getDateTimeMillis(0, 0, 21037186, (int) '4', (int) (short) 100, 21042530, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        java.lang.String str4 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        mutableDateTime6.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
        java.lang.String str12 = property9.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        java.lang.String str17 = skipDateTimeField16.getName();
        long long19 = skipDateTimeField16.roundFloor(0L);
        try {
            long long22 = skipDateTimeField16.set((-28857564470L), "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "monthOfYear" + "'", str17.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-2649600000L) + "'", long19 == (-2649600000L));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.clockhourOfDay();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        try {
            mutableDateTime3.setWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (BuddhistChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getDurationField();
        org.joda.time.DurationField durationField16 = offsetDateTimeField14.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.minus(readableDuration1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter3.withZoneUTC();
        java.lang.String str5 = instant2.toString(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970W014T000000Z" + "'", str5.equals("1970W014T000000Z"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2019-06-12T12:51:28.729Z", "", (int) (byte) 1, 0);
        long long6 = fixedDateTimeZone4.previousTransition((long) 8);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(28800000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 8L + "'", long6 == 8L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.add((long) (short) -1);
        org.joda.time.DateTime dateTime9 = mutableDateTime1.toDateTime();
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond((int) '#');
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now();
        mutableDateTime12.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime12.millisOfDay();
        mutableDateTime12.setHourOfDay(0);
        mutableDateTime12.setMillis(0L);
        boolean boolean20 = dateTime9.isBefore((org.joda.time.ReadableInstant) mutableDateTime12);
        org.joda.time.DateTime.Property property21 = dateTime9.dayOfMonth();
        org.joda.time.DateTime dateTime22 = dateTime9.toDateTime();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime22);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 1, dateTimeZone4);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
//        java.lang.String str8 = dateTimeZone4.getShortName(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 51, (int) 'a', 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "Jun");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 11);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.io.Writer writer1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        mutableDateTime2.setDayOfYear((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readableDuration7);
        org.joda.time.DateTime dateTime10 = dateTime6.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property11 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime12 = property11.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = iSOChronology14.weeks();
        org.joda.time.DateTime dateTime16 = dateTime12.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime dateTime18 = dateTime16.plusWeeks(0);
        org.joda.time.DateTime dateTime20 = dateTime16.withYearOfCentury(0);
        boolean boolean21 = mutableDateTime2.isAfter((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime24 = dateTime16.withMillis((long) 24);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.plusMonths((int) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setMillis(209916000000L);
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime4 = mutableDateTime0.copy();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.millisOfDay();
        int int4 = property3.getMinimumValue();
        java.util.Locale locale5 = null;
        int int6 = property3.getMaximumShortTextLength(locale5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.plus(readableDuration9);
        org.joda.time.DateTime dateTime12 = dateTime8.withDayOfYear((int) ' ');
        org.joda.time.Chronology chronology13 = dateTime8.getChronology();
        org.joda.time.DateTime dateTime15 = dateTime8.withYear(0);
        long long16 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime8);
        int int17 = property3.getMaximumValueOverall();
        org.joda.time.MutableDateTime mutableDateTime18 = property3.roundHalfCeiling();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-60000L) + "'", long16 == (-60000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86399999 + "'", int17 == 86399999);
        org.junit.Assert.assertNotNull(mutableDateTime18);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        boolean boolean5 = dateTime1.isEqual((org.joda.time.ReadableInstant) mutableDateTime4);
        int int6 = mutableDateTime4.getDayOfMonth();
        mutableDateTime4.setDayOfMonth(9);
        int int9 = mutableDateTime4.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        mutableDateTime2.addMillis(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendLiteral("2019-06-12T05:50:32.113-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendLiteral("2019-06-12T05:50:32.113-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder9.appendMonthOfYear(2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder17.appendLiteral("2019-06-12T05:50:32.113-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder17.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendTwoDigitWeekyear(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder27.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology32.dayOfWeek();
        java.lang.String str34 = iSOChronology32.toString();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology32.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime36 = org.joda.time.MutableDateTime.now();
        mutableDateTime36.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime36.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime41 = property39.set((int) '4');
        java.lang.String str42 = property39.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property39.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, dateTimeFieldType43, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = offsetDateTimeField45.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder27.appendDecimal(dateTimeFieldType46, 21037186, 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder26.appendFixedDecimal(dateTimeFieldType46, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder9.appendFixedDecimal(dateTimeFieldType46, 21038483);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder7.appendFixedDecimal(dateTimeFieldType46, 2);
        org.joda.time.format.DateTimeParser dateTimeParser56 = dateTimeFormatterBuilder55.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str34.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(mutableDateTime36);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(mutableDateTime41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "millisOfDay" + "'", str42.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeParser56);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 1, dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (short) 10);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        mutableDateTime2.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
        int int10 = mutableDateTime9.getDayOfYear();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
        mutableDateTime9.addMinutes(5);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime9.weekyear();
        int int15 = mutableDateTime9.getWeekOfWeekyear();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime9.weekyear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology3, locale4, (java.lang.Integer) 0);
        boolean boolean8 = dateTimeParserBucket6.restoreState((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology11, locale12, (java.lang.Integer) 0);
        dateTimeParserBucket14.setOffset((java.lang.Integer) 1000);
        org.joda.time.DateTimeZone dateTimeZone17 = dateTimeParserBucket14.getZone();
        dateTimeParserBucket6.setZone(dateTimeZone17);
        org.joda.time.Chronology chronology19 = dateTimeParserBucket6.getChronology();
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime(5178038400052L, chronology19);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.roundHalfEvenCopy();
        org.joda.time.DateTimeField dateTimeField9 = property6.getField();
        org.joda.time.DateTime dateTime10 = property6.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime12 = property6.addWrapFieldToCopy(8);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        boolean boolean3 = gJChronology0.equals((java.lang.Object) dateTimeZone2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        java.lang.String str6 = cachedDateTimeZone4.getNameKey((-3124138021965L));
        long long8 = cachedDateTimeZone4.previousTransition((long) 21035312);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "LMT" + "'", str6.equals("LMT"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-5756400001L) + "'", long8 == (-5756400001L));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        mutableDateTime2.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
        int int10 = mutableDateTime9.getDayOfYear();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.yearOfEra();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.dayOfWeek();
        java.lang.String str17 = iSOChronology15.toString();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
        mutableDateTime19.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime24 = property22.set((int) '4');
        java.lang.String str25 = property22.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType26, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField18);
        java.lang.String str31 = skipDateTimeField29.getAsShortText((long) (byte) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, (org.joda.time.DateTimeField) skipDateTimeField29);
        boolean boolean34 = skipDateTimeField29.isLeap((long) 10);
        org.joda.time.DurationField durationField35 = skipDateTimeField29.getRangeDurationField();
        int int36 = skipDateTimeField29.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "millisOfDay" + "'", str25.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Dec" + "'", str31.equals("Dec"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = mutableDateTime1.toDateTime(dateTimeZone7);
        org.joda.time.ReadableDuration readableDuration9 = null;
        mutableDateTime1.add(readableDuration9, 8);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime8 = property6.addToCopy(10L);
        try {
            org.joda.time.DateTime dateTime10 = property6.setCopy("Property[hourOfDay]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[hourOfDay]\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfWeek();
        java.lang.String str4 = iSOChronology2.toString();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        mutableDateTime6.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.set((int) '4');
        java.lang.String str12 = property9.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property9.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType13, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5);
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipDateTimeField16.getAsText((long) 1, locale18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = org.joda.time.MutableDateTime.now();
        mutableDateTime23.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime23.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime28 = property26.add((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime30 = property26.add((int) ' ');
        int int31 = mutableDateTime30.getDayOfYear();
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (org.joda.time.ReadableInstant) mutableDateTime30);
        org.joda.time.DateTimeField dateTimeField33 = gJChronology32.yearOfEra();
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.dayOfWeek();
        java.lang.String str38 = iSOChronology36.toString();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology36.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime40 = org.joda.time.MutableDateTime.now();
        mutableDateTime40.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property43 = mutableDateTime40.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime45 = property43.set((int) '4');
        java.lang.String str46 = property43.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property43.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, dateTimeFieldType47, (int) '4');
        org.joda.time.field.SkipDateTimeField skipDateTimeField50 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology34, dateTimeField39);
        java.lang.String str52 = skipDateTimeField50.getAsShortText((long) (byte) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology32, (org.joda.time.DateTimeField) skipDateTimeField50);
        org.joda.time.DurationField durationField54 = skipDateTimeField50.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = skipDateTimeField50.getType();
        int int57 = skipDateTimeField50.getLeapAmount((long) 1439);
        int int58 = skipDateTimeField50.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology62 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone61);
        java.util.Locale locale63 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket65 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology62, locale63, (java.lang.Integer) 0);
        dateTimeParserBucket65.setOffset((java.lang.Integer) 1000);
        org.joda.time.DateTimeZone dateTimeZone68 = dateTimeParserBucket65.getZone();
        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology70 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone69);
        org.joda.time.DurationField durationField71 = iSOChronology70.weeks();
        org.joda.time.DateTimeField dateTimeField72 = iSOChronology70.secondOfDay();
        dateTimeParserBucket65.saveField(dateTimeField72, 4);
        org.joda.time.DateTimeZone dateTimeZone75 = null;
        dateTimeParserBucket65.setZone(dateTimeZone75);
        java.util.Locale locale77 = dateTimeParserBucket65.getLocale();
        java.lang.String str78 = skipDateTimeField50.getAsShortText(0L, locale77);
        try {
            java.lang.String str79 = skipDateTimeField16.getAsText((int) '#', locale77);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str4.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "millisOfDay" + "'", str12.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "December" + "'", str19.equals("December"));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 365 + "'", int31 == 365);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str38.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(mutableDateTime40);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(mutableDateTime45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfDay" + "'", str46.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Dec" + "'", str52.equals("Dec"));
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 12 + "'", int58 == 12);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertNotNull(iSOChronology62);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertNotNull(dateTimeZone69);
        org.junit.Assert.assertNotNull(iSOChronology70);
        org.junit.Assert.assertNotNull(durationField71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertNotNull(locale77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "Dec" + "'", str78.equals("Dec"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        mutableDateTime2.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
        int int10 = mutableDateTime9.getDayOfYear();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.Chronology chronology12 = gJChronology11.withUTC();
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTimeField dateTimeField14 = gJChronology11.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone19 = iSOChronology17.getZone();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 1, dateTimeZone19);
        org.joda.time.Chronology chronology21 = gJChronology11.withZone(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField22 = gJChronology11.weekOfWeekyear();
        try {
            long long27 = gJChronology11.getDateTimeMillis((int) (byte) 1, 21118, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21118 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        mutableDateTime2.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.add((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = property5.add((int) ' ');
        int int10 = mutableDateTime9.getDayOfYear();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime9);
        mutableDateTime9.addMinutes(5);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime9.weekyear();
        org.joda.time.MutableDateTime mutableDateTime15 = property14.roundHalfFloor();
        org.joda.time.DateTimeZone dateTimeZone16 = mutableDateTime15.getZone();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime15.centuryOfEra();
        java.lang.String str18 = property17.getName();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "centuryOfEra" + "'", str18.equals("centuryOfEra"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendLiteral("2019-06-12T05:50:32.113-07:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.dayOfWeek();
        java.lang.String str17 = iSOChronology15.toString();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime19 = org.joda.time.MutableDateTime.now();
        mutableDateTime19.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime19.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime24 = property22.set((int) '4');
        java.lang.String str25 = property22.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property22.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType26, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField28.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder10.appendDecimal(dateTimeFieldType29, 21037186, 12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder9.appendFixedDecimal(dateTimeFieldType29, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder9.appendTwoDigitYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder9.appendTwoDigitYear(9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder9.appendClockhourOfHalfday(21142);
        boolean boolean41 = dateTimeFormatterBuilder9.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder9.appendHourOfDay(21061644);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str17.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "millisOfDay" + "'", str25.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDayOfYear((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readableDuration5);
        org.joda.time.DateTime dateTime8 = dateTime4.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property9 = dateTime4.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = property9.roundHalfCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField13 = iSOChronology12.weeks();
        org.joda.time.DateTime dateTime14 = dateTime10.toDateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks(0);
        org.joda.time.DateTime dateTime18 = dateTime14.withYearOfCentury(0);
        boolean boolean19 = mutableDateTime0.isAfter((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property20 = dateTime14.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.dayOfWeek();
        java.util.Locale locale25 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket(42478309116L, (org.joda.time.Chronology) iSOChronology23, locale25);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.halfdayOfDay();
        try {
            org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) property20, (org.joda.time.Chronology) iSOChronology23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.add((long) (short) -1);
        org.joda.time.DateTime dateTime9 = mutableDateTime1.toDateTime();
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withFields(readablePartial10);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(64);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((-21036537L), dateTimeZone14);
        long long17 = dateTimeZone14.convertUTCToLocal((-28857564470L));
        org.joda.time.DateTime dateTime18 = dateTime9.withZoneRetainFields(dateTimeZone14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendYearOfEra((int) (byte) 100, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendCenturyOfEra(9, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder22.appendLiteral(' ');
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        java.util.Locale locale31 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology30, locale31, (java.lang.Integer) 0);
        boolean boolean35 = dateTimeParserBucket33.restoreState((java.lang.Object) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
        java.util.Locale locale39 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket41 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology38, locale39, (java.lang.Integer) 0);
        dateTimeParserBucket41.setOffset((java.lang.Integer) 1000);
        org.joda.time.DateTimeZone dateTimeZone44 = dateTimeParserBucket41.getZone();
        dateTimeParserBucket33.setZone(dateTimeZone44);
        org.joda.time.MutableDateTime mutableDateTime46 = org.joda.time.MutableDateTime.now();
        mutableDateTime46.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property49 = mutableDateTime46.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime51 = property49.set((int) '4');
        java.lang.String str52 = property49.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property49.getFieldType();
        dateTimeParserBucket33.saveField(dateTimeFieldType53, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder22.appendShortText(dateTimeFieldType53);
        org.joda.time.DateTime dateTime58 = dateTime18.withField(dateTimeFieldType53, 21057734);
        boolean boolean60 = dateTime58.isBefore((-3124138021965L));
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28857564406L) + "'", long17 == (-28857564406L));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(mutableDateTime46);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(mutableDateTime51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "millisOfDay" + "'", str52.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.Chronology chronology3 = julianChronology0.withZone(dateTimeZone1);
        int int4 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology0.getZone();
        try {
            long long13 = julianChronology0.getDateTimeMillis(365, 8, 0, 16, (int) '#', 57600000, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        int int18 = offsetDateTimeField14.get((long) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime20.plus(readableDuration21);
        org.joda.time.DateTime dateTime24 = dateTime20.withDayOfYear((int) ' ');
        org.joda.time.Chronology chronology25 = dateTime20.getChronology();
        org.joda.time.DateTime dateTime27 = dateTime20.withHourOfDay((int) (byte) 10);
        org.joda.time.LocalTime localTime28 = dateTime27.toLocalTime();
        int[] intArray30 = null;
        int[] intArray32 = offsetDateTimeField14.addWrapPartial((org.joda.time.ReadablePartial) localTime28, (int) (short) 100, intArray30, 0);
        long long34 = offsetDateTimeField14.roundCeiling((long) 20);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        java.util.Locale locale40 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket42 = new org.joda.time.format.DateTimeParserBucket((long) 10, (org.joda.time.Chronology) iSOChronology39, locale40, (java.lang.Integer) 0);
        dateTimeParserBucket42.setOffset((java.lang.Integer) 1000);
        org.joda.time.DateTimeZone dateTimeZone45 = dateTimeParserBucket42.getZone();
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField48 = iSOChronology47.weeks();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.secondOfDay();
        dateTimeParserBucket42.saveField(dateTimeField49, 4);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        dateTimeParserBucket42.setZone(dateTimeZone52);
        java.util.Locale locale54 = dateTimeParserBucket42.getLocale();
        try {
            long long55 = offsetDateTimeField14.set((-665460885917222000L), "Dec", locale54);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Dec\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 64 + "'", int18 == 64);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(localTime28);
        org.junit.Assert.assertNull(intArray32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 28800000L + "'", long34 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(locale54);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(21057734, 0, 21061644, 5, 18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.add((long) (short) -1);
        org.joda.time.DateTime dateTime9 = mutableDateTime1.toDateTime();
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond((int) '#');
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime14 = dateTime11.withMillisOfSecond(24);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfWeek();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        mutableDateTime5.addMinutes((-1));
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) '4');
        java.lang.String str11 = property8.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType12, (int) '4');
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField14.getType();
        int int18 = offsetDateTimeField14.get((long) 0);
        boolean boolean19 = offsetDateTimeField14.isLenient();
        boolean boolean21 = offsetDateTimeField14.isLeap(350L);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone22);
        org.joda.time.ReadableDuration readableDuration24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.plus(readableDuration24);
        org.joda.time.DateTime dateTime27 = dateTime23.withDayOfYear((int) ' ');
        org.joda.time.Chronology chronology28 = dateTime23.getChronology();
        org.joda.time.DateTime dateTime30 = dateTime23.withHourOfDay((int) (byte) 10);
        org.joda.time.LocalTime localTime31 = dateTime30.toLocalTime();
        int int32 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) localTime31);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "millisOfDay" + "'", str11.equals("millisOfDay"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 64 + "'", int18 == 64);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.monthOfYear();
        mutableDateTime1.setRounding(dateTimeField5);
        mutableDateTime1.add((long) (short) -1);
        java.lang.String str9 = mutableDateTime1.toString();
        boolean boolean10 = mutableDateTime1.isAfterNow();
        try {
            java.lang.String str12 = mutableDateTime1.toString("2019-06-12T12:52:01.292Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-11-01T00:00:00.000-08:00" + "'", str9.equals("1969-11-01T00:00:00.000-08:00"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(21031798);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYearOfEra(2, 1439);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withDayOfYear((int) ' ');
        org.joda.time.Chronology chronology6 = dateTime1.getChronology();
        org.joda.time.DateTime dateTime8 = dateTime1.withYear(0);
        org.joda.time.DateTime dateTime9 = dateTime8.toDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime8.minusWeeks(9);
        org.joda.time.DateTime dateTime13 = dateTime8.withDayOfMonth(10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone4 = iSOChronology2.getZone();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) 21088, (org.joda.time.Chronology) iSOChronology2, locale6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(21031798);
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitYear(18, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(21031798);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitYear(21061326, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }
}

