import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.Chronology chronology2 = null;
        try {
            org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((int) ' ', (int) (short) 1, chronology2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DurationField durationField2 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test007");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560632313085L + "'", long1 == 1560632313085L);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 0, (int) (short) 1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, 1560632313085L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray3 = iSOChronology0.get(readablePeriod1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        long long7 = delegatedDateTimeField5.roundFloor((long) 0);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField5.getLeapDurationField();
        org.joda.time.DurationField durationField9 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField10 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField8, durationField9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1900800000L) + "'", long7 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        try {
            long long3 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) 'a', (int) (short) 1, (int) (short) 0, 0, (int) (byte) 1, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1560632313085L, (java.lang.Number) 0, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException9.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        org.joda.time.DurationFieldType durationFieldType15 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType15);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long9 = offsetDateTimeField4.remainder(0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField12 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType10, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9936000000L + "'", long9 == 9936000000L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.io.Writer writer2 = null;
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            dateTimeFormatter0.printTo(writer2, readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.ReadWritableInstant readWritableInstant1 = null;
        try {
            int int4 = dateTimeFormatter0.parseInto(readWritableInstant1, "GregorianChronology[UTC]", 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("4", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.joda.time.MonthDay.MONTH_OF_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.withChronologyRetainFields(chronology1);
        java.util.Locale locale4 = null;
        try {
            java.lang.String str5 = monthDay0.toString("GregorianChronology[UTC]", locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        try {
            long long9 = copticChronology0.getDateTimeMillis((int) (short) 10, (int) (short) 10, (int) (short) 10, (int) (short) -1, (int) (short) 10, (int) ' ', (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
        int[] intArray4 = new int[] {};
        try {
            copticChronology0.validate((org.joda.time.ReadablePartial) monthDay3, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withLocale(locale2);
        try {
            org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.withChronologyRetainFields(chronology1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.MonthDay monthDay5 = monthDay2.withFieldAdded(durationFieldType3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 10, (java.lang.Number) (short) -1, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.ReadWritableInstant readWritableInstant1 = null;
        try {
            int int4 = dateTimeFormatter0.parseInto(readWritableInstant1, "hi!", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.withChronologyRetainFields(chronology1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.MonthDay.Property property4 = monthDay2.property(dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.withDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 10, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        boolean boolean10 = offsetDateTimeField4.isSupported();
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = monthDay11.withChronologyRetainFields(chronology12);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology15.secondOfDay();
        org.joda.time.DateTimeField dateTimeField17 = copticChronology15.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 10);
        int int22 = offsetDateTimeField19.getDifference(0L, 0L);
        int int24 = offsetDateTimeField19.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay25 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.MonthDay monthDay27 = monthDay25.withChronologyRetainFields(chronology26);
        int[] intArray33 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int34 = offsetDateTimeField19.getMinimumValue((org.joda.time.ReadablePartial) monthDay27, intArray33);
        try {
            int[] intArray36 = offsetDateTimeField4.addWrapField((org.joda.time.ReadablePartial) monthDay13, 11, intArray33, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 11 + "'", int24 == 11);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 11 + "'", int34 == 11);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.DateTime dateTime5 = dateTime2.withField(dateTimeFieldType3, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean5 = dateTime3.isAfter((-1L));
        try {
            org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime3, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray7 = gregorianChronology0.get(readablePeriod5, 1560632313085L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isBefore(1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            int int6 = dateTime2.get(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("4");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"4\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType10, 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter2.printTo(writer3, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        boolean boolean6 = dateTime4.isBefore(1L);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime4.withZone(dateTimeZone8);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 10);
        int int12 = offsetDateTimeField9.getDifference(0L, 0L);
        int int14 = offsetDateTimeField9.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.MonthDay monthDay17 = monthDay15.withChronologyRetainFields(chronology16);
        int[] intArray23 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int24 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay17, intArray23);
        java.util.Locale locale25 = null;
        try {
            java.lang.String str26 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay17, locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyearOfCentury' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 11 + "'", int14 == 11);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 11 + "'", int24 == 11);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, 2000);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException9.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException17.addSuppressed((java.lang.Throwable) illegalFieldValueException20);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException20);
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException25.addSuppressed((java.lang.Throwable) illegalFieldValueException28);
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException32.addSuppressed((java.lang.Throwable) illegalFieldValueException35);
        illegalFieldValueException25.addSuppressed((java.lang.Throwable) illegalFieldValueException35);
        illegalFieldValueException20.addSuppressed((java.lang.Throwable) illegalFieldValueException35);
        java.lang.String str39 = illegalFieldValueException35.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) -1, (java.lang.Number) 691200000L, number3);
        java.lang.Number number8 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) -1, (java.lang.Number) 691200000L, number8);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        java.lang.String str11 = illegalFieldValueException9.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        try {
            long long7 = delegatedDateTimeField4.set((long) (byte) 1, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MonthDay monthDay3 = monthDay1.withChronologyRetainFields(chronology2);
        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.MonthDay.Property property6 = monthDay1.property(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "��" + "'", str4.equals("��"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        try {
            org.joda.time.DateTime dateTime5 = property3.setCopy("hi!");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.centuryOfEra();
        try {
            long long6 = copticChronology0.getDateTimeMillis(1, (int) (short) 10, 40, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (-10), (int) (short) 100, 42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.Date date0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        try {
            long long7 = gregorianChronology2.getDateTimeMillis((int) 'a', (int) (short) 1, 0, 42);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.String str7 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str8 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-10));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1560632313085L, (java.lang.Number) 100, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean4 = dateTime2.isBefore(1L);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime2.withZone(dateTimeZone6);
//        boolean boolean10 = dateTime8.isBefore(1560632322909L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        int[] intArray20 = monthDay12.getValues();
        try {
            int int22 = monthDay12.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str2 = gJChronology1.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        try {
            long long11 = gJChronology1.getDateTimeMillis(100, 15, 100, 110, 42, (int) ' ', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 110 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 40");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        try {
            org.joda.time.DateTime dateTime5 = dateTime2.withHourOfDay(44);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 44 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
        int int19 = offsetDateTimeField16.getDifference(0L, 0L);
        int int21 = offsetDateTimeField16.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay22.withChronologyRetainFields(chronology23);
        int[] intArray30 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int31 = offsetDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) monthDay24, intArray30);
        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = copticChronology32.secondOfDay();
        org.joda.time.DateTimeField dateTimeField34 = copticChronology32.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 10);
        int int39 = offsetDateTimeField36.getDifference(0L, 0L);
        int int41 = offsetDateTimeField36.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay42 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.MonthDay monthDay44 = monthDay42.withChronologyRetainFields(chronology43);
        int[] intArray50 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int51 = offsetDateTimeField36.getMinimumValue((org.joda.time.ReadablePartial) monthDay44, intArray50);
        boolean boolean52 = monthDay24.isEqual((org.joda.time.ReadablePartial) monthDay44);
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField54 = copticChronology53.secondOfDay();
        org.joda.time.DateTimeField dateTimeField55 = copticChronology53.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, 10);
        int int60 = offsetDateTimeField57.getDifference(0L, 0L);
        int int62 = offsetDateTimeField57.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay63 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology64 = null;
        org.joda.time.MonthDay monthDay65 = monthDay63.withChronologyRetainFields(chronology64);
        int[] intArray71 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int72 = offsetDateTimeField57.getMinimumValue((org.joda.time.ReadablePartial) monthDay65, intArray71);
        int[] intArray73 = monthDay65.getValues();
        int int74 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay44, intArray73);
        org.joda.time.MonthDay monthDay76 = monthDay44.plusDays((int) (short) 100);
        org.joda.time.chrono.CopticChronology copticChronology77 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField78 = copticChronology77.secondOfDay();
        org.joda.time.DateTimeField dateTimeField79 = copticChronology77.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField81 = new org.joda.time.field.OffsetDateTimeField(dateTimeField79, 10);
        int int84 = offsetDateTimeField81.getDifference(0L, 0L);
        int int86 = offsetDateTimeField81.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay87 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology88 = null;
        org.joda.time.MonthDay monthDay89 = monthDay87.withChronologyRetainFields(chronology88);
        int[] intArray95 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int96 = offsetDateTimeField81.getMinimumValue((org.joda.time.ReadablePartial) monthDay89, intArray95);
        int[] intArray97 = monthDay89.getValues();
        boolean boolean98 = monthDay44.isBefore((org.joda.time.ReadablePartial) monthDay89);
        org.joda.time.DateTimeField[] dateTimeFieldArray99 = monthDay89.getFields();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(copticChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 11 + "'", int62 == 11);
        org.junit.Assert.assertNotNull(monthDay63);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(monthDay76);
        org.junit.Assert.assertNotNull(copticChronology77);
        org.junit.Assert.assertNotNull(dateTimeField78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 11 + "'", int86 == 11);
        org.junit.Assert.assertNotNull(monthDay87);
        org.junit.Assert.assertNotNull(monthDay89);
        org.junit.Assert.assertNotNull(intArray95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 11 + "'", int96 == 11);
        org.junit.Assert.assertNotNull(intArray97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldArray99);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime5 = dateTime1.minusSeconds(11);
//        org.joda.time.DateTime.Property property6 = dateTime5.monthOfYear();
//        int int7 = property6.getMaximumValue();
//        org.junit.Assert.assertNotNull(gregorianCalendar2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 46 + "'", int3 == 46);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        java.util.Locale locale14 = null;
        int int15 = delegatedDateTimeField9.getMaximumShortTextLength(locale14);
        long long17 = delegatedDateTimeField9.roundHalfFloor(1560632322909L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559952000000L + "'", long17 == 1559952000000L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType13, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField10 = gJChronology9.hours();
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((int) '#', 13, (int) '#', (int) (byte) 1, 2, (int) '4', dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 13 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.String str7 = illegalFieldValueException2.getIllegalStringValue();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException10.addSuppressed((java.lang.Throwable) illegalFieldValueException13);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException13);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 100, 10, (int) (byte) 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1559952000000L, (java.lang.Number) 0L, (java.lang.Number) (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean4 = dateTime2.isAfter((-1L));
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTime2.toString("0", locale6);
//        int int8 = dateTime2.getDayOfWeek();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        try {
            long long13 = gregorianChronology0.getDateTimeMillis((int) (byte) 10, 420, 12, 44, 13, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 44 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(110, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 110 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = offsetDateTimeField4.getMinimumValue(readablePartial5);
        long long8 = offsetDateTimeField4.remainder((long) 15);
        long long10 = offsetDateTimeField4.roundHalfEven(94953600010L);
        try {
            long long13 = offsetDateTimeField4.set((long) 13, "-1");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekyearOfCentury must be in the range [11,110]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9936000015L + "'", long8 == 9936000015L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 85017600000L + "'", long10 == 85017600000L);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isBefore(1L);
        org.joda.time.DateTime dateTime6 = dateTime2.withSecondOfMinute(0);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime2.getZone();
        java.lang.String str9 = dateTimeZone7.getName((long) 100);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.weekOfWeekyear();
        try {
            org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime12, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.001" + "'", str9.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
        org.joda.time.DateTime dateTime8 = dateTime4.withMillis((long) 12);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.DateTime dateTime11 = dateTime8.withFieldAdded(durationFieldType9, (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) -1, (java.lang.Number) 691200000L, number3);
        java.lang.Number number8 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) -1, (java.lang.Number) 691200000L, number8);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        java.lang.Throwable[] throwableArray11 = illegalFieldValueException9.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) (short) 10);
        boolean boolean8 = delegatedDateTimeField4.isLeap((-1900800000L));
        int int10 = delegatedDateTimeField4.getMaximumValue((-31449599999L));
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType11, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(11);
        try {
            org.joda.time.LocalTime localTime5 = dateTimeFormatter3.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getRangeDurationField();
        int int14 = delegatedDateTimeField4.getMinimumValue((long) 248);
        boolean boolean15 = delegatedDateTimeField4.isSupported();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField4.getAsText(readablePartial5, (int) (byte) 100, locale7);
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MonthDay monthDay11 = monthDay9.withChronologyRetainFields(chronology10);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology13.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15, dateTimeFieldType16);
        long long19 = delegatedDateTimeField17.roundFloor((long) 0);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField17.getLeapDurationField();
        long long22 = delegatedDateTimeField17.roundHalfCeiling((long) (byte) 0);
        boolean boolean24 = delegatedDateTimeField17.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = copticChronology25.secondOfDay();
        org.joda.time.DateTimeField dateTimeField27 = copticChronology25.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 10);
        int int32 = offsetDateTimeField29.getDifference(0L, 0L);
        int int34 = offsetDateTimeField29.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay35 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.MonthDay monthDay37 = monthDay35.withChronologyRetainFields(chronology36);
        int[] intArray43 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int44 = offsetDateTimeField29.getMinimumValue((org.joda.time.ReadablePartial) monthDay37, intArray43);
        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = copticChronology45.secondOfDay();
        org.joda.time.DateTimeField dateTimeField47 = copticChronology45.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, 10);
        int int52 = offsetDateTimeField49.getDifference(0L, 0L);
        int int54 = offsetDateTimeField49.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay55 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology56 = null;
        org.joda.time.MonthDay monthDay57 = monthDay55.withChronologyRetainFields(chronology56);
        int[] intArray63 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int64 = offsetDateTimeField49.getMinimumValue((org.joda.time.ReadablePartial) monthDay57, intArray63);
        boolean boolean65 = monthDay37.isEqual((org.joda.time.ReadablePartial) monthDay57);
        org.joda.time.chrono.CopticChronology copticChronology66 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField67 = copticChronology66.secondOfDay();
        org.joda.time.DateTimeField dateTimeField68 = copticChronology66.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField(dateTimeField68, 10);
        int int73 = offsetDateTimeField70.getDifference(0L, 0L);
        int int75 = offsetDateTimeField70.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay76 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology77 = null;
        org.joda.time.MonthDay monthDay78 = monthDay76.withChronologyRetainFields(chronology77);
        int[] intArray84 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int85 = offsetDateTimeField70.getMinimumValue((org.joda.time.ReadablePartial) monthDay78, intArray84);
        int[] intArray86 = monthDay78.getValues();
        int int87 = delegatedDateTimeField17.getMinimumValue((org.joda.time.ReadablePartial) monthDay57, intArray86);
        java.util.Locale locale89 = null;
        try {
            int[] intArray90 = delegatedDateTimeField4.set((org.joda.time.ReadablePartial) monthDay11, 100, intArray86, "6", locale89);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1900800000L) + "'", long19 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 691200000L + "'", long22 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 11 + "'", int34 == 11);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 11 + "'", int44 == 11);
        org.junit.Assert.assertNotNull(copticChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 11 + "'", int54 == 11);
        org.junit.Assert.assertNotNull(monthDay55);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 11 + "'", int64 == 11);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(copticChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 11 + "'", int75 == 11);
        org.junit.Assert.assertNotNull(monthDay76);
        org.junit.Assert.assertNotNull(monthDay78);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 11 + "'", int85 == 11);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean4 = dateTime2.isAfter((-1L));
//        org.joda.time.DateTime dateTime6 = dateTime2.plus((long) (short) 10);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusYears(100);
//        int int9 = dateTime6.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1258 + "'", int9 == 1258);
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime1.withChronology(chronology6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632329915L + "'", long2 == 1560632329915L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isBefore(1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.DateTime dateTime7 = dateTime2.withField(dateTimeFieldType5, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        java.lang.String str5 = property3.getName();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfYear" + "'", str5.equals("dayOfYear"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.String str2 = dateTimeFormatter0.print(9936000015L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970" + "'", str2.equals("1970"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundFloorCopy();
        org.joda.time.DurationField durationField6 = property3.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNull(durationField6);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
//        java.lang.Object obj3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(obj3);
//        java.util.GregorianCalendar gregorianCalendar5 = dateTime4.toGregorianCalendar();
//        org.joda.time.DateTime.Property property6 = dateTime4.dayOfYear();
//        org.joda.time.DateTime dateTime7 = property6.getDateTime();
//        java.lang.String str8 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.secondOfMinute();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gregorianCalendar5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1:58:50 PM" + "'", str8.equals("1:58:50 PM"));
//        org.junit.Assert.assertNotNull(property9);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = delegatedDateTimeField4.getAsText(readablePartial5, (int) (byte) 100, locale7);
//        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology9.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 10);
//        int int16 = offsetDateTimeField13.getDifference(0L, 0L);
//        int int18 = offsetDateTimeField13.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.MonthDay monthDay21 = monthDay19.withChronologyRetainFields(chronology20);
//        int[] intArray27 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int28 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) monthDay21, intArray27);
//        int[] intArray29 = monthDay21.getValues();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay21, locale30);
//        java.util.Locale locale33 = null;
//        try {
//            java.lang.String str34 = monthDay21.toString("GregorianChronology[UTC]", locale33);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
//        org.junit.Assert.assertNotNull(copticChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 11 + "'", int18 == 11);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 11 + "'", int28 == 11);
//        org.junit.Assert.assertNotNull(intArray29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "6" + "'", str31.equals("6"));
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.ReadablePartial readablePartial7 = null;
        java.util.Locale locale9 = null;
        java.lang.String str10 = delegatedDateTimeField4.getAsText(readablePartial7, 0, locale9);
        int int12 = delegatedDateTimeField4.getMinimumValue(1560632313085L);
        try {
            long long15 = delegatedDateTimeField4.set(1L, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField6 = gJChronology5.hours();
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        try {
            org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((int) (byte) -1, 6, (org.joda.time.Chronology) gJChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "6", "1:58:46 PM");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType4, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getShortName((-1900800000L));
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 1);
        java.lang.String str7 = julianChronology6.toString();
        try {
            long long15 = julianChronology6.getDateTimeMillis(100, 1258, 420, (int) (byte) 100, (int) (short) 1, (int) (short) 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+32:00" + "'", str4.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "JulianChronology[+32:00,mdfw=1]" + "'", str7.equals("JulianChronology[+32:00,mdfw=1]"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getRangeDurationField();
        int int14 = delegatedDateTimeField4.getMinimumValue((long) 248);
        org.joda.time.DurationField durationField15 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField17 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(420, (int) (byte) 1, (-1), 420, (int) (short) -1, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 420 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 10);
        int int9 = offsetDateTimeField6.getDifference(0L, 0L);
        java.lang.String str11 = offsetDateTimeField6.getAsText(1560632313085L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) offsetDateTimeField6);
        java.lang.String str13 = skipUndoDateTimeField12.toString();
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        long long20 = delegatedDateTimeField18.roundFloor((long) 0);
        org.joda.time.DurationField durationField21 = delegatedDateTimeField18.getLeapDurationField();
        long long23 = delegatedDateTimeField18.roundHalfCeiling((long) (byte) 0);
        boolean boolean25 = delegatedDateTimeField18.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = copticChronology26.secondOfDay();
        org.joda.time.DateTimeField dateTimeField28 = copticChronology26.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 10);
        int int33 = offsetDateTimeField30.getDifference(0L, 0L);
        int int35 = offsetDateTimeField30.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.MonthDay monthDay38 = monthDay36.withChronologyRetainFields(chronology37);
        int[] intArray44 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int45 = offsetDateTimeField30.getMinimumValue((org.joda.time.ReadablePartial) monthDay38, intArray44);
        org.joda.time.chrono.CopticChronology copticChronology46 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField47 = copticChronology46.secondOfDay();
        org.joda.time.DateTimeField dateTimeField48 = copticChronology46.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, 10);
        int int53 = offsetDateTimeField50.getDifference(0L, 0L);
        int int55 = offsetDateTimeField50.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay56 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology57 = null;
        org.joda.time.MonthDay monthDay58 = monthDay56.withChronologyRetainFields(chronology57);
        int[] intArray64 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int65 = offsetDateTimeField50.getMinimumValue((org.joda.time.ReadablePartial) monthDay58, intArray64);
        boolean boolean66 = monthDay38.isEqual((org.joda.time.ReadablePartial) monthDay58);
        org.joda.time.chrono.CopticChronology copticChronology67 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField68 = copticChronology67.secondOfDay();
        org.joda.time.DateTimeField dateTimeField69 = copticChronology67.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField(dateTimeField69, 10);
        int int74 = offsetDateTimeField71.getDifference(0L, 0L);
        int int76 = offsetDateTimeField71.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay77 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology78 = null;
        org.joda.time.MonthDay monthDay79 = monthDay77.withChronologyRetainFields(chronology78);
        int[] intArray85 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int86 = offsetDateTimeField71.getMinimumValue((org.joda.time.ReadablePartial) monthDay79, intArray85);
        int[] intArray87 = monthDay79.getValues();
        int int88 = delegatedDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) monthDay58, intArray87);
        int int89 = skipUndoDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) monthDay58);
        try {
            long long92 = skipUndoDateTimeField12.set(9936000015L, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for weekyearOfCentury must be in the range [11,110]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "46" + "'", str11.equals("46"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[weekyearOfCentury]" + "'", str13.equals("DateTimeField[weekyearOfCentury]"));
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1900800000L) + "'", long20 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 691200000L + "'", long23 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(copticChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 11 + "'", int35 == 11);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 11 + "'", int45 == 11);
        org.junit.Assert.assertNotNull(copticChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 11 + "'", int55 == 11);
        org.junit.Assert.assertNotNull(monthDay56);
        org.junit.Assert.assertNotNull(monthDay58);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 11 + "'", int65 == 11);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(copticChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 11 + "'", int76 == 11);
        org.junit.Assert.assertNotNull(monthDay77);
        org.junit.Assert.assertNotNull(monthDay79);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 11 + "'", int86 == 11);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 110 + "'", int89 == 110);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str1 = gJChronology0.toString();
        int int2 = gJChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray4 = copticChronology0.get(readablePeriod2, (long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long9 = offsetDateTimeField4.remainder(0L);
        java.util.Locale locale12 = null;
        long long13 = offsetDateTimeField4.set((long) 10, "100", locale12);
        org.joda.time.DurationField durationField14 = offsetDateTimeField4.getDurationField();
        org.joda.time.DurationField durationField15 = offsetDateTimeField4.getLeapDurationField();
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = copticChronology16.secondOfDay();
        org.joda.time.DateTimeField dateTimeField18 = copticChronology16.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 10);
        int int22 = offsetDateTimeField20.getMaximumValue(9936000000L);
        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.MonthDay monthDay25 = monthDay23.withChronologyRetainFields(chronology24);
        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = copticChronology26.secondOfDay();
        org.joda.time.DateTimeField dateTimeField28 = copticChronology26.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 10);
        int int33 = offsetDateTimeField30.getDifference(0L, 0L);
        int int35 = offsetDateTimeField30.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.MonthDay monthDay38 = monthDay36.withChronologyRetainFields(chronology37);
        int[] intArray44 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int45 = offsetDateTimeField30.getMinimumValue((org.joda.time.ReadablePartial) monthDay38, intArray44);
        int[] intArray46 = monthDay38.getValues();
        int int47 = offsetDateTimeField20.getMinimumValue((org.joda.time.ReadablePartial) monthDay23, intArray46);
        java.util.Locale locale48 = null;
        try {
            java.lang.String str49 = offsetDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay23, locale48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyearOfCentury' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9936000000L + "'", long9 == 9936000000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 94953600010L + "'", long13 == 94953600010L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 110 + "'", int22 == 110);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(copticChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 11 + "'", int35 == 11);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 11 + "'", int45 == 11);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 11 + "'", int47 == 11);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-6) + "'", int1 == (-6));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = offsetDateTimeField4.getMinimumValue(readablePartial5);
        long long8 = offsetDateTimeField4.remainder((long) 15);
        long long10 = offsetDateTimeField4.roundHalfEven(94953600010L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField4.getAsText(readablePartial11, 1258, locale13);
        long long16 = offsetDateTimeField4.roundHalfCeiling((long) 46);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9936000015L + "'", long8 == 9936000015L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 85017600000L + "'", long10 == 85017600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1258" + "'", str14.equals("1258"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-9936000000L) + "'", long16 == (-9936000000L));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("1:58:50 PM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1:58:50 PM\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = offsetDateTimeField4.getMinimumValue(readablePartial5);
        long long9 = offsetDateTimeField4.add(0L, 334);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10540454400000L + "'", long9 == 10540454400000L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumTime();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException9.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        java.lang.Throwable[] throwableArray15 = illegalFieldValueException2.getSuppressed();
        java.lang.Number number16 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNull(number16);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        boolean boolean6 = dateTime1.isAfter((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime7 = dateTime5.withEarlierOffsetAtOverlap();
//        int int8 = dateTime7.getHourOfDay();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 786 + "'", int2 == 786);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(110, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 110 + "'", int2 == 110);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime2.plusWeeks(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("35");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfEvenCopy();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632333025L + "'", long2 == 1560632333025L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isBefore(1L);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime2.withZone(dateTimeZone6);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) -1, (java.lang.Number) 691200000L, number3);
        java.lang.Number number8 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) -1, (java.lang.Number) 691200000L, number8);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        java.lang.Number number11 = illegalFieldValueException9.getLowerBound();
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 691200000L + "'", number11.equals(691200000L));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-13) + "'", int1 == (-13));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsText((int) '#', locale8);
        int int11 = delegatedDateTimeField4.getMinimumValue((long) (-13));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35" + "'", str9.equals("35"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = org.joda.time.MonthDay.DAY_OF_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
        try {
            org.joda.time.DateTime dateTime8 = dateTime4.withDayOfYear(1258);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1258 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getShortName((-1900800000L));
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 1);
        java.lang.String str7 = julianChronology6.toString();
        try {
            long long15 = julianChronology6.getDateTimeMillis((int) (byte) 1, 837, 654, 0, (int) (short) 100, 12, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+32:00" + "'", str4.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "JulianChronology[+32:00,mdfw=1]" + "'", str7.equals("JulianChronology[+32:00,mdfw=1]"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
        int int31 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
        int int51 = offsetDateTimeField46.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
        int int72 = offsetDateTimeField67.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology74 = null;
        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
        int[] intArray83 = monthDay75.getValues();
        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
        java.util.Locale locale88 = null;
        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
        try {
            org.joda.time.MonthDay monthDay92 = property90.setCopy("Jun");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Jun\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(copticChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
        org.junit.Assert.assertNotNull(monthDay73);
        org.junit.Assert.assertNotNull(monthDay75);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(monthDay86);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
        org.junit.Assert.assertNotNull(property90);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.secondOfDay();
        try {
            long long7 = copticChronology0.getDateTimeMillis(13, (int) 'a', (int) '4', 1258);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        try {
            long long25 = offsetDateTimeField4.set((long) ' ', "2017-08-05T13:58:49.048-07:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2017-08-05T13:58:49.048-07:00\" for weekyearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime dateTime4 = dateTime1.minus(1560632322909L);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DurationField durationField7 = copticChronology5.years();
        boolean boolean8 = dateTime1.equals((java.lang.Object) durationField7);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusDays((int) (short) 10);
//        org.joda.time.LocalTime localTime4 = dateTime1.toLocalTime();
//        org.joda.time.DateTime.Property property5 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        boolean boolean10 = dateTime8.isBefore(1L);
//        long long11 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime8);
//        int int12 = dateTime8.getSecondOfDay();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 75535 + "'", int12 == 75535);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException9.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException17.addSuppressed((java.lang.Throwable) illegalFieldValueException20);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException20);
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException25.addSuppressed((java.lang.Throwable) illegalFieldValueException28);
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException32.addSuppressed((java.lang.Throwable) illegalFieldValueException35);
        illegalFieldValueException25.addSuppressed((java.lang.Throwable) illegalFieldValueException35);
        illegalFieldValueException20.addSuppressed((java.lang.Throwable) illegalFieldValueException35);
        java.lang.Throwable[] throwableArray39 = illegalFieldValueException35.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray39);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("46");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"46\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime5 = dateTime1.minusSeconds(11);
//        org.joda.time.DateTime.Property property6 = dateTime5.monthOfYear();
//        java.lang.String str7 = property6.getAsShortText();
//        java.util.Locale locale8 = null;
//        int int9 = property6.getMaximumTextLength(locale8);
//        org.junit.Assert.assertNotNull(gregorianCalendar2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 55 + "'", int3 == 55);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jun" + "'", str7.equals("Jun"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsText((int) '#', locale8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField4.getAsShortText(1560632313085L, locale11);
        long long14 = delegatedDateTimeField4.roundCeiling((long) 654);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35" + "'", str9.equals("35"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10" + "'", str12.equals("10"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 691200000L + "'", long14 == 691200000L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MonthDay monthDay3 = monthDay1.withChronologyRetainFields(chronology2);
        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay1);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 10);
        int int12 = offsetDateTimeField9.getDifference(0L, 0L);
        int int14 = offsetDateTimeField9.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.MonthDay monthDay17 = monthDay15.withChronologyRetainFields(chronology16);
        int[] intArray23 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int24 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay17, intArray23);
        long long27 = offsetDateTimeField9.add((long) (short) 1, (int) (short) -1);
        int int29 = offsetDateTimeField9.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
        org.joda.time.DurationField durationField36 = iSOChronology35.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = buddhistChronology37.monthOfYear();
        org.joda.time.DurationField durationField39 = buddhistChronology37.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField40 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType30, durationField36, durationField39);
        try {
            org.joda.time.MonthDay.Property property41 = monthDay1.property(dateTimeFieldType30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyearOfCentury' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "��" + "'", str4.equals("��"));
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 11 + "'", int14 == 11);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 11 + "'", int24 == 11);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-31449599999L) + "'", long27 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(buddhistChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(durationField39);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology1.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        int int8 = offsetDateTimeField5.getDifference(0L, 0L);
        int int10 = offsetDateTimeField5.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = monthDay11.withChronologyRetainFields(chronology12);
        int[] intArray19 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int20 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay13, intArray19);
        long long23 = offsetDateTimeField5.add((long) (short) 1, (int) (short) -1);
        int int25 = offsetDateTimeField5.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField5.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 11 + "'", int10 == 11);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 11 + "'", int20 == 11);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-31449599999L) + "'", long23 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.String str2 = gJChronology1.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZoneUTC();
//        java.lang.String str6 = dateTimeFormatter0.print((long) 15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "16" + "'", str6.equals("16"));
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        java.lang.String str6 = delegatedDateTimeField4.getAsText((long) (-1));
        boolean boolean7 = delegatedDateTimeField4.isSupported();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4" + "'", str6.equals("4"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean4 = dateTime2.isBefore(1L);
//        org.joda.time.DateTime dateTime6 = dateTime2.withSecondOfMinute(0);
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime2.getZone();
//        int int8 = dateTime2.getCenturyOfEra();
//        boolean boolean9 = dateTime2.isBeforeNow();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        boolean boolean2 = instant1.isBeforeNow();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 420, (-1), 1258, (int) (byte) 0, 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1258 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("��", (java.lang.Number) 20, number2, (java.lang.Number) 110);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertNull(number5);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
//        try {
//            org.joda.time.DateTime dateTime7 = dateTime4.withMonthOfYear(44);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 44 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632336527L + "'", long2 == 1560632336527L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
//        org.joda.time.DateTime dateTime4 = dateTime1.minus(1560632322909L);
//        int int5 = dateTime4.getYear();
//        org.junit.Assert.assertNotNull(gregorianCalendar2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str15 = gregorianChronology14.toString();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology18 = gregorianChronology14.withZone(dateTimeZone17);
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology19.secondOfDay();
        org.joda.time.DateTimeField dateTimeField21 = copticChronology19.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, dateTimeFieldType22);
        long long25 = delegatedDateTimeField23.roundFloor((long) 0);
        org.joda.time.DurationField durationField26 = delegatedDateTimeField23.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, (org.joda.time.DateTimeField) delegatedDateTimeField23);
        java.util.Locale locale28 = null;
        int int29 = delegatedDateTimeField23.getMaximumShortTextLength(locale28);
        long long32 = delegatedDateTimeField23.add((long) (-1), (int) ' ');
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField23);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GregorianChronology[UTC]" + "'", str15.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1900800000L) + "'", long25 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 78710399999L + "'", long32 == 78710399999L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("��", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"��\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        java.lang.String str6 = delegatedDateTimeField4.getAsText((-1900800000L));
        long long8 = delegatedDateTimeField4.roundHalfCeiling((long) 9);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4" + "'", str6.equals("4"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 691200000L + "'", long8 == 691200000L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 110);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 110 + "'", int1 == 110);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        try {
            org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(55, 11, (org.joda.time.Chronology) gregorianChronology4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("100");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsText((int) '#', locale8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
        int int19 = offsetDateTimeField16.getDifference(0L, 0L);
        int int21 = offsetDateTimeField16.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay22.withChronologyRetainFields(chronology23);
        int[] intArray30 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int31 = offsetDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) monthDay24, intArray30);
        try {
            int[] intArray33 = delegatedDateTimeField4.addWrapPartial(readablePartial10, (int) (byte) 10, intArray30, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35" + "'", str9.equals("35"));
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MonthDay monthDay3 = monthDay1.withChronologyRetainFields(chronology2);
        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.MonthDay monthDay9 = monthDay1.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        int int36 = monthDay9.indexOf(dateTimeFieldType35);
        org.joda.time.DurationField durationField37 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.days();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField42 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField37, durationField41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "��" + "'", str4.equals("��"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        int int9 = delegatedDateTimeField4.getMaximumValue((long) 52);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(420);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-420) + "'", int1 == (-420));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        java.lang.String str7 = dateTimeZone4.getShortName((-1900800000L));
        org.joda.time.Chronology chronology8 = copticChronology0.withZone(dateTimeZone4);
        java.lang.String str9 = dateTimeZone4.getID();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+32:00" + "'", str7.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+32:00" + "'", str9.equals("+32:00"));
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
//        long long3 = dateTime1.getMillis();
//        org.junit.Assert.assertNotNull(gregorianCalendar2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560632340763L + "'", long3 == 1560632340763L);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("1:58:58 PM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1:58:58 PM\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        boolean boolean6 = dateTime1.isAfter((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.Instant instant7 = new org.joda.time.Instant((java.lang.Object) dateTime5);
//        org.joda.time.DateTime.Property property8 = dateTime5.monthOfYear();
//        try {
//            org.joda.time.DateTime dateTime10 = property8.setCopy((int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 133 + "'", int2 == 133);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) -1, (java.lang.Number) 691200000L, number3);
        java.lang.Number number8 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) -1, (java.lang.Number) 691200000L, number8);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        java.lang.String str11 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number12 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str13 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) -1 + "'", number12.equals((byte) -1));
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        try {
            long long2 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
//        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
//        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
//        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
//        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
//        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
//        int int31 = offsetDateTimeField26.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
//        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
//        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
//        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
//        int int51 = offsetDateTimeField46.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology53 = null;
//        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
//        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
//        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
//        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
//        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
//        int int72 = offsetDateTimeField67.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology74 = null;
//        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
//        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
//        int[] intArray83 = monthDay75.getValues();
//        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
//        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
//        java.util.Locale locale88 = null;
//        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
//        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
//        java.lang.String str91 = property90.getAsString();
//        org.joda.time.MonthDay monthDay93 = property90.addWrapFieldToCopy((int) 'a');
//        org.joda.time.MonthDay monthDay95 = property90.setCopy((int) (byte) 1);
//        int int96 = property90.getMaximumValueOverall();
//        java.lang.String str97 = property90.getAsShortText();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
//        org.junit.Assert.assertNotNull(copticChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(copticChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertNotNull(monthDay86);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
//        org.junit.Assert.assertNotNull(property90);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "23" + "'", str91.equals("23"));
//        org.junit.Assert.assertNotNull(monthDay93);
//        org.junit.Assert.assertNotNull(monthDay95);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 31 + "'", int96 == 31);
//        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "23" + "'", str97.equals("23"));
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
        org.joda.time.DateTime dateTime8 = dateTime4.withMillisOfDay(248);
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withWeekOfWeekyear((-33));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -33 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("11:59:59 PM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 11:59:59 PM");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(110, (-1), 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withZone(dateTimeZone4);
        try {
            org.joda.time.DateTime dateTime10 = dateTime2.withTime(837, 55, (int) (byte) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 837 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology5 = gregorianChronology1.withZone(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology1.hours();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withPivotYear(56);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
        org.joda.time.DateTime dateTime8 = dateTime4.withMillis((long) 12);
        org.joda.time.Instant instant10 = new org.joda.time.Instant((long) (-10));
        int int11 = dateTime8.compareTo((org.joda.time.ReadableInstant) instant10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.util.Locale locale13 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withLocale(locale13);
        java.lang.String str15 = instant10.toString(dateTimeFormatter12);
        org.joda.time.Instant instant17 = instant10.withMillis(1560632330384L);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "11:59:59 PM" + "'", str15.equals("11:59:59 PM"));
        org.junit.Assert.assertNotNull(instant17);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        org.joda.time.DurationField durationField14 = skipUndoDateTimeField13.getRangeDurationField();
        try {
            long long17 = skipUndoDateTimeField13.set((long) (byte) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [0,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField14);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        try {
//            int int10 = property8.compareTo(readableInstant9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632343362L + "'", long2 == 1560632343362L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getShortName((-1900800000L));
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 1);
        java.lang.String str7 = julianChronology6.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+32:00" + "'", str4.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "JulianChronology[+32:00,mdfw=1]" + "'", str7.equals("JulianChronology[+32:00,mdfw=1]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis(6, (int) 'a', (int) (short) 0, 420);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime5 = property3.roundFloorCopy();
//        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
//        org.junit.Assert.assertNotNull(gregorianCalendar2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560582000000L + "'", long6 == 1560582000000L);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        java.lang.String str8 = delegatedDateTimeField4.toString();
        org.joda.time.DurationField durationField9 = delegatedDateTimeField4.getLeapDurationField();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField36 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DateTimeField[monthOfYear]" + "'", str8.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.withDurationAdded(readableDuration5, (int) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime7.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField4 = gJChronology3.hours();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology3.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) -1, (java.lang.Number) 691200000L, number3);
        java.lang.Number number8 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) -1, (java.lang.Number) 691200000L, number8);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        org.joda.time.DurationFieldType durationFieldType11 = illegalFieldValueException9.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType11);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 10, 6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone4);
        try {
            org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(40, 12, (org.joda.time.Chronology) buddhistChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 40 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 10);
        int int9 = offsetDateTimeField6.getDifference(0L, 0L);
        java.lang.String str11 = offsetDateTimeField6.getAsText(1560632313085L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) offsetDateTimeField6);
        java.lang.String str13 = skipUndoDateTimeField12.toString();
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        long long20 = delegatedDateTimeField18.roundFloor((long) 0);
        org.joda.time.DurationField durationField21 = delegatedDateTimeField18.getLeapDurationField();
        long long23 = delegatedDateTimeField18.roundHalfCeiling((long) (byte) 0);
        boolean boolean25 = delegatedDateTimeField18.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = copticChronology26.secondOfDay();
        org.joda.time.DateTimeField dateTimeField28 = copticChronology26.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 10);
        int int33 = offsetDateTimeField30.getDifference(0L, 0L);
        int int35 = offsetDateTimeField30.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.MonthDay monthDay38 = monthDay36.withChronologyRetainFields(chronology37);
        int[] intArray44 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int45 = offsetDateTimeField30.getMinimumValue((org.joda.time.ReadablePartial) monthDay38, intArray44);
        org.joda.time.chrono.CopticChronology copticChronology46 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField47 = copticChronology46.secondOfDay();
        org.joda.time.DateTimeField dateTimeField48 = copticChronology46.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, 10);
        int int53 = offsetDateTimeField50.getDifference(0L, 0L);
        int int55 = offsetDateTimeField50.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay56 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology57 = null;
        org.joda.time.MonthDay monthDay58 = monthDay56.withChronologyRetainFields(chronology57);
        int[] intArray64 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int65 = offsetDateTimeField50.getMinimumValue((org.joda.time.ReadablePartial) monthDay58, intArray64);
        boolean boolean66 = monthDay38.isEqual((org.joda.time.ReadablePartial) monthDay58);
        org.joda.time.chrono.CopticChronology copticChronology67 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField68 = copticChronology67.secondOfDay();
        org.joda.time.DateTimeField dateTimeField69 = copticChronology67.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField(dateTimeField69, 10);
        int int74 = offsetDateTimeField71.getDifference(0L, 0L);
        int int76 = offsetDateTimeField71.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay77 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology78 = null;
        org.joda.time.MonthDay monthDay79 = monthDay77.withChronologyRetainFields(chronology78);
        int[] intArray85 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int86 = offsetDateTimeField71.getMinimumValue((org.joda.time.ReadablePartial) monthDay79, intArray85);
        int[] intArray87 = monthDay79.getValues();
        int int88 = delegatedDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) monthDay58, intArray87);
        int int89 = skipUndoDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) monthDay58);
        java.util.Locale locale91 = null;
        java.lang.String str92 = skipUndoDateTimeField12.getAsText(482338505L, locale91);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "46" + "'", str11.equals("46"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[weekyearOfCentury]" + "'", str13.equals("DateTimeField[weekyearOfCentury]"));
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1900800000L) + "'", long20 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 691200000L + "'", long23 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(copticChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 11 + "'", int35 == 11);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 11 + "'", int45 == 11);
        org.junit.Assert.assertNotNull(copticChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 11 + "'", int55 == 11);
        org.junit.Assert.assertNotNull(monthDay56);
        org.junit.Assert.assertNotNull(monthDay58);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 11 + "'", int65 == 11);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(copticChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 11 + "'", int76 == 11);
        org.junit.Assert.assertNotNull(monthDay77);
        org.junit.Assert.assertNotNull(monthDay79);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 11 + "'", int86 == 11);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 110 + "'", int89 == 110);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "97" + "'", str92.equals("97"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.Interval interval4 = property3.toInterval();
        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval4);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(interval4);
        org.junit.Assert.assertNotNull(readableInterval5);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        java.lang.String str7 = dateTimeZone4.getShortName((-1900800000L));
        org.joda.time.Chronology chronology8 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.DurationField durationField9 = copticChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.era();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+32:00" + "'", str7.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 10);
        int int9 = offsetDateTimeField6.getDifference(0L, 0L);
        long long11 = offsetDateTimeField6.remainder(0L);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now();
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) monthDay12, 0, locale14);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) monthDay12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9936000000L + "'", long11 == 9936000000L);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.millisOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str5 = gJChronology4.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter3.withZoneUTC();
        boolean boolean8 = buddhistChronology0.equals((java.lang.Object) dateTimeFormatter7);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[UTC]" + "'", str5.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusDays((int) (short) 10);
        org.joda.time.LocalTime localTime4 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property5 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.Interval interval7 = property5.toInterval();
        org.joda.time.DateTime dateTime8 = property5.getDateTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology13.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 10);
        int int20 = offsetDateTimeField17.getDifference(0L, 0L);
        long long22 = offsetDateTimeField17.remainder(0L);
        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now();
        java.util.Locale locale25 = null;
        java.lang.String str26 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) monthDay23, 0, locale25);
        int int27 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay23);
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = copticChronology28.secondOfDay();
        org.joda.time.DateTimeField dateTimeField30 = copticChronology28.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 10);
        int int35 = offsetDateTimeField32.getDifference(0L, 0L);
        int int37 = offsetDateTimeField32.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay38 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology39 = null;
        org.joda.time.MonthDay monthDay40 = monthDay38.withChronologyRetainFields(chronology39);
        int[] intArray46 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int47 = offsetDateTimeField32.getMinimumValue((org.joda.time.ReadablePartial) monthDay40, intArray46);
        long long50 = offsetDateTimeField32.add((long) (short) 1, (int) (short) -1);
        int int52 = offsetDateTimeField32.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = offsetDateTimeField32.getType();
        try {
            org.joda.time.MonthDay.Property property54 = monthDay23.property(dateTimeFieldType53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyearOfCentury' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9936000000L + "'", long22 == 9936000000L);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 11 + "'", int37 == 11);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 11 + "'", int47 == 11);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-31449599999L) + "'", long50 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1969, (java.lang.Number) 10.0f, (java.lang.Number) 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        int int26 = offsetDateTimeField4.getLeapAmount((-1900800000L));
        long long28 = offsetDateTimeField4.roundHalfFloor((long) 40);
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField4.getAsShortText(1560632314000L, locale30);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-9936000000L) + "'", long28 == (-9936000000L));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "46" + "'", str31.equals("46"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getRangeDurationField();
        int int14 = delegatedDateTimeField4.getMinimumValue((long) 248);
        org.joda.time.DurationField durationField15 = delegatedDateTimeField4.getRangeDurationField();
        long long18 = delegatedDateTimeField4.add((long) (short) 100, 15);
        java.lang.String str20 = delegatedDateTimeField4.getAsShortText(0L);
        int int22 = delegatedDateTimeField4.getLeapAmount((long) (-1));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 36720000100L + "'", long18 == 36720000100L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "4" + "'", str20.equals("4"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = copticChronology20.secondOfDay();
        org.joda.time.DateTimeField dateTimeField22 = copticChronology20.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 10);
        int int27 = offsetDateTimeField24.getDifference(0L, 0L);
        int int29 = offsetDateTimeField24.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.MonthDay monthDay32 = monthDay30.withChronologyRetainFields(chronology31);
        int[] intArray38 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int39 = offsetDateTimeField24.getMinimumValue((org.joda.time.ReadablePartial) monthDay32, intArray38);
        boolean boolean40 = monthDay12.isEqual((org.joda.time.ReadablePartial) monthDay32);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = null;
        boolean boolean42 = monthDay32.isSupported(dateTimeFieldType41);
        org.joda.time.DurationFieldType durationFieldType43 = null;
        try {
            org.joda.time.MonthDay monthDay45 = monthDay32.withFieldAdded(durationFieldType43, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(copticChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 11 + "'", int39 == 11);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withPivotYear(11);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        boolean boolean9 = dateTime7.isAfter((-1L));
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTime7.toString("0", locale11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        java.lang.String str17 = dateTimeZone14.getShortName((-1900800000L));
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14, 1);
        org.joda.time.MutableDateTime mutableDateTime20 = dateTime7.toMutableDateTime((org.joda.time.Chronology) julianChronology19);
        int int23 = dateTimeFormatter1.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime20, "0", (int) ' ');
        try {
            org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.parse("20", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"20\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+32:00" + "'", str17.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-33) + "'", int23 == (-33));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundFloorCopy();
        org.joda.time.DateTime dateTime7 = property3.addToCopy(0);
        int int8 = property3.getLeapAmount();
        java.util.Locale locale9 = null;
        int int10 = property3.getMaximumTextLength(locale9);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str3 = gJChronology2.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZoneUTC();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str8 = gregorianChronology7.toString();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology11 = gregorianChronology7.withZone(dateTimeZone10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = dateTimeZone10.getShortName(10L, locale13);
        org.joda.time.Chronology chronology15 = gJChronology6.withZone(dateTimeZone10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology6);
        try {
            org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.parse("11:59:59 PM", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"11:59:59 PM\" is malformed at \" PM\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[UTC]" + "'", str3.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+32:00" + "'", str14.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTime();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("JulianChronology[+32:00,mdfw=1]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"JulianChronology[+32:00,mdfw=1]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        long long37 = preciseDateTimeField35.roundCeiling(1560632313085L);
        java.util.Locale locale38 = null;
        int int39 = preciseDateTimeField35.getMaximumShortTextLength(locale38);
        org.joda.time.DurationField durationField40 = preciseDateTimeField35.getRangeDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560632314000L + "'", long37 == 1560632314000L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(durationField40);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 1, (java.lang.Number) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 1, 0, (int) (short) 0, 46, 334, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 46 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isAfter((-1L));
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTime2.toString("0", locale6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime2.plus(readablePeriod8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.Instant instant5 = instant3.minus((long) (short) -1);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant3.plus(readableDuration6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Instant instant9 = instant7.minus(readableDuration8);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        int int4 = dateTimeFormatter2.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getShortName((-1900800000L));
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 1);
        long long10 = julianChronology6.add(78710399999L, 0L, 1258);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+32:00" + "'", str4.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 78710399999L + "'", long10 == 78710399999L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundFloorCopy();
        org.joda.time.DateTime dateTime7 = dateTime5.plusDays(13);
        boolean boolean8 = dateTime7.isEqualNow();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusDays((int) (short) 10);
        org.joda.time.LocalTime localTime4 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property5 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.Interval interval7 = property5.toInterval();
        try {
            org.joda.time.DateTime dateTime9 = property5.addToCopy(1560632313085L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 1560632313085 * 604800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(interval7);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        boolean boolean8 = delegatedDateTimeField4.isLeap((long) 46);
        try {
            long long11 = delegatedDateTimeField4.set((long) '#', "100");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
        boolean boolean10 = offsetDateTimeField4.isLenient();
        org.joda.time.DurationField durationField11 = offsetDateTimeField4.getRangeDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = buddhistChronology0.hours();
        org.joda.time.Chronology chronology3 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str2 = gJChronology1.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZoneUTC();
        java.lang.Appendable appendable5 = null;
        try {
            dateTimeFormatter0.printTo(appendable5, 1560632322909L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(13, 0, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("10", (java.lang.Number) (-13), (java.lang.Number) 334, (java.lang.Number) 15);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "1:59:05 PM");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 420, (long) 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4620L + "'", long2 == 4620L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isAfter((-1L));
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTime2.toString("0", locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str12 = dateTimeZone9.getShortName((-1900800000L));
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9, 1);
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime2.toMutableDateTime((org.joda.time.Chronology) julianChronology14);
        try {
            long long23 = julianChronology14.getDateTimeMillis(248, 46, 2019, (-1), 31, 12, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+32:00" + "'", str12.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
        org.joda.time.DateTime dateTime8 = dateTime4.withMillis((long) 12);
        org.joda.time.Instant instant10 = new org.joda.time.Instant((long) (-10));
        int int11 = dateTime8.compareTo((org.joda.time.ReadableInstant) instant10);
        org.joda.time.Instant instant13 = instant10.plus((long) (short) 1);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(instant13);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, 0, 0, 786);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronology();
        try {
            long long5 = dateTimeFormatter2.parseMillis("1258");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1258\" is malformed at \"58\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("35");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"35\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        long long8 = delegatedDateTimeField6.roundFloor((long) 0);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField6.getLeapDurationField();
        long long11 = delegatedDateTimeField6.roundHalfCeiling((long) (byte) 0);
        boolean boolean13 = delegatedDateTimeField6.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology14.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        int int21 = offsetDateTimeField18.getDifference(0L, 0L);
        int int23 = offsetDateTimeField18.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.MonthDay monthDay26 = monthDay24.withChronologyRetainFields(chronology25);
        int[] intArray32 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int33 = offsetDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) monthDay26, intArray32);
        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = copticChronology34.secondOfDay();
        org.joda.time.DateTimeField dateTimeField36 = copticChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 10);
        int int41 = offsetDateTimeField38.getDifference(0L, 0L);
        int int43 = offsetDateTimeField38.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay44 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.MonthDay monthDay46 = monthDay44.withChronologyRetainFields(chronology45);
        int[] intArray52 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int53 = offsetDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray52);
        boolean boolean54 = monthDay26.isEqual((org.joda.time.ReadablePartial) monthDay46);
        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = copticChronology55.secondOfDay();
        org.joda.time.DateTimeField dateTimeField57 = copticChronology55.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField57, 10);
        int int62 = offsetDateTimeField59.getDifference(0L, 0L);
        int int64 = offsetDateTimeField59.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay65 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.MonthDay monthDay67 = monthDay65.withChronologyRetainFields(chronology66);
        int[] intArray73 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int74 = offsetDateTimeField59.getMinimumValue((org.joda.time.ReadablePartial) monthDay67, intArray73);
        int[] intArray75 = monthDay67.getValues();
        int int76 = delegatedDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray75);
        boolean boolean77 = copticChronology0.equals((java.lang.Object) delegatedDateTimeField6);
        org.joda.time.Chronology chronology78 = copticChronology0.withUTC();
        org.joda.time.ReadablePeriod readablePeriod79 = null;
        try {
            int[] intArray81 = copticChronology0.get(readablePeriod79, (long) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1900800000L) + "'", long8 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 691200000L + "'", long11 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 11 + "'", int33 == 11);
        org.junit.Assert.assertNotNull(copticChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 11 + "'", int43 == 11);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 11 + "'", int53 == 11);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(copticChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 11 + "'", int64 == 11);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertNotNull(monthDay67);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 11 + "'", int74 == 11);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(chronology78);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 10, 6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int6 = offsetDateTimeField4.getMaximumValue(9936000000L);
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField4.getMinimumValue(readablePartial7);
        long long11 = offsetDateTimeField4.add(1560632320665L, (long) 13);
        int int13 = offsetDateTimeField4.get(1560632318274L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField4.getAsShortText(786, locale15);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 110 + "'", int6 == 110);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1971291520665L + "'", long11 == 1971291520665L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 46 + "'", int13 == 46);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "786" + "'", str16.equals("786"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.LocalDateTime localDateTime8 = null;
//        boolean boolean9 = dateTimeZone7.isLocalDateTimeGap(localDateTime8);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone7.getShortName(0L, locale11);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        java.lang.Object obj15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(obj15);
//        java.util.Locale locale17 = null;
//        java.util.Calendar calendar18 = dateTime16.toCalendar(locale17);
//        org.joda.time.DateTime dateTime20 = dateTime16.minusMillis(0);
//        org.joda.time.ReadableInstant readableInstant21 = null;
//        boolean boolean22 = dateTime16.isBefore(readableInstant21);
//        int int23 = cachedDateTimeZone14.getOffset((org.joda.time.ReadableInstant) dateTime16);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = cachedDateTimeZone14.getShortName(1L, locale25);
//        try {
//            org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((int) '4', 13, (int) (short) -1, (int) (short) 1, 13, 40, (org.joda.time.DateTimeZone) cachedDateTimeZone14);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 13 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+32:00" + "'", str12.equals("+32:00"));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
//        org.junit.Assert.assertNotNull(calendar18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 115200000 + "'", int23 == 115200000);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+32:00" + "'", str26.equals("+32:00"));
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("2017-08-05T13:59:03.031-07:00");
        org.junit.Assert.assertNotNull(dateTime1);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        int int9 = offsetDateTimeField4.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
//        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
//        java.lang.String str20 = monthDay12.toString();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "--06-15" + "'", str20.equals("--06-15"));
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology5 = gregorianChronology1.withZone(dateTimeZone4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTimeZone4.getShortName(10L, locale7);
        org.joda.time.Chronology chronology9 = gJChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology0.getZone();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+32:00" + "'", str8.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
        int int31 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
        int int51 = offsetDateTimeField46.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
        int int72 = offsetDateTimeField67.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology74 = null;
        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
        int[] intArray83 = monthDay75.getValues();
        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
        java.util.Locale locale88 = null;
        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
        int int90 = offsetDateTimeField4.getMinimumValue();
        long long92 = offsetDateTimeField4.roundHalfFloor((-1L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(copticChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
        org.junit.Assert.assertNotNull(monthDay73);
        org.junit.Assert.assertNotNull(monthDay75);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(monthDay86);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 11 + "'", int90 == 11);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + (-9936000000L) + "'", long92 == (-9936000000L));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology5 = gregorianChronology1.withZone(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology1.hours();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 100);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronology();
        java.lang.Appendable appendable4 = null;
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        long long14 = delegatedDateTimeField9.roundHalfCeiling((long) (byte) 0);
        boolean boolean16 = delegatedDateTimeField9.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = copticChronology17.secondOfDay();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology17.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
        int int24 = offsetDateTimeField21.getDifference(0L, 0L);
        int int26 = offsetDateTimeField21.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.MonthDay monthDay29 = monthDay27.withChronologyRetainFields(chronology28);
        int[] intArray35 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int36 = offsetDateTimeField21.getMinimumValue((org.joda.time.ReadablePartial) monthDay29, intArray35);
        org.joda.time.chrono.CopticChronology copticChronology37 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField38 = copticChronology37.secondOfDay();
        org.joda.time.DateTimeField dateTimeField39 = copticChronology37.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 10);
        int int44 = offsetDateTimeField41.getDifference(0L, 0L);
        int int46 = offsetDateTimeField41.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay47 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.MonthDay monthDay49 = monthDay47.withChronologyRetainFields(chronology48);
        int[] intArray55 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int56 = offsetDateTimeField41.getMinimumValue((org.joda.time.ReadablePartial) monthDay49, intArray55);
        boolean boolean57 = monthDay29.isEqual((org.joda.time.ReadablePartial) monthDay49);
        org.joda.time.chrono.CopticChronology copticChronology58 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField59 = copticChronology58.secondOfDay();
        org.joda.time.DateTimeField dateTimeField60 = copticChronology58.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, 10);
        int int65 = offsetDateTimeField62.getDifference(0L, 0L);
        int int67 = offsetDateTimeField62.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay68 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology69 = null;
        org.joda.time.MonthDay monthDay70 = monthDay68.withChronologyRetainFields(chronology69);
        int[] intArray76 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int77 = offsetDateTimeField62.getMinimumValue((org.joda.time.ReadablePartial) monthDay70, intArray76);
        int[] intArray78 = monthDay70.getValues();
        int int79 = delegatedDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay49, intArray78);
        org.joda.time.MonthDay monthDay81 = monthDay49.plusDays((int) (short) 100);
        org.joda.time.chrono.ISOChronology iSOChronology82 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay83 = new org.joda.time.MonthDay((java.lang.Object) monthDay81, (org.joda.time.Chronology) iSOChronology82);
        org.joda.time.MonthDay monthDay85 = monthDay81.minusMonths((int) '#');
        try {
            dateTimeFormatter2.printTo(appendable4, (org.joda.time.ReadablePartial) monthDay85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 691200000L + "'", long14 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 11 + "'", int26 == 11);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 11 + "'", int36 == 11);
        org.junit.Assert.assertNotNull(copticChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 11 + "'", int46 == 11);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 11 + "'", int56 == 11);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(copticChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 11 + "'", int67 == 11);
        org.junit.Assert.assertNotNull(monthDay68);
        org.junit.Assert.assertNotNull(monthDay70);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 11 + "'", int77 == 11);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertNotNull(monthDay81);
        org.junit.Assert.assertNotNull(iSOChronology82);
        org.junit.Assert.assertNotNull(monthDay85);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.ReadablePartial readablePartial7 = null;
        java.util.Locale locale9 = null;
        java.lang.String str10 = delegatedDateTimeField4.getAsText(readablePartial7, 0, locale9);
        int int12 = delegatedDateTimeField4.getMinimumValue(1560632313085L);
        int int13 = delegatedDateTimeField4.getMaximumValue();
        long long16 = delegatedDateTimeField4.addWrapField((long) (-13), (-420));
        long long18 = delegatedDateTimeField4.remainder((long) 654);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 21859199987L + "'", long16 == 21859199987L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1900800654L + "'", long18 == 1900800654L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        java.lang.String str8 = delegatedDateTimeField4.toString();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsShortText(13, locale10);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getLeapDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DateTimeField[monthOfYear]" + "'", str8.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13" + "'", str11.equals("13"));
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        java.util.Locale locale14 = null;
        int int15 = delegatedDateTimeField9.getMaximumShortTextLength(locale14);
        long long18 = delegatedDateTimeField9.add((-31449599999L), 56);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(0L);
        org.joda.time.MonthDay monthDay22 = monthDay20.withDayOfMonth(10);
        int[] intArray24 = null;
        try {
            int[] intArray26 = delegatedDateTimeField9.addWrapField((org.joda.time.ReadablePartial) monthDay20, 52, intArray24, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 105148800001L + "'", long18 == 105148800001L);
        org.junit.Assert.assertNotNull(monthDay22);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) (short) 10);
        boolean boolean8 = delegatedDateTimeField4.isLeap((-1900800000L));
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField4.getWrappedField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology6.secondOfDay();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology6.secondOfDay();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str11 = gregorianChronology10.toString();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology14 = gregorianChronology10.withZone(dateTimeZone13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = dateTimeZone13.getShortName(10L, locale16);
        org.joda.time.Chronology chronology18 = gJChronology9.withZone(dateTimeZone13);
        org.joda.time.Chronology chronology19 = copticChronology6.withZone(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone20 = copticChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
        try {
            org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(165, 75535, 871, 1, 0, 248, dateTimeZone20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 248 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GregorianChronology[UTC]" + "'", str11.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+32:00" + "'", str17.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getShortName((-1900800000L));
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 1);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.dayOfMonth();
        boolean boolean9 = julianChronology6.equals((java.lang.Object) 36720000100L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+32:00" + "'", str4.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean4 = dateTime2.isAfter((-1L));
//        org.joda.time.DateTime dateTime6 = dateTime2.plus((long) (short) 10);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusYears(100);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4716305952941L + "'", long9 == 4716305952941L);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(2, 40, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isBefore(1L);
        org.joda.time.DateTime dateTime6 = dateTime2.withSecondOfMinute(0);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime2.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime10 = null;
        boolean boolean11 = dateTimeZone9.isLocalDateTimeGap(localDateTime10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = dateTimeZone9.getShortName(0L, locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        long long18 = dateTimeZone7.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone16, 100L);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone16.getUncachedZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+32:00" + "'", str14.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-115199899L) + "'", long18 == (-115199899L));
        org.junit.Assert.assertNotNull(dateTimeZone19);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        java.lang.String str5 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[UTC]" + "'", str5.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.Locale locale2 = null;
        java.util.Calendar calendar3 = dateTime1.toCalendar(locale2);
        org.joda.time.DateTime dateTime5 = dateTime1.minusMillis(0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        boolean boolean7 = dateTime1.isBefore(readableInstant6);
        org.joda.time.DateTime dateTime9 = dateTime1.plusMinutes(871);
        org.junit.Assert.assertNotNull(calendar3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(46, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusDays((int) (short) 10);
        org.joda.time.LocalTime localTime4 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property5 = dateTime1.weekOfWeekyear();
        org.joda.time.Interval interval6 = property5.toInterval();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(interval6);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        int int9 = offsetDateTimeField4.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
//        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
//        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField21 = copticChronology20.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology20.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 10);
//        int int27 = offsetDateTimeField24.getDifference(0L, 0L);
//        int int29 = offsetDateTimeField24.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology31 = null;
//        org.joda.time.MonthDay monthDay32 = monthDay30.withChronologyRetainFields(chronology31);
//        int[] intArray38 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int39 = offsetDateTimeField24.getMinimumValue((org.joda.time.ReadablePartial) monthDay32, intArray38);
//        boolean boolean40 = monthDay12.isEqual((org.joda.time.ReadablePartial) monthDay32);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        java.lang.String str42 = monthDay12.toString(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(copticChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 11 + "'", int39 == 11);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "����-06-15T��:��:��.000" + "'", str42.equals("����-06-15T��:��:��.000"));
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology1.weekyearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = copticChronology1.add(readablePeriod4, 1L, (int) (short) 1);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) 44, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.secondOfDay();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        long long15 = delegatedDateTimeField13.roundFloor((long) 0);
        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getLeapDurationField();
        long long18 = delegatedDateTimeField13.roundHalfCeiling((long) (byte) 0);
        boolean boolean20 = delegatedDateTimeField13.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.secondOfDay();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology21.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, 10);
        int int28 = offsetDateTimeField25.getDifference(0L, 0L);
        int int30 = offsetDateTimeField25.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay31 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.MonthDay monthDay33 = monthDay31.withChronologyRetainFields(chronology32);
        int[] intArray39 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int40 = offsetDateTimeField25.getMinimumValue((org.joda.time.ReadablePartial) monthDay33, intArray39);
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField42 = copticChronology41.secondOfDay();
        org.joda.time.DateTimeField dateTimeField43 = copticChronology41.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, 10);
        int int48 = offsetDateTimeField45.getDifference(0L, 0L);
        int int50 = offsetDateTimeField45.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay51 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology52 = null;
        org.joda.time.MonthDay monthDay53 = monthDay51.withChronologyRetainFields(chronology52);
        int[] intArray59 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int60 = offsetDateTimeField45.getMinimumValue((org.joda.time.ReadablePartial) monthDay53, intArray59);
        boolean boolean61 = monthDay33.isEqual((org.joda.time.ReadablePartial) monthDay53);
        org.joda.time.chrono.CopticChronology copticChronology62 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField63 = copticChronology62.secondOfDay();
        org.joda.time.DateTimeField dateTimeField64 = copticChronology62.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField64, 10);
        int int69 = offsetDateTimeField66.getDifference(0L, 0L);
        int int71 = offsetDateTimeField66.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay72 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology73 = null;
        org.joda.time.MonthDay monthDay74 = monthDay72.withChronologyRetainFields(chronology73);
        int[] intArray80 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int81 = offsetDateTimeField66.getMinimumValue((org.joda.time.ReadablePartial) monthDay74, intArray80);
        int[] intArray82 = monthDay74.getValues();
        int int83 = delegatedDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) monthDay53, intArray82);
        org.joda.time.MonthDay monthDay85 = monthDay53.plusDays((int) (short) 100);
        boolean boolean86 = monthDay8.isEqual((org.joda.time.ReadablePartial) monthDay85);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1900800000L) + "'", long15 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 691200000L + "'", long18 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 11 + "'", int40 == 11);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 11 + "'", int50 == 11);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(monthDay53);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 11 + "'", int60 == 11);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(copticChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 11 + "'", int71 == 11);
        org.junit.Assert.assertNotNull(monthDay72);
        org.junit.Assert.assertNotNull(monthDay74);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 11 + "'", int81 == 11);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertNotNull(monthDay85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean3 = dateTime2.isBeforeNow();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        java.util.Locale locale9 = null;
        java.lang.String str10 = dateTimeZone5.getShortName(0L, locale9);
        org.joda.time.DateTime dateTime11 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.ReadableInstant readableInstant12 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, readableInstant12, 110);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 110");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+32:00" + "'", str10.equals("+32:00"));
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', (int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 1, (int) (short) 100, 20, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("166");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"166/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
//        java.lang.String str7 = dateTime6.toString();
//        org.joda.time.Instant instant9 = org.joda.time.Instant.parse("0");
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.Instant instant12 = instant9.withDurationAdded(readableDuration10, 110);
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) instant9);
//        java.lang.Object obj14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(obj14);
//        org.joda.time.DateTime dateTime17 = dateTime15.plusDays((int) (short) 10);
//        org.joda.time.LocalTime localTime18 = dateTime15.toLocalTime();
//        int int19 = dateTime15.getEra();
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime15.plus(readableDuration20);
//        int int22 = dateTime6.compareTo((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime dateTime24 = dateTime6.withEra(0);
//        org.junit.Assert.assertNotNull(gregorianCalendar2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2017-08-05T13:59:15.479-07:00" + "'", str7.equals("2017-08-05T13:59:15.479-07:00"));
//        org.junit.Assert.assertNotNull(instant9);
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        org.joda.time.DateTime.Property property8 = dateTime6.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        int int9 = offsetDateTimeField4.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
//        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
//        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
//        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
//        int int26 = offsetDateTimeField4.getLeapAmount((-1900800000L));
//        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField28 = copticChronology27.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField29 = copticChronology27.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, 10);
//        int int34 = offsetDateTimeField31.getDifference(0L, 0L);
//        int int36 = offsetDateTimeField31.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay37 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology38 = null;
//        org.joda.time.MonthDay monthDay39 = monthDay37.withChronologyRetainFields(chronology38);
//        int[] intArray45 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int46 = offsetDateTimeField31.getMinimumValue((org.joda.time.ReadablePartial) monthDay39, intArray45);
//        boolean boolean48 = monthDay39.equals((java.lang.Object) (-1900800000L));
//        int int49 = monthDay39.getDayOfMonth();
//        java.lang.String str50 = monthDay39.toString();
//        org.joda.time.chrono.CopticChronology copticChronology52 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField53 = copticChronology52.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField54 = copticChronology52.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, 10);
//        int int58 = offsetDateTimeField56.getMaximumValue(9936000000L);
//        org.joda.time.MonthDay monthDay59 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology60 = null;
//        org.joda.time.MonthDay monthDay61 = monthDay59.withChronologyRetainFields(chronology60);
//        org.joda.time.chrono.CopticChronology copticChronology62 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField63 = copticChronology62.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField64 = copticChronology62.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField64, 10);
//        int int69 = offsetDateTimeField66.getDifference(0L, 0L);
//        int int71 = offsetDateTimeField66.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay72 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology73 = null;
//        org.joda.time.MonthDay monthDay74 = monthDay72.withChronologyRetainFields(chronology73);
//        int[] intArray80 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int81 = offsetDateTimeField66.getMinimumValue((org.joda.time.ReadablePartial) monthDay74, intArray80);
//        int[] intArray82 = monthDay74.getValues();
//        int int83 = offsetDateTimeField56.getMinimumValue((org.joda.time.ReadablePartial) monthDay59, intArray82);
//        try {
//            int[] intArray85 = offsetDateTimeField4.addWrapField((org.joda.time.ReadablePartial) monthDay39, 4, intArray82, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(copticChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 11 + "'", int36 == 11);
//        org.junit.Assert.assertNotNull(monthDay37);
//        org.junit.Assert.assertNotNull(monthDay39);
//        org.junit.Assert.assertNotNull(intArray45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 11 + "'", int46 == 11);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 15 + "'", int49 == 15);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "--06-15" + "'", str50.equals("--06-15"));
//        org.junit.Assert.assertNotNull(copticChronology52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 110 + "'", int58 == 110);
//        org.junit.Assert.assertNotNull(monthDay59);
//        org.junit.Assert.assertNotNull(monthDay61);
//        org.junit.Assert.assertNotNull(copticChronology62);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 11 + "'", int71 == 11);
//        org.junit.Assert.assertNotNull(monthDay72);
//        org.junit.Assert.assertNotNull(monthDay74);
//        org.junit.Assert.assertNotNull(intArray80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 11 + "'", int81 == 11);
//        org.junit.Assert.assertNotNull(intArray82);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 11 + "'", int83 == 11);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(11);
        java.io.Writer writer4 = null;
        try {
            dateTimeFormatter0.printTo(writer4, (long) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1560632318274L, (long) 871);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1359310749216654L + "'", long2 == 1359310749216654L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long9 = offsetDateTimeField4.remainder(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay10, 0, locale12);
        long long15 = offsetDateTimeField4.roundFloor(1567987200000L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9936000000L + "'", long9 == 9936000000L);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1567987200000L + "'", long15 == 1567987200000L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 1560632347355L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
        int int31 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
        int int51 = offsetDateTimeField46.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
        int int72 = offsetDateTimeField67.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology74 = null;
        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
        int[] intArray83 = monthDay75.getValues();
        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
        java.util.Locale locale88 = null;
        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
        org.joda.time.MonthDay monthDay91 = monthDay86.plusMonths((int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType92 = null;
        int int93 = monthDay86.indexOf(dateTimeFieldType92);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(copticChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
        org.junit.Assert.assertNotNull(monthDay73);
        org.junit.Assert.assertNotNull(monthDay75);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(monthDay86);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
        org.junit.Assert.assertNotNull(monthDay91);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        int int9 = offsetDateTimeField4.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
//        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
//        boolean boolean21 = monthDay12.equals((java.lang.Object) (-1900800000L));
//        int int22 = monthDay12.getDayOfMonth();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
//        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.MonthDay monthDay26 = monthDay24.withChronologyRetainFields(chronology25);
//        java.lang.String str27 = dateTimeFormatter23.print((org.joda.time.ReadablePartial) monthDay24);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
//        org.joda.time.MonthDay monthDay32 = monthDay24.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology31);
//        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField34 = copticChronology33.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField35 = copticChronology33.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, 10);
//        int int40 = offsetDateTimeField37.getDifference(0L, 0L);
//        int int42 = offsetDateTimeField37.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay43 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology44 = null;
//        org.joda.time.MonthDay monthDay45 = monthDay43.withChronologyRetainFields(chronology44);
//        int[] intArray51 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int52 = offsetDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay45, intArray51);
//        long long55 = offsetDateTimeField37.add((long) (short) 1, (int) (short) -1);
//        int int57 = offsetDateTimeField37.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = offsetDateTimeField37.getType();
//        int int59 = monthDay32.indexOf(dateTimeFieldType58);
//        try {
//            org.joda.time.MonthDay.Property property60 = monthDay12.property(dateTimeFieldType58);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyearOfCentury' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertNotNull(monthDay26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "��" + "'", str27.equals("��"));
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(copticChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 11 + "'", int42 == 11);
//        org.junit.Assert.assertNotNull(monthDay43);
//        org.junit.Assert.assertNotNull(monthDay45);
//        org.junit.Assert.assertNotNull(intArray51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 11 + "'", int52 == 11);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-31449599999L) + "'", long55 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
//    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        java.util.Locale locale2 = null;
//        java.util.Calendar calendar3 = dateTime1.toCalendar(locale2);
//        org.joda.time.DateTime dateTime5 = dateTime1.minusMillis(0);
//        org.joda.time.LocalTime localTime6 = dateTime1.toLocalTime();
//        int int7 = dateTime1.getYear();
//        org.joda.time.DateTime dateTime9 = dateTime1.plusYears(0);
//        org.junit.Assert.assertNotNull(calendar3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long9 = offsetDateTimeField4.remainder(0L);
        java.util.Locale locale12 = null;
        long long13 = offsetDateTimeField4.set((long) 10, "100", locale12);
        org.joda.time.DurationField durationField14 = offsetDateTimeField4.getDurationField();
        org.joda.time.DurationField durationField15 = offsetDateTimeField4.getLeapDurationField();
        long long18 = offsetDateTimeField4.addWrapField((long) (-1), 44);
        try {
            long long21 = offsetDateTimeField4.add((long) 1, 1641427200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1641427200000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9936000000L + "'", long9 == 9936000000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 94953600010L + "'", long13 == 94953600010L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1767225600001L) + "'", long18 == (-1767225600001L));
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
//        org.joda.time.DateTime dateTime8 = dateTime4.withMillisOfDay(248);
//        org.joda.time.DateTime dateTime10 = dateTime8.withMillis(0L);
//        int int11 = dateTime10.getDayOfYear();
//        org.joda.time.DateTime dateTime13 = dateTime10.plusYears(6);
//        long long14 = dateTime10.getMillis();
//        org.junit.Assert.assertNotNull(gregorianCalendar2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 365 + "'", int11 == 365);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) 10.0d, "");
        illegalFieldValueException30.prependMessage("10");
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray4 = copticChronology0.get(readablePeriod2, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
//        org.joda.time.DurationField durationField4 = gJChronology3.hours();
//        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withDefaultYear(0);
//        java.lang.Object obj9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(obj9);
//        java.util.GregorianCalendar gregorianCalendar11 = dateTime10.toGregorianCalendar();
//        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
//        org.joda.time.DateTime dateTime13 = property12.getDateTime();
//        java.lang.String str14 = dateTimeFormatter8.print((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime.Property property15 = dateTime13.year();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime13, (int) (byte) 1);
//        int int18 = dateTime13.getWeekyear();
//        int int19 = dateTime13.getMinuteOfDay();
//        try {
//            org.joda.time.DateTime dateTime21 = dateTime13.withYearOfEra((-33));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -33 for yearOfEra must be in the range [1,292278993]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(gregorianCalendar11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1:59:17 PM" + "'", str14.equals("1:59:17 PM"));
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 839 + "'", int19 == 839);
//    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.minusYears((int) (byte) 0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632357150L + "'", long2 == 1560632357150L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        java.util.Locale locale14 = null;
        int int15 = delegatedDateTimeField9.getMaximumShortTextLength(locale14);
        int int16 = delegatedDateTimeField9.getMinimumValue();
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = copticChronology17.secondOfDay();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology17.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
        long long23 = delegatedDateTimeField21.roundFloor((long) 0);
        org.joda.time.DurationField durationField24 = delegatedDateTimeField21.getLeapDurationField();
        long long26 = delegatedDateTimeField21.roundHalfCeiling((long) (byte) 0);
        boolean boolean28 = delegatedDateTimeField21.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = copticChronology29.secondOfDay();
        org.joda.time.DateTimeField dateTimeField31 = copticChronology29.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        int int36 = offsetDateTimeField33.getDifference(0L, 0L);
        int int38 = offsetDateTimeField33.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay39 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology40 = null;
        org.joda.time.MonthDay monthDay41 = monthDay39.withChronologyRetainFields(chronology40);
        int[] intArray47 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int48 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) monthDay41, intArray47);
        org.joda.time.chrono.CopticChronology copticChronology49 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = copticChronology49.secondOfDay();
        org.joda.time.DateTimeField dateTimeField51 = copticChronology49.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, 10);
        int int56 = offsetDateTimeField53.getDifference(0L, 0L);
        int int58 = offsetDateTimeField53.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay59 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology60 = null;
        org.joda.time.MonthDay monthDay61 = monthDay59.withChronologyRetainFields(chronology60);
        int[] intArray67 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int68 = offsetDateTimeField53.getMinimumValue((org.joda.time.ReadablePartial) monthDay61, intArray67);
        boolean boolean69 = monthDay41.isEqual((org.joda.time.ReadablePartial) monthDay61);
        org.joda.time.chrono.CopticChronology copticChronology70 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField71 = copticChronology70.secondOfDay();
        org.joda.time.DateTimeField dateTimeField72 = copticChronology70.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField74 = new org.joda.time.field.OffsetDateTimeField(dateTimeField72, 10);
        int int77 = offsetDateTimeField74.getDifference(0L, 0L);
        int int79 = offsetDateTimeField74.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay80 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology81 = null;
        org.joda.time.MonthDay monthDay82 = monthDay80.withChronologyRetainFields(chronology81);
        int[] intArray88 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int89 = offsetDateTimeField74.getMinimumValue((org.joda.time.ReadablePartial) monthDay82, intArray88);
        int[] intArray90 = monthDay82.getValues();
        int int91 = delegatedDateTimeField21.getMinimumValue((org.joda.time.ReadablePartial) monthDay61, intArray90);
        org.joda.time.MonthDay monthDay93 = monthDay61.plusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod94 = null;
        org.joda.time.MonthDay monthDay96 = monthDay61.withPeriodAdded(readablePeriod94, (int) (byte) 0);
        int int97 = delegatedDateTimeField9.getMaximumValue((org.joda.time.ReadablePartial) monthDay96);
        org.joda.time.MonthDay monthDay99 = monthDay96.withMonthOfYear(11);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1900800000L) + "'", long23 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 691200000L + "'", long26 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 11 + "'", int38 == 11);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 11 + "'", int48 == 11);
        org.junit.Assert.assertNotNull(copticChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 11 + "'", int58 == 11);
        org.junit.Assert.assertNotNull(monthDay59);
        org.junit.Assert.assertNotNull(monthDay61);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 11 + "'", int68 == 11);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(copticChronology70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 11 + "'", int79 == 11);
        org.junit.Assert.assertNotNull(monthDay80);
        org.junit.Assert.assertNotNull(monthDay82);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 11 + "'", int89 == 11);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
        org.junit.Assert.assertNotNull(monthDay93);
        org.junit.Assert.assertNotNull(monthDay96);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 13 + "'", int97 == 13);
        org.junit.Assert.assertNotNull(monthDay99);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone1.getShortName(0L, locale5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+32:00" + "'", str6.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.ReadablePartial readablePartial7 = null;
        java.util.Locale locale9 = null;
        java.lang.String str10 = delegatedDateTimeField4.getAsText(readablePartial7, 0, locale9);
        int int12 = delegatedDateTimeField4.getMinimumValue(1560632313085L);
        int int13 = delegatedDateTimeField4.getMaximumValue();
        long long16 = delegatedDateTimeField4.addWrapField((long) (-13), (-420));
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField4.getAsShortText((long) (-6), locale18);
        long long22 = delegatedDateTimeField4.addWrapField(1900800654L, 115200000);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 21859199987L + "'", long16 == 21859199987L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "4" + "'", str19.equals("4"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 17452800654L + "'", long22 == 17452800654L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (byte) 0, (java.lang.Number) 56, (java.lang.Number) 691200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property5.getFieldType();
//        org.joda.time.DateTimeField dateTimeField7 = property5.getField();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632357897L + "'", long2 == 1560632357897L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFieldType6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long9 = offsetDateTimeField4.remainder(0L);
        java.util.Locale locale12 = null;
        long long13 = offsetDateTimeField4.set((long) 10, "100", locale12);
        org.joda.time.DurationField durationField14 = offsetDateTimeField4.getDurationField();
        org.joda.time.DurationField durationField15 = offsetDateTimeField4.getLeapDurationField();
        int int16 = offsetDateTimeField4.getMinimumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.util.Locale locale18 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter17.withLocale(locale18);
        org.joda.time.LocalTime localTime21 = dateTimeFormatter19.parseLocalTime("1:58:55 PM");
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localTime21, 624, locale23);
        long long26 = offsetDateTimeField4.roundCeiling((long) (byte) 1);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9936000000L + "'", long9 == 9936000000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 94953600010L + "'", long13 == 94953600010L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "624" + "'", str24.equals("624"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 22118400000L + "'", long26 == 22118400000L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone1.getShortName(0L, locale5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+32:00" + "'", str6.equals("+32:00"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) (short) 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long9 = offsetDateTimeField4.remainder(0L);
        java.util.Locale locale12 = null;
        long long13 = offsetDateTimeField4.set((long) 10, "100", locale12);
        long long15 = offsetDateTimeField4.roundFloor(0L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9936000000L + "'", long9 == 9936000000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 94953600010L + "'", long13 == 94953600010L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-9936000000L) + "'", long15 == (-9936000000L));
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
//        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
//        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
//        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
//        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
//        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
//        int int31 = offsetDateTimeField26.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
//        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
//        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
//        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
//        int int51 = offsetDateTimeField46.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology53 = null;
//        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
//        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
//        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
//        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
//        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
//        int int72 = offsetDateTimeField67.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology74 = null;
//        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
//        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
//        int[] intArray83 = monthDay75.getValues();
//        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
//        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
//        java.util.Locale locale88 = null;
//        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
//        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
//        java.lang.String str91 = property90.getAsText();
//        java.util.Locale locale92 = null;
//        java.lang.String str93 = property90.getAsText(locale92);
//        int int94 = property90.getMinimumValueOverall();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
//        org.junit.Assert.assertNotNull(copticChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(copticChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertNotNull(monthDay86);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
//        org.junit.Assert.assertNotNull(property90);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "23" + "'", str91.equals("23"));
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "23" + "'", str93.equals("23"));
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1 + "'", int94 == 1);
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusDays((int) (short) 10);
//        org.joda.time.LocalTime localTime4 = dateTime1.toLocalTime();
//        org.joda.time.DateTime.Property property5 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
//        java.lang.Object obj7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(obj7);
//        java.util.GregorianCalendar gregorianCalendar9 = dateTime8.toGregorianCalendar();
//        org.joda.time.DateTime.Property property10 = dateTime8.dayOfYear();
//        org.joda.time.DateTime dateTime11 = property10.getDateTime();
//        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks((int) 'a');
//        java.lang.String str14 = dateTime13.toString();
//        org.joda.time.Instant instant16 = org.joda.time.Instant.parse("0");
//        org.joda.time.ReadableDuration readableDuration17 = null;
//        org.joda.time.Instant instant19 = instant16.withDurationAdded(readableDuration17, 110);
//        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) instant16);
//        int int21 = property5.compareTo((org.joda.time.ReadableInstant) instant16);
//        long long22 = instant16.getMillis();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianCalendar9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2017-08-05T13:59:18.990-07:00" + "'", str14.equals("2017-08-05T13:59:18.990-07:00"));
//        org.junit.Assert.assertNotNull(instant16);
//        org.junit.Assert.assertNotNull(instant19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62167190822000L) + "'", long22 == (-62167190822000L));
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean3 = dateTime2.isBeforeNow();
        java.util.Date date4 = dateTime2.toDate();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.Locale locale2 = null;
        java.util.Calendar calendar3 = dateTime1.toCalendar(locale2);
        org.joda.time.DateTime dateTime5 = dateTime1.minusMillis(0);
        org.joda.time.DateTime dateTime7 = dateTime5.withHourOfDay(20);
        org.junit.Assert.assertNotNull(calendar3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        long long36 = preciseDateTimeField35.getUnitMillis();
        boolean boolean37 = preciseDateTimeField35.isLenient();
        java.lang.String str39 = preciseDateTimeField35.getAsShortText((long) 0);
        java.lang.String str41 = preciseDateTimeField35.getAsShortText((long) 624);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1000L + "'", long36 == 1000L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "0" + "'", str41.equals("0"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int6 = offsetDateTimeField4.getMaximumValue(9936000000L);
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField4.getMinimumValue(readablePartial7);
        long long11 = offsetDateTimeField4.add(1560632320665L, (long) 13);
        int int13 = offsetDateTimeField4.get(1560632318274L);
        long long15 = offsetDateTimeField4.roundHalfEven(691200000L);
        try {
            long long18 = offsetDateTimeField4.set(9936000000L, "786");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 786 for weekyearOfCentury must be in the range [11,110]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 110 + "'", int6 == 110);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1971291520665L + "'", long11 == 1971291520665L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 46 + "'", int13 == 46);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-9936000000L) + "'", long15 == (-9936000000L));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.DurationField durationField13 = delegatedDateTimeField4.getRangeDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        long long11 = offsetDateTimeField4.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9936000000L) + "'", long11 == (-9936000000L));
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean5 = dateTime3.isBefore(1L);
//        org.joda.time.DateTime dateTime7 = dateTime3.withSecondOfMinute(0);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime3.getZone();
//        int int9 = dateTime3.getCenturyOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.String str11 = gregorianChronology10.toString();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.Chronology chronology14 = gregorianChronology10.withZone(dateTimeZone13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone13.getShortName(10L, locale16);
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone13.getName((long) 31, locale20);
//        org.joda.time.DateTime dateTime22 = dateTime3.withZoneRetainFields(dateTimeZone13);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter0.withZone(dateTimeZone13);
//        java.lang.Integer int24 = dateTimeFormatter23.getPivotYear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GregorianChronology[UTC]" + "'", str11.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+32:00" + "'", str17.equals("+32:00"));
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+32:00" + "'", str21.equals("+32:00"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNull(int24);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("2017-08-05T13:59:00.693-07:00", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"2017-08-05T13:59:00.693-07:00/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusDays((int) (short) 10);
//        org.joda.time.LocalTime localTime4 = dateTime1.toLocalTime();
//        org.joda.time.DateTime.Property property5 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
//        java.lang.Object obj7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(obj7);
//        java.util.GregorianCalendar gregorianCalendar9 = dateTime8.toGregorianCalendar();
//        org.joda.time.DateTime.Property property10 = dateTime8.dayOfYear();
//        org.joda.time.DateTime dateTime11 = property10.getDateTime();
//        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks((int) 'a');
//        java.lang.String str14 = dateTime13.toString();
//        org.joda.time.Instant instant16 = org.joda.time.Instant.parse("0");
//        org.joda.time.ReadableDuration readableDuration17 = null;
//        org.joda.time.Instant instant19 = instant16.withDurationAdded(readableDuration17, 110);
//        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime13, (org.joda.time.ReadableInstant) instant16);
//        int int21 = property5.compareTo((org.joda.time.ReadableInstant) instant16);
//        org.joda.time.Instant instant23 = instant16.withMillis((long) 786);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianCalendar9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2017-08-05T13:59:19.695-07:00" + "'", str14.equals("2017-08-05T13:59:19.695-07:00"));
//        org.junit.Assert.assertNotNull(instant16);
//        org.junit.Assert.assertNotNull(instant19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(instant23);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.fullTime();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("786", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"786\" is malformed at \"6\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundFloorCopy();
        org.joda.time.DateTime dateTime7 = property3.addToCopy(0);
        int int8 = property3.getLeapAmount();
        org.joda.time.Interval interval9 = property3.toInterval();
        org.joda.time.ReadableInterval readableInterval10 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval9);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(readableInterval10);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology8.weekyearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        long long14 = copticChronology8.add(readablePeriod11, 1L, (int) (short) 1);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) 44, (org.joda.time.Chronology) copticChronology8);
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(420, 10, 0, 0, 12, 4, (int) (short) -1, (org.joda.time.Chronology) copticChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) -1);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
//        java.lang.String str2 = dateTimeFormatter0.print(85017600000L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5:00:00 PM PDT" + "'", str2.equals("5:00:00 PM PDT"));
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getShortName((-1900800000L));
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 1);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.minuteOfDay();
        java.lang.String str8 = julianChronology6.toString();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.yearOfEra();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology6.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology6.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+32:00" + "'", str4.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "JulianChronology[+32:00,mdfw=1]" + "'", str8.equals("JulianChronology[+32:00,mdfw=1]"));
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
//        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
//        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
//        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
//        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
//        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
//        int int31 = offsetDateTimeField26.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
//        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
//        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
//        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
//        int int51 = offsetDateTimeField46.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology53 = null;
//        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
//        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
//        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
//        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
//        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
//        int int72 = offsetDateTimeField67.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology74 = null;
//        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
//        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
//        int[] intArray83 = monthDay75.getValues();
//        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
//        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
//        java.util.Locale locale88 = null;
//        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
//        org.joda.time.MonthDay monthDay91 = monthDay86.plusMonths((int) ' ');
//        int int92 = monthDay86.getMonthOfYear();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
//        org.junit.Assert.assertNotNull(copticChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(copticChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertNotNull(monthDay86);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
//        org.junit.Assert.assertNotNull(monthDay91);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology5 = gregorianChronology1.withZone(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology1.hours();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        try {
            org.joda.time.LocalTime localTime9 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withYearOfEra(59);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
//        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
//        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
//        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
//        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
//        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
//        int int31 = offsetDateTimeField26.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
//        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
//        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
//        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
//        int int51 = offsetDateTimeField46.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology53 = null;
//        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
//        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
//        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
//        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
//        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
//        int int72 = offsetDateTimeField67.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology74 = null;
//        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
//        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
//        int[] intArray83 = monthDay75.getValues();
//        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
//        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
//        java.util.Locale locale88 = null;
//        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
//        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
//        java.lang.String str91 = property90.getAsText();
//        int int92 = property90.get();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
//        org.junit.Assert.assertNotNull(copticChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(copticChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertNotNull(monthDay86);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
//        org.junit.Assert.assertNotNull(property90);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "7" + "'", str91.equals("7"));
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 7 + "'", int92 == 7);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology1.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        long long7 = delegatedDateTimeField5.roundFloor((long) 0);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField5.getLeapDurationField();
        java.lang.String str9 = delegatedDateTimeField5.toString();
        org.joda.time.DurationField durationField10 = delegatedDateTimeField5.getLeapDurationField();
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.secondOfDay();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 10);
        int int18 = offsetDateTimeField15.getDifference(0L, 0L);
        int int20 = offsetDateTimeField15.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.MonthDay monthDay23 = monthDay21.withChronologyRetainFields(chronology22);
        int[] intArray29 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int30 = offsetDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) monthDay23, intArray29);
        long long33 = offsetDateTimeField15.add((long) (short) 1, (int) (short) -1);
        int int35 = offsetDateTimeField15.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField15.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException38 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone40);
        org.joda.time.DurationField durationField42 = iSOChronology41.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology43.monthOfYear();
        org.joda.time.DurationField durationField45 = buddhistChronology43.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField46 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType36, durationField42, durationField45);
        long long48 = preciseDateTimeField46.roundCeiling(0L);
        org.joda.time.DurationField durationField49 = preciseDateTimeField46.getRangeDurationField();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField50 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField10, durationField49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1900800000L) + "'", long7 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DateTimeField[monthOfYear]" + "'", str9.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 11 + "'", int20 == 11);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-31449599999L) + "'", long33 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(buddhistChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(durationField49);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        long long37 = preciseDateTimeField35.roundCeiling(1560632313085L);
        java.util.Locale locale38 = null;
        int int39 = preciseDateTimeField35.getMaximumShortTextLength(locale38);
        int int40 = preciseDateTimeField35.getMinimumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560632314000L + "'", long37 == 1560632314000L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        long long37 = preciseDateTimeField35.roundCeiling(1560632313085L);
        java.util.Locale locale38 = null;
        int int39 = preciseDateTimeField35.getMaximumShortTextLength(locale38);
        long long40 = preciseDateTimeField35.getUnitMillis();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560632314000L + "'", long37 == 1560632314000L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1000L + "'", long40 == 1000L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
//        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
//        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
//        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
//        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
//        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
//        int int31 = offsetDateTimeField26.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
//        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
//        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
//        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
//        int int51 = offsetDateTimeField46.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology53 = null;
//        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
//        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
//        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
//        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
//        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
//        int int72 = offsetDateTimeField67.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology74 = null;
//        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
//        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
//        int[] intArray83 = monthDay75.getValues();
//        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
//        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
//        java.util.Locale locale88 = null;
//        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
//        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
//        java.lang.String str91 = property90.getAsString();
//        java.util.Locale locale92 = null;
//        int int93 = property90.getMaximumTextLength(locale92);
//        java.lang.String str94 = property90.getName();
//        org.joda.time.DurationField durationField95 = property90.getDurationField();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
//        org.junit.Assert.assertNotNull(copticChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(copticChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertNotNull(monthDay86);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
//        org.junit.Assert.assertNotNull(property90);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "7" + "'", str91.equals("7"));
//        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 2 + "'", int93 == 2);
//        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "dayOfMonth" + "'", str94.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(durationField95);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        java.lang.Object obj2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendSecondOfMinute((-6));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        long long37 = preciseDateTimeField35.roundCeiling(0L);
        long long39 = preciseDateTimeField35.roundCeiling(78710399999L);
        int int40 = preciseDateTimeField35.getRange();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 78710400000L + "'", long39 == 78710400000L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3600 + "'", int40 == 3600);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        java.lang.Object obj6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(obj6);
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = dateTime7.toCalendar(locale8);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime7.toMutableDateTime(dateTimeZone11);
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) dateTime7);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
//        org.junit.Assert.assertNotNull(calendar9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(chronology14);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getShortName((-1900800000L));
        java.util.TimeZone timeZone5 = dateTimeZone1.toTimeZone();
        java.lang.Object obj6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(obj6);
        java.util.Locale locale8 = null;
        java.util.Calendar calendar9 = dateTime7.toCalendar(locale8);
        int int10 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime12 = dateTime7.withYearOfCentury(7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+32:00" + "'", str4.equals("+32:00"));
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(calendar9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 115200000 + "'", int10 == 115200000);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(365, 59, 654, (int) (short) 10, 1258, dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1258 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        java.util.Locale locale12 = null;
        try {
            long long13 = delegatedDateTimeField4.set((long) 165, "624", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 624 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00:00.001", "GregorianChronology[+32:00]");
        java.lang.String str3 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[+32:00]" + "'", str3.equals("GregorianChronology[+32:00]"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long9 = offsetDateTimeField4.remainder(0L);
        java.util.Locale locale12 = null;
        long long13 = offsetDateTimeField4.set((long) 10, "100", locale12);
        org.joda.time.DurationField durationField14 = offsetDateTimeField4.getDurationField();
        org.joda.time.DurationField durationField15 = offsetDateTimeField4.getLeapDurationField();
        int int17 = offsetDateTimeField4.getLeapAmount(0L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9936000000L + "'", long9 == 9936000000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 94953600010L + "'", long13 == 94953600010L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isBefore(1L);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property6 = dateTime2.weekOfWeekyear();
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = dateTime2.toString("5:00:00 PM PDT", locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        boolean boolean6 = property3.equals((java.lang.Object) 2);
//        org.joda.time.DateTime dateTime8 = property3.addToCopy(0L);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property3.getAsText(locale9);
//        org.joda.time.DateTime dateTime11 = property3.withMaximumValue();
//        org.joda.time.DateTime.Property property12 = dateTime11.centuryOfEra();
//        org.junit.Assert.assertNotNull(gregorianCalendar2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "365" + "'", str10.equals("365"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00:00.001", "GregorianChronology[+32:00]");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.001" + "'", str3.equals("+00:00:00.001"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str1 = dateTimeZone0.getID();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusDays((int) (short) 10);
        org.joda.time.LocalTime localTime4 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property5 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        int int7 = property5.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 53 + "'", int7 == 53);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DurationField durationField5 = property3.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNull(durationField5);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getShortName((-1900800000L));
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 1);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.minuteOfDay();
        java.lang.String str8 = julianChronology6.toString();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MonthDay monthDay11 = monthDay9.withChronologyRetainFields(chronology10);
        int[] intArray13 = julianChronology6.get((org.joda.time.ReadablePartial) monthDay11, (long) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+32:00" + "'", str4.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "JulianChronology[+32:00,mdfw=1]" + "'", str8.equals("JulianChronology[+32:00,mdfw=1]"));
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray13);
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
//        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
//        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
//        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
//        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
//        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
//        int int31 = offsetDateTimeField26.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
//        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
//        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
//        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
//        int int51 = offsetDateTimeField46.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology53 = null;
//        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
//        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
//        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
//        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
//        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
//        int int72 = offsetDateTimeField67.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology74 = null;
//        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
//        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
//        int[] intArray83 = monthDay75.getValues();
//        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
//        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
//        java.util.Locale locale88 = null;
//        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
//        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
//        java.lang.String str91 = property90.getAsString();
//        org.joda.time.MonthDay monthDay93 = property90.addWrapFieldToCopy((int) 'a');
//        org.joda.time.MonthDay monthDay95 = property90.setCopy((int) (byte) 1);
//        org.joda.time.DateTimeField dateTimeField96 = property90.getField();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
//        org.junit.Assert.assertNotNull(copticChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(copticChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertNotNull(monthDay86);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
//        org.junit.Assert.assertNotNull(property90);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "7" + "'", str91.equals("7"));
//        org.junit.Assert.assertNotNull(monthDay93);
//        org.junit.Assert.assertNotNull(monthDay95);
//        org.junit.Assert.assertNotNull(dateTimeField96);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime5 = dateTime1.withYear(11);
        org.joda.time.DateTime dateTime7 = dateTime5.withWeekOfWeekyear((int) (byte) 10);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        java.lang.String str7 = dateTimeZone4.getShortName((-1900800000L));
        org.joda.time.Chronology chronology8 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str10 = gregorianChronology9.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology13 = gregorianChronology9.withZone(dateTimeZone12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        long long20 = delegatedDateTimeField18.roundFloor((long) 0);
        org.joda.time.DurationField durationField21 = delegatedDateTimeField18.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        java.util.Locale locale23 = null;
        int int24 = delegatedDateTimeField18.getMaximumShortTextLength(locale23);
        long long27 = delegatedDateTimeField18.add((-31449599999L), 56);
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField(chronology8, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) delegatedDateTimeField18, (-33), (-10), 786);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -33 for monthOfYear must be in the range [-10,786]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+32:00" + "'", str7.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[UTC]" + "'", str10.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1900800000L) + "'", long20 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 105148800001L + "'", long27 == 105148800001L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        boolean boolean6 = dateTime1.isEqual((long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundFloorCopy();
        org.joda.time.DateTime dateTime7 = property3.addToCopy(0);
        java.util.Locale locale8 = null;
        java.util.Calendar calendar9 = dateTime7.toCalendar(locale8);
        try {
            org.joda.time.DateTime dateTime11 = dateTime7.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(calendar9);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = offsetDateTimeField4.getMinimumValue(readablePartial5);
        long long8 = offsetDateTimeField4.remainder((long) 15);
        long long10 = offsetDateTimeField4.roundHalfFloor((long) 3);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9936000015L + "'", long8 == 9936000015L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-9936000000L) + "'", long10 == (-9936000000L));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime5 = dateTime1.withYear(11);
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears(115200000);
        org.joda.time.DateTime dateTime9 = dateTime7.withSecondOfMinute(0);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.MutableDateTime mutableDateTime4 = instant3.toMutableDateTime();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        java.lang.Object obj2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.append(dateTimeFormatter14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 110);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 110");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isAfter((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime2.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime.Property property7 = dateTime2.dayOfMonth();
        org.joda.time.DurationField durationField8 = property7.getDurationField();
        long long11 = durationField8.subtract((long) 110, 32054400000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2769500159999999890L) + "'", long11 == (-2769500159999999890L));
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology1.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        long long7 = delegatedDateTimeField5.roundFloor((long) 0);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField5.getLeapDurationField();
//        long long10 = delegatedDateTimeField5.roundHalfCeiling((long) (byte) 0);
//        boolean boolean12 = delegatedDateTimeField5.isLeap((long) '#');
//        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology13.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = copticChronology13.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 10);
//        int int20 = offsetDateTimeField17.getDifference(0L, 0L);
//        int int22 = offsetDateTimeField17.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.MonthDay monthDay25 = monthDay23.withChronologyRetainFields(chronology24);
//        int[] intArray31 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int32 = offsetDateTimeField17.getMinimumValue((org.joda.time.ReadablePartial) monthDay25, intArray31);
//        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField34 = copticChronology33.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField35 = copticChronology33.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, 10);
//        int int40 = offsetDateTimeField37.getDifference(0L, 0L);
//        int int42 = offsetDateTimeField37.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay43 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology44 = null;
//        org.joda.time.MonthDay monthDay45 = monthDay43.withChronologyRetainFields(chronology44);
//        int[] intArray51 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int52 = offsetDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay45, intArray51);
//        boolean boolean53 = monthDay25.isEqual((org.joda.time.ReadablePartial) monthDay45);
//        org.joda.time.chrono.CopticChronology copticChronology54 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField55 = copticChronology54.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField56 = copticChronology54.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, 10);
//        int int61 = offsetDateTimeField58.getDifference(0L, 0L);
//        int int63 = offsetDateTimeField58.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay64 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology65 = null;
//        org.joda.time.MonthDay monthDay66 = monthDay64.withChronologyRetainFields(chronology65);
//        int[] intArray72 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int73 = offsetDateTimeField58.getMinimumValue((org.joda.time.ReadablePartial) monthDay66, intArray72);
//        int[] intArray74 = monthDay66.getValues();
//        int int75 = delegatedDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay45, intArray74);
//        org.joda.time.MonthDay monthDay77 = monthDay45.plusDays((int) (short) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology78 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay79 = new org.joda.time.MonthDay((java.lang.Object) monthDay77, (org.joda.time.Chronology) iSOChronology78);
//        org.joda.time.MonthDay monthDay81 = monthDay77.minusMonths((int) '#');
//        java.lang.Object obj82 = null;
//        org.joda.time.DateTime dateTime83 = new org.joda.time.DateTime(obj82);
//        java.util.GregorianCalendar gregorianCalendar84 = dateTime83.toGregorianCalendar();
//        boolean boolean85 = monthDay81.equals((java.lang.Object) dateTime83);
//        java.lang.String str86 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay81);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(copticChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1900800000L) + "'", long7 == (-1900800000L));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 691200000L + "'", long10 == 691200000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(copticChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 11 + "'", int22 == 11);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertNotNull(monthDay25);
//        org.junit.Assert.assertNotNull(intArray31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 11 + "'", int32 == 11);
//        org.junit.Assert.assertNotNull(copticChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 11 + "'", int42 == 11);
//        org.junit.Assert.assertNotNull(monthDay43);
//        org.junit.Assert.assertNotNull(monthDay45);
//        org.junit.Assert.assertNotNull(intArray51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 11 + "'", int52 == 11);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertNotNull(copticChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 11 + "'", int63 == 11);
//        org.junit.Assert.assertNotNull(monthDay64);
//        org.junit.Assert.assertNotNull(monthDay66);
//        org.junit.Assert.assertNotNull(intArray72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 11 + "'", int73 == 11);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
//        org.junit.Assert.assertNotNull(monthDay77);
//        org.junit.Assert.assertNotNull(iSOChronology78);
//        org.junit.Assert.assertNotNull(monthDay81);
//        org.junit.Assert.assertNotNull(gregorianCalendar84);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "Feb 7, ���� �:��:�� �" + "'", str86.equals("Feb 7, ���� �:��:�� �"));
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isAfter((-1L));
        org.joda.time.DateTime dateTime6 = dateTime2.plus((long) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.plusYears(100);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) dateTime4);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        java.util.Locale locale14 = null;
        int int15 = delegatedDateTimeField9.getMaximumShortTextLength(locale14);
        long long18 = delegatedDateTimeField9.add((long) (-1), (int) ' ');
        long long20 = delegatedDateTimeField9.roundCeiling((long) 110);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 78710399999L + "'", long18 == 78710399999L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 691200000L + "'", long20 == 691200000L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        java.lang.Object obj2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.append(dateTimeFormatter14);
        java.lang.Appendable appendable16 = null;
        java.lang.Object obj17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(obj17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusDays((int) (short) 10);
        org.joda.time.LocalTime localTime21 = dateTime18.toLocalTime();
        int int22 = dateTime18.getEra();
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime24 = dateTime18.plus(readableDuration23);
        try {
            dateTimeFormatter14.printTo(appendable16, (org.joda.time.ReadableInstant) dateTime18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusDays((int) (short) 10);
        org.joda.time.LocalTime localTime4 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property5 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DurationField durationField7 = property5.getDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.secondOfDay();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str5 = gregorianChronology4.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology8 = gregorianChronology4.withZone(dateTimeZone7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = dateTimeZone7.getShortName(10L, locale10);
        org.joda.time.Chronology chronology12 = gJChronology3.withZone(dateTimeZone7);
        org.joda.time.Chronology chronology13 = copticChronology0.withZone(dateTimeZone7);
        long long17 = copticChronology0.add(53568000000L, (long) '4', 839);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[UTC]" + "'", str5.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+32:00" + "'", str11.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 53568043628L + "'", long17 == 53568043628L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime7.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime7.hourOfDay();
        org.joda.time.Interval interval10 = property9.toInterval();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(interval10);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
//        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
//        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
//        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
//        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
//        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
//        int int31 = offsetDateTimeField26.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
//        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
//        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
//        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
//        int int51 = offsetDateTimeField46.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology53 = null;
//        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
//        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
//        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
//        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
//        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
//        int int72 = offsetDateTimeField67.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology74 = null;
//        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
//        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
//        int[] intArray83 = monthDay75.getValues();
//        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
//        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
//        java.util.Locale locale88 = null;
//        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
//        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
//        java.lang.String str91 = property90.getAsString();
//        org.joda.time.MonthDay monthDay93 = property90.addWrapFieldToCopy((int) 'a');
//        org.joda.time.MonthDay monthDay95 = property90.setCopy((int) (byte) 1);
//        int int96 = property90.getMaximumValueOverall();
//        org.joda.time.DurationField durationField97 = property90.getRangeDurationField();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
//        org.junit.Assert.assertNotNull(copticChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(copticChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertNotNull(monthDay86);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
//        org.junit.Assert.assertNotNull(property90);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "7" + "'", str91.equals("7"));
//        org.junit.Assert.assertNotNull(monthDay93);
//        org.junit.Assert.assertNotNull(monthDay95);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 31 + "'", int96 == 31);
//        org.junit.Assert.assertNotNull(durationField97);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 9936000015L, (java.lang.Object) "12");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(31, (int) '#', 52, 110, 3600, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 110 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        long long6 = offsetDateTimeField4.roundHalfEven((long) ' ');
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getDurationField();
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField4.getMaximumShortTextLength(locale8);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-9936000000L) + "'", long6 == (-9936000000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology5 = gregorianChronology1.withZone(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology1.hours();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.weekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField10);
        java.util.Locale locale14 = null;
        try {
            long long15 = skipDateTimeField11.set(1567987200000L, "JulianChronology[+32:00,mdfw=1]", locale14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"JulianChronology[+32:00,mdfw=1]\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology5 = gregorianChronology1.withZone(dateTimeZone4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTimeZone4.getShortName(10L, locale7);
        org.joda.time.Chronology chronology9 = gJChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime13.weekOfWeekyear();
        org.joda.time.DateTime dateTime15 = property14.getDateTime();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime18 = dateTime15.plusHours(248);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+32:00" + "'", str8.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
        int int31 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
        int int51 = offsetDateTimeField46.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
        int int72 = offsetDateTimeField67.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology74 = null;
        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
        int[] intArray83 = monthDay75.getValues();
        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
        java.util.Locale locale88 = null;
        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
        int int91 = property90.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(copticChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
        org.junit.Assert.assertNotNull(monthDay73);
        org.junit.Assert.assertNotNull(monthDay75);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(monthDay86);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
        org.junit.Assert.assertNotNull(property90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 31 + "'", int91 == 31);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
//        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
//        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
//        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
//        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
//        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
//        int int31 = offsetDateTimeField26.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
//        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
//        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
//        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
//        int int51 = offsetDateTimeField46.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology53 = null;
//        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
//        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
//        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
//        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
//        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
//        int int72 = offsetDateTimeField67.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology74 = null;
//        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
//        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
//        int[] intArray83 = monthDay75.getValues();
//        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
//        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
//        java.util.Locale locale88 = null;
//        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
//        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
//        java.lang.String str91 = property90.getAsString();
//        org.joda.time.MonthDay monthDay93 = property90.addWrapFieldToCopy((int) 'a');
//        org.joda.time.MonthDay monthDay94 = property90.getMonthDay();
//        int int95 = property90.getMaximumValue();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
//        org.junit.Assert.assertNotNull(copticChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(copticChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertNotNull(monthDay86);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
//        org.junit.Assert.assertNotNull(property90);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "7" + "'", str91.equals("7"));
//        org.junit.Assert.assertNotNull(monthDay93);
//        org.junit.Assert.assertNotNull(monthDay94);
//        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 31 + "'", int95 == 31);
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        java.util.Locale locale14 = null;
        int int15 = delegatedDateTimeField9.getMaximumShortTextLength(locale14);
        int int16 = delegatedDateTimeField9.getMinimumValue();
        java.util.Locale locale19 = null;
        try {
            long long20 = delegatedDateTimeField9.set((long) 999, "����-06-15T��:��:��.000", locale19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"����-06-15T��:��:��.000\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 365);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        java.util.Locale locale13 = null;
        java.lang.String str14 = delegatedDateTimeField4.getAsShortText(55, locale13);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "55" + "'", str14.equals("55"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property3.getAsShortText(locale5);
        org.joda.time.DateTime dateTime8 = property3.addToCopy((long) 420);
        int int9 = dateTime8.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        long long8 = delegatedDateTimeField6.roundFloor((long) 0);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField6.getLeapDurationField();
        long long11 = delegatedDateTimeField6.roundHalfCeiling((long) (byte) 0);
        boolean boolean13 = delegatedDateTimeField6.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology14.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        int int21 = offsetDateTimeField18.getDifference(0L, 0L);
        int int23 = offsetDateTimeField18.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.MonthDay monthDay26 = monthDay24.withChronologyRetainFields(chronology25);
        int[] intArray32 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int33 = offsetDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) monthDay26, intArray32);
        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = copticChronology34.secondOfDay();
        org.joda.time.DateTimeField dateTimeField36 = copticChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 10);
        int int41 = offsetDateTimeField38.getDifference(0L, 0L);
        int int43 = offsetDateTimeField38.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay44 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.MonthDay monthDay46 = monthDay44.withChronologyRetainFields(chronology45);
        int[] intArray52 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int53 = offsetDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray52);
        boolean boolean54 = monthDay26.isEqual((org.joda.time.ReadablePartial) monthDay46);
        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = copticChronology55.secondOfDay();
        org.joda.time.DateTimeField dateTimeField57 = copticChronology55.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField57, 10);
        int int62 = offsetDateTimeField59.getDifference(0L, 0L);
        int int64 = offsetDateTimeField59.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay65 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.MonthDay monthDay67 = monthDay65.withChronologyRetainFields(chronology66);
        int[] intArray73 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int74 = offsetDateTimeField59.getMinimumValue((org.joda.time.ReadablePartial) monthDay67, intArray73);
        int[] intArray75 = monthDay67.getValues();
        int int76 = delegatedDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray75);
        boolean boolean77 = copticChronology0.equals((java.lang.Object) delegatedDateTimeField6);
        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology80 = copticChronology0.withZone(dateTimeZone79);
        org.joda.time.DateTimeField dateTimeField81 = copticChronology0.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod82 = null;
        long long85 = copticChronology0.add(readablePeriod82, (long) 40, 12);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1900800000L) + "'", long8 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 691200000L + "'", long11 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 11 + "'", int33 == 11);
        org.junit.Assert.assertNotNull(copticChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 11 + "'", int43 == 11);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 11 + "'", int53 == 11);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(copticChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 11 + "'", int64 == 11);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertNotNull(monthDay67);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 11 + "'", int74 == 11);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(dateTimeZone79);
        org.junit.Assert.assertNotNull(chronology80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 40L + "'", long85 == 40L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField4 = gJChronology3.hours();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.joda.time.Chronology chronology6 = gJChronology3.withUTC();
        java.lang.String str7 = gJChronology3.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GJChronology[+00:00:00.001]" + "'", str7.equals("GJChronology[+00:00:00.001]"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        java.lang.Object obj2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear(6, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendFractionOfDay((int) (byte) 100, (-420));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        java.lang.Object obj2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder0.appendMillisOfDay(115200000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
//        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
//        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
//        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
//        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
//        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
//        int int31 = offsetDateTimeField26.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
//        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
//        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
//        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
//        int int51 = offsetDateTimeField46.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology53 = null;
//        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
//        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
//        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
//        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
//        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
//        int int72 = offsetDateTimeField67.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology74 = null;
//        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
//        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
//        int[] intArray83 = monthDay75.getValues();
//        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
//        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
//        java.util.Locale locale88 = null;
//        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
//        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
//        java.lang.String str91 = property90.getAsString();
//        org.joda.time.MonthDay monthDay93 = property90.addWrapFieldToCopy((int) 'a');
//        org.joda.time.ReadableInstant readableInstant94 = null;
//        try {
//            int int95 = property90.compareTo(readableInstant94);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
//        org.junit.Assert.assertNotNull(copticChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(copticChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertNotNull(monthDay86);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
//        org.junit.Assert.assertNotNull(property90);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "7" + "'", str91.equals("7"));
//        org.junit.Assert.assertNotNull(monthDay93);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.Instant instant6 = instant3.withDurationAdded(1559952000000L, (int) (byte) 1);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant9 = instant6.withDurationAdded(readableDuration7, 40);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology5 = gregorianChronology1.withZone(dateTimeZone4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTimeZone4.getShortName(10L, locale7);
        org.joda.time.Chronology chronology9 = gJChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology0.getZone();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField13 = gregorianChronology12.years();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+32:00" + "'", str8.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusDays((int) (short) 10);
        org.joda.time.LocalTime localTime4 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property5 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        boolean boolean10 = dateTime8.isBefore(1L);
        long long11 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.MonthDay monthDay14 = monthDay12.withChronologyRetainFields(chronology13);
        try {
            int int15 = property5.compareTo((org.joda.time.ReadablePartial) monthDay12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekOfWeekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(monthDay14);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
        org.joda.time.DateTime dateTime8 = dateTime4.withMillis((long) 12);
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMinutes(420);
        org.joda.time.DateTime.Property property12 = dateTime8.monthOfYear();
        org.joda.time.DateTime dateTime13 = dateTime8.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isBefore(1L);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime2.withZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.DateTime dateTime11 = dateTime2.withZone(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime2.hourOfDay();
        boolean boolean14 = dateTime2.isAfter((long) (-1));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        long long24 = offsetDateTimeField4.roundCeiling(1641427200000L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1662940800000L + "'", long24 == 1662940800000L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int6 = offsetDateTimeField4.getMaximumValue(9936000000L);
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField4.getMinimumValue(readablePartial7);
        int int10 = offsetDateTimeField4.get((long) 44);
        long long12 = offsetDateTimeField4.roundHalfEven((-31449599635L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 110 + "'", int6 == 110);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-41385600000L) + "'", long12 == (-41385600000L));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getRangeDurationField();
        int int14 = delegatedDateTimeField4.getMinimumValue((long) 248);
        org.joda.time.DurationField durationField15 = delegatedDateTimeField4.getRangeDurationField();
        long long18 = delegatedDateTimeField4.add((long) (short) 100, 15);
        try {
            long long21 = delegatedDateTimeField4.set((long) 'a', "0");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 36720000100L + "'", long18 == 36720000100L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.seconds();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("13");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        java.lang.Object obj2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder13.appendTimeZoneOffset("2017-08-05T13:59:12.208-07:00", true, 11, (int) (byte) 100);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap19 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder13.appendTimeZoneShortName(strMap19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder13.appendSecondOfDay(871);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean5 = dateTime3.isBefore(1L);
        org.joda.time.DateTime dateTime7 = dateTime3.withSecondOfMinute(0);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime3.getZone();
        org.joda.time.Chronology chronology9 = buddhistChronology0.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = buddhistChronology0.withUTC();
        org.joda.time.ReadablePartial readablePartial11 = null;
        try {
            long long13 = buddhistChronology0.set(readablePartial11, 1560632329915L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isAfter((-1L));
        org.joda.time.DateTime dateTime6 = dateTime2.plus((long) (short) 10);
        org.joda.time.DateTime.Property property7 = dateTime2.dayOfWeek();
        java.util.Locale locale9 = null;
        try {
            org.joda.time.DateTime dateTime10 = property7.setCopy("", locale9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.Locale locale2 = null;
        java.util.Calendar calendar3 = dateTime1.toCalendar(locale2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.fromCalendarFields(calendar3);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray5 = monthDay4.getFieldTypes();
        org.junit.Assert.assertNotNull(calendar3);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray5);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology2 = iSOChronology1.withUTC();
//        java.lang.String str3 = iSOChronology1.toString();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str3.equals("ISOChronology[America/Los_Angeles]"));
//    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfHour((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMillisOfSecond(44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendLiteral("100");
//        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatterBuilder19.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder16.append(dateTimeParser20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560632370375L + "'", long4 == 1560632370375L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeParser20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology5 = gregorianChronology1.withZone(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology1.hours();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.weekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField11.getAsShortText((long) (short) 100, locale13);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970" + "'", str14.equals("1970"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "-1", "1:58:46 PM");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "97", "hi!");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale10 = null;
        java.lang.String str13 = defaultNameProvider0.getName(locale10, "", "786");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str13);
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        boolean boolean6 = dateTime1.isAfter((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.Instant instant7 = new org.joda.time.Instant((java.lang.Object) dateTime5);
//        org.joda.time.MutableDateTime mutableDateTime8 = instant7.toMutableDateTimeISO();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 595 + "'", int2 == 595);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder0.appendFractionOfHour(871, 20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560632370649L + "'", long4 == 1560632370649L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(78710399999L);
        try {
            org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfSecond((-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = copticChronology0.add(readablePeriod3, 1L, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        long long8 = delegatedDateTimeField6.roundFloor((long) 0);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField6.getLeapDurationField();
        long long11 = delegatedDateTimeField6.roundHalfCeiling((long) (byte) 0);
        boolean boolean13 = delegatedDateTimeField6.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology14.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        int int21 = offsetDateTimeField18.getDifference(0L, 0L);
        int int23 = offsetDateTimeField18.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.MonthDay monthDay26 = monthDay24.withChronologyRetainFields(chronology25);
        int[] intArray32 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int33 = offsetDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) monthDay26, intArray32);
        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = copticChronology34.secondOfDay();
        org.joda.time.DateTimeField dateTimeField36 = copticChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 10);
        int int41 = offsetDateTimeField38.getDifference(0L, 0L);
        int int43 = offsetDateTimeField38.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay44 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.MonthDay monthDay46 = monthDay44.withChronologyRetainFields(chronology45);
        int[] intArray52 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int53 = offsetDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray52);
        boolean boolean54 = monthDay26.isEqual((org.joda.time.ReadablePartial) monthDay46);
        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = copticChronology55.secondOfDay();
        org.joda.time.DateTimeField dateTimeField57 = copticChronology55.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField57, 10);
        int int62 = offsetDateTimeField59.getDifference(0L, 0L);
        int int64 = offsetDateTimeField59.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay65 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.MonthDay monthDay67 = monthDay65.withChronologyRetainFields(chronology66);
        int[] intArray73 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int74 = offsetDateTimeField59.getMinimumValue((org.joda.time.ReadablePartial) monthDay67, intArray73);
        int[] intArray75 = monthDay67.getValues();
        int int76 = delegatedDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray75);
        boolean boolean77 = copticChronology0.equals((java.lang.Object) delegatedDateTimeField6);
        org.joda.time.Chronology chronology78 = copticChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField79 = copticChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1900800000L) + "'", long8 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 691200000L + "'", long11 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 11 + "'", int33 == 11);
        org.junit.Assert.assertNotNull(copticChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 11 + "'", int43 == 11);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 11 + "'", int53 == 11);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(copticChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 11 + "'", int64 == 11);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertNotNull(monthDay67);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 11 + "'", int74 == 11);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(chronology78);
        org.junit.Assert.assertNotNull(dateTimeField79);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        long long36 = preciseDateTimeField35.getUnitMillis();
        boolean boolean37 = preciseDateTimeField35.isLenient();
        java.lang.String str39 = preciseDateTimeField35.getAsShortText((long) 0);
        int int40 = preciseDateTimeField35.getMaximumValue();
        long long43 = preciseDateTimeField35.addWrapField(1560632323075L, 6);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1000L + "'", long36 == 1000L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3599 + "'", int40 == 3599);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560632329075L + "'", long43 == 1560632329075L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str2 = gJChronology1.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusDays((int) (short) 10);
//        org.joda.time.LocalTime localTime4 = dateTime1.toLocalTime();
//        org.joda.time.DateTime.Property property5 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
//        org.joda.time.Interval interval7 = property5.toInterval();
//        org.joda.time.DateTimeField dateTimeField8 = property5.getField();
//        long long9 = property5.remainder();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(interval7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 482371706L + "'", long9 == 482371706L);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("35", 13, 40, 786);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 13 for 35 must be in the range [40,786]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
//        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
//        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
//        org.joda.time.DurationField durationField14 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.secondOfMinute();
//        java.lang.Object obj16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(obj16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime20 = dateTime17.withMillisOfDay((int) 'a');
//        int int21 = dateTime17.getDayOfMonth();
//        org.joda.time.DateTime dateTime23 = dateTime17.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property24 = dateTime17.secondOfDay();
//        org.joda.time.DateTime dateTime26 = dateTime17.withSecondOfMinute(0);
//        org.joda.time.Instant instant28 = new org.joda.time.Instant((long) (-10));
//        org.joda.time.DateTime dateTime29 = instant28.toDateTimeISO();
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology30 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.ReadableDateTime) dateTime26, (org.joda.time.ReadableDateTime) dateTime29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560632372647L + "'", long18 == 1560632372647L);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime29);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.io.Writer writer1 = null;
        java.lang.Object obj2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
        java.util.GregorianCalendar gregorianCalendar4 = dateTime3.toGregorianCalendar();
        org.joda.time.DateTime dateTime6 = dateTime3.minus(1560632322909L);
        java.lang.Object obj7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(obj7);
        java.util.GregorianCalendar gregorianCalendar9 = dateTime8.toGregorianCalendar();
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfYear();
        org.joda.time.DateTime dateTime11 = property10.getDateTime();
        org.joda.time.DateTime dateTime13 = dateTime11.minusWeeks((int) 'a');
        org.joda.time.DateTime dateTime15 = dateTime11.withMillis((long) 12);
        org.joda.time.Instant instant17 = new org.joda.time.Instant((long) (-10));
        int int18 = dateTime15.compareTo((org.joda.time.ReadableInstant) instant17);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.util.Locale locale20 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter19.withLocale(locale20);
        java.lang.String str22 = instant17.toString(dateTimeFormatter19);
        boolean boolean23 = dateTime6.isBefore((org.joda.time.ReadableInstant) instant17);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianCalendar4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "11:59:59 PM" + "'", str22.equals("11:59:59 PM"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology23.secondOfDay();
        org.joda.time.DateTimeField dateTimeField25 = copticChronology23.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 10);
        int int30 = offsetDateTimeField27.getDifference(0L, 0L);
        int int32 = offsetDateTimeField27.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.withChronologyRetainFields(chronology34);
        int[] intArray41 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int42 = offsetDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) monthDay35, intArray41);
        long long45 = offsetDateTimeField27.add((long) (short) 1, (int) (short) -1);
        int int47 = offsetDateTimeField27.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = offsetDateTimeField27.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType48, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType48, 3599);
        org.joda.time.IllegalFieldValueException illegalFieldValueException54 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType48, "2017-08-05T13:59:03.031-07:00");
        java.lang.String str55 = illegalFieldValueException54.getFieldName();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 11 + "'", int32 == 11);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 11 + "'", int42 == 11);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-31449599999L) + "'", long45 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "weekyearOfCentury" + "'", str55.equals("weekyearOfCentury"));
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
//        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
//        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
//        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
//        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
//        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
//        int int31 = offsetDateTimeField26.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
//        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
//        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
//        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
//        int int51 = offsetDateTimeField46.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology53 = null;
//        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
//        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
//        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
//        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
//        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
//        int int72 = offsetDateTimeField67.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology74 = null;
//        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
//        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
//        int[] intArray83 = monthDay75.getValues();
//        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
//        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
//        java.util.Locale locale88 = null;
//        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
//        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
//        java.lang.String str91 = property90.getAsString();
//        int int92 = property90.getMaximumValue();
//        org.joda.time.DateTimeField dateTimeField93 = property90.getField();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
//        org.junit.Assert.assertNotNull(copticChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(copticChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertNotNull(monthDay86);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
//        org.junit.Assert.assertNotNull(property90);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "23" + "'", str91.equals("23"));
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 31 + "'", int92 == 31);
//        org.junit.Assert.assertNotNull(dateTimeField93);
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isAfter((-1L));
        org.joda.time.DateTime dateTime6 = dateTime2.plus((long) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfDay(2);
        org.joda.time.DateTime dateTime10 = dateTime6.plusHours(13);
        org.joda.time.TimeOfDay timeOfDay11 = dateTime10.toTimeOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(timeOfDay11);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str4 = dateTimeZone1.getShortName((-1900800000L));
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.LocalDateTime localDateTime7 = null;
//        boolean boolean8 = dateTimeZone6.isLocalDateTimeGap(localDateTime7);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone6.getShortName(0L, locale10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
//        java.lang.Object obj14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(obj14);
//        java.util.Locale locale16 = null;
//        java.util.Calendar calendar17 = dateTime15.toCalendar(locale16);
//        org.joda.time.DateTime dateTime19 = dateTime15.minusMillis(0);
//        org.joda.time.ReadableInstant readableInstant20 = null;
//        boolean boolean21 = dateTime15.isBefore(readableInstant20);
//        int int22 = cachedDateTimeZone13.getOffset((org.joda.time.ReadableInstant) dateTime15);
//        long long24 = dateTimeZone1.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone13, 1560632356034L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+32:00" + "'", str4.equals("+32:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+32:00" + "'", str11.equals("+32:00"));
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
//        org.junit.Assert.assertNotNull(calendar17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 115200000 + "'", int22 == 115200000);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560632356034L + "'", long24 == 1560632356034L);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getRangeDurationField();
        int int14 = delegatedDateTimeField4.getMinimumValue((long) 248);
        long long17 = delegatedDateTimeField4.add((long) '#', (long) 0);
        java.util.Locale locale18 = null;
        int int19 = delegatedDateTimeField4.getMaximumTextLength(locale18);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35L + "'", long17 == 35L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getShortName((-1900800000L));
        java.util.TimeZone timeZone5 = dateTimeZone1.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+32:00" + "'", str4.equals("+32:00"));
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "4");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        try {
            org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean4 = dateTime2.isBefore(1L);
//        org.joda.time.DateTime dateTime6 = dateTime2.withSecondOfMinute(0);
//        int int7 = dateTime2.getSecondOfMinute();
//        org.joda.time.DateTime.Property property8 = dateTime2.yearOfCentury();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 34 + "'", int7 == 34);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        java.util.Locale locale14 = null;
        int int15 = delegatedDateTimeField9.getMaximumShortTextLength(locale14);
        int int18 = delegatedDateTimeField9.getDifference((long) (byte) 10, 0L);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField9.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException9.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException17.addSuppressed((java.lang.Throwable) illegalFieldValueException20);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException20);
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException25.addSuppressed((java.lang.Throwable) illegalFieldValueException28);
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException32.addSuppressed((java.lang.Throwable) illegalFieldValueException35);
        illegalFieldValueException25.addSuppressed((java.lang.Throwable) illegalFieldValueException35);
        illegalFieldValueException20.addSuppressed((java.lang.Throwable) illegalFieldValueException35);
        java.lang.String str39 = illegalFieldValueException20.getIllegalValueAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = illegalFieldValueException20.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertNull(dateTimeFieldType40);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
//        java.lang.Object obj3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(obj3);
//        java.util.GregorianCalendar gregorianCalendar5 = dateTime4.toGregorianCalendar();
//        org.joda.time.DateTime.Property property6 = dateTime4.dayOfYear();
//        org.joda.time.DateTime dateTime7 = property6.getDateTime();
//        java.lang.String str8 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.year();
//        boolean boolean10 = property9.isLeap();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gregorianCalendar5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1:59:34 PM" + "'", str8.equals("1:59:34 PM"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusDays((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withDayOfMonth(55);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 55 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.withDurationAdded(readableDuration5, (int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime2.minusDays((int) ' ');
        org.joda.time.DateTime dateTime11 = dateTime9.withDayOfYear(365);
        boolean boolean12 = dateTime11.isAfterNow();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusDays((int) (short) 10);
        org.joda.time.LocalTime localTime4 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property5 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        boolean boolean10 = dateTime8.isBefore(1L);
        long long11 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = copticChronology17.secondOfDay();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology17.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType20);
        long long23 = delegatedDateTimeField21.roundFloor((long) 0);
        org.joda.time.DurationField durationField24 = delegatedDateTimeField21.getLeapDurationField();
        long long26 = delegatedDateTimeField21.roundHalfCeiling((long) (byte) 0);
        boolean boolean28 = delegatedDateTimeField21.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = copticChronology29.secondOfDay();
        org.joda.time.DateTimeField dateTimeField31 = copticChronology29.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 10);
        int int36 = offsetDateTimeField33.getDifference(0L, 0L);
        int int38 = offsetDateTimeField33.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay39 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology40 = null;
        org.joda.time.MonthDay monthDay41 = monthDay39.withChronologyRetainFields(chronology40);
        int[] intArray47 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int48 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) monthDay41, intArray47);
        org.joda.time.chrono.CopticChronology copticChronology49 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = copticChronology49.secondOfDay();
        org.joda.time.DateTimeField dateTimeField51 = copticChronology49.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, 10);
        int int56 = offsetDateTimeField53.getDifference(0L, 0L);
        int int58 = offsetDateTimeField53.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay59 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology60 = null;
        org.joda.time.MonthDay monthDay61 = monthDay59.withChronologyRetainFields(chronology60);
        int[] intArray67 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int68 = offsetDateTimeField53.getMinimumValue((org.joda.time.ReadablePartial) monthDay61, intArray67);
        boolean boolean69 = monthDay41.isEqual((org.joda.time.ReadablePartial) monthDay61);
        org.joda.time.chrono.CopticChronology copticChronology70 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField71 = copticChronology70.secondOfDay();
        org.joda.time.DateTimeField dateTimeField72 = copticChronology70.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField74 = new org.joda.time.field.OffsetDateTimeField(dateTimeField72, 10);
        int int77 = offsetDateTimeField74.getDifference(0L, 0L);
        int int79 = offsetDateTimeField74.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay80 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology81 = null;
        org.joda.time.MonthDay monthDay82 = monthDay80.withChronologyRetainFields(chronology81);
        int[] intArray88 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int89 = offsetDateTimeField74.getMinimumValue((org.joda.time.ReadablePartial) monthDay82, intArray88);
        int[] intArray90 = monthDay82.getValues();
        int int91 = delegatedDateTimeField21.getMinimumValue((org.joda.time.ReadablePartial) monthDay61, intArray90);
        org.joda.time.MonthDay monthDay93 = monthDay61.plusDays((int) (short) 100);
        java.util.Locale locale95 = null;
        java.lang.String str96 = delegatedDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) monthDay61, (int) (byte) 10, locale95);
        try {
            int int97 = property5.compareTo((org.joda.time.ReadablePartial) monthDay61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekOfWeekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1900800000L) + "'", long23 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 691200000L + "'", long26 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 11 + "'", int38 == 11);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 11 + "'", int48 == 11);
        org.junit.Assert.assertNotNull(copticChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 11 + "'", int58 == 11);
        org.junit.Assert.assertNotNull(monthDay59);
        org.junit.Assert.assertNotNull(monthDay61);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 11 + "'", int68 == 11);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(copticChronology70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 11 + "'", int79 == 11);
        org.junit.Assert.assertNotNull(monthDay80);
        org.junit.Assert.assertNotNull(monthDay82);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 11 + "'", int89 == 11);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
        org.junit.Assert.assertNotNull(monthDay93);
        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "10" + "'", str96.equals("10"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(0L);
        boolean boolean2 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isAfter((-1L));
        org.joda.time.DateTime dateTime6 = dateTime2.plus((long) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfDay(2);
        org.joda.time.DateTime dateTime10 = dateTime6.plusHours(13);
        org.joda.time.DateTime.Property property11 = dateTime10.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundFloorCopy();
        org.joda.time.DateTime dateTime7 = property3.addToCopy(0);
        org.joda.time.DateTime dateTime9 = property3.setCopy(1);
        try {
            org.joda.time.DateTime dateTime11 = property3.setCopy("1:59:05 PM");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1:59:05 PM\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int6 = offsetDateTimeField4.getMaximumValue(9936000000L);
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField4.getMinimumValue(readablePartial7);
        java.lang.String str10 = offsetDateTimeField4.getAsText(1560582000000L);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.secondOfDay();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, dateTimeFieldType14);
        long long17 = delegatedDateTimeField15.roundFloor((long) 0);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField15.getLeapDurationField();
        long long20 = delegatedDateTimeField15.roundHalfCeiling((long) (byte) 0);
        boolean boolean22 = delegatedDateTimeField15.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology23.secondOfDay();
        org.joda.time.DateTimeField dateTimeField25 = copticChronology23.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 10);
        int int30 = offsetDateTimeField27.getDifference(0L, 0L);
        int int32 = offsetDateTimeField27.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.withChronologyRetainFields(chronology34);
        int[] intArray41 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int42 = offsetDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) monthDay35, intArray41);
        org.joda.time.chrono.CopticChronology copticChronology43 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = copticChronology43.secondOfDay();
        org.joda.time.DateTimeField dateTimeField45 = copticChronology43.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, 10);
        int int50 = offsetDateTimeField47.getDifference(0L, 0L);
        int int52 = offsetDateTimeField47.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay53 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology54 = null;
        org.joda.time.MonthDay monthDay55 = monthDay53.withChronologyRetainFields(chronology54);
        int[] intArray61 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int62 = offsetDateTimeField47.getMinimumValue((org.joda.time.ReadablePartial) monthDay55, intArray61);
        boolean boolean63 = monthDay35.isEqual((org.joda.time.ReadablePartial) monthDay55);
        org.joda.time.chrono.CopticChronology copticChronology64 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField65 = copticChronology64.secondOfDay();
        org.joda.time.DateTimeField dateTimeField66 = copticChronology64.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, 10);
        int int71 = offsetDateTimeField68.getDifference(0L, 0L);
        int int73 = offsetDateTimeField68.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay74 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology75 = null;
        org.joda.time.MonthDay monthDay76 = monthDay74.withChronologyRetainFields(chronology75);
        int[] intArray82 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int83 = offsetDateTimeField68.getMinimumValue((org.joda.time.ReadablePartial) monthDay76, intArray82);
        int[] intArray84 = monthDay76.getValues();
        int int85 = delegatedDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) monthDay55, intArray84);
        org.joda.time.MonthDay monthDay87 = monthDay55.plusDays((int) (short) 100);
        org.joda.time.chrono.ISOChronology iSOChronology88 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay89 = new org.joda.time.MonthDay((java.lang.Object) monthDay87, (org.joda.time.Chronology) iSOChronology88);
        int int90 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay89);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 110 + "'", int6 == 110);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "46" + "'", str10.equals("46"));
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1900800000L) + "'", long17 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 691200000L + "'", long20 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 11 + "'", int32 == 11);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 11 + "'", int42 == 11);
        org.junit.Assert.assertNotNull(copticChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 11 + "'", int52 == 11);
        org.junit.Assert.assertNotNull(monthDay53);
        org.junit.Assert.assertNotNull(monthDay55);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 11 + "'", int62 == 11);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(copticChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 11 + "'", int73 == 11);
        org.junit.Assert.assertNotNull(monthDay74);
        org.junit.Assert.assertNotNull(monthDay76);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 11 + "'", int83 == 11);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
        org.junit.Assert.assertNotNull(monthDay87);
        org.junit.Assert.assertNotNull(iSOChronology88);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 110 + "'", int90 == 110);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        org.joda.time.DurationFieldType durationFieldType36 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField38 = new org.joda.time.field.ScaledDurationField(durationField34, durationFieldType36, 115200000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(78710399999L);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        org.joda.time.DateTime.Property property3 = dateTime1.secondOfDay();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone1.getShortName(0L, locale5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long11 = dateTimeZone1.convertLocalToUTC(105148800001L, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+32:00" + "'", str6.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 105033600001L + "'", long11 == 105033600001L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (byte) 10);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int6 = offsetDateTimeField4.getMaximumValue(9936000000L);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MonthDay monthDay9 = monthDay7.withChronologyRetainFields(chronology8);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        int[] intArray30 = monthDay22.getValues();
        int int31 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay7, intArray30);
        org.joda.time.MonthDay.Property property32 = monthDay7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField33 = property32.getField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 110 + "'", int6 == 110);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeField33);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int6 = offsetDateTimeField4.getLeapAmount((long) (-1));
        boolean boolean8 = offsetDateTimeField4.isLeap(100L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isAfter((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime2.isSupported(dateTimeFieldType5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime2.plus(readableDuration7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isBefore(1L);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime2.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime10 = dateTime2.plusMonths(12);
        org.joda.time.DateTime dateTime11 = dateTime2.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
//        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
//        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
//        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
//        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
//        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
//        int int31 = offsetDateTimeField26.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
//        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
//        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
//        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
//        int int51 = offsetDateTimeField46.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology53 = null;
//        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
//        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
//        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
//        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
//        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
//        int int72 = offsetDateTimeField67.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology74 = null;
//        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
//        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
//        int[] intArray83 = monthDay75.getValues();
//        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
//        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
//        java.util.Locale locale88 = null;
//        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
//        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
//        org.joda.time.DurationField durationField91 = property90.getRangeDurationField();
//        int int92 = property90.getMinimumValueOverall();
//        java.lang.String str93 = property90.getAsShortText();
//        java.util.Locale locale95 = null;
//        org.joda.time.MonthDay monthDay96 = property90.setCopy("24", locale95);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
//        org.junit.Assert.assertNotNull(copticChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(copticChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertNotNull(monthDay86);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
//        org.junit.Assert.assertNotNull(property90);
//        org.junit.Assert.assertNotNull(durationField91);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
//        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "23" + "'", str93.equals("23"));
//        org.junit.Assert.assertNotNull(monthDay96);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getRangeDurationField();
        int int14 = delegatedDateTimeField4.getMinimumValue((long) 248);
        org.joda.time.DurationField durationField15 = delegatedDateTimeField4.getRangeDurationField();
        java.lang.String str16 = delegatedDateTimeField4.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[monthOfYear]" + "'", str16.equals("DateTimeField[monthOfYear]"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isAfter((-1L));
        org.joda.time.DateTime dateTime6 = dateTime2.plus((long) (short) 10);
        org.joda.time.DateTime.Property property7 = dateTime2.dayOfWeek();
        org.joda.time.DateTime dateTime8 = property7.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime11 = dateTime8.withDurationAdded((long) 1969, 0);
        org.joda.time.DateMidnight dateMidnight12 = dateTime8.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateMidnight12);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) (short) 10);
        long long8 = delegatedDateTimeField4.roundFloor((long) 19);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField4.getType();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1900800000L) + "'", long8 == (-1900800000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        org.joda.time.Instant instant2 = org.joda.time.Instant.parse("0");
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        org.joda.time.Instant instant4 = instant2.minus(readableDuration3);
//        org.joda.time.Instant instant6 = instant4.minus((long) (short) -1);
//        org.joda.time.Instant instant7 = instant4.toInstant();
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) instant7);
//        org.joda.time.Chronology chronology9 = dateTimeFormatter0.getChronolgy();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(instant4);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "07" + "'", str8.equals("07"));
//        org.junit.Assert.assertNull(chronology9);
//    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime5 = dateTime1.minusSeconds(11);
//        org.joda.time.DateTime.Property property6 = dateTime5.dayOfYear();
//        try {
//            org.joda.time.DateTime dateTime8 = dateTime5.withDayOfMonth(654);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 654 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianCalendar2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 36 + "'", int3 == 36);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
//        org.joda.time.DateTime dateTime4 = dateTime1.minus(1560632322909L);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.plus(readableDuration5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withDefaultYear(0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatter9.getPrinter();
//        java.lang.String str11 = dateTime6.toString(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(gregorianCalendar2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimePrinter10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4:00:53 PM" + "'", str11.equals("4:00:53 PM"));
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
//        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
//        int int19 = offsetDateTimeField14.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
//        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
//        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
//        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
//        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
//        java.lang.String str47 = unsupportedDateTimeField46.toString();
//        java.util.Locale locale49 = null;
//        try {
//            java.lang.String str50 = unsupportedDateTimeField46.getAsShortText(17452800654L, locale49);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632376744L + "'", long2 == 1560632376744L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("dayOfMonth", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"dayOfMonth\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isAfter((-1L));
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTime2.toString("0", locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str12 = dateTimeZone9.getShortName((-1900800000L));
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9, 1);
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime2.toMutableDateTime((org.joda.time.Chronology) julianChronology14);
        try {
            long long23 = julianChronology14.getDateTimeMillis(165, 0, 110, 420, (-420), 34, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 420 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+32:00" + "'", str12.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone1.getShortName(0L, locale5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int10 = cachedDateTimeZone8.getStandardOffset((long) 1969);
        int int12 = cachedDateTimeZone8.getOffset((-31449599635L));
        java.util.TimeZone timeZone13 = cachedDateTimeZone8.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+32:00" + "'", str6.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 115200000 + "'", int10 == 115200000);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 115200000 + "'", int12 == 115200000);
        org.junit.Assert.assertNotNull(timeZone13);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long4 = buddhistChronology0.add((long) (short) 1, 1560628897763L, 10);
//        java.lang.Object obj5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime9 = dateTime6.withMillisOfDay((int) 'a');
//        int int10 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTime dateTime12 = dateTime6.withDayOfYear((int) (byte) 1);
//        java.lang.Object obj13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj13);
//        org.joda.time.DateTime dateTime16 = dateTime14.plusDays((int) (short) 10);
//        org.joda.time.LocalTime localTime17 = dateTime14.toLocalTime();
//        int int18 = dateTime14.getEra();
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime14.plus(readableDuration19);
//        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.ReadableDateTime) dateTime12, (org.joda.time.ReadableDateTime) dateTime20);
//        try {
//            long long26 = limitChronology21.getDateTimeMillis(12, 3, 0, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 15606288977631L + "'", long4 == 15606288977631L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560632376870L + "'", long7 == 1560632376870L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(limitChronology21);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        long long28 = offsetDateTimeField4.addWrapField((long) 365, (int) (byte) -1);
        try {
            long long31 = offsetDateTimeField4.add((-41385600000L), 1560632347355L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1560632347355");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-31449599635L) + "'", long28 == (-31449599635L));
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long6 = buddhistChronology2.add((long) (short) 1, 1560628897763L, 10);
//        java.lang.Object obj7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(obj7);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime11 = dateTime8.withMillisOfDay((int) 'a');
//        int int12 = dateTime8.getDayOfMonth();
//        org.joda.time.DateTime dateTime14 = dateTime8.withDayOfYear((int) (byte) 1);
//        java.lang.Object obj15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(obj15);
//        org.joda.time.DateTime dateTime18 = dateTime16.plusDays((int) (short) 10);
//        org.joda.time.LocalTime localTime19 = dateTime16.toLocalTime();
//        int int20 = dateTime16.getEra();
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime16.plus(readableDuration21);
//        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology2, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime22);
//        try {
//            org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay(34, 15, (org.joda.time.Chronology) limitChronology23);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 34 for monthOfYear must not be larger than 12");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 15606288977631L + "'", long6 == 15606288977631L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560632376926L + "'", long9 == 1560632376926L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(limitChronology23);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        java.util.Locale locale14 = null;
        int int15 = delegatedDateTimeField9.getMaximumShortTextLength(locale14);
        long long17 = delegatedDateTimeField9.remainder(1560632323158L);
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.secondOfDay();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology18.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, 10);
        int int25 = offsetDateTimeField22.getDifference(0L, 0L);
        long long27 = offsetDateTimeField22.remainder(0L);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) monthDay28, 0, locale30);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = copticChronology33.secondOfDay();
        org.joda.time.DateTimeField dateTimeField35 = copticChronology33.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, 10);
        int int39 = offsetDateTimeField37.getMaximumValue(9936000000L);
        org.joda.time.MonthDay monthDay40 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology41 = null;
        org.joda.time.MonthDay monthDay42 = monthDay40.withChronologyRetainFields(chronology41);
        org.joda.time.chrono.CopticChronology copticChronology43 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = copticChronology43.secondOfDay();
        org.joda.time.DateTimeField dateTimeField45 = copticChronology43.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, 10);
        int int50 = offsetDateTimeField47.getDifference(0L, 0L);
        int int52 = offsetDateTimeField47.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay53 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology54 = null;
        org.joda.time.MonthDay monthDay55 = monthDay53.withChronologyRetainFields(chronology54);
        int[] intArray61 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int62 = offsetDateTimeField47.getMinimumValue((org.joda.time.ReadablePartial) monthDay55, intArray61);
        int[] intArray63 = monthDay55.getValues();
        int int64 = offsetDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay40, intArray63);
        int[] intArray66 = delegatedDateTimeField9.add((org.joda.time.ReadablePartial) monthDay28, (int) (short) -1, intArray63, (int) (byte) 0);
        long long68 = delegatedDateTimeField9.roundHalfEven(1560632340763L);
        long long71 = delegatedDateTimeField9.add((long) 420, 680323158L);
        java.util.Locale locale74 = null;
        try {
            long long75 = delegatedDateTimeField9.set(40L, "166", locale74);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 680323158L + "'", long17 == 680323158L);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9936000000L + "'", long27 == 9936000000L);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 110 + "'", int39 == 110);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertNotNull(copticChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 11 + "'", int52 == 11);
        org.junit.Assert.assertNotNull(monthDay53);
        org.junit.Assert.assertNotNull(monthDay55);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 11 + "'", int62 == 11);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 11 + "'", int64 == 11);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1559952000000L + "'", long68 == 1559952000000L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1651489700659200420L + "'", long71 == 1651489700659200420L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isAfter((-1L));
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTime2.toString("0", locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str12 = dateTimeZone9.getShortName((-1900800000L));
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9, 1);
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime2.toMutableDateTime((org.joda.time.Chronology) julianChronology14);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime2.withDurationAdded(readableDuration16, 3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+32:00" + "'", str12.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 97, (long) 595);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57715 + "'", int2 == 57715);
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.millisOfDay();
//        java.lang.String str3 = buddhistChronology0.toString();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str3.equals("BuddhistChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long10 = offsetDateTimeField4.add((long) (short) 0, (long) (byte) 0);
        int int12 = offsetDateTimeField4.getLeapAmount((long) (short) 1);
        try {
            long long15 = offsetDateTimeField4.add(0L, 1560632370510L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1560632370510");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        java.lang.String str7 = dateTimeZone4.getShortName((-1900800000L));
        org.joda.time.Chronology chronology8 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str10 = gregorianChronology9.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology13 = gregorianChronology9.withZone(dateTimeZone12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        long long20 = delegatedDateTimeField18.roundFloor((long) 0);
        org.joda.time.DurationField durationField21 = delegatedDateTimeField18.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        java.util.Locale locale23 = null;
        int int24 = delegatedDateTimeField18.getMaximumShortTextLength(locale23);
        long long27 = delegatedDateTimeField18.add((-31449599999L), 56);
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField(chronology8, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        int int29 = skipDateTimeField28.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField30 = skipDateTimeField28.getWrappedField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+32:00" + "'", str7.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[UTC]" + "'", str10.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1900800000L) + "'", long20 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 105148800001L + "'", long27 == 105148800001L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(dateTimeField30);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter0.parseMutableDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.fullTime();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
//        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
//        int int19 = offsetDateTimeField14.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
//        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
//        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
//        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
//        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
//        java.lang.String str47 = unsupportedDateTimeField46.toString();
//        java.util.Locale locale49 = null;
//        try {
//            java.lang.String str50 = unsupportedDateTimeField46.getAsText((long) 57715, locale49);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632377636L + "'", long2 == 1560632377636L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
//    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
//        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
//        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
//        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
//        int int19 = offsetDateTimeField16.getDifference(0L, 0L);
//        int int21 = offsetDateTimeField16.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology23 = null;
//        org.joda.time.MonthDay monthDay24 = monthDay22.withChronologyRetainFields(chronology23);
//        int[] intArray30 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int31 = offsetDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) monthDay24, intArray30);
//        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField33 = copticChronology32.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField34 = copticChronology32.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 10);
//        int int39 = offsetDateTimeField36.getDifference(0L, 0L);
//        int int41 = offsetDateTimeField36.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay42 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology43 = null;
//        org.joda.time.MonthDay monthDay44 = monthDay42.withChronologyRetainFields(chronology43);
//        int[] intArray50 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int51 = offsetDateTimeField36.getMinimumValue((org.joda.time.ReadablePartial) monthDay44, intArray50);
//        boolean boolean52 = monthDay24.isEqual((org.joda.time.ReadablePartial) monthDay44);
//        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField54 = copticChronology53.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField55 = copticChronology53.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, 10);
//        int int60 = offsetDateTimeField57.getDifference(0L, 0L);
//        int int62 = offsetDateTimeField57.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay63 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology64 = null;
//        org.joda.time.MonthDay monthDay65 = monthDay63.withChronologyRetainFields(chronology64);
//        int[] intArray71 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int72 = offsetDateTimeField57.getMinimumValue((org.joda.time.ReadablePartial) monthDay65, intArray71);
//        int[] intArray73 = monthDay65.getValues();
//        int int74 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay44, intArray73);
//        org.joda.time.MonthDay monthDay76 = monthDay44.plusDays((int) (short) 100);
//        org.joda.time.chrono.CopticChronology copticChronology77 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField78 = copticChronology77.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField79 = copticChronology77.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField81 = new org.joda.time.field.OffsetDateTimeField(dateTimeField79, 10);
//        int int84 = offsetDateTimeField81.getDifference(0L, 0L);
//        int int86 = offsetDateTimeField81.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay87 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology88 = null;
//        org.joda.time.MonthDay monthDay89 = monthDay87.withChronologyRetainFields(chronology88);
//        int[] intArray95 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int96 = offsetDateTimeField81.getMinimumValue((org.joda.time.ReadablePartial) monthDay89, intArray95);
//        int[] intArray97 = monthDay89.getValues();
//        boolean boolean98 = monthDay44.isBefore((org.joda.time.ReadablePartial) monthDay89);
//        java.lang.String str99 = monthDay44.toString();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
//        org.junit.Assert.assertNotNull(copticChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
//        org.junit.Assert.assertNotNull(monthDay42);
//        org.junit.Assert.assertNotNull(monthDay44);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertNotNull(copticChronology53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 11 + "'", int62 == 11);
//        org.junit.Assert.assertNotNull(monthDay63);
//        org.junit.Assert.assertNotNull(monthDay65);
//        org.junit.Assert.assertNotNull(intArray71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
//        org.junit.Assert.assertNotNull(intArray73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//        org.junit.Assert.assertNotNull(monthDay76);
//        org.junit.Assert.assertNotNull(copticChronology77);
//        org.junit.Assert.assertNotNull(dateTimeField78);
//        org.junit.Assert.assertNotNull(dateTimeField79);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 11 + "'", int86 == 11);
//        org.junit.Assert.assertNotNull(monthDay87);
//        org.junit.Assert.assertNotNull(monthDay89);
//        org.junit.Assert.assertNotNull(intArray95);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 11 + "'", int96 == 11);
//        org.junit.Assert.assertNotNull(intArray97);
//        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
//        org.junit.Assert.assertTrue("'" + str99 + "' != '" + "--06-15" + "'", str99.equals("--06-15"));
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("4", (java.lang.Number) (short) 1, (java.lang.Number) (byte) 10, (java.lang.Number) 100L);
        java.lang.String str5 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1 for 4 must be in the range [10,100]" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value 1 for 4 must be in the range [10,100]"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getShortName((-1900800000L));
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 1);
        long long9 = dateTimeZone1.convertLocalToUTC(0L, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+32:00" + "'", str4.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-115200000L) + "'", long9 == (-115200000L));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isBefore(1L);
        org.joda.time.DateTime dateTime6 = dateTime2.withSecondOfMinute(0);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime2.getZone();
        int int8 = dateTime2.getCenturyOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str10 = gregorianChronology9.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology13 = gregorianChronology9.withZone(dateTimeZone12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dateTimeZone12.getShortName(10L, locale15);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        java.util.Locale locale19 = null;
        java.lang.String str20 = dateTimeZone12.getName((long) 31, locale19);
        org.joda.time.DateTime dateTime21 = dateTime2.withZoneRetainFields(dateTimeZone12);
        java.lang.String str23 = dateTimeZone12.getShortName(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[UTC]" + "'", str10.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+32:00" + "'", str16.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+32:00" + "'", str20.equals("+32:00"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+32:00" + "'", str23.equals("+32:00"));
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560632378068L + "'", long4 == 1560632378068L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withZone(dateTimeZone4);
        java.util.Locale locale6 = null;
        java.util.Calendar calendar7 = dateTime2.toCalendar(locale6);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(calendar7);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(365, (int) (short) 100, (-6), 42, 75535, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 42 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology5 = gregorianChronology1.withZone(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology1.hours();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean4 = dateTime2.isBefore(1L);
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime dateTime8 = dateTime2.plusDays(786);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekShortText();
//        java.lang.Object obj11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(obj11);
//        long long13 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime15 = dateTime12.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property16 = dateTime15.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property16.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder9.appendSignedDecimal(dateTimeFieldType17, (int) (short) 100, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder9.appendDayOfMonth(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder22.appendTimeZoneOffset("2017-08-05T13:59:12.208-07:00", true, 11, (int) (byte) 100);
//        java.lang.Object obj28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(obj28);
//        long long30 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.DateTime dateTime32 = dateTime29.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property33 = dateTime32.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property33.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder22.appendShortText(dateTimeFieldType34);
//        int int36 = dateTime2.get(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560632378594L + "'", long13 == 1560632378594L);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560632378596L + "'", long30 == 1560632378596L);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 75578 + "'", int36 == 75578);
//    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
//        java.lang.Object obj3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(obj3);
//        java.util.GregorianCalendar gregorianCalendar5 = dateTime4.toGregorianCalendar();
//        org.joda.time.DateTime.Property property6 = dateTime4.dayOfYear();
//        org.joda.time.DateTime dateTime7 = property6.getDateTime();
//        java.lang.String str8 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.year();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.secondOfDay();
//        boolean boolean14 = copticChronology10.equals((java.lang.Object) 9936000000L);
//        org.joda.time.DateTime dateTime15 = dateTime7.toDateTime((org.joda.time.Chronology) copticChronology10);
//        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond(334);
//        org.joda.time.DateTime.Property property18 = dateTime15.secondOfDay();
//        int int19 = dateTime15.getSecondOfDay();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gregorianCalendar5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1:59:38 PM" + "'", str8.equals("1:59:38 PM"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 75578 + "'", int19 == 75578);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
        org.joda.time.DateTime dateTime8 = dateTime4.withMillis((long) 12);
        org.joda.time.Instant instant10 = new org.joda.time.Instant((long) (-10));
        int int11 = dateTime8.compareTo((org.joda.time.ReadableInstant) instant10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.util.Locale locale13 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withLocale(locale13);
        java.lang.String str15 = instant10.toString(dateTimeFormatter12);
        org.joda.time.Instant instant18 = instant10.withDurationAdded(1560632378594L, 55);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "11:59:59 PM" + "'", str15.equals("11:59:59 PM"));
        org.junit.Assert.assertNotNull(instant18);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
        int int31 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
        int int51 = offsetDateTimeField46.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
        int int72 = offsetDateTimeField67.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology74 = null;
        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
        int[] intArray83 = monthDay75.getValues();
        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
        java.util.Locale locale88 = null;
        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
        org.joda.time.MonthDay monthDay91 = monthDay86.plusMonths((int) ' ');
        java.util.Locale locale93 = null;
        try {
            java.lang.String str94 = monthDay86.toString("11:59:59 PM", locale93);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(copticChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
        org.junit.Assert.assertNotNull(monthDay73);
        org.junit.Assert.assertNotNull(monthDay75);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(monthDay86);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
        org.junit.Assert.assertNotNull(monthDay91);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(1560632370712L);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
//        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
//        int int19 = offsetDateTimeField14.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
//        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
//        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
//        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
//        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
//        java.lang.String str47 = unsupportedDateTimeField46.toString();
//        try {
//            long long49 = unsupportedDateTimeField46.roundFloor(1560632318057L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632379055L + "'", long2 == 1560632379055L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1969");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.Instant instant5 = instant3.minus((long) (short) -1);
        org.joda.time.Instant instant6 = instant3.toInstant();
        org.joda.time.Instant instant8 = instant3.plus(1560632336585L);
        org.joda.time.Chronology chronology9 = instant3.getChronology();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }
}

