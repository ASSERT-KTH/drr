import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        org.joda.time.DurationField durationField14 = skipUndoDateTimeField13.getRangeDurationField();
        boolean boolean15 = skipUndoDateTimeField13.isSupported();
        java.lang.String str17 = skipUndoDateTimeField13.getAsShortText(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4" + "'", str17.equals("4"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.ReadablePartial readablePartial7 = null;
        java.util.Locale locale9 = null;
        java.lang.String str10 = delegatedDateTimeField4.getAsText(readablePartial7, 0, locale9);
        int int12 = delegatedDateTimeField4.getMinimumValue(1560632313085L);
        int int13 = delegatedDateTimeField4.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = copticChronology16.secondOfDay();
        org.joda.time.DateTimeField dateTimeField18 = copticChronology16.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType19);
        long long22 = delegatedDateTimeField20.roundFloor((long) 0);
        org.joda.time.DurationField durationField23 = delegatedDateTimeField20.getLeapDurationField();
        long long25 = delegatedDateTimeField20.roundHalfCeiling((long) (byte) 0);
        boolean boolean27 = delegatedDateTimeField20.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = copticChronology28.secondOfDay();
        org.joda.time.DateTimeField dateTimeField30 = copticChronology28.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 10);
        int int35 = offsetDateTimeField32.getDifference(0L, 0L);
        int int37 = offsetDateTimeField32.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay38 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology39 = null;
        org.joda.time.MonthDay monthDay40 = monthDay38.withChronologyRetainFields(chronology39);
        int[] intArray46 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int47 = offsetDateTimeField32.getMinimumValue((org.joda.time.ReadablePartial) monthDay40, intArray46);
        org.joda.time.chrono.CopticChronology copticChronology48 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = copticChronology48.secondOfDay();
        org.joda.time.DateTimeField dateTimeField50 = copticChronology48.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 10);
        int int55 = offsetDateTimeField52.getDifference(0L, 0L);
        int int57 = offsetDateTimeField52.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay58 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology59 = null;
        org.joda.time.MonthDay monthDay60 = monthDay58.withChronologyRetainFields(chronology59);
        int[] intArray66 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int67 = offsetDateTimeField52.getMinimumValue((org.joda.time.ReadablePartial) monthDay60, intArray66);
        boolean boolean68 = monthDay40.isEqual((org.joda.time.ReadablePartial) monthDay60);
        org.joda.time.chrono.CopticChronology copticChronology69 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField70 = copticChronology69.secondOfDay();
        org.joda.time.DateTimeField dateTimeField71 = copticChronology69.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField73 = new org.joda.time.field.OffsetDateTimeField(dateTimeField71, 10);
        int int76 = offsetDateTimeField73.getDifference(0L, 0L);
        int int78 = offsetDateTimeField73.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay79 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology80 = null;
        org.joda.time.MonthDay monthDay81 = monthDay79.withChronologyRetainFields(chronology80);
        int[] intArray87 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int88 = offsetDateTimeField73.getMinimumValue((org.joda.time.ReadablePartial) monthDay81, intArray87);
        int[] intArray89 = monthDay81.getValues();
        int int90 = delegatedDateTimeField20.getMinimumValue((org.joda.time.ReadablePartial) monthDay60, intArray89);
        try {
            int[] intArray92 = delegatedDateTimeField4.addWrapPartial(readablePartial14, 1969, intArray89, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1969");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1900800000L) + "'", long22 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 691200000L + "'", long25 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 11 + "'", int37 == 11);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 11 + "'", int47 == 11);
        org.junit.Assert.assertNotNull(copticChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 11 + "'", int57 == 11);
        org.junit.Assert.assertNotNull(monthDay58);
        org.junit.Assert.assertNotNull(monthDay60);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 11 + "'", int67 == 11);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(copticChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 11 + "'", int78 == 11);
        org.junit.Assert.assertNotNull(monthDay79);
        org.junit.Assert.assertNotNull(monthDay81);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 11 + "'", int88 == 11);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 1 + "'", int90 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long9 = offsetDateTimeField4.remainder(0L);
        java.util.Locale locale12 = null;
        long long13 = offsetDateTimeField4.set((long) 10, "100", locale12);
        org.joda.time.DurationField durationField14 = offsetDateTimeField4.getDurationField();
        org.joda.time.DurationField durationField15 = offsetDateTimeField4.getLeapDurationField();
        java.util.Locale locale18 = null;
        try {
            long long19 = offsetDateTimeField4.set((long) 6, "Jun", locale18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Jun\" for weekyearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9936000000L + "'", long9 == 9936000000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 94953600010L + "'", long13 == 94953600010L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getRangeDurationField();
        int int14 = delegatedDateTimeField4.getMinimumValue((long) 248);
        org.joda.time.DurationField durationField15 = delegatedDateTimeField4.getRangeDurationField();
        long long18 = delegatedDateTimeField4.add((long) (short) 100, 15);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField4.getAsShortText((long) 10, locale20);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 36720000100L + "'", long18 == 36720000100L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "4" + "'", str21.equals("4"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology1);
        try {
            org.joda.time.LocalDateTime localDateTime4 = dateTimeFormatter2.parseLocalDateTime("2017-08-05T13:59:12.208-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2017-08-05T13:59:12.208-07:00\" is malformed at \"17-08-05T13:59:12.208-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
//        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
//        int int19 = offsetDateTimeField14.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
//        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
//        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
//        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
//        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
//        java.lang.String str47 = unsupportedDateTimeField46.toString();
//        try {
//            long long49 = unsupportedDateTimeField46.roundHalfCeiling((long) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632380341L + "'", long2 == 1560632380341L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        long long8 = delegatedDateTimeField6.roundFloor((long) 0);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField6.getLeapDurationField();
        long long11 = delegatedDateTimeField6.roundHalfCeiling((long) (byte) 0);
        boolean boolean13 = delegatedDateTimeField6.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology14.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        int int21 = offsetDateTimeField18.getDifference(0L, 0L);
        int int23 = offsetDateTimeField18.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.MonthDay monthDay26 = monthDay24.withChronologyRetainFields(chronology25);
        int[] intArray32 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int33 = offsetDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) monthDay26, intArray32);
        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = copticChronology34.secondOfDay();
        org.joda.time.DateTimeField dateTimeField36 = copticChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 10);
        int int41 = offsetDateTimeField38.getDifference(0L, 0L);
        int int43 = offsetDateTimeField38.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay44 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.MonthDay monthDay46 = monthDay44.withChronologyRetainFields(chronology45);
        int[] intArray52 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int53 = offsetDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray52);
        boolean boolean54 = monthDay26.isEqual((org.joda.time.ReadablePartial) monthDay46);
        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = copticChronology55.secondOfDay();
        org.joda.time.DateTimeField dateTimeField57 = copticChronology55.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField57, 10);
        int int62 = offsetDateTimeField59.getDifference(0L, 0L);
        int int64 = offsetDateTimeField59.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay65 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.MonthDay monthDay67 = monthDay65.withChronologyRetainFields(chronology66);
        int[] intArray73 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int74 = offsetDateTimeField59.getMinimumValue((org.joda.time.ReadablePartial) monthDay67, intArray73);
        int[] intArray75 = monthDay67.getValues();
        int int76 = delegatedDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray75);
        boolean boolean77 = copticChronology0.equals((java.lang.Object) delegatedDateTimeField6);
        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology80 = copticChronology0.withZone(dateTimeZone79);
        org.joda.time.DateTimeField dateTimeField81 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField82 = copticChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1900800000L) + "'", long8 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 691200000L + "'", long11 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 11 + "'", int33 == 11);
        org.junit.Assert.assertNotNull(copticChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 11 + "'", int43 == 11);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 11 + "'", int53 == 11);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(copticChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 11 + "'", int64 == 11);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertNotNull(monthDay67);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 11 + "'", int74 == 11);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(dateTimeZone79);
        org.junit.Assert.assertNotNull(chronology80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertNotNull(dateTimeField82);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isAfter((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime2.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime.Property property7 = dateTime2.dayOfMonth();
        org.joda.time.DurationField durationField8 = property7.getDurationField();
        org.joda.time.DateTime dateTime10 = property7.setCopy(1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.shortDate();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("46", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"46\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getShortName(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.001" + "'", str4.equals("+00:00:00.001"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("55", (int) (short) 1);
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder3.writeTo("GregorianChronology[UTC]", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
//        java.lang.Object obj3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(obj3);
//        java.util.GregorianCalendar gregorianCalendar5 = dateTime4.toGregorianCalendar();
//        org.joda.time.DateTime.Property property6 = dateTime4.dayOfYear();
//        org.joda.time.DateTime dateTime7 = property6.getDateTime();
//        java.lang.String str8 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.year();
//        org.joda.time.Interval interval10 = property9.toInterval();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gregorianCalendar5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1:59:40 PM" + "'", str8.equals("1:59:40 PM"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(interval10);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 595, (-31449599635L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-18712511782825L) + "'", long2 == (-18712511782825L));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long9 = offsetDateTimeField4.remainder(0L);
        org.joda.time.DurationField durationField10 = offsetDateTimeField4.getRangeDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withLocale(locale12);
        org.joda.time.LocalTime localTime15 = dateTimeFormatter13.parseLocalTime("1:58:55 PM");
        int int16 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime15);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9936000000L + "'", long9 == 9936000000L);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        java.lang.String str8 = delegatedDateTimeField4.toString();
        org.joda.time.DurationField durationField9 = delegatedDateTimeField4.getLeapDurationField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, 2000);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        boolean boolean16 = dateTime14.isBefore(1L);
        org.joda.time.DateTime dateTime18 = dateTime14.withSecondOfMinute(0);
        org.joda.time.LocalDateTime localDateTime19 = dateTime14.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfYear();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 2000, (org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.util.Locale locale29 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter28.withLocale(locale29);
        org.joda.time.LocalTime localTime32 = dateTimeFormatter30.parseLocalTime("1:58:55 PM");
        int[] intArray34 = gregorianChronology24.get((org.joda.time.ReadablePartial) localTime32, 21859199987L);
        java.util.Locale locale36 = null;
        try {
            int[] intArray37 = offsetDateTimeField11.set((org.joda.time.ReadablePartial) localDateTime19, 56, intArray34, "2017-08-05T13:58:49.048-07:00", locale36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2017-08-05T13:58:49.048-07:00\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DateTimeField[monthOfYear]" + "'", str8.equals("DateTimeField[monthOfYear]"));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(localTime32);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(1560632329075L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundFloorCopy();
        org.joda.time.DateTime dateTime7 = property3.addToCopy(0);
        java.util.Locale locale8 = null;
        java.util.Calendar calendar9 = dateTime7.toCalendar(locale8);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.fromCalendarFields(calendar9);
        java.lang.Object obj11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(obj11);
        java.util.Locale locale13 = null;
        java.util.Calendar calendar14 = dateTime12.toCalendar(locale13);
        org.joda.time.DateTime dateTime16 = dateTime12.minusMillis(0);
        boolean boolean18 = dateTime12.isBefore((long) 44);
        org.joda.time.DateTime.Property property19 = dateTime12.centuryOfEra();
        boolean boolean20 = org.joda.time.field.FieldUtils.equals((java.lang.Object) monthDay10, (java.lang.Object) dateTime12);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(calendar9);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(calendar14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        org.joda.time.DurationField durationField14 = skipUndoDateTimeField13.getRangeDurationField();
        boolean boolean15 = skipUndoDateTimeField13.isSupported();
        long long18 = skipUndoDateTimeField13.add(1567987200000L, (long) (byte) 0);
        long long21 = skipUndoDateTimeField13.add((long) 44, (-1));
        long long24 = skipUndoDateTimeField13.add(1560632370649L, (long) 115200000);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1567987200000L + "'", long18 == 1567987200000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2591999956L) + "'", long21 == (-2591999956L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 279650445656370649L + "'", long24 == 279650445656370649L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(78710399999L);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfMonth();
        org.joda.time.DateTime dateTime4 = dateTime1.withMillis((long) 871);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) 10.0d, "");
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str32 = gregorianChronology31.toString();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology35 = gregorianChronology31.withZone(dateTimeZone34);
        org.joda.time.DurationField durationField36 = gregorianChronology31.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField36);
        try {
            int int39 = unsupportedDateTimeField37.getLeapAmount(15606288977631L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyearOfCentury field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "GregorianChronology[UTC]" + "'", str32.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(1560632370510L, 1560632378596L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3121264749106L + "'", long2 == 3121264749106L);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        int int9 = offsetDateTimeField4.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
//        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
//        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
//        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
//        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
//        long long36 = preciseDateTimeField35.getUnitMillis();
//        boolean boolean37 = preciseDateTimeField35.isLenient();
//        java.lang.String str39 = preciseDateTimeField35.getAsShortText((long) 0);
//        int int40 = preciseDateTimeField35.getMaximumValue();
//        java.lang.Object obj41 = null;
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(obj41);
//        long long43 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime42);
//        org.joda.time.DateTime dateTime45 = dateTime42.withMillisOfDay((int) 'a');
//        int int46 = dateTime42.getDayOfMonth();
//        org.joda.time.DateTime dateTime48 = dateTime42.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property49 = dateTime42.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = property49.getFieldType();
//        org.joda.time.chrono.CopticChronology copticChronology51 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField52 = copticChronology51.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField53 = copticChronology51.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, 10);
//        int int58 = offsetDateTimeField55.getDifference(0L, 0L);
//        int int60 = offsetDateTimeField55.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay61 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology62 = null;
//        org.joda.time.MonthDay monthDay63 = monthDay61.withChronologyRetainFields(chronology62);
//        int[] intArray69 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int70 = offsetDateTimeField55.getMinimumValue((org.joda.time.ReadablePartial) monthDay63, intArray69);
//        long long73 = offsetDateTimeField55.add((long) (short) 1, (int) (short) -1);
//        int int75 = offsetDateTimeField55.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType76 = offsetDateTimeField55.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException78 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType76, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone80 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology81 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone80);
//        org.joda.time.DurationField durationField82 = iSOChronology81.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology83 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField84 = buddhistChronology83.monthOfYear();
//        org.joda.time.DurationField durationField85 = buddhistChronology83.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField86 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType76, durationField82, durationField85);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField87 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType50, durationField85);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField91 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) preciseDateTimeField35, dateTimeFieldType50, 40, (-420), 40);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(buddhistChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1000L + "'", long36 == 1000L);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3599 + "'", int40 == 3599);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560632381556L + "'", long43 == 1560632381556L);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 15 + "'", int46 == 15);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertNotNull(copticChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 11 + "'", int60 == 11);
//        org.junit.Assert.assertNotNull(monthDay61);
//        org.junit.Assert.assertNotNull(monthDay63);
//        org.junit.Assert.assertNotNull(intArray69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 11 + "'", int70 == 11);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-31449599999L) + "'", long73 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType76);
//        org.junit.Assert.assertNotNull(dateTimeZone80);
//        org.junit.Assert.assertNotNull(iSOChronology81);
//        org.junit.Assert.assertNotNull(durationField82);
//        org.junit.Assert.assertNotNull(buddhistChronology83);
//        org.junit.Assert.assertNotNull(dateTimeField84);
//        org.junit.Assert.assertNotNull(durationField85);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField87);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (-10));
        org.joda.time.Instant instant4 = instant1.withDurationAdded((-115199899L), (int) ' ');
        org.junit.Assert.assertNotNull(instant4);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
//        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
//        int int19 = offsetDateTimeField14.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
//        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
//        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
//        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
//        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = unsupportedDateTimeField46.getType();
//        try {
//            long long50 = unsupportedDateTimeField46.addWrapField(1560632375109L, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632382289L + "'", long2 == 1560632382289L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("35");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        boolean boolean5 = delegatedDateTimeField4.isLenient();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isBefore(1L);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime2.withZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.DateTime dateTime11 = dateTime2.withZone(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime2.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("20");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"20\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 10, 6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.Chronology chronology6 = buddhistChronology3.withZone(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
//        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
//        int int19 = offsetDateTimeField14.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
//        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
//        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
//        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
//        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
//        java.lang.String str47 = unsupportedDateTimeField46.toString();
//        org.joda.time.DurationField durationField48 = unsupportedDateTimeField46.getLeapDurationField();
//        try {
//            int int50 = unsupportedDateTimeField46.getLeapAmount(1560628897763L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632382423L + "'", long2 == 1560632382423L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNull(durationField48);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone1.getShortName(0L, locale5);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+32:00" + "'", str6.equals("+32:00"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = dateTimeZone4.isLocalDateTimeGap(localDateTime5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = dateTimeZone4.getShortName(0L, locale8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        int int13 = cachedDateTimeZone11.getStandardOffset((long) 1969);
        java.lang.String str15 = cachedDateTimeZone11.getNameKey(0L);
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone11.getUncachedZone();
        org.joda.time.Chronology chronology17 = iSOChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone11);
        org.joda.time.DurationField durationField18 = iSOChronology2.centuries();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+32:00" + "'", str9.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 115200000 + "'", int13 == 115200000);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(durationField18);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property3.getAsShortText(locale5);
//        org.joda.time.DateTime dateTime8 = property3.addToCopy((long) 420);
//        java.util.Locale locale9 = null;
//        int int10 = property3.getMaximumShortTextLength(locale9);
//        java.util.Locale locale11 = null;
//        int int12 = property3.getMaximumTextLength(locale11);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "24" + "'", str6.equals("24"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(595, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57715 + "'", int2 == 57715);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfHour((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendDayOfWeekText();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560632383214L + "'", long4 == 1560632383214L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        java.lang.String str6 = delegatedDateTimeField4.getAsText((-1900800000L));
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsText(1969, locale8);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4" + "'", str6.equals("4"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        org.joda.time.DurationField durationField14 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        java.lang.String str20 = dateTimeZone17.getShortName((-1900800000L));
        java.util.TimeZone timeZone21 = dateTimeZone17.toTimeZone();
        java.lang.Object obj22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj22);
        java.util.Locale locale24 = null;
        java.util.Calendar calendar25 = dateTime23.toCalendar(locale24);
        int int26 = dateTimeZone17.getOffset((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(dateTimeZone28);
        boolean boolean31 = dateTime29.isBefore(1L);
        org.joda.time.DateTime dateTime33 = dateTime29.withSecondOfMinute(0);
        org.joda.time.LocalDateTime localDateTime34 = dateTime29.toLocalDateTime();
        boolean boolean35 = dateTimeZone17.isLocalDateTimeGap(localDateTime34);
        org.joda.time.Chronology chronology36 = gregorianChronology0.withZone(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+32:00" + "'", str20.equals("+32:00"));
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(calendar25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 115200000 + "'", int26 == 115200000);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localDateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(chronology36);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean4 = dateTime2.isAfter((-1L));
//        org.joda.time.DateTime dateTime6 = dateTime2.plus((long) (short) 10);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusYears(100);
//        int int9 = dateTime6.getDayOfMonth();
//        int int10 = dateTime6.getMinuteOfHour();
//        org.joda.time.DateTime.Property property11 = dateTime6.centuryOfEra();
//        java.lang.Object obj12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(obj12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfDay((int) 'a');
//        int int17 = dateTime13.getDayOfMonth();
//        org.joda.time.DateTime dateTime19 = dateTime13.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property20 = dateTime13.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
//        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
//        int int31 = offsetDateTimeField26.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
//        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
//        long long44 = offsetDateTimeField26.add((long) (short) 1, (int) (short) -1);
//        int int46 = offsetDateTimeField26.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = offsetDateTimeField26.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType47, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone51);
//        org.joda.time.DurationField durationField53 = iSOChronology52.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology54.monthOfYear();
//        org.joda.time.DurationField durationField56 = buddhistChronology54.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField57 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType47, durationField53, durationField56);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField58 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField56);
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = unsupportedDateTimeField58.getType();
//        boolean boolean60 = dateTime6.isSupported(dateTimeFieldType59);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560632384271L + "'", long14 == 1560632384271L);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 17 + "'", int17 == 17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-31449599999L) + "'", long44 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(iSOChronology52);
//        org.junit.Assert.assertNotNull(durationField53);
//        org.junit.Assert.assertNotNull(buddhistChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
//        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
//        int int19 = offsetDateTimeField14.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
//        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
//        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
//        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
//        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
//        java.lang.String str47 = unsupportedDateTimeField46.toString();
//        org.joda.time.DurationField durationField48 = unsupportedDateTimeField46.getDurationField();
//        try {
//            long long51 = unsupportedDateTimeField46.set(105148800001L, "");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632384922L + "'", long2 == 1560632384922L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 17 + "'", int5 == 17);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNotNull(durationField48);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("��", false);
        long long7 = dateTimeZone3.convertLocalToUTC(0L, false, (long) 420);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long10 = offsetDateTimeField4.add((long) (short) 0, (long) (byte) 0);
        long long12 = offsetDateTimeField4.roundHalfCeiling((long) ' ');
        long long15 = offsetDateTimeField4.add(0L, (long) 52);
        org.joda.time.DurationField durationField16 = offsetDateTimeField4.getLeapDurationField();
        java.lang.Object obj17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(obj17);
        java.util.GregorianCalendar gregorianCalendar19 = dateTime18.toGregorianCalendar();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
        org.joda.time.DateTime dateTime21 = property20.getDateTime();
        org.joda.time.DateTime dateTime22 = property20.roundFloorCopy();
        org.joda.time.DateTime dateTime24 = property20.addToCopy(0);
        java.util.Locale locale25 = null;
        java.util.Calendar calendar26 = dateTime24.toCalendar(locale25);
        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.fromCalendarFields(calendar26);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray28 = monthDay27.getFieldTypes();
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay27, 624, locale30);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9936000000L) + "'", long12 == (-9936000000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1641427200000L + "'", long15 == 1641427200000L);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertNotNull(gregorianCalendar19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(calendar26);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "624" + "'", str31.equals("624"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        long long37 = preciseDateTimeField35.roundCeiling(0L);
        java.util.Locale locale39 = null;
        java.lang.String str40 = preciseDateTimeField35.getAsText((long) 334, locale39);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "0" + "'", str40.equals("0"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long9 = offsetDateTimeField4.remainder(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay10, 0, locale12);
        try {
            org.joda.time.DateTimeField dateTimeField15 = monthDay10.getField((-13));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: -13");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9936000000L + "'", long9 == 9936000000L);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getShortName((-1900800000L));
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 1);
        try {
            long long14 = julianChronology6.getDateTimeMillis(0, 52, 3599, (int) (byte) 0, 0, 20, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+32:00" + "'", str4.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology6);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        java.lang.String str7 = dateTimeZone4.getShortName((-1900800000L));
        org.joda.time.Chronology chronology8 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str10 = gregorianChronology9.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology13 = gregorianChronology9.withZone(dateTimeZone12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        long long20 = delegatedDateTimeField18.roundFloor((long) 0);
        org.joda.time.DurationField durationField21 = delegatedDateTimeField18.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        java.util.Locale locale23 = null;
        int int24 = delegatedDateTimeField18.getMaximumShortTextLength(locale23);
        long long27 = delegatedDateTimeField18.add((-31449599999L), 56);
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField(chronology8, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        int int30 = delegatedDateTimeField18.getMaximumValue((long) (-420));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+32:00" + "'", str7.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[UTC]" + "'", str10.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1900800000L) + "'", long20 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 105148800001L + "'", long27 == 105148800001L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 13 + "'", int30 == 13);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        int int5 = dateTime4.getYear();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
        int int31 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
        int int51 = offsetDateTimeField46.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
        int int72 = offsetDateTimeField67.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology74 = null;
        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
        int[] intArray83 = monthDay75.getValues();
        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
        java.util.Locale locale88 = null;
        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
        org.joda.time.DurationField durationField91 = property90.getRangeDurationField();
        int int92 = property90.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType93 = property90.getFieldType();
        org.joda.time.DurationField durationField94 = property90.getDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(copticChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
        org.junit.Assert.assertNotNull(monthDay73);
        org.junit.Assert.assertNotNull(monthDay75);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(monthDay86);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
        org.junit.Assert.assertNotNull(property90);
        org.junit.Assert.assertNotNull(durationField91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType93);
        org.junit.Assert.assertNotNull(durationField94);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime3.isBeforeNow();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTime(dateTimeZone5);
//        int int7 = mutableDateTime6.getMinuteOfHour();
//        int int10 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime6, "dayOfMonth", 31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 59 + "'", int7 == 59);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-32) + "'", int10 == (-32));
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        java.lang.String str2 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime dateTime4 = dateTime1.minus(1560632322909L);
        int int5 = dateTime1.getHourOfDay();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getShortName((-1900800000L));
        java.util.TimeZone timeZone5 = dateTimeZone1.toTimeZone();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+32:00" + "'", str4.equals("+32:00"));
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        java.lang.String str7 = dateTimeZone4.getShortName((-1900800000L));
        org.joda.time.Chronology chronology8 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.DurationField durationField9 = copticChronology0.halfdays();
        try {
            long long17 = copticChronology0.getDateTimeMillis(57715, 110, (int) 'a', 3, 100, (int) (short) -1, (-420));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+32:00" + "'", str7.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField9);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int6 = offsetDateTimeField4.getMaximumValue(9936000000L);
//        org.joda.time.ReadablePartial readablePartial7 = null;
//        int int8 = offsetDateTimeField4.getMinimumValue(readablePartial7);
//        java.lang.Object obj9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(obj9);
//        java.util.Locale locale11 = null;
//        java.util.Calendar calendar12 = dateTime10.toCalendar(locale11);
//        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.fromCalendarFields(calendar12);
//        int int14 = monthDay13.getDayOfMonth();
//        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField17 = copticChronology16.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField18 = copticChronology16.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 10);
//        int int22 = offsetDateTimeField20.getMaximumValue(9936000000L);
//        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.MonthDay monthDay25 = monthDay23.withChronologyRetainFields(chronology24);
//        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField27 = copticChronology26.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField28 = copticChronology26.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 10);
//        int int33 = offsetDateTimeField30.getDifference(0L, 0L);
//        int int35 = offsetDateTimeField30.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology37 = null;
//        org.joda.time.MonthDay monthDay38 = monthDay36.withChronologyRetainFields(chronology37);
//        int[] intArray44 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int45 = offsetDateTimeField30.getMinimumValue((org.joda.time.ReadablePartial) monthDay38, intArray44);
//        int[] intArray46 = monthDay38.getValues();
//        int int47 = offsetDateTimeField20.getMinimumValue((org.joda.time.ReadablePartial) monthDay23, intArray46);
//        try {
//            int[] intArray49 = offsetDateTimeField4.set((org.joda.time.ReadablePartial) monthDay13, (int) 'a', intArray46, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekyearOfCentury must be in the range [11,110]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 110 + "'", int6 == 110);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
//        org.junit.Assert.assertNotNull(calendar12);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
//        org.junit.Assert.assertNotNull(copticChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 110 + "'", int22 == 110);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertNotNull(monthDay25);
//        org.junit.Assert.assertNotNull(copticChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 11 + "'", int35 == 11);
//        org.junit.Assert.assertNotNull(monthDay36);
//        org.junit.Assert.assertNotNull(monthDay38);
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 11 + "'", int45 == 11);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 11 + "'", int47 == 11);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        long long8 = delegatedDateTimeField6.roundFloor((long) 0);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField6.getLeapDurationField();
        long long11 = delegatedDateTimeField6.roundHalfCeiling((long) (byte) 0);
        boolean boolean13 = delegatedDateTimeField6.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology14.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        int int21 = offsetDateTimeField18.getDifference(0L, 0L);
        int int23 = offsetDateTimeField18.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.MonthDay monthDay26 = monthDay24.withChronologyRetainFields(chronology25);
        int[] intArray32 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int33 = offsetDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) monthDay26, intArray32);
        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = copticChronology34.secondOfDay();
        org.joda.time.DateTimeField dateTimeField36 = copticChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 10);
        int int41 = offsetDateTimeField38.getDifference(0L, 0L);
        int int43 = offsetDateTimeField38.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay44 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.MonthDay monthDay46 = monthDay44.withChronologyRetainFields(chronology45);
        int[] intArray52 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int53 = offsetDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray52);
        boolean boolean54 = monthDay26.isEqual((org.joda.time.ReadablePartial) monthDay46);
        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = copticChronology55.secondOfDay();
        org.joda.time.DateTimeField dateTimeField57 = copticChronology55.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField57, 10);
        int int62 = offsetDateTimeField59.getDifference(0L, 0L);
        int int64 = offsetDateTimeField59.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay65 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.MonthDay monthDay67 = monthDay65.withChronologyRetainFields(chronology66);
        int[] intArray73 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int74 = offsetDateTimeField59.getMinimumValue((org.joda.time.ReadablePartial) monthDay67, intArray73);
        int[] intArray75 = monthDay67.getValues();
        int int76 = delegatedDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray75);
        boolean boolean77 = copticChronology0.equals((java.lang.Object) delegatedDateTimeField6);
        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology80 = copticChronology0.withZone(dateTimeZone79);
        org.joda.time.DateTimeField dateTimeField81 = copticChronology0.secondOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField82 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField81);
        org.joda.time.DurationField durationField83 = delegatedDateTimeField82.getDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1900800000L) + "'", long8 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 691200000L + "'", long11 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 11 + "'", int33 == 11);
        org.junit.Assert.assertNotNull(copticChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 11 + "'", int43 == 11);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 11 + "'", int53 == 11);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(copticChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 11 + "'", int64 == 11);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertNotNull(monthDay67);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 11 + "'", int74 == 11);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(dateTimeZone79);
        org.junit.Assert.assertNotNull(chronology80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertNotNull(durationField83);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) -1, (java.lang.Number) 691200000L, number3);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 691200000L + "'", number5.equals(691200000L));
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("100");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withDefaultYear(0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatter7.getPrinter();
//        org.joda.time.format.DateTimeParser dateTimeParser9 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter8, dateTimeParser9);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
//        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeFormatter11.getZone();
//        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter11.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder3.append(dateTimePrinter8, dateTimeParser13);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeFormatter15.getZone();
//        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter15.getParser();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser17 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder0.append(dateTimePrinter8, dateTimeParserArray18);
//        java.lang.Object obj20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(obj20);
//        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime dateTime24 = dateTime21.withMillisOfDay((int) 'a');
//        int int25 = dateTime21.getDayOfMonth();
//        org.joda.time.DateTime dateTime27 = dateTime21.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property28 = dateTime21.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder19.appendDecimal(dateTimeFieldType29, (-420), 248);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimePrinter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeParser13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeParser17);
//        org.junit.Assert.assertNotNull(dateTimeParserArray18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560632386366L + "'", long22 == 1560632386366L);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 17 + "'", int25 == 17);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("1:58:46 PM", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1:58:46 PM\" is malformed at \":58:46 PM\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField4 = gJChronology3.hours();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        boolean boolean10 = dateTime8.isAfter((-1L));
        org.joda.time.DateTime dateTime12 = dateTime8.plus((long) (short) 10);
        org.joda.time.DateTime.Property property13 = dateTime8.dayOfWeek();
        try {
            org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime8, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 31");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long9 = offsetDateTimeField4.remainder(0L);
        java.util.Locale locale12 = null;
        long long13 = offsetDateTimeField4.set((long) 10, "100", locale12);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField4, 248, 12, 999);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9936000000L + "'", long9 == 9936000000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 94953600010L + "'", long13 == 94953600010L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2017-08-05T13:59:18.990-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 10);
        int int9 = offsetDateTimeField6.getDifference(0L, 0L);
        java.lang.String str11 = offsetDateTimeField6.getAsText(1560632313085L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, (org.joda.time.DateTimeField) offsetDateTimeField6);
        java.lang.String str13 = skipUndoDateTimeField12.toString();
        org.joda.time.DurationField durationField14 = skipUndoDateTimeField12.getDurationField();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "46" + "'", str11.equals("46"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[weekyearOfCentury]" + "'", str13.equals("DateTimeField[weekyearOfCentury]"));
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        long long36 = preciseDateTimeField35.getUnitMillis();
        long long39 = preciseDateTimeField35.set(1560632340763L, (int) 'a');
        boolean boolean40 = preciseDateTimeField35.isLenient();
        long long42 = preciseDateTimeField35.roundCeiling((long) 31);
        int int44 = preciseDateTimeField35.getLeapAmount(1560632344027L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1000L + "'", long36 == 1000L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560628897763L + "'", long39 == 1560628897763L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1000L + "'", long42 == 1000L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField4.getAsText((long) (-420), locale26);
        long long29 = offsetDateTimeField4.roundHalfCeiling((long) (short) 1);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "97" + "'", str27.equals("97"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-9936000000L) + "'", long29 == (-9936000000L));
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        long long6 = copticChronology0.add(readablePeriod3, 1L, (int) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        java.lang.String str11 = dateTimeZone8.getShortName((-1900800000L));
//        java.util.TimeZone timeZone12 = dateTimeZone8.toTimeZone();
//        java.lang.Object obj13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj13);
//        java.util.Locale locale15 = null;
//        java.util.Calendar calendar16 = dateTime14.toCalendar(locale15);
//        int int17 = dateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean22 = dateTime20.isBefore(1L);
//        org.joda.time.DateTime dateTime24 = dateTime20.withSecondOfMinute(0);
//        org.joda.time.LocalDateTime localDateTime25 = dateTime20.toLocalDateTime();
//        boolean boolean26 = dateTimeZone8.isLocalDateTimeGap(localDateTime25);
//        long long28 = copticChronology0.set((org.joda.time.ReadablePartial) localDateTime25, 1L);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+32:00" + "'", str11.equals("+32:00"));
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNotNull(calendar16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 115200000 + "'", int17 == 115200000);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10513227586719L + "'", long28 == 10513227586719L);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        long long36 = preciseDateTimeField35.getUnitMillis();
        long long38 = preciseDateTimeField35.remainder(105148800001L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1000L + "'", long36 == 1000L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.LocalDateTime localDateTime2 = null;
//        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone1.getShortName(0L, locale5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) cachedDateTimeZone8);
//        java.lang.Object obj10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(obj10);
//        int int12 = dateTime11.getMillisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        boolean boolean16 = dateTime11.isAfter((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.Instant instant17 = new org.joda.time.Instant((java.lang.Object) dateTime15);
//        org.joda.time.DateTime dateTime19 = dateTime15.plusMinutes(786);
//        boolean boolean20 = cachedDateTimeZone8.equals((java.lang.Object) dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+32:00" + "'", str6.equals("+32:00"));
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 11 + "'", int12 == 11);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology5 = gregorianChronology1.withZone(dateTimeZone4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTimeZone4.getShortName(10L, locale7);
        org.joda.time.Chronology chronology9 = gJChronology0.withZone(dateTimeZone4);
        try {
            long long14 = gJChronology0.getDateTimeMillis(1969, (-13), (-10), 53);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -13 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+32:00" + "'", str8.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        java.lang.String str7 = dateTimeZone4.getShortName((-1900800000L));
        org.joda.time.Chronology chronology8 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.Instant instant10 = new org.joda.time.Instant();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime13 = instant10.toDateTime(dateTimeZone12);
        try {
            org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime13, 165);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 165");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+32:00" + "'", str7.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone1.getShortName(0L, locale5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long10 = cachedDateTimeZone8.previousTransition((long) 2);
        int int12 = cachedDateTimeZone8.getStandardOffset(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+32:00" + "'", str6.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 115200000 + "'", int12 == 115200000);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
//        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
//        int int19 = offsetDateTimeField14.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
//        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
//        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
//        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
//        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
//        java.lang.String str47 = unsupportedDateTimeField46.toString();
//        org.joda.time.DurationField durationField48 = unsupportedDateTimeField46.getDurationField();
//        try {
//            long long50 = unsupportedDateTimeField46.remainder(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632387155L + "'", long2 == 1560632387155L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 17 + "'", int5 == 17);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNotNull(durationField48);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long4 = buddhistChronology0.add((long) (short) 1, 1560628897763L, 10);
//        java.lang.Object obj5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime9 = dateTime6.withMillisOfDay((int) 'a');
//        int int10 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTime dateTime12 = dateTime6.withDayOfYear((int) (byte) 1);
//        java.lang.Object obj13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj13);
//        org.joda.time.DateTime dateTime16 = dateTime14.plusDays((int) (short) 10);
//        org.joda.time.LocalTime localTime17 = dateTime14.toLocalTime();
//        int int18 = dateTime14.getEra();
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime14.plus(readableDuration19);
//        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.ReadableDateTime) dateTime12, (org.joda.time.ReadableDateTime) dateTime20);
//        try {
//            long long29 = limitChronology21.getDateTimeMillis((int) (byte) 100, 2, 46, (int) (short) 100, (int) (byte) 100, 0, 46);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 46 for dayOfMonth must be in the range [1,28]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 15606288977631L + "'", long4 == 15606288977631L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560632387200L + "'", long7 == 1560632387200L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 17 + "'", int10 == 17);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(limitChronology21);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.DurationField durationField10 = offsetDateTimeField4.getDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfSecond(334);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendShortText(dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
        int int31 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
        int int51 = offsetDateTimeField46.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
        int int72 = offsetDateTimeField67.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology74 = null;
        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
        int[] intArray83 = monthDay75.getValues();
        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
        java.util.Locale locale88 = null;
        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
        int int90 = offsetDateTimeField4.getMinimumValue();
        java.lang.String str91 = offsetDateTimeField4.getName();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(copticChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
        org.junit.Assert.assertNotNull(monthDay73);
        org.junit.Assert.assertNotNull(monthDay75);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(monthDay86);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 11 + "'", int90 == 11);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "weekyearOfCentury" + "'", str91.equals("weekyearOfCentury"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        int int9 = offsetDateTimeField4.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
//        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
//        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
//        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
//        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
//        long long36 = preciseDateTimeField35.getUnitMillis();
//        long long39 = preciseDateTimeField35.set(1560632340763L, (int) 'a');
//        boolean boolean40 = preciseDateTimeField35.isLenient();
//        long long42 = preciseDateTimeField35.roundCeiling((long) 31);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = preciseDateTimeField35.getAsShortText(0, locale44);
//        java.lang.Object obj46 = null;
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(obj46);
//        long long48 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime47);
//        org.joda.time.DateTime dateTime50 = dateTime47.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property51 = dateTime50.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property51.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField53 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) preciseDateTimeField35, dateTimeFieldType52);
//        boolean boolean55 = zeroIsMaxDateTimeField53.isLeap(1560632340763L);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(buddhistChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1000L + "'", long36 == 1000L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560628897763L + "'", long39 == 1560628897763L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1000L + "'", long42 == 1000L);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "0" + "'", str45.equals("0"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560632387448L + "'", long48 == 1560632387448L);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
//        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
//        int int19 = offsetDateTimeField14.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
//        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
//        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
//        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
//        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
//        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeUtils.getZone(dateTimeZone48);
//        java.lang.String str51 = dateTimeZone49.getName(0L);
//        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        boolean boolean57 = dateTime55.isBefore(1L);
//        org.joda.time.DateTime dateTime59 = dateTime55.withSecondOfMinute(0);
//        org.joda.time.LocalDateTime localDateTime60 = dateTime55.toLocalDateTime();
//        boolean boolean61 = dateTimeZone49.isLocalDateTimeGap(localDateTime60);
//        java.util.Locale locale63 = null;
//        try {
//            java.lang.String str64 = unsupportedDateTimeField46.getAsShortText((org.joda.time.ReadablePartial) localDateTime60, 7, locale63);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632387801L + "'", long2 == 1560632387801L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 17 + "'", int5 == 17);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "+00:00:00.001" + "'", str51.equals("+00:00:00.001"));
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(localDateTime60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfHour((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMillisOfSecond(44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendYear(2, 19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560632387853L + "'", long4 == 1560632387853L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(75578, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.secondOfDay();
        boolean boolean4 = copticChronology0.equals((java.lang.Object) 9936000000L);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.year();
        org.joda.time.DurationField durationField6 = copticChronology0.hours();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        int int9 = offsetDateTimeField4.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
//        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
//        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
//        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
//        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
//        long long37 = preciseDateTimeField35.roundCeiling(0L);
//        java.lang.String str38 = preciseDateTimeField35.toString();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder39.appendDayOfWeekShortText();
//        java.lang.Object obj41 = null;
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(obj41);
//        long long43 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime42);
//        org.joda.time.DateTime dateTime45 = dateTime42.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property46 = dateTime45.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property46.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder39.appendSignedDecimal(dateTimeFieldType47, (int) (short) 100, (int) (byte) 10);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) preciseDateTimeField35, dateTimeFieldType47, 17, 0, 52);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(buddhistChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "DateTimeField[weekyearOfCentury]" + "'", str38.equals("DateTimeField[weekyearOfCentury]"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560632387971L + "'", long43 == 1560632387971L);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) (short) 10);
        boolean boolean8 = delegatedDateTimeField4.isLeap((-1900800000L));
        int int11 = delegatedDateTimeField4.getDifference(0L, (long) (-6));
        int int14 = delegatedDateTimeField4.getDifference((long) 595, (long) 1258);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean4 = dateTime2.isAfter((-1L));
//        org.joda.time.DateTime dateTime6 = dateTime2.plus((long) (short) 10);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusYears(100);
//        int int9 = dateTime6.getDayOfMonth();
//        java.util.Locale locale10 = null;
//        java.util.Calendar calendar11 = dateTime6.toCalendar(locale10);
//        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.fromCalendarFields(calendar11);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
//        org.junit.Assert.assertNotNull(calendar11);
//        org.junit.Assert.assertNotNull(monthDay12);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.Instant instant5 = instant3.minus((long) (short) -1);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant3.plus(readableDuration6);
        org.joda.time.DateTime dateTime8 = instant7.toDateTimeISO();
        org.joda.time.DateTime dateTime10 = dateTime8.withHourOfDay(10);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.DateTimeFormat.shortDate();
//        org.joda.time.Chronology chronology15 = dateTimeFormatter14.getChronolgy();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter14.withPivotYear(11);
//        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatter17.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder0.append(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560632388475L + "'", long4 == 1560632388475L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimePrinter18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MonthDay monthDay3 = monthDay1.withChronologyRetainFields(chronology2);
        java.lang.String str4 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.MonthDay monthDay9 = monthDay1.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology8);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType11 = monthDay1.getFieldType((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "��" + "'", str4.equals("��"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        long long36 = preciseDateTimeField35.getUnitMillis();
        boolean boolean37 = preciseDateTimeField35.isLenient();
        java.lang.String str39 = preciseDateTimeField35.getAsShortText((long) 0);
        int int40 = preciseDateTimeField35.getMaximumValue();
        org.joda.time.DurationField durationField41 = preciseDateTimeField35.getRangeDurationField();
        long long43 = preciseDateTimeField35.roundFloor(1560632344027L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1000L + "'", long36 == 1000L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3599 + "'", int40 == 3599);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560632344000L + "'", long43 == 1560632344000L);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        boolean boolean6 = property3.equals((java.lang.Object) 2);
//        org.joda.time.DateTime dateTime8 = property3.addToCopy(0L);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property3.getAsText(locale9);
//        org.joda.time.DateTime dateTime11 = property3.withMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        java.lang.String str16 = dateTimeZone13.getShortName((-1900800000L));
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13, 1);
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.minuteOfDay();
//        java.lang.String str20 = julianChronology18.toString();
//        org.joda.time.DateTimeField dateTimeField21 = julianChronology18.yearOfEra();
//        org.joda.time.DateTime dateTime22 = dateTime11.withChronology((org.joda.time.Chronology) julianChronology18);
//        org.joda.time.DateTime dateTime24 = dateTime11.minusMinutes(40);
//        org.junit.Assert.assertNotNull(gregorianCalendar2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "168" + "'", str10.equals("168"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+32:00" + "'", str16.equals("+32:00"));
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "JulianChronology[+32:00,mdfw=1]" + "'", str20.equals("JulianChronology[+32:00,mdfw=1]"));
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
//        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
//        int int19 = offsetDateTimeField14.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
//        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
//        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
//        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
//        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = unsupportedDateTimeField46.getType();
//        long long50 = unsupportedDateTimeField46.add((long) 837, (int) '4');
//        try {
//            long long52 = unsupportedDateTimeField46.roundHalfCeiling(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632388854L + "'", long2 == 1560632388854L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 17 + "'", int5 == 17);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 187200837L + "'", long50 == 187200837L);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str1 = gJChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[UTC]" + "'", str1.equals("GJChronology[UTC]"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException9.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        java.lang.Number number15 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.Number number16 = illegalFieldValueException2.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType17 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertNull(durationFieldType17);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = offsetDateTimeField4.getMinimumValue(readablePartial5);
        long long8 = offsetDateTimeField4.remainder((long) 15);
        long long10 = offsetDateTimeField4.roundHalfEven(94953600010L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField4.getAsText(readablePartial11, 1258, locale13);
        boolean boolean16 = offsetDateTimeField4.isLeap(1971291520665L);
        long long18 = offsetDateTimeField4.remainder((long) 53);
        org.joda.time.DurationField durationField19 = offsetDateTimeField4.getLeapDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9936000015L + "'", long8 == 9936000015L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 85017600000L + "'", long10 == 85017600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1258" + "'", str14.equals("1258"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9936000053L + "'", long18 == 9936000053L);
        org.junit.Assert.assertNull(durationField19);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder13.appendTimeZoneOffset("2017-08-05T13:59:12.208-07:00", true, 11, (int) (byte) 100);
//        java.lang.Object obj19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(obj19);
//        long long21 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime23 = dateTime20.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder13.appendShortText(dateTimeFieldType25);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap27 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendTimeZoneName(strMap27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560632389001L + "'", long4 == 1560632389001L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560632389002L + "'", long21 == 1560632389002L);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[+32:00]" + "'", str1.equals("BuddhistChronology[+32:00]"));
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.Locale locale2 = null;
        java.util.Calendar calendar3 = dateTime1.toCalendar(locale2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime1.toMutableDateTime(dateTimeZone5);
        java.lang.String str9 = dateTimeZone5.getName((-18712511782825L));
        org.junit.Assert.assertNotNull(calendar3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+32:00" + "'", str9.equals("+32:00"));
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
//        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
//        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
//        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
//        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
//        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
//        int int31 = offsetDateTimeField26.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
//        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
//        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
//        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
//        int int51 = offsetDateTimeField46.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology53 = null;
//        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
//        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
//        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
//        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
//        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
//        int int72 = offsetDateTimeField67.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology74 = null;
//        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
//        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
//        int[] intArray83 = monthDay75.getValues();
//        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
//        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
//        java.util.Locale locale88 = null;
//        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
//        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
//        java.lang.String str91 = property90.getAsString();
//        org.joda.time.MonthDay monthDay93 = property90.addWrapFieldToCopy((int) 'a');
//        org.joda.time.MonthDay monthDay95 = property90.setCopy((int) (byte) 1);
//        int int96 = property90.getMaximumValueOverall();
//        java.util.Locale locale97 = null;
//        java.lang.String str98 = property90.getAsText(locale97);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
//        org.junit.Assert.assertNotNull(copticChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(copticChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertNotNull(monthDay86);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
//        org.junit.Assert.assertNotNull(property90);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "25" + "'", str91.equals("25"));
//        org.junit.Assert.assertNotNull(monthDay93);
//        org.junit.Assert.assertNotNull(monthDay95);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 31 + "'", int96 == 31);
//        org.junit.Assert.assertTrue("'" + str98 + "' != '" + "25" + "'", str98.equals("25"));
//    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        int int9 = offsetDateTimeField4.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
//        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
//        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
//        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
//        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
//        long long36 = preciseDateTimeField35.getUnitMillis();
//        long long39 = preciseDateTimeField35.set(1560632340763L, (int) 'a');
//        boolean boolean40 = preciseDateTimeField35.isLenient();
//        long long42 = preciseDateTimeField35.roundCeiling((long) 31);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = preciseDateTimeField35.getAsShortText(0, locale44);
//        java.lang.Object obj46 = null;
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(obj46);
//        long long48 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime47);
//        org.joda.time.DateTime dateTime50 = dateTime47.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property51 = dateTime50.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property51.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField53 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) preciseDateTimeField35, dateTimeFieldType52);
//        long long55 = zeroIsMaxDateTimeField53.roundHalfFloor((long) 52);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(buddhistChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1000L + "'", long36 == 1000L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560628897763L + "'", long39 == 1560628897763L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1000L + "'", long42 == 1000L);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "0" + "'", str45.equals("0"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560632389827L + "'", long48 == 1560632389827L);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("55", (int) (short) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("Feb 7, ���� �:��:�� �", 839);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeZoneBuilder6.toDateTimeZone("0", true);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
//        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
//        int int19 = offsetDateTimeField14.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
//        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
//        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
//        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
//        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = unsupportedDateTimeField46.getType();
//        long long50 = unsupportedDateTimeField46.add((long) 837, (int) '4');
//        try {
//            long long53 = unsupportedDateTimeField46.addWrapField(691200000L, (-10));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632390087L + "'", long2 == 1560632390087L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 17 + "'", int5 == 17);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 187200837L + "'", long50 == 187200837L);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("GJChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"GJChronology[UTC]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean5 = dateTime3.isBefore(1L);
        org.joda.time.DateTime dateTime7 = dateTime3.withSecondOfMinute(0);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime3.getZone();
        java.lang.String str10 = dateTimeZone8.getName((long) 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withZone(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        boolean boolean6 = property3.equals((java.lang.Object) 2);
//        org.joda.time.DateTime dateTime8 = property3.addToCopy(0L);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property3.getAsText(locale9);
//        org.joda.time.DateTime dateTime11 = property3.withMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        boolean boolean16 = dateTime14.isAfter((-1L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        boolean boolean18 = dateTime14.isSupported(dateTimeFieldType17);
//        org.joda.time.DateTime.Property property19 = dateTime14.dayOfMonth();
//        boolean boolean20 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime14);
//        java.lang.Object obj21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(obj21);
//        java.util.GregorianCalendar gregorianCalendar23 = dateTime22.toGregorianCalendar();
//        org.joda.time.DateTime.Property property24 = dateTime22.dayOfYear();
//        org.joda.time.DateTime dateTime25 = property24.getDateTime();
//        org.joda.time.DateTime dateTime26 = property24.roundFloorCopy();
//        org.joda.time.DateTime dateTime28 = property24.addToCopy(0);
//        java.util.Locale locale29 = null;
//        java.util.Calendar calendar30 = dateTime28.toCalendar(locale29);
//        org.joda.time.MonthDay monthDay31 = org.joda.time.MonthDay.fromCalendarFields(calendar30);
//        org.joda.time.DateTime dateTime32 = dateTime14.withFields((org.joda.time.ReadablePartial) monthDay31);
//        org.junit.Assert.assertNotNull(gregorianCalendar2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "168" + "'", str10.equals("168"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(gregorianCalendar23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(calendar30);
//        org.junit.Assert.assertNotNull(monthDay31);
//        org.junit.Assert.assertNotNull(dateTime32);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(number3);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        boolean boolean6 = property3.equals((java.lang.Object) 2);
//        org.joda.time.DateTime dateTime8 = property3.addToCopy(0L);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property3.getAsText(locale9);
//        org.joda.time.DateTime dateTime11 = property3.withMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        boolean boolean16 = dateTime14.isAfter((-1L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        boolean boolean18 = dateTime14.isSupported(dateTimeFieldType17);
//        org.joda.time.DateTime.Property property19 = dateTime14.dayOfMonth();
//        boolean boolean20 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime.Property property21 = dateTime11.era();
//        org.junit.Assert.assertNotNull(gregorianCalendar2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "168" + "'", str10.equals("168"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(property21);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long10 = offsetDateTimeField4.add((long) (short) 0, (long) (byte) 0);
        int int12 = offsetDateTimeField4.getLeapAmount((long) (short) 1);
        int int13 = offsetDateTimeField4.getMinimumValue();
        long long16 = offsetDateTimeField4.addWrapField(85017600000L, (int) (byte) -1);
        long long18 = offsetDateTimeField4.roundHalfEven(482371706L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 53568000000L + "'", long16 == 53568000000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-9936000000L) + "'", long18 == (-9936000000L));
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        int int9 = offsetDateTimeField4.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
//        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
//        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
//        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
//        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
//        long long36 = preciseDateTimeField35.getUnitMillis();
//        long long39 = preciseDateTimeField35.set(1560632340763L, (int) 'a');
//        boolean boolean40 = preciseDateTimeField35.isLenient();
//        long long42 = preciseDateTimeField35.roundCeiling((long) 31);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = preciseDateTimeField35.getAsShortText(0, locale44);
//        java.lang.Object obj46 = null;
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(obj46);
//        long long48 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime47);
//        org.joda.time.DateTime dateTime50 = dateTime47.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property51 = dateTime50.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property51.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField53 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) preciseDateTimeField35, dateTimeFieldType52);
//        boolean boolean54 = preciseDateTimeField35.isLenient();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(buddhistChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1000L + "'", long36 == 1000L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560628897763L + "'", long39 == 1560628897763L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1000L + "'", long42 == 1000L);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "0" + "'", str45.equals("0"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560632391362L + "'", long48 == 1560632391362L);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology5 = gregorianChronology1.withZone(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology1.hours();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withPivotYear((-420));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
        org.joda.time.DateTime dateTime8 = dateTime4.withMillisOfDay(248);
        org.joda.time.DateTime dateTime10 = dateTime8.withMillis(0L);
        int int11 = dateTime10.getDayOfYear();
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears(6);
        org.joda.time.DateTime dateTime14 = dateTime13.toDateTimeISO();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
        org.joda.time.DateTime dateTime8 = dateTime4.withMillis((long) 12);
        org.joda.time.Instant instant10 = new org.joda.time.Instant((long) (-10));
        int int11 = dateTime8.compareTo((org.joda.time.ReadableInstant) instant10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.util.Locale locale13 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withLocale(locale13);
        java.lang.String str15 = instant10.toString(dateTimeFormatter12);
        org.joda.time.MutableDateTime mutableDateTime16 = instant10.toMutableDateTime();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "11:59:59 PM" + "'", str15.equals("11:59:59 PM"));
        org.junit.Assert.assertNotNull(mutableDateTime16);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra(1969, 1258);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatterBuilder8.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
        int int19 = offsetDateTimeField16.getDifference(0L, 0L);
        int int21 = offsetDateTimeField16.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay22.withChronologyRetainFields(chronology23);
        int[] intArray30 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int31 = offsetDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) monthDay24, intArray30);
        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = copticChronology32.secondOfDay();
        org.joda.time.DateTimeField dateTimeField34 = copticChronology32.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 10);
        int int39 = offsetDateTimeField36.getDifference(0L, 0L);
        int int41 = offsetDateTimeField36.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay42 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.MonthDay monthDay44 = monthDay42.withChronologyRetainFields(chronology43);
        int[] intArray50 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int51 = offsetDateTimeField36.getMinimumValue((org.joda.time.ReadablePartial) monthDay44, intArray50);
        boolean boolean52 = monthDay24.isEqual((org.joda.time.ReadablePartial) monthDay44);
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField54 = copticChronology53.secondOfDay();
        org.joda.time.DateTimeField dateTimeField55 = copticChronology53.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, 10);
        int int60 = offsetDateTimeField57.getDifference(0L, 0L);
        int int62 = offsetDateTimeField57.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay63 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology64 = null;
        org.joda.time.MonthDay monthDay65 = monthDay63.withChronologyRetainFields(chronology64);
        int[] intArray71 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int72 = offsetDateTimeField57.getMinimumValue((org.joda.time.ReadablePartial) monthDay65, intArray71);
        int[] intArray73 = monthDay65.getValues();
        int int74 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay44, intArray73);
        org.joda.time.MonthDay monthDay76 = monthDay44.plusDays((int) (short) 100);
        org.joda.time.chrono.ISOChronology iSOChronology77 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay78 = new org.joda.time.MonthDay((java.lang.Object) monthDay76, (org.joda.time.Chronology) iSOChronology77);
        int int79 = monthDay78.size();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(copticChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 11 + "'", int62 == 11);
        org.junit.Assert.assertNotNull(monthDay63);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(monthDay76);
        org.junit.Assert.assertNotNull(iSOChronology77);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 2 + "'", int79 == 2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendFractionOfHour(44, 31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral("100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withDefaultYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatter12.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser14 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone17 = dateTimeFormatter16.getZone();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder8.append(dateTimePrinter13, dateTimeParser18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone21 = dateTimeFormatter20.getZone();
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatter20.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray23 = new org.joda.time.format.DateTimeParser[] { dateTimeParser22 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder5.append(dateTimePrinter13, dateTimeParserArray23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeParser22);
        org.junit.Assert.assertNotNull(dateTimeParserArray23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isAfter((-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime2.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime.Property property7 = dateTime2.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long4 = buddhistChronology0.add((long) (short) 1, 1560628897763L, 10);
//        java.lang.Object obj5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime9 = dateTime6.withMillisOfDay((int) 'a');
//        int int10 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTime dateTime12 = dateTime6.withDayOfYear((int) (byte) 1);
//        java.lang.Object obj13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj13);
//        org.joda.time.DateTime dateTime16 = dateTime14.plusDays((int) (short) 10);
//        org.joda.time.LocalTime localTime17 = dateTime14.toLocalTime();
//        int int18 = dateTime14.getEra();
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime14.plus(readableDuration19);
//        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.ReadableDateTime) dateTime12, (org.joda.time.ReadableDateTime) dateTime20);
//        java.lang.String str22 = limitChronology21.toString();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 15606288977631L + "'", long4 == 15606288977631L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560632392138L + "'", long7 == 1560632392138L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 17 + "'", int10 == 17);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(limitChronology21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "LimitChronology[BuddhistChronology[UTC], 2019-01-01T04:59:52.138+32:00, 2019-06-17T04:59:52.139+32:00]" + "'", str22.equals("LimitChronology[BuddhistChronology[UTC], 2019-01-01T04:59:52.138+32:00, 2019-06-17T04:59:52.139+32:00]"));
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(7, (int) (short) -1, 837, 624, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 624 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        java.lang.Object obj0 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekShortText();
//        java.lang.Object obj3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(obj3);
//        long long5 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime7 = dateTime4.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType9, (int) (short) 100, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder1.appendDayOfMonth(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder1.appendTimeZoneShortName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendYearOfCentury((int) '#', (-13));
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) '#');
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560632392355L + "'", long5 == 1560632392355L);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isBefore(1L);
        org.joda.time.DateTime dateTime6 = dateTime2.withSecondOfMinute(0);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime2.getZone();
        int int8 = dateTime2.getCenturyOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str10 = gregorianChronology9.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology13 = gregorianChronology9.withZone(dateTimeZone12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dateTimeZone12.getShortName(10L, locale15);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        java.util.Locale locale19 = null;
        java.lang.String str20 = dateTimeZone12.getName((long) 31, locale19);
        org.joda.time.DateTime dateTime21 = dateTime2.withZoneRetainFields(dateTimeZone12);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, 786);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 786");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[UTC]" + "'", str10.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+32:00" + "'", str16.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+32:00" + "'", str20.equals("+32:00"));
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        long long36 = preciseDateTimeField35.getUnitMillis();
        boolean boolean37 = preciseDateTimeField35.isLenient();
        java.lang.String str39 = preciseDateTimeField35.getAsShortText((long) 0);
        long long41 = preciseDateTimeField35.roundCeiling((long) 75578);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1000L + "'", long36 == 1000L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 76000L + "'", long41 == 76000L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("2017-08-05T13:59:00.693-07:00", 59, 15, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for 2017-08-05T13:59:00.693-07:00 must be in the range [15,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusDays((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean6 = dateTime4.isBefore(1L);
//        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime4);
//        int int8 = dateTime4.getDayOfWeek();
//        org.joda.time.DateTime dateTime10 = dateTime4.withEra((int) (byte) 1);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getName(locale2, "", "JulianChronology[+32:00,mdfw=1]");
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) (short) 10);
        boolean boolean8 = delegatedDateTimeField4.isLeap((-1900800000L));
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField4.getType();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField4 = gJChronology3.hours();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology6.secondOfDay();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology6.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 10);
        boolean boolean11 = gJChronology3.equals((java.lang.Object) dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        java.lang.String str7 = dateTimeZone4.getShortName((-1900800000L));
        org.joda.time.Chronology chronology8 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.DurationField durationField9 = copticChronology0.halfdays();
        try {
            long long12 = durationField9.subtract((long) 19, 1560632374147L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -1560632374147 * 43200000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+32:00" + "'", str7.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getShortName((-1900800000L));
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 1);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+32:00" + "'", str4.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.lang.String str4 = dateTimeZone2.getName(0L);
        java.lang.String str6 = dateTimeZone2.getShortName(9936000053L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.001" + "'", str4.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.001" + "'", str6.equals("+00:00:00.001"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        java.util.Locale locale14 = null;
        int int15 = delegatedDateTimeField9.getMaximumShortTextLength(locale14);
        long long17 = delegatedDateTimeField9.remainder(1560632323158L);
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.secondOfDay();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology18.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, 10);
        int int25 = offsetDateTimeField22.getDifference(0L, 0L);
        long long27 = offsetDateTimeField22.remainder(0L);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) monthDay28, 0, locale30);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = copticChronology33.secondOfDay();
        org.joda.time.DateTimeField dateTimeField35 = copticChronology33.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, 10);
        int int39 = offsetDateTimeField37.getMaximumValue(9936000000L);
        org.joda.time.MonthDay monthDay40 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology41 = null;
        org.joda.time.MonthDay monthDay42 = monthDay40.withChronologyRetainFields(chronology41);
        org.joda.time.chrono.CopticChronology copticChronology43 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = copticChronology43.secondOfDay();
        org.joda.time.DateTimeField dateTimeField45 = copticChronology43.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, 10);
        int int50 = offsetDateTimeField47.getDifference(0L, 0L);
        int int52 = offsetDateTimeField47.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay53 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology54 = null;
        org.joda.time.MonthDay monthDay55 = monthDay53.withChronologyRetainFields(chronology54);
        int[] intArray61 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int62 = offsetDateTimeField47.getMinimumValue((org.joda.time.ReadablePartial) monthDay55, intArray61);
        int[] intArray63 = monthDay55.getValues();
        int int64 = offsetDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay40, intArray63);
        int[] intArray66 = delegatedDateTimeField9.add((org.joda.time.ReadablePartial) monthDay28, (int) (short) -1, intArray63, (int) (byte) 0);
        long long68 = delegatedDateTimeField9.roundHalfEven(1560632340763L);
        long long71 = delegatedDateTimeField9.add((long) 420, 680323158L);
        java.util.Locale locale73 = null;
        java.lang.String str74 = delegatedDateTimeField9.getAsShortText((long) 13, locale73);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 680323158L + "'", long17 == 680323158L);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9936000000L + "'", long27 == 9936000000L);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 110 + "'", int39 == 110);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertNotNull(copticChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 11 + "'", int52 == 11);
        org.junit.Assert.assertNotNull(monthDay53);
        org.junit.Assert.assertNotNull(monthDay55);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 11 + "'", int62 == 11);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 11 + "'", int64 == 11);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1559952000000L + "'", long68 == 1559952000000L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1651489700659200420L + "'", long71 == 1651489700659200420L);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "4" + "'", str74.equals("4"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.io.Writer writer1 = null;
        java.lang.Object obj2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
        java.util.GregorianCalendar gregorianCalendar4 = dateTime3.toGregorianCalendar();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        org.joda.time.DateTime dateTime8 = dateTime6.minusWeeks((int) 'a');
        org.joda.time.DateTime dateTime10 = dateTime6.withMillisOfDay(248);
        org.joda.time.DateTime dateTime12 = dateTime10.withMillis(0L);
        int int13 = dateTime12.getDayOfYear();
        org.joda.time.DateTime dateTime15 = dateTime12.plusYears(6);
        org.joda.time.DateTime dateTime17 = dateTime12.withDayOfYear(44);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianCalendar4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("2017-08-05T13:59:03.031-07:00", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 2017-08-05T13:59:03.031-07:00");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) 10.0d, "");
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str32 = gregorianChronology31.toString();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology35 = gregorianChronology31.withZone(dateTimeZone34);
        org.joda.time.DurationField durationField36 = gregorianChronology31.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField36);
        try {
            long long39 = unsupportedDateTimeField37.roundHalfEven((long) 110);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyearOfCentury field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "GregorianChronology[UTC]" + "'", str32.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendPattern("4:00:53 PM");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560632393710L + "'", long4 == 1560632393710L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
//        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
//        int int19 = offsetDateTimeField14.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
//        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
//        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
//        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
//        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
//        java.lang.String str47 = unsupportedDateTimeField46.toString();
//        try {
//            int int48 = unsupportedDateTimeField46.getMinimumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632393732L + "'", long2 == 1560632393732L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 17 + "'", int5 == 17);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology1.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        int int8 = offsetDateTimeField5.getDifference(0L, 0L);
        int int10 = offsetDateTimeField5.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = monthDay11.withChronologyRetainFields(chronology12);
        int[] intArray19 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int20 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay13, intArray19);
        long long23 = offsetDateTimeField5.add((long) (short) 1, (int) (short) -1);
        int int25 = offsetDateTimeField5.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DurationField durationField32 = iSOChronology31.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology33.monthOfYear();
        org.joda.time.DurationField durationField35 = buddhistChronology33.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField36 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType26, durationField32, durationField35);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField37 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 11 + "'", int10 == 11);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 11 + "'", int20 == 11);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-31449599999L) + "'", long23 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(buddhistChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(durationField35);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long9 = offsetDateTimeField4.remainder(0L);
        java.util.Locale locale12 = null;
        long long13 = offsetDateTimeField4.set((long) 10, "100", locale12);
        org.joda.time.DurationField durationField14 = offsetDateTimeField4.getDurationField();
        org.joda.time.DurationField durationField15 = offsetDateTimeField4.getLeapDurationField();
        int int16 = offsetDateTimeField4.getMinimumValue();
        int int18 = offsetDateTimeField4.getMinimumValue((long) 100);
        try {
            long long21 = offsetDateTimeField4.set((long) 11, 786);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 786 for weekyearOfCentury must be in the range [11,110]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9936000000L + "'", long9 == 9936000000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 94953600010L + "'", long13 == 94953600010L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 11 + "'", int18 == 11);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("55", (int) (short) 1);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder3.writeTo("--06-15", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
//        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
//        int int19 = offsetDateTimeField14.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
//        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
//        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
//        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
//        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
//        long long49 = unsupportedDateTimeField46.add((long) 53, (int) (short) -1);
//        org.joda.time.MonthDay monthDay50 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology51 = null;
//        org.joda.time.MonthDay monthDay52 = monthDay50.withChronologyRetainFields(chronology51);
//        int[] intArray54 = null;
//        try {
//            int[] intArray56 = unsupportedDateTimeField46.addWrapPartial((org.joda.time.ReadablePartial) monthDay50, 871, intArray54, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632394607L + "'", long2 == 1560632394607L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 17 + "'", int5 == 17);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-3599947L) + "'", long49 == (-3599947L));
//        org.junit.Assert.assertNotNull(monthDay50);
//        org.junit.Assert.assertNotNull(monthDay52);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(0L);
        org.joda.time.MonthDay monthDay6 = monthDay4.withDayOfMonth(10);
        int[] intArray8 = copticChronology0.get((org.joda.time.ReadablePartial) monthDay6, 0L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(intArray8);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfHour((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendTimeZoneId();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560632394696L + "'", long4 == 1560632394696L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
        int int19 = offsetDateTimeField16.getDifference(0L, 0L);
        int int21 = offsetDateTimeField16.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay22.withChronologyRetainFields(chronology23);
        int[] intArray30 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int31 = offsetDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) monthDay24, intArray30);
        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = copticChronology32.secondOfDay();
        org.joda.time.DateTimeField dateTimeField34 = copticChronology32.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 10);
        int int39 = offsetDateTimeField36.getDifference(0L, 0L);
        int int41 = offsetDateTimeField36.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay42 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.MonthDay monthDay44 = monthDay42.withChronologyRetainFields(chronology43);
        int[] intArray50 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int51 = offsetDateTimeField36.getMinimumValue((org.joda.time.ReadablePartial) monthDay44, intArray50);
        boolean boolean52 = monthDay24.isEqual((org.joda.time.ReadablePartial) monthDay44);
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField54 = copticChronology53.secondOfDay();
        org.joda.time.DateTimeField dateTimeField55 = copticChronology53.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, 10);
        int int60 = offsetDateTimeField57.getDifference(0L, 0L);
        int int62 = offsetDateTimeField57.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay63 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology64 = null;
        org.joda.time.MonthDay monthDay65 = monthDay63.withChronologyRetainFields(chronology64);
        int[] intArray71 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int72 = offsetDateTimeField57.getMinimumValue((org.joda.time.ReadablePartial) monthDay65, intArray71);
        int[] intArray73 = monthDay65.getValues();
        int int74 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay44, intArray73);
        org.joda.time.MonthDay monthDay76 = monthDay44.plusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod77 = null;
        org.joda.time.MonthDay monthDay79 = monthDay44.withPeriodAdded(readablePeriod77, (int) (byte) 0);
        try {
            java.lang.String str81 = monthDay79.toString("2017-08-05T13:59:08.711-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(copticChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 11 + "'", int62 == 11);
        org.junit.Assert.assertNotNull(monthDay63);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(monthDay76);
        org.junit.Assert.assertNotNull(monthDay79);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        long long4 = buddhistChronology0.add((long) (short) 1, 1560628897763L, 10);
//        java.lang.Object obj5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime9 = dateTime6.withMillisOfDay((int) 'a');
//        int int10 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTime dateTime12 = dateTime6.withDayOfYear((int) (byte) 1);
//        java.lang.Object obj13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj13);
//        org.joda.time.DateTime dateTime16 = dateTime14.plusDays((int) (short) 10);
//        org.joda.time.LocalTime localTime17 = dateTime14.toLocalTime();
//        int int18 = dateTime14.getEra();
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime14.plus(readableDuration19);
//        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.ReadableDateTime) dateTime12, (org.joda.time.ReadableDateTime) dateTime20);
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology0.centuryOfEra();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 15606288977631L + "'", long4 == 15606288977631L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560632394757L + "'", long7 == 1560632394757L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 17 + "'", int10 == 17);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(limitChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean5 = dateTime3.isBefore(1L);
        org.joda.time.DateTime dateTime7 = dateTime3.withSecondOfMinute(0);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime3.getZone();
        org.joda.time.Chronology chronology9 = buddhistChronology0.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        boolean boolean15 = dateTime13.isBefore(1L);
        org.joda.time.DateTime dateTime17 = dateTime13.withSecondOfMinute(0);
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime13.getZone();
        int int19 = dateTime13.getCenturyOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str21 = gregorianChronology20.toString();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology24 = gregorianChronology20.withZone(dateTimeZone23);
        java.util.Locale locale26 = null;
        java.lang.String str27 = dateTimeZone23.getShortName(10L, locale26);
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        java.util.Locale locale30 = null;
        java.lang.String str31 = dateTimeZone23.getName((long) 31, locale30);
        org.joda.time.DateTime dateTime32 = dateTime13.withZoneRetainFields(dateTimeZone23);
        boolean boolean33 = buddhistChronology0.equals((java.lang.Object) dateTime13);
        org.joda.time.DateTime dateTime35 = dateTime13.plusMillis(0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20 + "'", int19 == 20);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "GregorianChronology[UTC]" + "'", str21.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+32:00" + "'", str27.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+32:00" + "'", str31.equals("+32:00"));
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTime35);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfEra(1969, 1258);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendSecondOfDay(999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear(0, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        long long36 = preciseDateTimeField35.getUnitMillis();
        boolean boolean37 = preciseDateTimeField35.isLenient();
        java.lang.String str39 = preciseDateTimeField35.getAsShortText((long) 0);
        org.joda.time.DurationField durationField40 = preciseDateTimeField35.getDurationField();
        java.util.Locale locale41 = null;
        int int42 = preciseDateTimeField35.getMaximumShortTextLength(locale41);
        long long44 = preciseDateTimeField35.remainder((long) 70);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1000L + "'", long36 == 1000L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 70L + "'", long44 == 70L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.LocalDateTime localDateTime2 = null;
//        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone1.getShortName(0L, locale5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.Object obj9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(obj9);
//        java.util.Locale locale11 = null;
//        java.util.Calendar calendar12 = dateTime10.toCalendar(locale11);
//        org.joda.time.DateTime dateTime14 = dateTime10.minusMillis(0);
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        boolean boolean16 = dateTime10.isBefore(readableInstant15);
//        int int17 = cachedDateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime10);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = cachedDateTimeZone8.getShortName(1L, locale19);
//        java.util.TimeZone timeZone21 = cachedDateTimeZone8.toTimeZone();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+32:00" + "'", str6.equals("+32:00"));
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
//        org.junit.Assert.assertNotNull(calendar12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 115200000 + "'", int17 == 115200000);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+32:00" + "'", str20.equals("+32:00"));
//        org.junit.Assert.assertNotNull(timeZone21);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.Instant instant2 = org.joda.time.Instant.parse("0");
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant4 = instant2.minus(readableDuration3);
        org.joda.time.Instant instant6 = instant4.minus((long) (short) -1);
        org.joda.time.Instant instant7 = instant4.toInstant();
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) instant7);
        java.util.Locale locale9 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "16" + "'", str8.equals("16"));
        org.junit.Assert.assertNull(locale9);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        long long14 = delegatedDateTimeField9.roundHalfCeiling((long) (byte) 0);
        boolean boolean16 = delegatedDateTimeField9.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = copticChronology17.secondOfDay();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology17.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 10);
        int int24 = offsetDateTimeField21.getDifference(0L, 0L);
        int int26 = offsetDateTimeField21.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.MonthDay monthDay29 = monthDay27.withChronologyRetainFields(chronology28);
        int[] intArray35 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int36 = offsetDateTimeField21.getMinimumValue((org.joda.time.ReadablePartial) monthDay29, intArray35);
        org.joda.time.chrono.CopticChronology copticChronology37 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField38 = copticChronology37.secondOfDay();
        org.joda.time.DateTimeField dateTimeField39 = copticChronology37.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 10);
        int int44 = offsetDateTimeField41.getDifference(0L, 0L);
        int int46 = offsetDateTimeField41.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay47 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.MonthDay monthDay49 = monthDay47.withChronologyRetainFields(chronology48);
        int[] intArray55 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int56 = offsetDateTimeField41.getMinimumValue((org.joda.time.ReadablePartial) monthDay49, intArray55);
        boolean boolean57 = monthDay29.isEqual((org.joda.time.ReadablePartial) monthDay49);
        org.joda.time.chrono.CopticChronology copticChronology58 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField59 = copticChronology58.secondOfDay();
        org.joda.time.DateTimeField dateTimeField60 = copticChronology58.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, 10);
        int int65 = offsetDateTimeField62.getDifference(0L, 0L);
        int int67 = offsetDateTimeField62.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay68 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology69 = null;
        org.joda.time.MonthDay monthDay70 = monthDay68.withChronologyRetainFields(chronology69);
        int[] intArray76 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int77 = offsetDateTimeField62.getMinimumValue((org.joda.time.ReadablePartial) monthDay70, intArray76);
        int[] intArray78 = monthDay70.getValues();
        int int79 = delegatedDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay49, intArray78);
        org.joda.time.MonthDay monthDay81 = monthDay49.plusDays((int) (short) 100);
        java.util.Locale locale83 = null;
        java.lang.String str84 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay49, (int) (byte) 10, locale83);
        long long86 = delegatedDateTimeField4.roundCeiling((long) (short) -1);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 691200000L + "'", long14 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 11 + "'", int26 == 11);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 11 + "'", int36 == 11);
        org.junit.Assert.assertNotNull(copticChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 11 + "'", int46 == 11);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 11 + "'", int56 == 11);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(copticChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 11 + "'", int67 == 11);
        org.junit.Assert.assertNotNull(monthDay68);
        org.junit.Assert.assertNotNull(monthDay70);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 11 + "'", int77 == 11);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertNotNull(monthDay81);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "10" + "'", str84.equals("10"));
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 691200000L + "'", long86 == 691200000L);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        long long10 = offsetDateTimeField4.add((long) (short) 0, (long) (byte) 0);
//        int int12 = offsetDateTimeField4.getLeapAmount((long) (short) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendDayOfWeekShortText();
//        java.lang.Object obj15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(obj15);
//        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime19 = dateTime16.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property20 = dateTime19.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder13.appendSignedDecimal(dateTimeFieldType21, (int) (short) 100, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder13.appendDayOfMonth(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder26.appendTimeZoneOffset("2017-08-05T13:59:12.208-07:00", true, 11, (int) (byte) 100);
//        java.lang.Object obj32 = null;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(obj32);
//        long long34 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime dateTime36 = dateTime33.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property37 = dateTime36.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder26.appendShortText(dateTimeFieldType38);
//        org.joda.time.chrono.CopticChronology copticChronology40 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField41 = copticChronology40.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField42 = copticChronology40.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, 10);
//        int int47 = offsetDateTimeField44.getDifference(0L, 0L);
//        int int49 = offsetDateTimeField44.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay50 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology51 = null;
//        org.joda.time.MonthDay monthDay52 = monthDay50.withChronologyRetainFields(chronology51);
//        int[] intArray58 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int59 = offsetDateTimeField44.getMinimumValue((org.joda.time.ReadablePartial) monthDay52, intArray58);
//        long long62 = offsetDateTimeField44.add((long) (short) 1, (int) (short) -1);
//        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
//        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
//        int int72 = offsetDateTimeField67.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology74 = null;
//        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
//        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
//        long long85 = offsetDateTimeField67.add((long) (short) 1, (int) (short) -1);
//        int int87 = offsetDateTimeField67.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType88 = offsetDateTimeField67.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException90 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType88, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField92 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField44, dateTimeFieldType88, 3599);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException94 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType88, "2017-08-05T13:59:03.031-07:00");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder95 = dateTimeFormatterBuilder39.appendShortText(dateTimeFieldType88);
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField97 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType88, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560632395579L + "'", long17 == 1560632395579L);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560632395581L + "'", long34 == 1560632395581L);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(copticChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 11 + "'", int49 == 11);
//        org.junit.Assert.assertNotNull(monthDay50);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(intArray58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 11 + "'", int59 == 11);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-31449599999L) + "'", long62 == (-31449599999L));
//        org.junit.Assert.assertNotNull(copticChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-31449599999L) + "'", long85 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType88);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder95);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withDefaultYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatter7.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter8, dateTimeParser9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeFormatter11.getZone();
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder3.append(dateTimePrinter8, dateTimeParser13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeFormatter15.getZone();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder0.append(dateTimePrinter8, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendLiteral("100");
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatterBuilder22.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter8, dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimePrinter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeParser23);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
//        int int7 = dateTime4.getWeekyear();
//        int int8 = dateTime4.getDayOfYear();
//        org.junit.Assert.assertNotNull(gregorianCalendar2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 168 + "'", int8 == 168);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("2017-08-05T13:59:15.479-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2017-08-05T13:59:15.479-07:00\" is malformed at \"T13:59:15.479-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology1.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str8 = dateTimeZone5.getShortName((-1900800000L));
        org.joda.time.Chronology chronology9 = copticChronology1.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(1971291520665L, dateTimeZone5);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (-32));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+32:00" + "'", str8.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.DateTimeFormat.shortTime();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.append(dateTimeFormatter14);
//        java.lang.Object obj16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(obj16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime20 = dateTime17.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property21 = dateTime20.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder15.appendDecimal(dateTimeFieldType22, 1258, (int) (byte) 10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560632396014L + "'", long4 == 1560632396014L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560632396016L + "'", long18 == 1560632396016L);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(9936000000L, 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 109296000000L + "'", long2 == 109296000000L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology1.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        int int8 = offsetDateTimeField5.getDifference(0L, 0L);
        java.lang.String str10 = offsetDateTimeField5.getAsText(1560632313085L);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.secondOfDay();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology11.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, dateTimeFieldType14);
        long long17 = delegatedDateTimeField15.roundFloor((long) 0);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField15.getLeapDurationField();
        long long20 = delegatedDateTimeField15.roundHalfCeiling((long) (byte) 0);
        boolean boolean22 = delegatedDateTimeField15.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology23.secondOfDay();
        org.joda.time.DateTimeField dateTimeField25 = copticChronology23.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 10);
        int int30 = offsetDateTimeField27.getDifference(0L, 0L);
        int int32 = offsetDateTimeField27.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.withChronologyRetainFields(chronology34);
        int[] intArray41 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int42 = offsetDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) monthDay35, intArray41);
        org.joda.time.chrono.CopticChronology copticChronology43 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = copticChronology43.secondOfDay();
        org.joda.time.DateTimeField dateTimeField45 = copticChronology43.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, 10);
        int int50 = offsetDateTimeField47.getDifference(0L, 0L);
        int int52 = offsetDateTimeField47.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay53 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology54 = null;
        org.joda.time.MonthDay monthDay55 = monthDay53.withChronologyRetainFields(chronology54);
        int[] intArray61 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int62 = offsetDateTimeField47.getMinimumValue((org.joda.time.ReadablePartial) monthDay55, intArray61);
        boolean boolean63 = monthDay35.isEqual((org.joda.time.ReadablePartial) monthDay55);
        org.joda.time.chrono.CopticChronology copticChronology64 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField65 = copticChronology64.secondOfDay();
        org.joda.time.DateTimeField dateTimeField66 = copticChronology64.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, 10);
        int int71 = offsetDateTimeField68.getDifference(0L, 0L);
        int int73 = offsetDateTimeField68.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay74 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology75 = null;
        org.joda.time.MonthDay monthDay76 = monthDay74.withChronologyRetainFields(chronology75);
        int[] intArray82 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int83 = offsetDateTimeField68.getMinimumValue((org.joda.time.ReadablePartial) monthDay76, intArray82);
        int[] intArray84 = monthDay76.getValues();
        int int85 = delegatedDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) monthDay55, intArray84);
        org.joda.time.MonthDay monthDay87 = monthDay55.plusDays((int) (short) 100);
        java.util.Locale locale89 = null;
        java.lang.String str90 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) monthDay87, 10, locale89);
        org.joda.time.MonthDay.Property property91 = monthDay87.dayOfMonth();
        org.joda.time.DurationField durationField92 = property91.getRangeDurationField();
        int int93 = property91.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType94 = property91.getFieldType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField95 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "46" + "'", str10.equals("46"));
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1900800000L) + "'", long17 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 691200000L + "'", long20 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 11 + "'", int32 == 11);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 11 + "'", int42 == 11);
        org.junit.Assert.assertNotNull(copticChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 11 + "'", int52 == 11);
        org.junit.Assert.assertNotNull(monthDay53);
        org.junit.Assert.assertNotNull(monthDay55);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 11 + "'", int62 == 11);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(copticChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 11 + "'", int73 == 11);
        org.junit.Assert.assertNotNull(monthDay74);
        org.junit.Assert.assertNotNull(monthDay76);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 11 + "'", int83 == 11);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
        org.junit.Assert.assertNotNull(monthDay87);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "10" + "'", str90.equals("10"));
        org.junit.Assert.assertNotNull(property91);
        org.junit.Assert.assertNotNull(durationField92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType94);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        long long8 = delegatedDateTimeField6.roundFloor((long) 0);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField6.getLeapDurationField();
        long long11 = delegatedDateTimeField6.roundHalfCeiling((long) (byte) 0);
        boolean boolean13 = delegatedDateTimeField6.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology14.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        int int21 = offsetDateTimeField18.getDifference(0L, 0L);
        int int23 = offsetDateTimeField18.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.MonthDay monthDay26 = monthDay24.withChronologyRetainFields(chronology25);
        int[] intArray32 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int33 = offsetDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) monthDay26, intArray32);
        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = copticChronology34.secondOfDay();
        org.joda.time.DateTimeField dateTimeField36 = copticChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 10);
        int int41 = offsetDateTimeField38.getDifference(0L, 0L);
        int int43 = offsetDateTimeField38.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay44 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.MonthDay monthDay46 = monthDay44.withChronologyRetainFields(chronology45);
        int[] intArray52 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int53 = offsetDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray52);
        boolean boolean54 = monthDay26.isEqual((org.joda.time.ReadablePartial) monthDay46);
        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = copticChronology55.secondOfDay();
        org.joda.time.DateTimeField dateTimeField57 = copticChronology55.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField57, 10);
        int int62 = offsetDateTimeField59.getDifference(0L, 0L);
        int int64 = offsetDateTimeField59.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay65 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.MonthDay monthDay67 = monthDay65.withChronologyRetainFields(chronology66);
        int[] intArray73 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int74 = offsetDateTimeField59.getMinimumValue((org.joda.time.ReadablePartial) monthDay67, intArray73);
        int[] intArray75 = monthDay67.getValues();
        int int76 = delegatedDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray75);
        boolean boolean77 = copticChronology0.equals((java.lang.Object) delegatedDateTimeField6);
        org.joda.time.Chronology chronology78 = copticChronology0.withUTC();
        org.joda.time.DurationField durationField79 = copticChronology0.minutes();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1900800000L) + "'", long8 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 691200000L + "'", long11 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 11 + "'", int33 == 11);
        org.junit.Assert.assertNotNull(copticChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 11 + "'", int43 == 11);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 11 + "'", int53 == 11);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(copticChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 11 + "'", int64 == 11);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertNotNull(monthDay67);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 11 + "'", int74 == 11);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(chronology78);
        org.junit.Assert.assertNotNull(durationField79);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray6 = gregorianChronology1.get(readablePeriod4, 1560632394030L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology4.secondOfDay();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology4.weekyearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = copticChronology4.add(readablePeriod7, 1L, (int) (short) 1);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((long) 44, (org.joda.time.Chronology) copticChronology4);
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadablePartial) monthDay11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.centuries();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime dateTime4 = dateTime1.minus(1560632322909L);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readableDuration5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime4.isSupported(dateTimeFieldType7);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField4.getMaximumShortTextLength(locale8);
        long long11 = delegatedDateTimeField4.roundHalfEven((long) 31);
        long long14 = delegatedDateTimeField4.add(482338505L, (int) '4');
        int int16 = delegatedDateTimeField4.get(1560632381556L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 691200000L + "'", long11 == 691200000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 126712738505L + "'", long14 == 126712738505L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        java.lang.String str6 = delegatedDateTimeField4.getAsText((long) (-1));
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        int int9 = delegatedDateTimeField4.getMinimumValue(1560632336254L);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime12 = null;
        boolean boolean13 = dateTimeZone11.isLocalDateTimeGap(localDateTime12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dateTimeZone11.getShortName(0L, locale15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) cachedDateTimeZone18);
        java.util.Locale locale20 = null;
        java.lang.String str21 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay19, locale20);
        try {
            long long24 = delegatedDateTimeField4.set(1560632330384L, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4" + "'", str6.equals("4"));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+32:00" + "'", str16.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "6" + "'", str21.equals("6"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
        org.joda.time.DateTime dateTime8 = dateTime4.withMillis((long) 12);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.withDurationAdded(readableDuration9, 7);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "2017-08-05T13:59:03.031-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
        org.joda.time.DateTime dateTime8 = dateTime4.withMillis((long) 12);
        org.joda.time.Instant instant10 = new org.joda.time.Instant((long) (-10));
        int int11 = dateTime8.compareTo((org.joda.time.ReadableInstant) instant10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.util.Locale locale13 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withLocale(locale13);
        java.lang.String str15 = instant10.toString(dateTimeFormatter12);
        org.joda.time.LocalDateTime localDateTime17 = dateTimeFormatter12.parseLocalDateTime("1:58:50 PM");
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "11:59:59 PM" + "'", str15.equals("11:59:59 PM"));
        org.junit.Assert.assertNotNull(localDateTime17);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(837, 786, (-33));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = offsetDateTimeField4.getMinimumValue(readablePartial5);
        long long8 = offsetDateTimeField4.remainder((long) 15);
        long long10 = offsetDateTimeField4.roundHalfEven(94953600010L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField4.getAsText(readablePartial11, 1258, locale13);
        long long17 = offsetDateTimeField4.getDifferenceAsLong(0L, 315705675578L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9936000015L + "'", long8 == 9936000015L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 85017600000L + "'", long10 == 85017600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1258" + "'", str14.equals("1258"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-10L) + "'", long17 == (-10L));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology5 = gregorianChronology1.withZone(dateTimeZone4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTimeZone4.getShortName(10L, locale7);
        org.joda.time.Chronology chronology9 = gJChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology0.getZone();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        java.lang.String str17 = dateTimeZone14.getShortName((-1900800000L));
        java.util.TimeZone timeZone18 = dateTimeZone14.toTimeZone();
        java.lang.Object obj19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(obj19);
        java.util.Locale locale21 = null;
        java.util.Calendar calendar22 = dateTime20.toCalendar(locale21);
        int int23 = dateTimeZone14.getOffset((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
        boolean boolean28 = dateTime26.isBefore(1L);
        org.joda.time.DateTime dateTime30 = dateTime26.withSecondOfMinute(0);
        org.joda.time.LocalDateTime localDateTime31 = dateTime26.toLocalDateTime();
        boolean boolean32 = dateTimeZone14.isLocalDateTimeGap(localDateTime31);
        boolean boolean33 = dateTimeZone10.isLocalDateTimeGap(localDateTime31);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+32:00" + "'", str8.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+32:00" + "'", str17.equals("+32:00"));
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(calendar22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 115200000 + "'", int23 == 115200000);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localDateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
//        int int8 = dateTime1.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime1.toMutableDateTime(dateTimeZone10);
//        int int13 = dateTime1.getMillisOfSecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632397587L + "'", long2 == 1560632397587L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 17 + "'", int5 == 17);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 587 + "'", int13 == 587);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        long long36 = preciseDateTimeField35.getUnitMillis();
        boolean boolean37 = preciseDateTimeField35.isLenient();
        java.lang.String str39 = preciseDateTimeField35.getAsShortText((long) 0);
        int int40 = preciseDateTimeField35.getMaximumValue();
        java.util.Locale locale42 = null;
        java.lang.String str43 = preciseDateTimeField35.getAsText((int) 'a', locale42);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1000L + "'", long36 == 1000L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3599 + "'", int40 == 3599);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "97" + "'", str43.equals("97"));
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
//        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
//        int int19 = offsetDateTimeField14.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
//        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
//        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
//        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
//        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
//        long long49 = unsupportedDateTimeField46.add((long) 53, (int) (short) -1);
//        boolean boolean50 = unsupportedDateTimeField46.isLenient();
//        try {
//            int int52 = unsupportedDateTimeField46.getMaximumValue((long) 25);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632397746L + "'", long2 == 1560632397746L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 17 + "'", int5 == 17);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-3599947L) + "'", long49 == (-3599947L));
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
//        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
//        int int19 = offsetDateTimeField14.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
//        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
//        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
//        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
//        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
//        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = unsupportedDateTimeField46.getType();
//        long long50 = unsupportedDateTimeField46.add((long) 837, (int) '4');
//        try {
//            long long52 = unsupportedDateTimeField46.roundHalfCeiling(1560632392616L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632397774L + "'", long2 == 1560632397774L);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 17 + "'", int5 == 17);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 187200837L + "'", long50 == 187200837L);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("55", (int) (short) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder3.setStandardOffset((int) (short) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder5.setFixedSavings("UnsupportedDateTimeField", 25);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = dateTimeZone6.isLocalDateTimeGap(localDateTime7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = dateTimeZone6.getShortName(0L, locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        java.lang.String str13 = gregorianChronology12.toString();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((int) 'a', 587, (-1), (int) (byte) 100, (-1538513957), (org.joda.time.Chronology) gregorianChronology12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+32:00" + "'", str11.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[+32:00]" + "'", str13.equals("GregorianChronology[+32:00]"));
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearText();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560632397827L + "'", long4 == 1560632397827L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int6 = offsetDateTimeField4.getMaximumValue(9936000000L);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MonthDay monthDay9 = monthDay7.withChronologyRetainFields(chronology8);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        int[] intArray30 = monthDay22.getValues();
        int int31 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay7, intArray30);
        org.joda.time.MonthDay.Property property32 = monthDay7.dayOfMonth();
        int int33 = property32.getMinimumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 110 + "'", int6 == 110);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        java.util.Locale locale2 = null;
//        java.util.Calendar calendar3 = dateTime1.toCalendar(locale2);
//        org.joda.time.DateTime dateTime5 = dateTime1.minusMillis(0);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
//        java.lang.Object obj8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(obj8);
//        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime12 = dateTime9.withMillisOfDay((int) 'a');
//        int int13 = dateTime9.getDayOfMonth();
//        org.joda.time.DateTime dateTime15 = dateTime9.withDayOfYear((int) (byte) 1);
//        org.joda.time.DateTime.Property property16 = dateTime9.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property16.getFieldType();
//        int int18 = dateTime7.get(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(calendar3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560632397967L + "'", long10 == 1560632397967L);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 17 + "'", int13 == 17);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 17997 + "'", int18 == 17997);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        java.lang.String str7 = dateTimeZone4.getShortName((-1900800000L));
        org.joda.time.Chronology chronology8 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.DurationField durationField9 = copticChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+32:00" + "'", str7.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        long long8 = delegatedDateTimeField6.roundFloor((long) 0);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField6.getLeapDurationField();
        long long11 = delegatedDateTimeField6.roundHalfCeiling((long) (byte) 0);
        boolean boolean13 = delegatedDateTimeField6.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology14.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        int int21 = offsetDateTimeField18.getDifference(0L, 0L);
        int int23 = offsetDateTimeField18.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.MonthDay monthDay26 = monthDay24.withChronologyRetainFields(chronology25);
        int[] intArray32 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int33 = offsetDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) monthDay26, intArray32);
        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = copticChronology34.secondOfDay();
        org.joda.time.DateTimeField dateTimeField36 = copticChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 10);
        int int41 = offsetDateTimeField38.getDifference(0L, 0L);
        int int43 = offsetDateTimeField38.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay44 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.MonthDay monthDay46 = monthDay44.withChronologyRetainFields(chronology45);
        int[] intArray52 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int53 = offsetDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray52);
        boolean boolean54 = monthDay26.isEqual((org.joda.time.ReadablePartial) monthDay46);
        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = copticChronology55.secondOfDay();
        org.joda.time.DateTimeField dateTimeField57 = copticChronology55.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField57, 10);
        int int62 = offsetDateTimeField59.getDifference(0L, 0L);
        int int64 = offsetDateTimeField59.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay65 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.MonthDay monthDay67 = monthDay65.withChronologyRetainFields(chronology66);
        int[] intArray73 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int74 = offsetDateTimeField59.getMinimumValue((org.joda.time.ReadablePartial) monthDay67, intArray73);
        int[] intArray75 = monthDay67.getValues();
        int int76 = delegatedDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray75);
        boolean boolean77 = copticChronology0.equals((java.lang.Object) delegatedDateTimeField6);
        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology80 = copticChronology0.withZone(dateTimeZone79);
        org.joda.time.DateTimeField dateTimeField81 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone82 = copticChronology0.getZone();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1900800000L) + "'", long8 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 691200000L + "'", long11 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 11 + "'", int33 == 11);
        org.junit.Assert.assertNotNull(copticChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 11 + "'", int43 == 11);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 11 + "'", int53 == 11);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(copticChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 11 + "'", int64 == 11);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertNotNull(monthDay67);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 11 + "'", int74 == 11);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(dateTimeZone79);
        org.junit.Assert.assertNotNull(chronology80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertNotNull(dateTimeZone82);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        int int9 = offsetDateTimeField4.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
//        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
//        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
//        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
//        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
//        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
//        long long36 = preciseDateTimeField35.getUnitMillis();
//        long long39 = preciseDateTimeField35.set(1560632340763L, (int) 'a');
//        boolean boolean40 = preciseDateTimeField35.isLenient();
//        long long42 = preciseDateTimeField35.roundCeiling((long) 31);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = preciseDateTimeField35.getAsShortText(0, locale44);
//        java.lang.Object obj46 = null;
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(obj46);
//        long long48 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime47);
//        org.joda.time.DateTime dateTime50 = dateTime47.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property51 = dateTime50.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property51.getFieldType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField53 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) preciseDateTimeField35, dateTimeFieldType52);
//        long long55 = zeroIsMaxDateTimeField53.roundHalfCeiling(40L);
//        int int58 = zeroIsMaxDateTimeField53.getDifference(22118400000L, 1560632357897L);
//        int int60 = zeroIsMaxDateTimeField53.getLeapAmount(315705675578L);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(buddhistChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1000L + "'", long36 == 1000L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560628897763L + "'", long39 == 1560628897763L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1000L + "'", long42 == 1000L);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "0" + "'", str45.equals("0"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560632398368L + "'", long48 == 1560632398368L);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1538513957) + "'", int58 == (-1538513957));
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long10 = offsetDateTimeField4.add((long) (short) 0, (long) (byte) 0);
        int int12 = offsetDateTimeField4.getLeapAmount((long) (short) 1);
        int int13 = offsetDateTimeField4.getMinimumValue();
        long long15 = offsetDateTimeField4.roundCeiling(1560632347355L);
        int int17 = offsetDateTimeField4.getLeapAmount(4716305952941L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1567987200000L + "'", long15 == 1567987200000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
//        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
//        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
//        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
//        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
//        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
//        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
//        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
//        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
//        int int31 = offsetDateTimeField26.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
//        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
//        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
//        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
//        int int51 = offsetDateTimeField46.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology53 = null;
//        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
//        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
//        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
//        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
//        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
//        int int72 = offsetDateTimeField67.getMinimumValue(0L);
//        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
//        org.joda.time.Chronology chronology74 = null;
//        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
//        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
//        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
//        int[] intArray83 = monthDay75.getValues();
//        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
//        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
//        java.util.Locale locale88 = null;
//        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
//        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
//        java.lang.String str91 = property90.getAsString();
//        org.joda.time.MonthDay monthDay93 = property90.addWrapFieldToCopy((int) 'a');
//        org.joda.time.MonthDay monthDay94 = property90.getMonthDay();
//        try {
//            org.joda.time.MonthDay monthDay96 = property90.setCopy((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
//        org.junit.Assert.assertNotNull(copticChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
//        org.junit.Assert.assertNotNull(copticChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
//        org.junit.Assert.assertNotNull(monthDay52);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(copticChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertNotNull(monthDay86);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
//        org.junit.Assert.assertNotNull(property90);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "25" + "'", str91.equals("25"));
//        org.junit.Assert.assertNotNull(monthDay93);
//        org.junit.Assert.assertNotNull(monthDay94);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
//        java.lang.Object obj2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfWeek(1258);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560632398627L + "'", long4 == 1560632398627L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
//        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
//        java.lang.String str7 = dateTime6.toString();
//        org.joda.time.Instant instant9 = org.joda.time.Instant.parse("0");
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.Instant instant12 = instant9.withDurationAdded(readableDuration10, 110);
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) instant9);
//        java.lang.Object obj14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(obj14);
//        org.joda.time.DateTime dateTime17 = dateTime15.plusDays((int) (short) 10);
//        org.joda.time.LocalTime localTime18 = dateTime15.toLocalTime();
//        int int19 = dateTime15.getEra();
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime15.plus(readableDuration20);
//        int int22 = dateTime6.compareTo((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime dateTime24 = dateTime21.withMinuteOfHour((int) ' ');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        java.lang.String str27 = gJChronology26.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter25.withChronology((org.joda.time.Chronology) gJChronology26);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter25.withZoneUTC();
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.String str32 = gregorianChronology31.toString();
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
//        org.joda.time.Chronology chronology35 = gregorianChronology31.withZone(dateTimeZone34);
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = dateTimeZone34.getShortName(10L, locale37);
//        org.joda.time.Chronology chronology39 = gJChronology30.withZone(dateTimeZone34);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter25.withChronology((org.joda.time.Chronology) gJChronology30);
//        org.joda.time.DateTimeZone dateTimeZone41 = gJChronology30.getZone();
//        org.joda.time.MutableDateTime mutableDateTime42 = dateTime24.toMutableDateTime(dateTimeZone41);
//        org.junit.Assert.assertNotNull(gregorianCalendar2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2017-08-07T04:59:58.657+32:00" + "'", str7.equals("2017-08-07T04:59:58.657+32:00"));
//        org.junit.Assert.assertNotNull(instant9);
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "GJChronology[UTC]" + "'", str27.equals("GJChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "GregorianChronology[UTC]" + "'", str32.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "+32:00" + "'", str38.equals("+32:00"));
//        org.junit.Assert.assertNotNull(chronology39);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(mutableDateTime42);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.clockhourOfDay();
        try {
            long long8 = copticChronology0.getDateTimeMillis(837, 0, 115200000, 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long9 = offsetDateTimeField4.remainder(0L);
        java.util.Locale locale12 = null;
        long long13 = offsetDateTimeField4.set((long) 10, "100", locale12);
        org.joda.time.DurationField durationField14 = offsetDateTimeField4.getDurationField();
        org.joda.time.DurationField durationField15 = offsetDateTimeField4.getLeapDurationField();
        long long17 = offsetDateTimeField4.roundHalfCeiling((long) 365);
        org.joda.time.DurationField durationField18 = offsetDateTimeField4.getLeapDurationField();
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(0L);
        org.joda.time.MonthDay monthDay22 = monthDay20.withDayOfMonth(10);
        java.util.Locale locale23 = null;
        try {
            java.lang.String str24 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay22, locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyearOfCentury' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9936000000L + "'", long9 == 9936000000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 94953600010L + "'", long13 == 94953600010L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-9936000000L) + "'", long17 == (-9936000000L));
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(monthDay22);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.withDurationAdded(readableDuration5, (int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime2.withEra(0);
        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded((long) 19, (-1));
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.minus(readableDuration13);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str2 = gJChronology1.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str7 = gregorianChronology6.toString();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology10 = gregorianChronology6.withZone(dateTimeZone9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone9.getShortName(10L, locale12);
        org.joda.time.Chronology chronology14 = gJChronology5.withZone(dateTimeZone9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str17 = gregorianChronology16.toString();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology20 = gregorianChronology16.withZone(dateTimeZone19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone19.getShortName(10L, locale22);
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone19);
        java.util.Locale locale26 = null;
        java.lang.String str27 = dateTimeZone19.getName((long) 31, locale26);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter0.withZone(dateTimeZone19);
        try {
            org.joda.time.MutableDateTime mutableDateTime30 = dateTimeFormatter28.parseMutableDateTime("100");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"100\" is malformed at \"0\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[UTC]" + "'", str7.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+32:00" + "'", str13.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[UTC]" + "'", str17.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+32:00" + "'", str23.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+32:00" + "'", str27.equals("+32:00"));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(9936000000L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.Locale locale2 = null;
        java.util.Calendar calendar3 = dateTime1.toCalendar(locale2);
        org.joda.time.DateTime dateTime5 = dateTime1.minusMillis(0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        boolean boolean7 = dateTime1.isBefore(readableInstant6);
        org.joda.time.DateTime dateTime8 = dateTime1.toDateTimeISO();
        int int9 = dateTime1.getMillisOfDay();
        org.junit.Assert.assertNotNull(calendar3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 28800000 + "'", int9 == 28800000);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        int int8 = delegatedDateTimeField4.getMaximumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean3 = dateTime2.isBeforeNow();
        int int4 = dateTime2.getYearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime2.withDurationAdded(1560632380036L, 1969);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isBefore(1L);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime2.withZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.DateTime dateTime11 = dateTime2.withZone(dateTimeZone10);
        try {
            org.joda.time.DateTime dateTime13 = dateTime11.withMonthOfYear(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1:59:03 PM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1:59:03 PM' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        java.lang.String str5 = property3.getAsShortText();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "117" + "'", str5.equals("117"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean3 = dateTime2.isBeforeNow();
        org.joda.time.DateTime dateTime5 = dateTime2.plusSeconds(55);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        java.lang.Object obj2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str7 = gregorianChronology6.toString();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology10 = gregorianChronology6.withZone(dateTimeZone9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone9.getShortName(10L, locale12);
        org.joda.time.Chronology chronology14 = gJChronology5.withZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone15 = gJChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.DateTime.Property property19 = dateTime18.weekOfWeekyear();
        org.joda.time.DateTime dateTime20 = property19.getDateTime();
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime20);
        try {
            org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.ReadableDateTime) dateTime3, (org.joda.time.ReadableDateTime) dateTime20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[UTC]" + "'", str7.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+32:00" + "'", str13.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gJChronology21);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology1.secondOfDay();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology9 = gregorianChronology5.withZone(dateTimeZone8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone8.getShortName(10L, locale11);
        org.joda.time.Chronology chronology13 = gJChronology4.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology14 = copticChronology1.withZone(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone15 = copticChronology1.getZone();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(1560632391362L, (org.joda.time.Chronology) copticChronology1);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[UTC]" + "'", str6.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+32:00" + "'", str12.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        long long36 = preciseDateTimeField35.getUnitMillis();
        long long39 = preciseDateTimeField35.set(1560632340763L, (int) 'a');
        boolean boolean40 = preciseDateTimeField35.isLenient();
        long long42 = preciseDateTimeField35.roundCeiling((long) 31);
        java.util.Locale locale44 = null;
        java.lang.String str45 = preciseDateTimeField35.getAsShortText(0, locale44);
        java.lang.Object obj46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(obj46);
        long long48 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime47);
        org.joda.time.DateTime dateTime50 = dateTime47.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property51 = dateTime50.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property51.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField53 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) preciseDateTimeField35, dateTimeFieldType52);
        long long55 = zeroIsMaxDateTimeField53.roundHalfCeiling(40L);
        long long58 = zeroIsMaxDateTimeField53.add(0L, 1560632370375L);
        int int60 = zeroIsMaxDateTimeField53.getMaximumValue(1560632330384L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1000L + "'", long36 == 1000L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560628897763L + "'", long39 == 1560628897763L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1000L + "'", long42 == 1000L);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "0" + "'", str45.equals("0"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 9936000000L + "'", long48 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560632370375000L + "'", long58 == 1560632370375000L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 3600 + "'", int60 == 3600);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology1.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 10);
        int int8 = offsetDateTimeField5.getDifference(0L, 0L);
        int int10 = offsetDateTimeField5.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MonthDay monthDay13 = monthDay11.withChronologyRetainFields(chronology12);
        int[] intArray19 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int20 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) monthDay13, intArray19);
        long long23 = offsetDateTimeField5.add((long) (short) 1, (int) (short) -1);
        int int25 = offsetDateTimeField5.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) 10.0d, "");
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str33 = gregorianChronology32.toString();
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology36 = gregorianChronology32.withZone(dateTimeZone35);
        org.joda.time.DurationField durationField37 = gregorianChronology32.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField38 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField37);
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 11 + "'", int10 == 11);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 11 + "'", int20 == 11);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-31449599999L) + "'", long23 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "GregorianChronology[UTC]" + "'", str33.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField38);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
        int int31 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
        int int51 = offsetDateTimeField46.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
        int int72 = offsetDateTimeField67.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology74 = null;
        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
        int[] intArray83 = monthDay75.getValues();
        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
        java.util.Locale locale88 = null;
        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
        int int91 = offsetDateTimeField4.getLeapAmount(17452800654L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(copticChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
        org.junit.Assert.assertNotNull(monthDay73);
        org.junit.Assert.assertNotNull(monthDay75);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(monthDay86);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long4 = buddhistChronology0.add((long) (short) 1, 1560628897763L, 10);
        java.lang.Object obj5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj5);
        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime9 = dateTime6.withMillisOfDay((int) 'a');
        int int10 = dateTime6.getDayOfMonth();
        org.joda.time.DateTime dateTime12 = dateTime6.withDayOfYear((int) (byte) 1);
        java.lang.Object obj13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusDays((int) (short) 10);
        org.joda.time.LocalTime localTime17 = dateTime14.toLocalTime();
        int int18 = dateTime14.getEra();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime20 = dateTime14.plus(readableDuration19);
        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.ReadableDateTime) dateTime12, (org.joda.time.ReadableDateTime) dateTime20);
        org.joda.time.DurationField durationField22 = limitChronology21.minutes();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 15606288977631L + "'", long4 == 15606288977631L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9936000000L + "'", long7 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 27 + "'", int10 == 27);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(limitChronology21);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.Chronology chronology7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(871, 46, 54, 420, 0, 59, (-1538513957), chronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 420 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(11);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology9 = gregorianChronology5.withZone(dateTimeZone8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = dateTimeZone8.getShortName(10L, locale11);
        org.joda.time.Chronology chronology13 = gJChronology4.withZone(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology4.getZone();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.weekOfWeekyear();
        org.joda.time.DateTime dateTime19 = property18.getDateTime();
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTimeZone dateTimeZone21 = gJChronology20.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter0.withZone(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[UTC]" + "'", str6.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+32:00" + "'", str12.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology23.secondOfDay();
        org.joda.time.DateTimeField dateTimeField25 = copticChronology23.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 10);
        int int30 = offsetDateTimeField27.getDifference(0L, 0L);
        int int32 = offsetDateTimeField27.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.withChronologyRetainFields(chronology34);
        int[] intArray41 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int42 = offsetDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) monthDay35, intArray41);
        long long45 = offsetDateTimeField27.add((long) (short) 1, (int) (short) -1);
        int int47 = offsetDateTimeField27.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = offsetDateTimeField27.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType48, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType48, 3599);
        org.joda.time.IllegalFieldValueException illegalFieldValueException54 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType48, "2017-08-05T13:59:03.031-07:00");
        org.joda.time.IllegalFieldValueException illegalFieldValueException57 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException60 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException57.addSuppressed((java.lang.Throwable) illegalFieldValueException60);
        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException67 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException64.addSuppressed((java.lang.Throwable) illegalFieldValueException67);
        illegalFieldValueException57.addSuppressed((java.lang.Throwable) illegalFieldValueException67);
        org.joda.time.IllegalFieldValueException illegalFieldValueException72 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException75 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException72.addSuppressed((java.lang.Throwable) illegalFieldValueException75);
        illegalFieldValueException57.addSuppressed((java.lang.Throwable) illegalFieldValueException75);
        org.joda.time.IllegalFieldValueException illegalFieldValueException80 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException83 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException80.addSuppressed((java.lang.Throwable) illegalFieldValueException83);
        org.joda.time.IllegalFieldValueException illegalFieldValueException87 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException90 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException87.addSuppressed((java.lang.Throwable) illegalFieldValueException90);
        illegalFieldValueException80.addSuppressed((java.lang.Throwable) illegalFieldValueException90);
        illegalFieldValueException75.addSuppressed((java.lang.Throwable) illegalFieldValueException90);
        java.lang.String str94 = illegalFieldValueException75.getIllegalValueAsString();
        java.lang.String str95 = illegalFieldValueException75.toString();
        illegalFieldValueException54.addSuppressed((java.lang.Throwable) illegalFieldValueException75);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 11 + "'", int32 == 11);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 11 + "'", int42 == 11);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-31449599999L) + "'", long45 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "" + "'", str94.equals(""));
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported" + "'", str95.equals("org.joda.time.IllegalFieldValueException: Value \"\" for  is not supported"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
        org.joda.time.LocalDateTime localDateTime9 = dateTime4.toLocalDateTime();
        try {
            org.joda.time.DateTime dateTime11 = dateTime4.withMonthOfYear(334);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 334 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDateTime9);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime1.plusDays(42);
        try {
            java.lang.String str12 = dateTime1.toString("DateTimeField[weekyearOfCentury]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.secondOfDay();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str5 = gregorianChronology4.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology8 = gregorianChronology4.withZone(dateTimeZone7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = dateTimeZone7.getShortName(10L, locale10);
        org.joda.time.Chronology chronology12 = gJChronology3.withZone(dateTimeZone7);
        org.joda.time.Chronology chronology13 = copticChronology0.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        java.lang.Object obj16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(obj16);
        java.util.GregorianCalendar gregorianCalendar18 = dateTime17.toGregorianCalendar();
        org.joda.time.DateTime.Property property19 = dateTime17.dayOfYear();
        org.joda.time.DateTime dateTime20 = property19.roundHalfCeilingCopy();
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime20);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[UTC]" + "'", str5.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+32:00" + "'", str11.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianCalendar18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gJChronology21);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendCenturyOfEra(1258, 15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 10, 6);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(monthDay3);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        org.joda.time.DurationField durationField14 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.secondOfMinute();
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.Instant instant6 = instant3.withDurationAdded(1559952000000L, (int) (byte) 1);
        org.joda.time.Instant instant9 = instant3.withDurationAdded(1560632392138L, 3600);
        long long10 = instant9.getMillis();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 5556109277296800L + "'", long10 == 5556109277296800L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField4.getAsText((int) '#', locale8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField4.getAsText(1969, locale11);
        boolean boolean13 = delegatedDateTimeField4.isSupported();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "35" + "'", str9.equals("35"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone1.getShortName(0L, locale5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        boolean boolean12 = dateTime10.isAfter((-1L));
        org.joda.time.DateTime dateTime14 = dateTime10.plus((long) (short) 10);
        org.joda.time.DateTime dateTime16 = dateTime14.plusYears(100);
        int int17 = dateTime14.getDayOfMonth();
        try {
            org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime14, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 17");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+32:00" + "'", str6.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 26 + "'", int17 == 26);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
        long long49 = unsupportedDateTimeField46.add((long) 53, (int) (short) -1);
        org.joda.time.MonthDay monthDay50 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.MonthDay monthDay52 = monthDay50.withChronologyRetainFields(chronology51);
        try {
            int int53 = unsupportedDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay52);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-3599947L) + "'", long49 == (-3599947L));
        org.junit.Assert.assertNotNull(monthDay50);
        org.junit.Assert.assertNotNull(monthDay52);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.Locale locale2 = null;
        java.util.Calendar calendar3 = dateTime1.toCalendar(locale2);
        org.joda.time.DateTime dateTime5 = dateTime1.minusMillis(0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        boolean boolean7 = dateTime1.isBefore(readableInstant6);
        org.joda.time.DateTime dateTime8 = dateTime1.toDateTimeISO();
        java.lang.Object obj9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(obj9);
        java.util.GregorianCalendar gregorianCalendar11 = dateTime10.toGregorianCalendar();
        int int12 = dateTime10.getSecondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime10.minusSeconds(11);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime16 = dateTime1.toDateTime(chronology15);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str19 = gregorianChronology18.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology22 = gregorianChronology18.withZone(dateTimeZone21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = dateTimeZone21.getShortName(10L, locale24);
        org.joda.time.Chronology chronology26 = gJChronology17.withZone(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone27 = gJChronology17.getZone();
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime29 = dateTime16.toMutableDateTime(dateTimeZone27);
        org.junit.Assert.assertNotNull(calendar3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianCalendar11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "GregorianChronology[UTC]" + "'", str19.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+32:00" + "'", str25.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        int int2 = gJChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone1.getShortName(0L, locale5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int10 = cachedDateTimeZone8.getStandardOffset((long) 1969);
        int int12 = cachedDateTimeZone8.getOffset((-31449599635L));
        int int14 = cachedDateTimeZone8.getOffsetFromLocal(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+32:00" + "'", str6.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 115200000 + "'", int10 == 115200000);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 115200000 + "'", int12 == 115200000);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 115200000 + "'", int14 == 115200000);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getShortName((-1900800000L));
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 1);
        org.joda.time.Chronology chronology7 = julianChronology6.withUTC();
        try {
            long long12 = julianChronology6.getDateTimeMillis(786, (int) '#', 7, (-1538513957));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1538513957 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+32:00" + "'", str4.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str2 = gJChronology1.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.Chronology chronology4 = dateTimeFormatter0.getChronology();
        try {
            long long6 = dateTimeFormatter0.parseMillis("��");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"��\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNull(chronology4);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField4.getMaximumShortTextLength(locale8);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField14.getAsText(readablePartial15, (int) (byte) 100, locale17);
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology19.secondOfDay();
        org.joda.time.DateTimeField dateTimeField21 = copticChronology19.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, 10);
        int int26 = offsetDateTimeField23.getDifference(0L, 0L);
        int int28 = offsetDateTimeField23.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay29 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.MonthDay monthDay31 = monthDay29.withChronologyRetainFields(chronology30);
        int[] intArray37 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int38 = offsetDateTimeField23.getMinimumValue((org.joda.time.ReadablePartial) monthDay31, intArray37);
        int[] intArray39 = monthDay31.getValues();
        java.util.Locale locale40 = null;
        java.lang.String str41 = delegatedDateTimeField14.getAsText((org.joda.time.ReadablePartial) monthDay31, locale40);
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(dateTimeZone43);
        boolean boolean45 = dateTime44.isBeforeNow();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.MutableDateTime mutableDateTime47 = dateTime44.toMutableDateTime(dateTimeZone46);
        org.joda.time.DateTime dateTime48 = monthDay31.toDateTime((org.joda.time.ReadableInstant) mutableDateTime47);
        org.joda.time.chrono.CopticChronology copticChronology50 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField51 = copticChronology50.secondOfDay();
        org.joda.time.DateTimeField dateTimeField52 = copticChronology50.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, 10);
        int int57 = offsetDateTimeField54.getDifference(0L, 0L);
        int int59 = offsetDateTimeField54.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay60 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology61 = null;
        org.joda.time.MonthDay monthDay62 = monthDay60.withChronologyRetainFields(chronology61);
        int[] intArray68 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int69 = offsetDateTimeField54.getMinimumValue((org.joda.time.ReadablePartial) monthDay62, intArray68);
        int[] intArray70 = monthDay62.getValues();
        try {
            int[] intArray72 = delegatedDateTimeField4.set((org.joda.time.ReadablePartial) monthDay31, (-13), intArray70, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 11 + "'", int28 == 11);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 11 + "'", int38 == 11);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "4" + "'", str41.equals("4"));
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(mutableDateTime47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(copticChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 11 + "'", int59 == 11);
        org.junit.Assert.assertNotNull(monthDay60);
        org.junit.Assert.assertNotNull(monthDay62);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 11 + "'", int69 == 11);
        org.junit.Assert.assertNotNull(intArray70);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (-10));
        org.joda.time.DateTime dateTime2 = instant1.toDateTimeISO();
        org.joda.time.Instant instant3 = instant1.toInstant();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone3.getShortName(10L, locale6);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField9 = julianChronology8.weekyears();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        try {
            long long15 = julianChronology8.getDateTimeMillis(0, 27, 12, 56);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+32:00" + "'", str7.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (-10));
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology6 = gregorianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.monthOfYear();
        org.joda.time.DurationField durationField8 = gregorianChronology2.centuries();
        org.joda.time.MonthDay monthDay9 = monthDay1.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology13.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 10);
        int int20 = offsetDateTimeField17.getDifference(0L, 0L);
        long long22 = offsetDateTimeField17.remainder(0L);
        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now();
        java.util.Locale locale25 = null;
        java.lang.String str26 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) monthDay23, 0, locale25);
        int int27 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay23);
        int int28 = monthDay23.getDayOfMonth();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9936000000L + "'", long22 == 9936000000L);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 27 + "'", int28 == 27);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        long long36 = preciseDateTimeField35.getUnitMillis();
        long long39 = preciseDateTimeField35.set(1560632340763L, (int) 'a');
        boolean boolean40 = preciseDateTimeField35.isLenient();
        long long42 = preciseDateTimeField35.roundCeiling((long) 31);
        java.util.Locale locale44 = null;
        java.lang.String str45 = preciseDateTimeField35.getAsShortText(0, locale44);
        java.lang.Object obj46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(obj46);
        long long48 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime47);
        org.joda.time.DateTime dateTime50 = dateTime47.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property51 = dateTime50.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property51.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField53 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) preciseDateTimeField35, dateTimeFieldType52);
        long long55 = zeroIsMaxDateTimeField53.roundHalfCeiling(40L);
        long long58 = zeroIsMaxDateTimeField53.add(0L, 1560632370375L);
        int int61 = zeroIsMaxDateTimeField53.getDifference((long) (-420), 691200000L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1000L + "'", long36 == 1000L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560628897763L + "'", long39 == 1560628897763L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1000L + "'", long42 == 1000L);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "0" + "'", str45.equals("0"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 9936000000L + "'", long48 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560632370375000L + "'", long58 == 1560632370375000L);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-691200) + "'", int61 == (-691200));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00:00.001", "GregorianChronology[+32:00]");
        java.lang.Class<?> wildcardClass3 = illegalFieldValueException2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        long long8 = delegatedDateTimeField6.roundFloor((long) 0);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField6.getLeapDurationField();
        long long11 = delegatedDateTimeField6.roundHalfCeiling((long) (byte) 0);
        boolean boolean13 = delegatedDateTimeField6.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology14.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        int int21 = offsetDateTimeField18.getDifference(0L, 0L);
        int int23 = offsetDateTimeField18.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.MonthDay monthDay26 = monthDay24.withChronologyRetainFields(chronology25);
        int[] intArray32 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int33 = offsetDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) monthDay26, intArray32);
        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = copticChronology34.secondOfDay();
        org.joda.time.DateTimeField dateTimeField36 = copticChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 10);
        int int41 = offsetDateTimeField38.getDifference(0L, 0L);
        int int43 = offsetDateTimeField38.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay44 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.MonthDay monthDay46 = monthDay44.withChronologyRetainFields(chronology45);
        int[] intArray52 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int53 = offsetDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray52);
        boolean boolean54 = monthDay26.isEqual((org.joda.time.ReadablePartial) monthDay46);
        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = copticChronology55.secondOfDay();
        org.joda.time.DateTimeField dateTimeField57 = copticChronology55.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField57, 10);
        int int62 = offsetDateTimeField59.getDifference(0L, 0L);
        int int64 = offsetDateTimeField59.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay65 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.MonthDay monthDay67 = monthDay65.withChronologyRetainFields(chronology66);
        int[] intArray73 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int74 = offsetDateTimeField59.getMinimumValue((org.joda.time.ReadablePartial) monthDay67, intArray73);
        int[] intArray75 = monthDay67.getValues();
        int int76 = delegatedDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray75);
        boolean boolean77 = copticChronology0.equals((java.lang.Object) delegatedDateTimeField6);
        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology80 = copticChronology0.withZone(dateTimeZone79);
        org.joda.time.DurationField durationField81 = copticChronology0.years();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1900800000L) + "'", long8 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 691200000L + "'", long11 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 11 + "'", int33 == 11);
        org.junit.Assert.assertNotNull(copticChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 11 + "'", int43 == 11);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 11 + "'", int53 == 11);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(copticChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 11 + "'", int64 == 11);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertNotNull(monthDay67);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 11 + "'", int74 == 11);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(dateTimeZone79);
        org.junit.Assert.assertNotNull(chronology80);
        org.junit.Assert.assertNotNull(durationField81);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) -1, (java.lang.Number) 691200000L, number3);
        java.lang.Number number8 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (byte) -1, (java.lang.Number) 691200000L, number8);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        java.lang.String str11 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number12 = illegalFieldValueException4.getIllegalNumberValue();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException15.addSuppressed((java.lang.Throwable) illegalFieldValueException18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException22.addSuppressed((java.lang.Throwable) illegalFieldValueException25);
        illegalFieldValueException15.addSuppressed((java.lang.Throwable) illegalFieldValueException25);
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException30.addSuppressed((java.lang.Throwable) illegalFieldValueException33);
        illegalFieldValueException15.addSuppressed((java.lang.Throwable) illegalFieldValueException33);
        java.lang.Throwable[] throwableArray36 = illegalFieldValueException15.getSuppressed();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException15);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) -1 + "'", number12.equals((byte) -1));
        org.junit.Assert.assertNotNull(throwableArray36);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        java.util.Locale locale16 = null;
        try {
            long long17 = skipUndoDateTimeField13.set(126712738505L, "UTC", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long9 = offsetDateTimeField4.remainder(0L);
        java.util.Locale locale12 = null;
        long long13 = offsetDateTimeField4.set((long) 10, "100", locale12);
        org.joda.time.DurationField durationField14 = offsetDateTimeField4.getDurationField();
        org.joda.time.DurationField durationField15 = offsetDateTimeField4.getLeapDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.util.Locale locale17 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withLocale(locale17);
        org.joda.time.LocalTime localTime20 = dateTimeFormatter18.parseLocalTime("1:58:55 PM");
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localTime20, 20, locale22);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
        org.joda.time.DateTime.Property property27 = dateTime26.weekOfWeekyear();
        org.joda.time.DateTime dateTime28 = property27.getDateTime();
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = copticChronology29.secondOfDay();
        org.joda.time.DateTimeField dateTimeField31 = copticChronology29.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31, dateTimeFieldType32);
        org.joda.time.ReadablePartial readablePartial34 = null;
        java.util.Locale locale36 = null;
        java.lang.String str37 = delegatedDateTimeField33.getAsText(readablePartial34, (int) (byte) 100, locale36);
        boolean boolean38 = delegatedDateTimeField33.isLenient();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = delegatedDateTimeField33.getType();
        org.joda.time.DateTime.Property property40 = dateTime28.property(dateTimeFieldType39);
        try {
            int int41 = localTime20.get(dateTimeFieldType39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'monthOfYear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9936000000L + "'", long9 == 9936000000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 94953600010L + "'", long13 == 94953600010L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(localTime20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "20" + "'", str23.equals("20"));
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "100" + "'", str37.equals("100"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(property40);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundHalfCeiling((-1900800000L));
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology7.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, dateTimeFieldType10);
        long long13 = delegatedDateTimeField11.roundFloor((long) 0);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField11.getLeapDurationField();
        long long16 = delegatedDateTimeField11.roundHalfCeiling((long) (byte) 0);
        boolean boolean18 = delegatedDateTimeField11.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology19.secondOfDay();
        org.joda.time.DateTimeField dateTimeField21 = copticChronology19.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, 10);
        int int26 = offsetDateTimeField23.getDifference(0L, 0L);
        int int28 = offsetDateTimeField23.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay29 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.MonthDay monthDay31 = monthDay29.withChronologyRetainFields(chronology30);
        int[] intArray37 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int38 = offsetDateTimeField23.getMinimumValue((org.joda.time.ReadablePartial) monthDay31, intArray37);
        org.joda.time.chrono.CopticChronology copticChronology39 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField40 = copticChronology39.secondOfDay();
        org.joda.time.DateTimeField dateTimeField41 = copticChronology39.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, 10);
        int int46 = offsetDateTimeField43.getDifference(0L, 0L);
        int int48 = offsetDateTimeField43.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay49 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.MonthDay monthDay51 = monthDay49.withChronologyRetainFields(chronology50);
        int[] intArray57 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int58 = offsetDateTimeField43.getMinimumValue((org.joda.time.ReadablePartial) monthDay51, intArray57);
        boolean boolean59 = monthDay31.isEqual((org.joda.time.ReadablePartial) monthDay51);
        org.joda.time.chrono.CopticChronology copticChronology60 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField61 = copticChronology60.secondOfDay();
        org.joda.time.DateTimeField dateTimeField62 = copticChronology60.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField(dateTimeField62, 10);
        int int67 = offsetDateTimeField64.getDifference(0L, 0L);
        int int69 = offsetDateTimeField64.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay70 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology71 = null;
        org.joda.time.MonthDay monthDay72 = monthDay70.withChronologyRetainFields(chronology71);
        int[] intArray78 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int79 = offsetDateTimeField64.getMinimumValue((org.joda.time.ReadablePartial) monthDay72, intArray78);
        int[] intArray80 = monthDay72.getValues();
        int int81 = delegatedDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) monthDay51, intArray80);
        org.joda.time.MonthDay monthDay83 = monthDay51.plusDays((int) (short) 100);
        org.joda.time.chrono.ISOChronology iSOChronology84 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay85 = new org.joda.time.MonthDay((java.lang.Object) monthDay83, (org.joda.time.Chronology) iSOChronology84);
        java.util.Locale locale86 = null;
        java.lang.String str87 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay83, locale86);
        java.util.Locale locale89 = null;
        java.lang.String str90 = delegatedDateTimeField4.getAsText((long) (byte) 1, locale89);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1900800000L) + "'", long13 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 691200000L + "'", long16 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 11 + "'", int28 == 11);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 11 + "'", int38 == 11);
        org.junit.Assert.assertNotNull(copticChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 11 + "'", int48 == 11);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 11 + "'", int58 == 11);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(copticChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 11 + "'", int69 == 11);
        org.junit.Assert.assertNotNull(monthDay70);
        org.junit.Assert.assertNotNull(monthDay72);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 11 + "'", int79 == 11);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertNotNull(monthDay83);
        org.junit.Assert.assertNotNull(iSOChronology84);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "5" + "'", str87.equals("5"));
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "4" + "'", str90.equals("4"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone1.getShortName(0L, locale5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int10 = cachedDateTimeZone8.getStandardOffset((long) 1969);
        int int12 = cachedDateTimeZone8.getOffset((-31449599635L));
        long long14 = cachedDateTimeZone8.previousTransition(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+32:00" + "'", str6.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 115200000 + "'", int10 == 115200000);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 115200000 + "'", int12 == 115200000);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis(115200000, 110, 31, 11, (int) (byte) 0, 59, 654);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 110 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            int[] intArray4 = copticChronology0.get(readablePartial2, 1560632399337L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        boolean boolean10 = property8.isLeap();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
        int int31 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
        int int51 = offsetDateTimeField46.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
        int int72 = offsetDateTimeField67.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology74 = null;
        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
        int[] intArray83 = monthDay75.getValues();
        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
        java.util.Locale locale88 = null;
        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
        org.joda.time.DurationField durationField91 = property90.getRangeDurationField();
        int int92 = property90.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType93 = property90.getFieldType();
        java.lang.String str94 = property90.getName();
        java.util.Locale locale96 = null;
        try {
            org.joda.time.MonthDay monthDay97 = property90.setCopy("ISOChronology[UTC]", locale96);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ISOChronology[UTC]\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(copticChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
        org.junit.Assert.assertNotNull(monthDay73);
        org.junit.Assert.assertNotNull(monthDay75);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(monthDay86);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
        org.junit.Assert.assertNotNull(property90);
        org.junit.Assert.assertNotNull(durationField91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType93);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "dayOfMonth" + "'", str94.equals("dayOfMonth"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        java.lang.String str2 = gJChronology1.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfYear();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 2000, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withLocale(locale12);
        org.joda.time.LocalTime localTime15 = dateTimeFormatter13.parseLocalTime("1:58:55 PM");
        int[] intArray17 = gregorianChronology7.get((org.joda.time.ReadablePartial) localTime15, 21859199987L);
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.secondOfDay();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology18.secondOfDay();
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str23 = gregorianChronology22.toString();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology26 = gregorianChronology22.withZone(dateTimeZone25);
        java.util.Locale locale28 = null;
        java.lang.String str29 = dateTimeZone25.getShortName(10L, locale28);
        org.joda.time.Chronology chronology30 = gJChronology21.withZone(dateTimeZone25);
        org.joda.time.Chronology chronology31 = copticChronology18.withZone(dateTimeZone25);
        org.joda.time.DateTimeZone dateTimeZone32 = copticChronology18.getZone();
        org.joda.time.Chronology chronology33 = gregorianChronology7.withZone(dateTimeZone32);
        org.joda.time.Chronology chronology34 = gJChronology1.withZone(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GJChronology[UTC]" + "'", str2.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "GregorianChronology[UTC]" + "'", str23.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+32:00" + "'", str29.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(chronology34);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean3 = dateTime2.isBeforeNow();
        int int4 = dateTime2.getYearOfCentury();
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
        long long49 = unsupportedDateTimeField46.add((long) 53, (int) (short) -1);
        boolean boolean50 = unsupportedDateTimeField46.isLenient();
        java.lang.Object obj51 = null;
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(obj51);
        java.util.Locale locale53 = null;
        java.util.Calendar calendar54 = dateTime52.toCalendar(locale53);
        org.joda.time.MonthDay monthDay55 = org.joda.time.MonthDay.fromCalendarFields(calendar54);
        org.joda.time.chrono.CopticChronology copticChronology57 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField58 = copticChronology57.secondOfDay();
        org.joda.time.DateTimeField dateTimeField59 = copticChronology57.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField61 = new org.joda.time.field.OffsetDateTimeField(dateTimeField59, 10);
        int int64 = offsetDateTimeField61.getDifference(0L, 0L);
        int int66 = offsetDateTimeField61.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay67 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology68 = null;
        org.joda.time.MonthDay monthDay69 = monthDay67.withChronologyRetainFields(chronology68);
        int[] intArray75 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int76 = offsetDateTimeField61.getMinimumValue((org.joda.time.ReadablePartial) monthDay69, intArray75);
        try {
            int[] intArray78 = unsupportedDateTimeField46.set((org.joda.time.ReadablePartial) monthDay55, 44, intArray75, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-3599947L) + "'", long49 == (-3599947L));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(calendar54);
        org.junit.Assert.assertNotNull(monthDay55);
        org.junit.Assert.assertNotNull(copticChronology57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 11 + "'", int66 == 11);
        org.junit.Assert.assertNotNull(monthDay67);
        org.junit.Assert.assertNotNull(monthDay69);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 11 + "'", int76 == 11);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        java.lang.Object obj3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(obj3);
        java.util.GregorianCalendar gregorianCalendar5 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTime.Property property6 = dateTime4.dayOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        java.lang.String str8 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter2.withPivotYear(20);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gregorianCalendar5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "8:00:00 AM" + "'", str8.equals("8:00:00 AM"));
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.seconds();
        org.joda.time.DurationField durationField2 = gJChronology0.minutes();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        java.lang.Object obj3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(obj3);
        java.util.GregorianCalendar gregorianCalendar5 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTime.Property property6 = dateTime4.dayOfYear();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        java.lang.String str8 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        java.lang.String str10 = property9.getAsString();
        org.joda.time.DurationField durationField11 = property9.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gregorianCalendar5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "8:00:00 AM" + "'", str8.equals("8:00:00 AM"));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("55", (int) (short) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("Feb 7, ���� �:��:�� �", 839);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder6.setStandardOffset(110);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder6.addCutover(999, 'a', 54, 165, (int) (short) 0, false, 17997);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("DateTimeField[weekyearOfCentury]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: DateTimeField[weekyearOfCentury]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone2.getShortName(0L, locale6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) true, (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+32:00" + "'", str7.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology8);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundFloorCopy();
        java.lang.String str6 = dateTime5.toString();
        org.joda.time.DateTime.Property property7 = dateTime5.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970-04-27T00:00:00.000+32:00" + "'", str6.equals("1970-04-27T00:00:00.000+32:00"));
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime dateTime5 = dateTime1.minusSeconds(11);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readableDuration6);
        int int8 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.minusMonths(365);
        org.joda.time.DateTime.Property property11 = dateTime7.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 18 + "'", int8 == 18);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        java.lang.String str7 = dateTimeZone4.getShortName((-1900800000L));
        org.joda.time.Chronology chronology8 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone4);
        java.lang.Object obj10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(obj10);
        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime14 = dateTime11.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property15 = dateTime14.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        boolean boolean17 = dateTime9.isSupported(dateTimeFieldType16);
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, (java.lang.Number) 1560632375677L, (java.lang.Number) 1560632356034L, (java.lang.Number) 1560632355843L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+32:00" + "'", str7.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9936000000L + "'", long12 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DurationField durationField2 = copticChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        boolean boolean5 = copticChronology0.equals((java.lang.Object) dateTimeFormatter4);
        java.util.Locale locale6 = dateTimeFormatter4.getLocale();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(locale6);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone1.getShortName(0L, locale5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        try {
            org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime8, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+32:00" + "'", str6.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
        int int11 = offsetDateTimeField4.getLeapAmount((long) (-420));
        long long13 = offsetDateTimeField4.roundHalfEven(1560632318274L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1567987200000L + "'", long13 == 1567987200000L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime5 = dateTime1.withYear(11);
        org.joda.time.DateTime.Property property6 = dateTime1.dayOfMonth();
        org.joda.time.DateTime.Property property7 = dateTime1.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.Number number7 = illegalFieldValueException5.getIllegalNumberValue();
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
        int int19 = offsetDateTimeField16.getDifference(0L, 0L);
        int int21 = offsetDateTimeField16.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay22.withChronologyRetainFields(chronology23);
        int[] intArray30 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int31 = offsetDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) monthDay24, intArray30);
        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = copticChronology32.secondOfDay();
        org.joda.time.DateTimeField dateTimeField34 = copticChronology32.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 10);
        int int39 = offsetDateTimeField36.getDifference(0L, 0L);
        int int41 = offsetDateTimeField36.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay42 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.MonthDay monthDay44 = monthDay42.withChronologyRetainFields(chronology43);
        int[] intArray50 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int51 = offsetDateTimeField36.getMinimumValue((org.joda.time.ReadablePartial) monthDay44, intArray50);
        boolean boolean52 = monthDay24.isEqual((org.joda.time.ReadablePartial) monthDay44);
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField54 = copticChronology53.secondOfDay();
        org.joda.time.DateTimeField dateTimeField55 = copticChronology53.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, 10);
        int int60 = offsetDateTimeField57.getDifference(0L, 0L);
        int int62 = offsetDateTimeField57.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay63 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology64 = null;
        org.joda.time.MonthDay monthDay65 = monthDay63.withChronologyRetainFields(chronology64);
        int[] intArray71 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int72 = offsetDateTimeField57.getMinimumValue((org.joda.time.ReadablePartial) monthDay65, intArray71);
        int[] intArray73 = monthDay65.getValues();
        int int74 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay44, intArray73);
        org.joda.time.MonthDay monthDay76 = monthDay44.plusDays((int) (short) 100);
        org.joda.time.chrono.ISOChronology iSOChronology77 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay78 = new org.joda.time.MonthDay((java.lang.Object) monthDay76, (org.joda.time.Chronology) iSOChronology77);
        org.joda.time.MonthDay monthDay80 = monthDay76.minusMonths((int) '#');
        java.lang.Object obj81 = null;
        org.joda.time.DateTime dateTime82 = new org.joda.time.DateTime(obj81);
        java.util.GregorianCalendar gregorianCalendar83 = dateTime82.toGregorianCalendar();
        boolean boolean84 = monthDay80.equals((java.lang.Object) dateTime82);
        org.joda.time.MonthDay.Property property85 = monthDay80.dayOfMonth();
        java.lang.String str86 = property85.getName();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(copticChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 11 + "'", int62 == 11);
        org.junit.Assert.assertNotNull(monthDay63);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(monthDay76);
        org.junit.Assert.assertNotNull(iSOChronology77);
        org.junit.Assert.assertNotNull(monthDay80);
        org.junit.Assert.assertNotNull(gregorianCalendar83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(property85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "dayOfMonth" + "'", str86.equals("dayOfMonth"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        try {
            org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) 2019, 839);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 839");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
        long long49 = unsupportedDateTimeField46.add((long) 53, (int) (short) -1);
        try {
            java.lang.String str51 = unsupportedDateTimeField46.getAsText((long) 44);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-3599947L) + "'", long49 == (-3599947L));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.clockhourOfHalfday();
        try {
            long long11 = gregorianChronology1.getDateTimeMillis(595, 595, 165, (int) (short) -1, 7, (int) (byte) 100, 837);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isBefore(1L);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        int int6 = dateTime2.getDayOfWeek();
        org.joda.time.DateTime dateTime7 = dateTime2.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
        long long12 = offsetDateTimeField4.add((long) 75578, (int) (short) 10);
        org.joda.time.DurationField durationField13 = offsetDateTimeField4.getRangeDurationField();
        long long15 = offsetDateTimeField4.roundFloor((long) 839);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 315705675578L + "'", long12 == 315705675578L);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-9936000000L) + "'", long15 == (-9936000000L));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
        java.lang.String str47 = unsupportedDateTimeField46.toString();
        java.util.Locale locale49 = null;
        try {
            java.lang.String str50 = unsupportedDateTimeField46.getAsText(0, locale49);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property5 = dateTime4.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime12 = dateTime4.toDateTime(dateTimeZone7);
        java.util.Locale locale14 = null;
        try {
            java.lang.String str15 = dateTime12.toString("ISOChronology[America/Los_Angeles]", locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: I");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("55", (int) (short) 1);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("46", 2, 12, 54, '4', (-10), 42, 3599, false, 27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        java.lang.Object obj2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendDayOfWeekShortText();
        java.lang.Object obj17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(obj17);
        long long19 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = dateTime18.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property22 = dateTime21.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder15.appendSignedDecimal(dateTimeFieldType23, (int) (short) 100, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder15.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder28.appendTimeZoneOffset("2017-08-05T13:59:12.208-07:00", true, 11, (int) (byte) 100);
        java.lang.Object obj34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(obj34);
        long long36 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime dateTime38 = dateTime35.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property39 = dateTime38.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder28.appendShortText(dateTimeFieldType40);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder14.appendDecimal(dateTimeFieldType40, 0, 168);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder14.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9936000000L + "'", long4 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9936000000L + "'", long19 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9936000000L + "'", long36 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isBefore(1L);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property6 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime2.dayOfWeek();
        org.joda.time.DateTime dateTime10 = dateTime2.withDurationAdded(1560632397827L, 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.io.Writer writer2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
        try {
            int int47 = unsupportedDateTimeField46.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(1L);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        org.joda.time.DateTime dateTime6 = property2.addToCopy((long) (short) 10);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970" + "'", str4.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(53, (-13), (-691200), (-33), 10, (int) '#', dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -33 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime dateTime5 = dateTime1.minusSeconds(11);
        org.joda.time.DateTime.Property property6 = dateTime5.monthOfYear();
        java.lang.String str7 = property6.getAsShortText();
        org.joda.time.DateTime dateTime8 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime9 = property6.roundCeilingCopy();
        int int10 = property6.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Apr" + "'", str7.equals("Apr"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        java.lang.Object obj2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfHour((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMillisOfSecond(44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendMonthOfYearShortText();
        boolean boolean18 = dateTimeFormatterBuilder14.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9936000000L + "'", long4 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "13", 786, 168);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        long long28 = offsetDateTimeField4.addWrapField((long) 365, (int) (byte) -1);
        long long30 = offsetDateTimeField4.roundHalfFloor((long) 27);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-31449599635L) + "'", long28 == (-31449599635L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-9936000000L) + "'", long30 == (-9936000000L));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumShortTextLength(locale4);
        int int6 = property3.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        try {
            org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((java.lang.Object) dateTimeZone1, (org.joda.time.Chronology) buddhistChronology3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        java.lang.Object obj2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder13.appendTimeZoneOffset("2017-08-05T13:59:12.208-07:00", true, 11, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendTwoDigitWeekyear((int) (byte) 100, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9936000000L + "'", long4 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
        long long49 = unsupportedDateTimeField46.add((long) 53, (int) (short) -1);
        try {
            long long51 = unsupportedDateTimeField46.roundHalfCeiling(4716305952941L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-3599947L) + "'", long49 == (-3599947L));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        long long36 = preciseDateTimeField35.getUnitMillis();
        long long39 = preciseDateTimeField35.set(1560632340763L, (int) 'a');
        boolean boolean40 = preciseDateTimeField35.isLenient();
        long long42 = preciseDateTimeField35.roundCeiling((long) 31);
        java.util.Locale locale44 = null;
        java.lang.String str45 = preciseDateTimeField35.getAsShortText(0, locale44);
        java.lang.Object obj46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(obj46);
        long long48 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime47);
        org.joda.time.DateTime dateTime50 = dateTime47.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property51 = dateTime50.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property51.getFieldType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField53 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) preciseDateTimeField35, dateTimeFieldType52);
        long long56 = zeroIsMaxDateTimeField53.addWrapField(0L, 53);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1000L + "'", long36 == 1000L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560628897763L + "'", long39 == 1560628897763L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1000L + "'", long42 == 1000L);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "0" + "'", str45.equals("0"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 9936000000L + "'", long48 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 53000L + "'", long56 == 53000L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getRangeDurationField();
        int int14 = delegatedDateTimeField4.getMinimumValue((long) 248);
        long long17 = delegatedDateTimeField4.add((long) '#', (long) 0);
        int int19 = delegatedDateTimeField4.getLeapAmount((long) '4');
        long long21 = delegatedDateTimeField4.roundHalfCeiling(1560632372820L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35L + "'", long17 == 35L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1559952000000L + "'", long21 == 1559952000000L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        try {
            long long8 = gJChronology3.getDateTimeMillis(44, 0, 3599, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology3);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.Locale locale2 = null;
        java.util.Calendar calendar3 = dateTime1.toCalendar(locale2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime dateTime8 = property7.getDateTime();
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.secondOfDay();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField13.getAsText(readablePartial14, (int) (byte) 100, locale16);
        boolean boolean18 = delegatedDateTimeField13.isLenient();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = delegatedDateTimeField13.getType();
        org.joda.time.DateTime.Property property20 = dateTime8.property(dateTimeFieldType19);
        int int21 = dateTime1.get(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(calendar3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundHalfCeiling((-1900800000L));
        long long9 = delegatedDateTimeField4.getDifferenceAsLong((long) 59, 70L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = offsetDateTimeField4.getMinimumValue(readablePartial5);
        long long8 = offsetDateTimeField4.remainder((long) 15);
        long long10 = offsetDateTimeField4.roundHalfEven(94953600010L);
        long long12 = offsetDateTimeField4.roundHalfCeiling(1560632399449L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9936000015L + "'", long8 == 9936000015L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 85017600000L + "'", long10 == 85017600000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1567987200000L + "'", long12 == 1567987200000L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime.Property property2 = dateTime1.era();
        java.util.Locale locale3 = null;
        int int4 = property2.getMaximumTextLength(locale3);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("0");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 110);
        org.joda.time.DateTime dateTime5 = instant4.toDateTime();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        java.util.Locale locale14 = null;
        int int15 = delegatedDateTimeField9.getMaximumShortTextLength(locale14);
        int int18 = delegatedDateTimeField9.getDifference((long) (byte) 10, 0L);
        int int20 = delegatedDateTimeField9.getMaximumValue(0L);
        boolean boolean22 = delegatedDateTimeField9.isLeap(187200837L);
        int int24 = delegatedDateTimeField9.getMaximumValue((long) 2);
        java.util.Locale locale27 = null;
        try {
            long long28 = delegatedDateTimeField9.set((long) 871, "1:58:46 PM", locale27);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1:58:46 PM\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 13 + "'", int24 == 13);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField11 = gJChronology10.hours();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.Chronology chronology13 = gJChronology10.withUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.Chronology chronology20 = gJChronology10.withZone(dateTimeZone15);
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((-13), 34, 165, 454, 0, 9, 839, dateTimeZone15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 454 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
        java.lang.String str47 = unsupportedDateTimeField46.toString();
        org.joda.time.DurationField durationField48 = unsupportedDateTimeField46.getDurationField();
        try {
            int int50 = unsupportedDateTimeField46.getMaximumValue(1560632379788L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(durationField48);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        long long14 = delegatedDateTimeField4.add(0L, (long) '#');
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 84931200000L + "'", long14 == 84931200000L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
        org.joda.time.chrono.CopticChronology copticChronology47 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField48 = copticChronology47.secondOfDay();
        org.joda.time.DateTimeField dateTimeField49 = copticChronology47.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, 10);
        int int54 = offsetDateTimeField51.getDifference(0L, 0L);
        int int56 = offsetDateTimeField51.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay57 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology58 = null;
        org.joda.time.MonthDay monthDay59 = monthDay57.withChronologyRetainFields(chronology58);
        int[] intArray65 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int66 = offsetDateTimeField51.getMinimumValue((org.joda.time.ReadablePartial) monthDay59, intArray65);
        boolean boolean68 = monthDay59.equals((java.lang.Object) (-1900800000L));
        int int69 = monthDay59.getDayOfMonth();
        java.lang.String str70 = monthDay59.toString();
        try {
            int int71 = unsupportedDateTimeField46.getMaximumValue((org.joda.time.ReadablePartial) monthDay59);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertNotNull(copticChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 11 + "'", int56 == 11);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertNotNull(monthDay59);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 11 + "'", int66 == 11);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 27 + "'", int69 == 27);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "--04-27" + "'", str70.equals("--04-27"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        org.joda.time.DateTime dateTime3 = dateTime1.plusDays((int) (short) 10);
        org.joda.time.LocalTime localTime4 = dateTime1.toLocalTime();
        int int5 = dateTime1.getEra();
        try {
            org.joda.time.DateTime dateTime7 = dateTime1.withSecondOfMinute((-33));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -33 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException9.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException17.addSuppressed((java.lang.Throwable) illegalFieldValueException20);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException20);
        java.lang.Throwable[] throwableArray23 = illegalFieldValueException2.getSuppressed();
        java.lang.String str24 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        int int8 = dateTime4.getDayOfYear();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 117 + "'", int8 == 117);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
        java.lang.String str47 = unsupportedDateTimeField46.toString();
        org.joda.time.DurationField durationField48 = unsupportedDateTimeField46.getLeapDurationField();
        org.joda.time.DurationField durationField49 = unsupportedDateTimeField46.getLeapDurationField();
        try {
            java.lang.String str51 = unsupportedDateTimeField46.getAsText((long) 59);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNull(durationField48);
        org.junit.Assert.assertNull(durationField49);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        java.util.Locale locale14 = null;
        int int15 = delegatedDateTimeField9.getMaximumShortTextLength(locale14);
        int int17 = delegatedDateTimeField9.getLeapAmount((-41385600000L));
        org.joda.time.DateTimeField dateTimeField18 = delegatedDateTimeField9.getWrappedField();
        boolean boolean20 = delegatedDateTimeField9.isLeap(1560632344000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime dateTime5 = dateTime1.minusSeconds(11);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfYear();
        org.joda.time.DateTime dateTime8 = property6.addToCopy(654);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = iSOChronology30.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.monthOfYear();
        org.joda.time.DurationField durationField34 = buddhistChronology32.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType25, durationField31, durationField34);
        long long36 = preciseDateTimeField35.getUnitMillis();
        long long39 = preciseDateTimeField35.set(1560632340763L, (int) 'a');
        boolean boolean40 = preciseDateTimeField35.isLenient();
        long long42 = preciseDateTimeField35.roundCeiling((long) 31);
        boolean boolean43 = preciseDateTimeField35.isSupported();
        java.util.Locale locale45 = null;
        java.lang.String str46 = preciseDateTimeField35.getAsShortText(115200000, locale45);
        long long49 = preciseDateTimeField35.add(1560632370287L, (long) (-13));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1000L + "'", long36 == 1000L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560628897763L + "'", long39 == 1560628897763L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1000L + "'", long42 == 1000L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "115200000" + "'", str46.equals("115200000"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560632357287L + "'", long49 == 1560632357287L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int6 = offsetDateTimeField4.getMaximumValue(9936000000L);
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField4.getMinimumValue(readablePartial7);
        long long11 = offsetDateTimeField4.add(1560632320665L, (long) 13);
        int int13 = offsetDateTimeField4.get(1560632318274L);
        boolean boolean15 = offsetDateTimeField4.isLeap((long) 6);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 110 + "'", int6 == 110);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1971291520665L + "'", long11 == 1971291520665L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 46 + "'", int13 == 46);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
        long long49 = unsupportedDateTimeField46.add((long) 53, (int) (short) -1);
        java.util.Locale locale51 = null;
        try {
            java.lang.String str52 = unsupportedDateTimeField46.getAsText(0, locale51);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-3599947L) + "'", long49 == (-3599947L));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        org.joda.time.DurationField durationField14 = skipUndoDateTimeField13.getRangeDurationField();
        boolean boolean15 = skipUndoDateTimeField13.isSupported();
        long long18 = skipUndoDateTimeField13.add(1567987200000L, (long) (byte) 0);
        int int19 = skipUndoDateTimeField13.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1567987200000L + "'", long18 == 1567987200000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
        org.joda.time.DateTime dateTime8 = dateTime4.withMillisOfDay(248);
        org.joda.time.DateTime dateTime10 = dateTime8.withMillis(0L);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfEra();
        try {
            org.joda.time.DateTime dateTime13 = property11.setCopy((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = unsupportedDateTimeField46.getType();
        try {
            long long49 = unsupportedDateTimeField46.roundCeiling(1560632397587L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long9 = offsetDateTimeField4.remainder(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay10, 0, locale12);
        int int15 = offsetDateTimeField4.getLeapAmount(1641427200000L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9936000000L + "'", long9 == 9936000000L);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
        int int31 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
        int int51 = offsetDateTimeField46.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
        int int72 = offsetDateTimeField67.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology74 = null;
        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
        int[] intArray83 = monthDay75.getValues();
        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
        java.util.Locale locale88 = null;
        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
        java.lang.String str91 = property90.getAsString();
        org.joda.time.MonthDay monthDay93 = property90.addWrapFieldToCopy((int) 'a');
        org.joda.time.MonthDay monthDay95 = property90.setCopy((int) (byte) 1);
        int int96 = property90.getMaximumValueOverall();
        java.lang.String str97 = property90.getAsText();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(copticChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
        org.junit.Assert.assertNotNull(monthDay73);
        org.junit.Assert.assertNotNull(monthDay75);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(monthDay86);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
        org.junit.Assert.assertNotNull(property90);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "4" + "'", str91.equals("4"));
        org.junit.Assert.assertNotNull(monthDay93);
        org.junit.Assert.assertNotNull(monthDay95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 31 + "'", int96 == 31);
        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "4" + "'", str97.equals("4"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean5 = dateTime3.isBefore(1L);
        org.joda.time.DateTime dateTime7 = dateTime3.withSecondOfMinute(0);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime3.getZone();
        org.joda.time.Chronology chronology9 = buddhistChronology0.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        boolean boolean15 = dateTime13.isBefore(1L);
        org.joda.time.DateTime dateTime17 = dateTime13.withSecondOfMinute(0);
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime13.getZone();
        int int19 = dateTime13.getCenturyOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str21 = gregorianChronology20.toString();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology24 = gregorianChronology20.withZone(dateTimeZone23);
        java.util.Locale locale26 = null;
        java.lang.String str27 = dateTimeZone23.getShortName(10L, locale26);
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone23);
        java.util.Locale locale30 = null;
        java.lang.String str31 = dateTimeZone23.getName((long) 31, locale30);
        org.joda.time.DateTime dateTime32 = dateTime13.withZoneRetainFields(dateTimeZone23);
        boolean boolean33 = buddhistChronology0.equals((java.lang.Object) dateTime13);
        try {
            org.joda.time.DateTime dateTime35 = dateTime13.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "GregorianChronology[UTC]" + "'", str21.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+32:00" + "'", str27.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+32:00" + "'", str31.equals("+32:00"));
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean5 = dateTime3.isBefore(1L);
        org.joda.time.DateTime dateTime7 = dateTime3.withSecondOfMinute(0);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime3.getZone();
        org.joda.time.Chronology chronology9 = buddhistChronology0.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology0.yearOfCentury();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        int int24 = offsetDateTimeField4.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) 10.0d, "");
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str32 = gregorianChronology31.toString();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology35 = gregorianChronology31.withZone(dateTimeZone34);
        org.joda.time.DurationField durationField36 = gregorianChronology31.hours();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField36);
        try {
            int int38 = unsupportedDateTimeField37.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyearOfCentury field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "GregorianChronology[UTC]" + "'", str32.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("100");
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        java.lang.String str10 = dateTimeZone7.getShortName((-1900800000L));
        org.joda.time.Chronology chronology11 = copticChronology3.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone7);
        java.lang.Object obj13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj13);
        long long15 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property18 = dateTime17.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        boolean boolean20 = dateTime12.isSupported(dateTimeFieldType19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType19, (int) 'a', 42);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder0.append(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+32:00" + "'", str10.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9936000000L + "'", long15 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
        java.lang.String str47 = unsupportedDateTimeField46.toString();
        org.joda.time.DurationField durationField48 = unsupportedDateTimeField46.getDurationField();
        try {
            long long51 = unsupportedDateTimeField46.set(1560632347355L, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(durationField48);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundFloor((long) 0);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getLeapDurationField();
        long long9 = delegatedDateTimeField4.roundHalfCeiling((long) (byte) 0);
        boolean boolean11 = delegatedDateTimeField4.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology12.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 10);
        int int19 = offsetDateTimeField16.getDifference(0L, 0L);
        int int21 = offsetDateTimeField16.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay22.withChronologyRetainFields(chronology23);
        int[] intArray30 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int31 = offsetDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) monthDay24, intArray30);
        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = copticChronology32.secondOfDay();
        org.joda.time.DateTimeField dateTimeField34 = copticChronology32.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 10);
        int int39 = offsetDateTimeField36.getDifference(0L, 0L);
        int int41 = offsetDateTimeField36.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay42 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.MonthDay monthDay44 = monthDay42.withChronologyRetainFields(chronology43);
        int[] intArray50 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int51 = offsetDateTimeField36.getMinimumValue((org.joda.time.ReadablePartial) monthDay44, intArray50);
        boolean boolean52 = monthDay24.isEqual((org.joda.time.ReadablePartial) monthDay44);
        org.joda.time.chrono.CopticChronology copticChronology53 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField54 = copticChronology53.secondOfDay();
        org.joda.time.DateTimeField dateTimeField55 = copticChronology53.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, 10);
        int int60 = offsetDateTimeField57.getDifference(0L, 0L);
        int int62 = offsetDateTimeField57.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay63 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology64 = null;
        org.joda.time.MonthDay monthDay65 = monthDay63.withChronologyRetainFields(chronology64);
        int[] intArray71 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int72 = offsetDateTimeField57.getMinimumValue((org.joda.time.ReadablePartial) monthDay65, intArray71);
        int[] intArray73 = monthDay65.getValues();
        int int74 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay44, intArray73);
        org.joda.time.MonthDay monthDay76 = monthDay44.plusDays((int) (short) 100);
        org.joda.time.ReadablePeriod readablePeriod77 = null;
        org.joda.time.MonthDay monthDay79 = monthDay44.withPeriodAdded(readablePeriod77, (int) (byte) 0);
        org.joda.time.ReadablePeriod readablePeriod80 = null;
        org.joda.time.MonthDay monthDay81 = monthDay44.minus(readablePeriod80);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 691200000L + "'", long9 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(copticChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(copticChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 11 + "'", int62 == 11);
        org.junit.Assert.assertNotNull(monthDay63);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(monthDay76);
        org.junit.Assert.assertNotNull(monthDay79);
        org.junit.Assert.assertNotNull(monthDay81);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("1970");
        java.lang.Appendable appendable2 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        boolean boolean7 = dateTime5.isBefore(1L);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime5);
        int int9 = dateTime5.getDayOfWeek();
        org.joda.time.DateTime dateTime11 = dateTime5.withEra((int) (byte) 1);
        try {
            dateTimeFormatter1.printTo(appendable2, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = unsupportedDateTimeField46.getType();
        org.joda.time.DurationField durationField48 = unsupportedDateTimeField46.getDurationField();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(durationField48);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "Property[weekOfWeekyear]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isBefore(1L);
        org.joda.time.DateTime dateTime6 = dateTime2.withSecondOfMinute(0);
        int int7 = dateTime2.getSecondOfMinute();
        org.joda.time.DateTime.Property property8 = dateTime2.monthOfYear();
        java.util.Locale locale9 = null;
        int int10 = property8.getMaximumTextLength(locale9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime1.plusDays(42);
        org.joda.time.DateTime.Property property11 = dateTime1.weekyear();
        org.joda.time.TimeOfDay timeOfDay12 = dateTime1.toTimeOfDay();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(timeOfDay12);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        long long11 = delegatedDateTimeField9.roundFloor((long) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField9);
        java.util.Locale locale14 = null;
        int int15 = delegatedDateTimeField9.getMaximumShortTextLength(locale14);
        long long18 = delegatedDateTimeField9.add((-31449599999L), 56);
        java.lang.String str19 = delegatedDateTimeField9.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1900800000L) + "'", long11 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 105148800001L + "'", long18 == 105148800001L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "monthOfYear" + "'", str19.equals("monthOfYear"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        java.lang.String str7 = dateTimeZone4.getShortName((-1900800000L));
        org.joda.time.Chronology chronology8 = copticChronology0.withZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str10 = gregorianChronology9.toString();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology13 = gregorianChronology9.withZone(dateTimeZone12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology14.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType17);
        long long20 = delegatedDateTimeField18.roundFloor((long) 0);
        org.joda.time.DurationField durationField21 = delegatedDateTimeField18.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        java.util.Locale locale23 = null;
        int int24 = delegatedDateTimeField18.getMaximumShortTextLength(locale23);
        long long27 = delegatedDateTimeField18.add((-31449599999L), 56);
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField(chronology8, (org.joda.time.DateTimeField) delegatedDateTimeField18);
        int int29 = skipDateTimeField28.getMinimumValue();
        long long32 = skipDateTimeField28.set((long) ' ', 11);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+32:00" + "'", str7.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[UTC]" + "'", str10.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1900800000L) + "'", long20 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 105148800001L + "'", long27 == 105148800001L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 18144000032L + "'", long32 == 18144000032L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.Locale locale2 = null;
        java.util.Calendar calendar3 = dateTime1.toCalendar(locale2);
        org.joda.time.DateTime dateTime5 = dateTime1.minusMillis(0);
        boolean boolean7 = dateTime1.isBefore((long) 44);
        org.joda.time.DateTime.Property property8 = dateTime1.centuryOfEra();
        boolean boolean9 = dateTime1.isEqualNow();
        java.lang.String str10 = dateTime1.toString();
        org.junit.Assert.assertNotNull(calendar3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970-04-27T08:00:00.000+32:00" + "'", str10.equals("1970-04-27T08:00:00.000+32:00"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property4 = dateTime2.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.withDurationAdded(readableDuration5, (int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime2.minusDays((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField4.getAsShortText((long) 20, locale9);
        java.lang.String str11 = offsetDateTimeField4.getName();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "97" + "'", str10.equals("97"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "weekyearOfCentury" + "'", str11.equals("weekyearOfCentury"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        long long6 = delegatedDateTimeField4.roundHalfCeiling((-1900800000L));
        long long8 = delegatedDateTimeField4.remainder((long) (short) 10);
        long long10 = delegatedDateTimeField4.roundHalfFloor((long) 999);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1900800000L) + "'", long6 == (-1900800000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1900800010L + "'", long8 == 1900800010L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 691200000L + "'", long10 == 691200000L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime5 = property3.roundFloorCopy();
        org.joda.time.DateTime dateTime7 = property3.addToCopy(0);
        org.joda.time.DateTime dateTime9 = property3.setCopy(1);
        boolean boolean10 = dateTime9.isBeforeNow();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone1.getShortName(0L, locale5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.Object obj9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(obj9);
        java.util.Locale locale11 = null;
        java.util.Calendar calendar12 = dateTime10.toCalendar(locale11);
        org.joda.time.DateTime dateTime14 = dateTime10.minusMillis(0);
        org.joda.time.ReadableInstant readableInstant15 = null;
        boolean boolean16 = dateTime10.isBefore(readableInstant15);
        int int17 = cachedDateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime10);
        long long20 = cachedDateTimeZone8.adjustOffset(0L, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+32:00" + "'", str6.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(calendar12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 115200000 + "'", int17 == 115200000);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withDefaultYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeFormatter8.getZone();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.append(dateTimePrinter5, dateTimeParser10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(786);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withLocale(locale15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.append(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property3.getAsShortText(locale5);
        org.joda.time.DateTime dateTime7 = property3.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "17" + "'", str6.equals("17"));
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("97", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"97/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (-33));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
        java.lang.String str47 = unsupportedDateTimeField46.toString();
        org.joda.time.DurationField durationField48 = unsupportedDateTimeField46.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = unsupportedDateTimeField46.getType();
        try {
            java.lang.String str51 = unsupportedDateTimeField46.getAsText((long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        try {
            long long10 = gJChronology5.getDateTimeMillis(248, 42, 17997, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 42 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        long long8 = delegatedDateTimeField6.roundFloor((long) 0);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField6.getLeapDurationField();
        long long11 = delegatedDateTimeField6.roundHalfCeiling((long) (byte) 0);
        boolean boolean13 = delegatedDateTimeField6.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology14.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 10);
        int int21 = offsetDateTimeField18.getDifference(0L, 0L);
        int int23 = offsetDateTimeField18.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.MonthDay monthDay26 = monthDay24.withChronologyRetainFields(chronology25);
        int[] intArray32 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int33 = offsetDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) monthDay26, intArray32);
        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = copticChronology34.secondOfDay();
        org.joda.time.DateTimeField dateTimeField36 = copticChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 10);
        int int41 = offsetDateTimeField38.getDifference(0L, 0L);
        int int43 = offsetDateTimeField38.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay44 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.MonthDay monthDay46 = monthDay44.withChronologyRetainFields(chronology45);
        int[] intArray52 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int53 = offsetDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray52);
        boolean boolean54 = monthDay26.isEqual((org.joda.time.ReadablePartial) monthDay46);
        org.joda.time.chrono.CopticChronology copticChronology55 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = copticChronology55.secondOfDay();
        org.joda.time.DateTimeField dateTimeField57 = copticChronology55.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField57, 10);
        int int62 = offsetDateTimeField59.getDifference(0L, 0L);
        int int64 = offsetDateTimeField59.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay65 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.MonthDay monthDay67 = monthDay65.withChronologyRetainFields(chronology66);
        int[] intArray73 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int74 = offsetDateTimeField59.getMinimumValue((org.joda.time.ReadablePartial) monthDay67, intArray73);
        int[] intArray75 = monthDay67.getValues();
        int int76 = delegatedDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray75);
        boolean boolean77 = copticChronology0.equals((java.lang.Object) delegatedDateTimeField6);
        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology80 = copticChronology0.withZone(dateTimeZone79);
        org.joda.time.DateTimeField dateTimeField81 = copticChronology0.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod82 = null;
        long long85 = copticChronology0.add(readablePeriod82, 1359310749216654L, 0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1900800000L) + "'", long8 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 691200000L + "'", long11 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 11 + "'", int33 == 11);
        org.junit.Assert.assertNotNull(copticChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 11 + "'", int43 == 11);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 11 + "'", int53 == 11);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(copticChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 11 + "'", int64 == 11);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertNotNull(monthDay67);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 11 + "'", int74 == 11);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(dateTimeZone79);
        org.junit.Assert.assertNotNull(chronology80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1359310749216654L + "'", long85 == 1359310749216654L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("7");
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(0L);
        org.joda.time.MonthDay monthDay3 = monthDay1.withDayOfMonth(10);
        try {
            java.lang.String str5 = monthDay1.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay3);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isBefore(1L);
        org.joda.time.DateTime dateTime6 = dateTime2.withSecondOfMinute(0);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime2.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime10 = null;
        boolean boolean11 = dateTimeZone9.isLocalDateTimeGap(localDateTime10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = dateTimeZone9.getShortName(0L, locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        long long18 = dateTimeZone7.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone16, 100L);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str21 = gregorianChronology20.toString();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.Chronology chronology24 = gregorianChronology20.withZone(dateTimeZone23);
        java.util.Locale locale26 = null;
        java.lang.String str27 = dateTimeZone23.getShortName(10L, locale26);
        org.joda.time.Chronology chronology28 = gJChronology19.withZone(dateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone29 = gJChronology19.getZone();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(dateTimeZone31);
        org.joda.time.DateTime.Property property33 = dateTime32.weekOfWeekyear();
        org.joda.time.DateTime dateTime34 = property33.getDateTime();
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, (org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime dateTime37 = dateTime34.minusMinutes(53);
        int int38 = cachedDateTimeZone16.getOffset((org.joda.time.ReadableInstant) dateTime37);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+32:00" + "'", str14.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-115199899L) + "'", long18 == (-115199899L));
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "GregorianChronology[UTC]" + "'", str21.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+32:00" + "'", str27.equals("+32:00"));
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 115200000 + "'", int38 == 115200000);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long4 = buddhistChronology0.add((long) (short) 1, 1560628897763L, 10);
        java.lang.Object obj5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj5);
        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime9 = dateTime6.withMillisOfDay((int) 'a');
        int int10 = dateTime6.getDayOfMonth();
        org.joda.time.DateTime dateTime12 = dateTime6.withDayOfYear((int) (byte) 1);
        java.lang.Object obj13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusDays((int) (short) 10);
        org.joda.time.LocalTime localTime17 = dateTime14.toLocalTime();
        int int18 = dateTime14.getEra();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime20 = dateTime14.plus(readableDuration19);
        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.ReadableDateTime) dateTime12, (org.joda.time.ReadableDateTime) dateTime20);
        org.joda.time.DateTime dateTime22 = limitChronology21.getLowerLimit();
        org.joda.time.MutableDateTime mutableDateTime23 = dateTime22.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 15606288977631L + "'", long4 == 15606288977631L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9936000000L + "'", long7 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 27 + "'", int10 == 27);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(limitChronology21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            long long5 = gJChronology0.getDateTimeMillis(837, (int) (byte) 0, (-691200), 54);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
        java.lang.String str47 = unsupportedDateTimeField46.toString();
        org.joda.time.DurationField durationField48 = unsupportedDateTimeField46.getDurationField();
        try {
            int int50 = unsupportedDateTimeField46.get((long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(durationField48);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone1.getShortName(0L, locale5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField8 = gregorianChronology7.days();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+32:00" + "'", str6.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("dayOfMonth", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: dayOfMonth");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = iSOChronology2.days();
        java.lang.String str4 = iSOChronology2.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[+32:00]" + "'", str4.equals("ISOChronology[+32:00]"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        long long9 = offsetDateTimeField4.remainder(0L);
        java.util.Locale locale12 = null;
        long long13 = offsetDateTimeField4.set((long) 10, "100", locale12);
        org.joda.time.DurationField durationField14 = offsetDateTimeField4.getDurationField();
        org.joda.time.DurationField durationField15 = offsetDateTimeField4.getLeapDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.util.Locale locale17 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withLocale(locale17);
        org.joda.time.LocalTime localTime20 = dateTimeFormatter18.parseLocalTime("1:58:55 PM");
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localTime20, 20, locale22);
        long long26 = offsetDateTimeField4.addWrapField(0L, (int) (short) 1);
        int int27 = offsetDateTimeField4.getMinimumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9936000000L + "'", long9 == 9936000000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 94953600010L + "'", long13 == 94953600010L);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(localTime20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "20" + "'", str23.equals("20"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 32054400000L + "'", long26 == 32054400000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 595, (java.lang.Number) 1560632347355L, (java.lang.Number) 1359310749216654L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withDefaultYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatter7.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter8, dateTimeParser9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeFormatter11.getZone();
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder3.append(dateTimePrinter8, dateTimeParser13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeFormatter15.getZone();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray18 = new org.joda.time.format.DateTimeParser[] { dateTimeParser17 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder0.append(dateTimePrinter8, dateTimeParserArray18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter20.withDefaultYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter23 = dateTimeFormatter22.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder19.append(dateTimePrinter23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder19.appendDayOfMonth((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimePrinter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeParserArray18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimePrinter23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        long long4 = buddhistChronology0.add((long) (short) 1, 1560628897763L, 10);
        java.lang.Object obj5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(obj5);
        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime9 = dateTime6.withMillisOfDay((int) 'a');
        int int10 = dateTime6.getDayOfMonth();
        org.joda.time.DateTime dateTime12 = dateTime6.withDayOfYear((int) (byte) 1);
        java.lang.Object obj13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusDays((int) (short) 10);
        org.joda.time.LocalTime localTime17 = dateTime14.toLocalTime();
        int int18 = dateTime14.getEra();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime20 = dateTime14.plus(readableDuration19);
        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.ReadableDateTime) dateTime12, (org.joda.time.ReadableDateTime) dateTime20);
        org.joda.time.DateTime.Property property22 = dateTime20.era();
        int int23 = dateTime20.getYear();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 15606288977631L + "'", long4 == 15606288977631L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9936000000L + "'", long7 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 27 + "'", int10 == 27);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(limitChronology21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1970 + "'", int23 == 1970);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        boolean boolean4 = property3.isLeap();
        java.lang.String str5 = property3.getAsString();
        org.joda.time.DateTime dateTime6 = property3.roundFloorCopy();
        int int7 = dateTime6.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17" + "'", str5.equals("17"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(0L);
        org.joda.time.MonthDay monthDay3 = monthDay1.withDayOfMonth(10);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.MonthDay monthDay5 = monthDay3.withChronologyRetainFields(chronology4);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(monthDay5);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        boolean boolean4 = property3.isLeap();
        java.lang.String str5 = property3.toString();
        org.joda.time.DateTime dateTime7 = property3.addToCopy((long) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[weekOfWeekyear]" + "'", str5.equals("Property[weekOfWeekyear]"));
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean4 = dateTime2.isAfter((-1L));
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTime2.toString("0", locale6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        java.lang.String str12 = dateTimeZone9.getShortName((-1900800000L));
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9, 1);
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime2.toMutableDateTime((org.joda.time.Chronology) julianChronology14);
        org.joda.time.DateMidnight dateMidnight16 = dateTime2.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+32:00" + "'", str12.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(dateMidnight16);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 999);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getShortName((-1900800000L));
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 1);
        java.lang.String str7 = julianChronology6.toString();
        org.joda.time.Chronology chronology8 = julianChronology6.withUTC();
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.secondOfDay();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology9.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType12);
        long long15 = delegatedDateTimeField13.roundFloor((long) 0);
        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getLeapDurationField();
        long long18 = delegatedDateTimeField13.roundHalfCeiling((long) (byte) 0);
        boolean boolean20 = delegatedDateTimeField13.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.secondOfDay();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology21.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, 10);
        int int28 = offsetDateTimeField25.getDifference(0L, 0L);
        int int30 = offsetDateTimeField25.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay31 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.MonthDay monthDay33 = monthDay31.withChronologyRetainFields(chronology32);
        int[] intArray39 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int40 = offsetDateTimeField25.getMinimumValue((org.joda.time.ReadablePartial) monthDay33, intArray39);
        org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField42 = copticChronology41.secondOfDay();
        org.joda.time.DateTimeField dateTimeField43 = copticChronology41.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, 10);
        int int48 = offsetDateTimeField45.getDifference(0L, 0L);
        int int50 = offsetDateTimeField45.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay51 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology52 = null;
        org.joda.time.MonthDay monthDay53 = monthDay51.withChronologyRetainFields(chronology52);
        int[] intArray59 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int60 = offsetDateTimeField45.getMinimumValue((org.joda.time.ReadablePartial) monthDay53, intArray59);
        boolean boolean61 = monthDay33.isEqual((org.joda.time.ReadablePartial) monthDay53);
        org.joda.time.chrono.CopticChronology copticChronology62 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField63 = copticChronology62.secondOfDay();
        org.joda.time.DateTimeField dateTimeField64 = copticChronology62.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField(dateTimeField64, 10);
        int int69 = offsetDateTimeField66.getDifference(0L, 0L);
        int int71 = offsetDateTimeField66.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay72 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology73 = null;
        org.joda.time.MonthDay monthDay74 = monthDay72.withChronologyRetainFields(chronology73);
        int[] intArray80 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int81 = offsetDateTimeField66.getMinimumValue((org.joda.time.ReadablePartial) monthDay74, intArray80);
        int[] intArray82 = monthDay74.getValues();
        int int83 = delegatedDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) monthDay53, intArray82);
        org.joda.time.MonthDay monthDay85 = monthDay53.plusDays((int) (short) 100);
        org.joda.time.chrono.ISOChronology iSOChronology86 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay87 = new org.joda.time.MonthDay((java.lang.Object) monthDay85, (org.joda.time.Chronology) iSOChronology86);
        org.joda.time.MonthDay monthDay89 = monthDay85.minusMonths((int) '#');
        int[] intArray91 = julianChronology6.get((org.joda.time.ReadablePartial) monthDay85, (long) 40);
        org.joda.time.DateTimeZone dateTimeZone92 = julianChronology6.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+32:00" + "'", str4.equals("+32:00"));
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "JulianChronology[+32:00,mdfw=1]" + "'", str7.equals("JulianChronology[+32:00,mdfw=1]"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1900800000L) + "'", long15 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 691200000L + "'", long18 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 11 + "'", int40 == 11);
        org.junit.Assert.assertNotNull(copticChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 11 + "'", int50 == 11);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(monthDay53);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 11 + "'", int60 == 11);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(copticChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 11 + "'", int71 == 11);
        org.junit.Assert.assertNotNull(monthDay72);
        org.junit.Assert.assertNotNull(monthDay74);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 11 + "'", int81 == 11);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertNotNull(monthDay85);
        org.junit.Assert.assertNotNull(iSOChronology86);
        org.junit.Assert.assertNotNull(monthDay89);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertNotNull(dateTimeZone92);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone1.getShortName(0L, locale5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        int int11 = cachedDateTimeZone8.getStandardOffset(5556109277296800L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+32:00" + "'", str6.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 115200000 + "'", int11 == 115200000);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone1.getShortName(0L, locale5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int10 = cachedDateTimeZone8.getStandardOffset((long) 1969);
        java.lang.String str12 = cachedDateTimeZone8.getNameKey(0L);
        org.joda.time.DateTimeZone dateTimeZone13 = cachedDateTimeZone8.getUncachedZone();
        java.util.Locale locale15 = null;
        java.lang.String str16 = cachedDateTimeZone8.getName((-3599947L), locale15);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+32:00" + "'", str6.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 115200000 + "'", int10 == 115200000);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+32:00" + "'", str16.equals("+32:00"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        java.lang.String str9 = offsetDateTimeField4.getAsText(1560632313085L);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        long long16 = delegatedDateTimeField14.roundFloor((long) 0);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getLeapDurationField();
        long long19 = delegatedDateTimeField14.roundHalfCeiling((long) (byte) 0);
        boolean boolean21 = delegatedDateTimeField14.isLeap((long) '#');
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.secondOfDay();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 10);
        int int29 = offsetDateTimeField26.getDifference(0L, 0L);
        int int31 = offsetDateTimeField26.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.MonthDay monthDay34 = monthDay32.withChronologyRetainFields(chronology33);
        int[] intArray40 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int41 = offsetDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.chrono.CopticChronology copticChronology42 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = copticChronology42.secondOfDay();
        org.joda.time.DateTimeField dateTimeField44 = copticChronology42.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 10);
        int int49 = offsetDateTimeField46.getDifference(0L, 0L);
        int int51 = offsetDateTimeField46.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.MonthDay monthDay54 = monthDay52.withChronologyRetainFields(chronology53);
        int[] intArray60 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int61 = offsetDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray60);
        boolean boolean62 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay54);
        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.secondOfDay();
        org.joda.time.DateTimeField dateTimeField65 = copticChronology63.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 10);
        int int70 = offsetDateTimeField67.getDifference(0L, 0L);
        int int72 = offsetDateTimeField67.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology74 = null;
        org.joda.time.MonthDay monthDay75 = monthDay73.withChronologyRetainFields(chronology74);
        int[] intArray81 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int82 = offsetDateTimeField67.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
        int[] intArray83 = monthDay75.getValues();
        int int84 = delegatedDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay54, intArray83);
        org.joda.time.MonthDay monthDay86 = monthDay54.plusDays((int) (short) 100);
        java.util.Locale locale88 = null;
        java.lang.String str89 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay86, 10, locale88);
        org.joda.time.MonthDay.Property property90 = monthDay86.dayOfMonth();
        java.lang.String str91 = property90.getAsString();
        org.joda.time.MonthDay monthDay93 = property90.addWrapFieldToCopy((int) 'a');
        org.joda.time.MonthDay monthDay95 = property90.setCopy((int) (byte) 1);
        int int96 = property90.getMaximumValue();
        int int97 = property90.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "46" + "'", str9.equals("46"));
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1900800000L) + "'", long16 == (-1900800000L));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 691200000L + "'", long19 == 691200000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 11 + "'", int31 == 11);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 11 + "'", int41 == 11);
        org.junit.Assert.assertNotNull(copticChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 11 + "'", int61 == 11);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(copticChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 11 + "'", int72 == 11);
        org.junit.Assert.assertNotNull(monthDay73);
        org.junit.Assert.assertNotNull(monthDay75);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 11 + "'", int82 == 11);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(monthDay86);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
        org.junit.Assert.assertNotNull(property90);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "4" + "'", str91.equals("4"));
        org.junit.Assert.assertNotNull(monthDay93);
        org.junit.Assert.assertNotNull(monthDay95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 31 + "'", int96 == 31);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 1 + "'", int97 == 1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        java.lang.Object obj2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj2);
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime6 = dateTime3.withMillisOfDay((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType8, (int) (short) 100, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfHour((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMillisOfSecond(44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder14.appendFractionOfMinute(31, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendTwoDigitWeekyear(3, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9936000000L + "'", long4 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone1.getShortName(0L, locale5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long12 = cachedDateTimeZone8.convertLocalToUTC(0L, false, (long) 1969);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+32:00" + "'", str6.equals("+32:00"));
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-115200000L) + "'", long12 == (-115200000L));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 10);
        int int7 = offsetDateTimeField4.getDifference(0L, 0L);
        int int9 = offsetDateTimeField4.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MonthDay monthDay12 = monthDay10.withChronologyRetainFields(chronology11);
        int[] intArray18 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int19 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay12, intArray18);
        long long22 = offsetDateTimeField4.add((long) (short) 1, (int) (short) -1);
        long long24 = offsetDateTimeField4.roundFloor(1567987200000L);
        boolean boolean25 = offsetDateTimeField4.isLenient();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31449599999L) + "'", long22 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1567987200000L + "'", long24 == 1567987200000L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        java.lang.Object obj8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(obj8);
        int int10 = dateTime9.getMillisOfSecond();
        boolean boolean11 = dateTime7.equals((java.lang.Object) dateTime9);
        int int12 = dateTime7.getSecondOfMinute();
        java.lang.Object obj13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj13);
        java.util.GregorianCalendar gregorianCalendar15 = dateTime14.toGregorianCalendar();
        org.joda.time.DateTime.Property property16 = dateTime14.dayOfYear();
        org.joda.time.DateTime dateTime17 = property16.roundFloorCopy();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.withChronology(chronology18);
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime7, (org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter21.withDefaultYear(0);
        java.lang.Object obj24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(obj24);
        java.util.GregorianCalendar gregorianCalendar26 = dateTime25.toGregorianCalendar();
        org.joda.time.DateTime.Property property27 = dateTime25.dayOfYear();
        org.joda.time.DateTime dateTime28 = property27.getDateTime();
        java.lang.String str29 = dateTimeFormatter23.print((org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.DateTime.Property property30 = dateTime28.year();
        org.joda.time.chrono.CopticChronology copticChronology31 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = copticChronology31.secondOfDay();
        org.joda.time.DateTimeField dateTimeField33 = copticChronology31.secondOfDay();
        boolean boolean35 = copticChronology31.equals((java.lang.Object) 9936000000L);
        org.joda.time.DateTime dateTime36 = dateTime28.toDateTime((org.joda.time.Chronology) copticChronology31);
        org.joda.time.DateTime dateTime38 = dateTime36.withMillisOfSecond(334);
        int int39 = dateTime7.compareTo((org.joda.time.ReadableInstant) dateTime36);
        org.joda.time.DateTime.Property property40 = dateTime36.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(gregorianCalendar15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(gregorianCalendar26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "8:00:00 AM" + "'", str29.equals("8:00:00 AM"));
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(copticChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(property40);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        java.util.GregorianCalendar gregorianCalendar2 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) 'a');
        org.joda.time.DateTime dateTime8 = dateTime4.withMillisOfDay(248);
        org.joda.time.DateTime dateTime10 = dateTime8.withMillis(0L);
        int int11 = dateTime10.getDayOfYear();
        org.joda.time.DateTime dateTime13 = dateTime10.plusYears(6);
        org.joda.time.DateTime dateTime15 = dateTime13.plusMonths(110);
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField9.getAsText(readablePartial10, (int) (byte) 100, locale12);
        boolean boolean14 = delegatedDateTimeField9.isLenient();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = delegatedDateTimeField9.getType();
        org.joda.time.DateTime.Property property16 = dateTime4.property(dateTimeFieldType15);
        org.joda.time.DurationField durationField17 = property16.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(obj0);
        long long2 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay((int) 'a');
        int int5 = dateTime1.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear((int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = copticChronology10.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 10);
        int int17 = offsetDateTimeField14.getDifference(0L, 0L);
        int int19 = offsetDateTimeField14.getMinimumValue(0L);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.withChronologyRetainFields(chronology21);
        int[] intArray28 = new int[] { (short) -1, 10, 'a', (byte) 100, 10 };
        int int29 = offsetDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay22, intArray28);
        long long32 = offsetDateTimeField14.add((long) (short) 1, (int) (short) -1);
        int int34 = offsetDateTimeField14.getLeapAmount((long) 110);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "2017-08-05T13:58:49.048-07:00");
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = iSOChronology40.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.monthOfYear();
        org.joda.time.DurationField durationField44 = buddhistChronology42.hours();
        org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType35, durationField41, durationField44);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField44);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = unsupportedDateTimeField46.getType();
        try {
            long long49 = unsupportedDateTimeField46.roundHalfCeiling(1560632386848L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9936000000L + "'", long2 == 9936000000L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 11 + "'", int19 == 11);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-31449599999L) + "'", long32 == (-31449599999L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
    }
}

