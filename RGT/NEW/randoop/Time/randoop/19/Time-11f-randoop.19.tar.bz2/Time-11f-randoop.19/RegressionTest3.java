import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test01");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply(324000000000L, (-8262829895193344276L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 324000000000 * -8262829895193344276");
        } catch (java.lang.ArithmeticException e) {
        }
    }

//    @Test
//    public void test02() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test02");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        long long14 = offsetDateTimeField7.set(1560628667826L, (int) 'a');
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField7.getAsText((long) (short) 100, locale16);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField7.getDurationField();
//        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField7.getWrappedField();
//        long long22 = offsetDateTimeField7.addWrapField((-62072697599999L), (int) (short) 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField7.getType();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-00:00:00.001" + "'", str3.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259199999L) + "'", long11 == (-259199999L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62152632132174L) + "'", long14 == (-62152632132174L));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2067" + "'", str17.equals("2067"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62041247999999L) + "'", long22 == (-62041247999999L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//    }

//    @Test
//    public void test03() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test03");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.hourOfHalfday();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-00:00:00.001" + "'", str3.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test04");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.minutes();
        try {
            long long8 = gregorianChronology2.getDateTimeMillis((int) 'a', 93956, (-6), (-253143653));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -253143653 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test05");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period2.withMinutes((int) (short) 10);
        org.joda.time.Period period8 = period6.withHours((int) (short) 1);
        int int9 = period8.getMinutes();
        org.joda.time.Period period11 = period8.plusMillis((int) ' ');
        org.joda.time.DurationFieldType durationFieldType13 = period11.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField15 = new org.joda.time.field.PreciseDurationField(durationFieldType13, 1234826687606400003L);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField16 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType13);
        boolean boolean17 = unsupportedDurationField16.isPrecise();
        boolean boolean18 = unsupportedDurationField16.isSupported();
        boolean boolean19 = unsupportedDurationField16.isSupported();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertNotNull(unsupportedDurationField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

//    @Test
//    public void test06() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test06");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        boolean boolean12 = offsetDateTimeField7.isLeap((long) 4);
//        long long14 = offsetDateTimeField7.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField7.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, (int) (short) 1, (int) (short) 1, (int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long26 = gregorianChronology20.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology20.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology20.minuteOfHour();
//        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DurationField durationField30 = gregorianChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField30);
//        boolean boolean32 = unsupportedDateTimeField31.isSupported();
//        long long35 = unsupportedDateTimeField31.add((-62152628954174L), (-18469900L));
//        org.joda.time.DurationField durationField36 = unsupportedDateTimeField31.getRangeDurationField();
//        java.lang.String str37 = unsupportedDateTimeField31.toString();
//        long long40 = unsupportedDateTimeField31.getDifferenceAsLong(0L, 96L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-00:00:00.001" + "'", str3.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259199999L) + "'", long14 == (-259199999L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 39130101L + "'", long26 == 39130101L);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-582915900222554174L) + "'", long35 == (-582915900222554174L));
//        org.junit.Assert.assertNull(durationField36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "UnsupportedDateTimeField" + "'", str37.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//    }

//    @Test
//    public void test07() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test07");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.lang.String str7 = dateTimeZone5.getName(0L);
//        java.lang.String str9 = dateTimeZone5.getName((long) '4');
//        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone5);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
//        org.joda.time.Chronology chronology16 = iSOChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        long long18 = fixedDateTimeZone15.convertUTCToLocal((long) (short) 0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        int int21 = cachedDateTimeZone19.getStandardOffset(2440588L);
//        int int23 = cachedDateTimeZone19.getOffset(0L);
//        long long25 = cachedDateTimeZone19.previousTransition(3818402150390975528L);
//        boolean boolean26 = cachedDateTimeZone19.isFixed();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-00:00:00.001" + "'", str7.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-00:00:00.001" + "'", str9.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 3818402150390975528L + "'", long25 == 3818402150390975528L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test08");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfWeek();
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant2, readableInstant3);
        org.joda.time.Period period6 = period4.minusMinutes(0);
        org.joda.time.Period period8 = period4.minusSeconds(262);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, chronology10);
        org.joda.time.Period period13 = period11.withSeconds((int) (short) 10);
        org.joda.time.Period period15 = period11.withMinutes((int) (short) 10);
        org.joda.time.Period period17 = period15.withHours((int) (short) 1);
        org.joda.time.Duration duration18 = period17.toStandardDuration();
        org.joda.time.DurationFieldType[] durationFieldTypeArray19 = period17.getFieldTypes();
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.forFields(durationFieldTypeArray19);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        boolean boolean22 = periodType20.isSupported(durationFieldType21);
        org.joda.time.PeriodType periodType23 = periodType20.withDaysRemoved();
        org.joda.time.Period period24 = period4.normalizedStandard(periodType23);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant26, readableDuration27);
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period((java.lang.Object) period28, periodType29, chronology30);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField33 = gregorianChronology32.millis();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.secondOfDay();
        org.joda.time.Period period35 = new org.joda.time.Period((-1L), periodType29, (org.joda.time.Chronology) gregorianChronology32);
        try {
            org.joda.time.Period period36 = new org.joda.time.Period((java.lang.Object) iSOChronology0, periodType23, (org.joda.time.Chronology) gregorianChronology32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertNotNull(durationFieldTypeArray19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
    }

//    @Test
//    public void test09() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test09");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.yearOfCentury();
//        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearDay();
//        org.joda.time.PeriodType periodType9 = periodType8.withWeeksRemoved();
//        try {
//            org.joda.time.Period period10 = new org.joda.time.Period((java.lang.Object) dateTimeField7, periodType9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130101L + "'", long6 == 39130101L);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(periodType8);
//        org.junit.Assert.assertNotNull(periodType9);
//    }

//    @Test
//    public void test10() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test10");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.lang.String str7 = dateTimeZone5.getName(0L);
//        java.lang.String str9 = dateTimeZone5.getName((long) '4');
//        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone5);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
//        org.joda.time.Chronology chronology16 = iSOChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        long long18 = fixedDateTimeZone15.convertUTCToLocal((long) (short) 0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        boolean boolean20 = fixedDateTimeZone15.isFixed();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-00:00:00.001" + "'", str7.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-00:00:00.001" + "'", str9.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test11");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-900), 2067, (-900), 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-635) + "'", int4 == (-635));
    }

//    @Test
//    public void test12() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test12");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.lang.String str9 = offsetDateTimeField7.getAsText((long) (byte) 100);
//        long long12 = offsetDateTimeField7.add(28800000L, (long) 8);
//        long long14 = offsetDateTimeField7.roundHalfFloor((-210866673600000L));
//        boolean boolean16 = offsetDateTimeField7.isLeap(17040844799418L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-00:00:00.001" + "'", str3.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2067" + "'", str9.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 252835200000L + "'", long12 == 252835200000L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-210863779199999L) + "'", long14 == (-210863779199999L));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test13");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        boolean boolean12 = offsetDateTimeField7.isLeap((long) 4);
//        long long14 = offsetDateTimeField7.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField7.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, (int) (short) 1, (int) (short) 1, (int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long26 = gregorianChronology20.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology20.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology20.minuteOfHour();
//        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DurationField durationField30 = gregorianChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField30);
//        boolean boolean32 = unsupportedDateTimeField31.isSupported();
//        long long35 = unsupportedDateTimeField31.add((-62152628954174L), (-18469900L));
//        org.joda.time.DurationField durationField36 = unsupportedDateTimeField31.getRangeDurationField();
//        long long39 = unsupportedDateTimeField31.add(31795200001L, 0);
//        try {
//            long long41 = unsupportedDateTimeField31.roundHalfCeiling((long) 156520400);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-00:00:00.001" + "'", str3.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259199999L) + "'", long14 == (-259199999L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 39130101L + "'", long26 == 39130101L);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-582915900222554174L) + "'", long35 == (-582915900222554174L));
//        org.junit.Assert.assertNull(durationField36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 31795200001L + "'", long39 == 31795200001L);
//    }

//    @Test
//    public void test14() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test14");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        long long14 = offsetDateTimeField7.set(1560628667826L, (int) 'a');
//        java.lang.String str15 = offsetDateTimeField7.toString();
//        long long17 = offsetDateTimeField7.roundHalfCeiling((long) (short) 1);
//        int int20 = offsetDateTimeField7.getDifference((long) (byte) 0, (long) (byte) 10);
//        org.joda.time.DurationField durationField21 = offsetDateTimeField7.getLeapDurationField();
//        long long24 = offsetDateTimeField7.add(6681L, 0L);
//        long long26 = offsetDateTimeField7.roundHalfCeiling(1560628667826L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-00:00:00.001" + "'", str3.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259199999L) + "'", long11 == (-259199999L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62152632132174L) + "'", long14 == (-62152632132174L));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[weekyear]" + "'", str15.equals("DateTimeField[weekyear]"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-259199999L) + "'", long17 == (-259199999L));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 6681L + "'", long24 == 6681L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546214400001L + "'", long26 == 1546214400001L);
//    }

//    @Test
//    public void test15() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test15");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
//        org.joda.time.DurationField durationField9 = gregorianChronology0.centuries();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130101L + "'", long6 == 39130101L);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(durationField9);
//    }

//    @Test
//    public void test16() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test16");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        long long9 = offsetDateTimeField7.roundHalfCeiling((long) (byte) -1);
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        int[] intArray13 = new int[] { (-1), 292279090 };
//        int int14 = offsetDateTimeField7.getMinimumValue(readablePartial10, intArray13);
//        java.lang.String str15 = offsetDateTimeField7.getName();
//        org.joda.time.DurationField durationField16 = offsetDateTimeField7.getDurationField();
//        java.util.TimeZone timeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        java.lang.String str20 = dateTimeZone18.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) 'a');
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = offsetDateTimeField24.getAsShortText((long) (byte) 1, locale26);
//        boolean boolean29 = offsetDateTimeField24.isLeap((long) 4);
//        long long31 = offsetDateTimeField24.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField24.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, (java.lang.Number) (-68260881600000L), (java.lang.Number) (-18469900L), (java.lang.Number) 1.0d);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, (java.lang.Number) 28800000L, "PeriodType[Time]");
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType32, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-00:00:00.001" + "'", str3.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259199999L) + "'", long9 == (-259199999L));
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292274957) + "'", int14 == (-292274957));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "weekyear" + "'", str15.equals("weekyear"));
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2067" + "'", str27.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-259199999L) + "'", long31 == (-259199999L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test17");
        org.joda.time.Period period1 = org.joda.time.Period.millis((-635));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test18");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.minutes();
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology2);
        java.lang.String str5 = lenientChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology4.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[GregorianChronology[America/Los_Angeles,mdfw=1]]" + "'", str5.equals("LenientChronology[GregorianChronology[America/Los_Angeles,mdfw=1]]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test19");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.days();
        java.lang.String str1 = periodType0.getName();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType3 = periodType2.withDaysRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period6.toDurationTo(readableInstant7);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, chronology10);
        org.joda.time.Period period12 = period6.withFields((org.joda.time.ReadablePeriod) period11);
        org.joda.time.Weeks weeks13 = period11.toStandardWeeks();
        org.joda.time.Period period15 = org.joda.time.Period.hours(1000);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) -1, chronology17);
        org.joda.time.Period period20 = period18.withSeconds((int) (short) 10);
        org.joda.time.Period period22 = period18.withMinutes((int) (short) 10);
        org.joda.time.Period period24 = period22.withHours((int) (short) 1);
        int int25 = period24.getMinutes();
        org.joda.time.Period period27 = period24.plusMillis((int) ' ');
        org.joda.time.DurationFieldType durationFieldType29 = period27.getFieldType(0);
        org.joda.time.Period period31 = period15.withField(durationFieldType29, (-1000));
        int int32 = period11.get(durationFieldType29);
        int int33 = periodType2.indexOf(durationFieldType29);
        boolean boolean34 = periodType0.isSupported(durationFieldType29);
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.Period period37 = new org.joda.time.Period((long) (short) -1, chronology36);
        org.joda.time.Period period39 = period37.withSeconds((int) (short) 10);
        org.joda.time.Period period41 = period37.withMinutes((int) (short) 10);
        org.joda.time.Period period43 = period41.withMonths(0);
        org.joda.time.Period period45 = period41.withHours((int) (byte) -1);
        int int46 = period41.getSeconds();
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.Period period49 = new org.joda.time.Period((long) (short) -1, chronology48);
        org.joda.time.Period period51 = period49.withSeconds((int) (short) 10);
        org.joda.time.Period period53 = period49.withMinutes((int) (short) 10);
        org.joda.time.Period period55 = period53.withHours((int) (short) 1);
        int int56 = period55.getMinutes();
        org.joda.time.Period period58 = period55.plusMillis((int) ' ');
        org.joda.time.DurationFieldType durationFieldType60 = period58.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField62 = new org.joda.time.field.PreciseDurationField(durationFieldType60, 1234826687606400003L);
        int int63 = period41.indexOf(durationFieldType60);
        boolean boolean64 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType0, (java.lang.Object) durationFieldType60);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Days" + "'", str1.equals("Days"));
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(weeks13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(durationFieldType29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 10 + "'", int56 == 10);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test20");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period2.withMinutes((int) (short) 10);
        org.joda.time.Period period8 = period6.withHours((int) (short) 1);
        int int9 = period8.getMinutes();
        org.joda.time.Period period11 = period8.plusMillis((int) ' ');
        org.joda.time.DurationFieldType durationFieldType13 = period11.getFieldType(0);
        org.joda.time.field.PreciseDurationField preciseDurationField15 = new org.joda.time.field.PreciseDurationField(durationFieldType13, 1234826687606400003L);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField16 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType13);
        boolean boolean17 = unsupportedDurationField16.isSupported();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (short) -1, chronology19);
        org.joda.time.Period period22 = period20.withSeconds((int) (short) 10);
        org.joda.time.Period period24 = period22.withMinutes((int) (byte) 1);
        org.joda.time.Period period26 = period24.plusDays(0);
        org.joda.time.Period period27 = period24.normalizedStandard();
        boolean boolean28 = unsupportedDurationField16.equals((java.lang.Object) period24);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertNotNull(unsupportedDurationField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test21");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.Period period14 = new org.joda.time.Period((long) (short) -1, chronology13);
//        org.joda.time.Period period16 = period14.withSeconds((int) (short) 10);
//        org.joda.time.Period period18 = period16.withMinutes((int) (byte) 1);
//        int[] intArray19 = period16.getValues();
//        int int20 = offsetDateTimeField7.getMinimumValue(readablePartial11, intArray19);
//        long long22 = offsetDateTimeField7.roundHalfFloor(3061238400001L);
//        java.lang.String str23 = offsetDateTimeField7.getName();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-00:00:00.001" + "'", str3.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292274957) + "'", int20 == (-292274957));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 3061238400001L + "'", long22 == 3061238400001L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "weekyear" + "'", str23.equals("weekyear"));
//    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test22");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) '#');
        org.joda.time.Period period3 = org.joda.time.Period.hours(1000);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) -1, chronology5);
        org.joda.time.Period period8 = period6.withSeconds((int) (short) 10);
        org.joda.time.Period period10 = period6.withMinutes((int) (short) 10);
        org.joda.time.Period period12 = period10.withHours((int) (short) 1);
        int int13 = period12.getMinutes();
        org.joda.time.Period period15 = period12.plusMillis((int) ' ');
        org.joda.time.DurationFieldType durationFieldType17 = period15.getFieldType(0);
        org.joda.time.Period period19 = period3.withField(durationFieldType17, (-1000));
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(durationFieldType17, "");
        org.joda.time.Period period23 = period1.withField(durationFieldType17, (-635));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period23);
    }

//    @Test
//    public void test23() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test23");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        long long12 = offsetDateTimeField7.roundCeiling((long) (byte) -1);
//        java.lang.String str13 = offsetDateTimeField7.toString();
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField7.getAsText(readablePartial14, (int) (byte) 100, locale16);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField7.getLeapDurationField();
//        int int20 = offsetDateTimeField7.getMaximumValue(252835200000L);
//        org.joda.time.ReadablePartial readablePartial21 = null;
//        int int22 = offsetDateTimeField7.getMaximumValue(readablePartial21);
//        long long25 = offsetDateTimeField7.add(1529179066035L, (long) (short) 100);
//        long long27 = offsetDateTimeField7.roundCeiling(230400000L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-00:00:00.001" + "'", str3.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31795200001L + "'", long12 == 31795200001L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[weekyear]" + "'", str13.equals("DateTimeField[weekyear]"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 292279090 + "'", int20 == 292279090);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292279090 + "'", int22 == 292279090);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 4685025466035L + "'", long25 == 4685025466035L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 31795200001L + "'", long27 == 31795200001L);
//    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test24");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, chronology6);
        org.joda.time.Period period8 = period2.withFields((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Duration duration9 = period2.toStandardDuration();
        org.joda.time.Period period11 = period2.minusYears(28800000);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test25");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(1560628667826L);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        long long10 = fixedDateTimeZone4.nextTransition((long) (short) 0);
        int int12 = fixedDateTimeZone4.getOffset((long) '4');
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableInstant13, readableDuration14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((java.lang.Object) period15, periodType16, chronology17);
        org.joda.time.PeriodType periodType19 = periodType16.withYearsRemoved();
        org.joda.time.PeriodType periodType20 = periodType16.withMillisRemoved();
        org.joda.time.PeriodType periodType21 = periodType20.withHoursRemoved();
        org.joda.time.PeriodType periodType22 = periodType20.withMillisRemoved();
        boolean boolean23 = fixedDateTimeZone4.equals((java.lang.Object) periodType20);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.util.TimeZone timeZone26 = dateTimeZone25.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forTimeZone(timeZone26);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
        long long30 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone27, (long) 97);
        java.lang.String str31 = dateTimeZone27.getID();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 96L + "'", long30 == 96L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UTC" + "'", str31.equals("UTC"));
    }

//    @Test
//    public void test26() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test26");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        java.lang.String str11 = dateTimeZone10.getID();
//        long long14 = dateTimeZone10.adjustOffset((long) (byte) 0, true);
//        java.util.TimeZone timeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
//        long long18 = dateTimeZone10.getMillisKeepLocal(dateTimeZone16, (long) 4);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone10);
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
//        org.joda.time.ReadableInstant readableInstant22 = null;
//        org.joda.time.ReadableDuration readableDuration23 = null;
//        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
//        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.seconds();
//        org.joda.time.Chronology chronology26 = null;
//        org.joda.time.Period period27 = new org.joda.time.Period((java.lang.Object) period24, periodType25, chronology26);
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField29 = gregorianChronology28.millis();
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.secondOfDay();
//        org.joda.time.Period period31 = new org.joda.time.Period((-1L), periodType25, (org.joda.time.Chronology) gregorianChronology28);
//        org.joda.time.Period period33 = period31.plusSeconds((int) (short) 100);
//        long long36 = zonedChronology20.add((org.joda.time.ReadablePeriod) period33, 96L, 0);
//        org.joda.time.DateTimeField dateTimeField37 = zonedChronology20.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone38 = zonedChronology20.getZone();
//        long long41 = dateTimeZone38.adjustOffset((-5400L), false);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130101L + "'", long6 == 39130101L);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4L + "'", long18 == 4L);
//        org.junit.Assert.assertNotNull(zonedChronology20);
//        org.junit.Assert.assertNotNull(periodType25);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 96L + "'", long36 == 96L);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-5400L) + "'", long41 == (-5400L));
//    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test27");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period4.withMinutes((int) (byte) 1);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.Period period10 = period6.minusWeeks((-292274957));
        org.joda.time.Period period12 = period6.withDays(0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test28");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("-1", (java.lang.Number) 1001L, (java.lang.Number) 1560628666035L, (java.lang.Number) 1001L);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test29() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test29");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        boolean boolean12 = offsetDateTimeField7.isLeap((long) 4);
//        long long14 = offsetDateTimeField7.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField7.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, (int) (short) 1, (int) (short) 1, (int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long26 = gregorianChronology20.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology20.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology20.minuteOfHour();
//        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DurationField durationField30 = gregorianChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField30);
//        boolean boolean32 = unsupportedDateTimeField31.isSupported();
//        long long35 = unsupportedDateTimeField31.add((-62152628954174L), (-18469900L));
//        org.joda.time.DurationField durationField36 = unsupportedDateTimeField31.getRangeDurationField();
//        try {
//            int int38 = unsupportedDateTimeField31.getLeapAmount((-32399991L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-00:00:00.001" + "'", str3.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259199999L) + "'", long14 == (-259199999L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 39130101L + "'", long26 == 39130101L);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-582915900222554174L) + "'", long35 == (-582915900222554174L));
//        org.junit.Assert.assertNull(durationField36);
//    }

//    @Test
//    public void test30() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test30");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        int int12 = offsetDateTimeField7.getLeapAmount((long) (-1));
//        long long14 = offsetDateTimeField7.roundHalfCeiling((long) (short) 10);
//        long long16 = offsetDateTimeField7.roundCeiling(36L);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, (int) ' ');
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        java.lang.String str22 = dateTimeZone20.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
//        java.lang.String str28 = offsetDateTimeField26.getAsText((long) (byte) 100);
//        long long30 = offsetDateTimeField26.roundCeiling((-18469900L));
//        org.joda.time.ReadablePartial readablePartial31 = null;
//        int int32 = offsetDateTimeField26.getMinimumValue(readablePartial31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = offsetDateTimeField26.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType33, (-253143653));
//        org.joda.time.DurationField durationField36 = offsetDateTimeField35.getDurationField();
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = offsetDateTimeField35.getAsShortText(1000, locale38);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-00:00:00.001" + "'", str3.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259199999L) + "'", long14 == (-259199999L));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 31795200001L + "'", long16 == 31795200001L);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-00:00:00.001" + "'", str22.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2067" + "'", str28.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31795200001L + "'", long30 == 31795200001L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-292274957) + "'", int32 == (-292274957));
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1000" + "'", str39.equals("1000"));
//    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test31");
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period7.toDurationTo(readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((java.lang.Object) period14, periodType15, chronology16);
        org.joda.time.PeriodType periodType18 = periodType15.withYearsRemoved();
        org.joda.time.PeriodType periodType19 = periodType18.withSecondsRemoved();
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant4, (org.joda.time.ReadableDuration) duration9, periodType18);
        org.joda.time.Period period21 = new org.joda.time.Period((long) 10, 0L, periodType18);
        org.joda.time.Period period22 = new org.joda.time.Period(32054400001L, 189302400010L, periodType18);
        org.joda.time.PeriodType periodType23 = periodType18.withMonthsRemoved();
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType23);
    }

//    @Test
//    public void test32() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test32");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.yearOfEra();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-00:00:00.001" + "'", str3.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//    }

//    @Test
//    public void test33() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test33");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        boolean boolean12 = offsetDateTimeField7.isLeap((long) 4);
//        long long14 = offsetDateTimeField7.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField7.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, (int) (short) 1, (int) (short) 1, (int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long26 = gregorianChronology20.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology20.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology20.minuteOfHour();
//        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DurationField durationField30 = gregorianChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField30);
//        boolean boolean32 = unsupportedDateTimeField31.isSupported();
//        long long35 = unsupportedDateTimeField31.add((-62152628954174L), (-18469900L));
//        org.joda.time.DurationField durationField36 = unsupportedDateTimeField31.getRangeDurationField();
//        java.lang.String str37 = unsupportedDateTimeField31.toString();
//        org.joda.time.ReadablePartial readablePartial38 = null;
//        java.util.Locale locale39 = null;
//        try {
//            java.lang.String str40 = unsupportedDateTimeField31.getAsShortText(readablePartial38, locale39);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-00:00:00.001" + "'", str3.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259199999L) + "'", long14 == (-259199999L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 39130101L + "'", long26 == 39130101L);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-582915900222554174L) + "'", long35 == (-582915900222554174L));
//        org.junit.Assert.assertNull(durationField36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "UnsupportedDateTimeField" + "'", str37.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test34");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("(\"org.joda.time.JodaTimePermission\" \"PT1M9.999S\")", (int) '4');
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("LenientChronology[GregorianChronology[UTC]]", true);
        java.io.OutputStream outputStream8 = null;
        try {
            dateTimeZoneBuilder0.writeTo("1", outputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

//    @Test
//    public void test35() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test35");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.lang.String str7 = dateTimeZone5.getName(0L);
//        java.lang.String str9 = dateTimeZone5.getName((long) '4');
//        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone5);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
//        org.joda.time.Chronology chronology16 = iSOChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        long long18 = fixedDateTimeZone15.convertUTCToLocal((long) (short) 0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        int int21 = cachedDateTimeZone19.getStandardOffset(2440588L);
//        long long23 = cachedDateTimeZone19.previousTransition((long) (-253144762));
//        boolean boolean24 = cachedDateTimeZone19.isFixed();
//        long long26 = cachedDateTimeZone19.previousTransition(252547200000L);
//        org.joda.time.DateTimeZone dateTimeZone27 = cachedDateTimeZone19.getUncachedZone();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-00:00:00.001" + "'", str7.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-00:00:00.001" + "'", str9.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-253144762L) + "'", long23 == (-253144762L));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 252547200000L + "'", long26 == 252547200000L);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//    }

//    @Test
//    public void test36() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test36");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.year();
//        org.joda.time.DurationField durationField10 = gregorianChronology0.hours();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.Period period13 = new org.joda.time.Period((long) (short) -1, chronology12);
//        org.joda.time.Period period15 = period13.withSeconds((int) (short) 10);
//        org.joda.time.Period period17 = period13.withMinutes((int) (short) 10);
//        org.joda.time.Period period19 = period17.withHours((int) (short) 1);
//        int int20 = period19.getMinutes();
//        org.joda.time.Period period22 = period19.plusMillis((int) ' ');
//        org.joda.time.DurationFieldType durationFieldType24 = period22.getFieldType(0);
//        org.joda.time.field.PreciseDurationField preciseDurationField26 = new org.joda.time.field.PreciseDurationField(durationFieldType24, 31823999999L);
//        org.joda.time.field.ScaledDurationField scaledDurationField28 = new org.joda.time.field.ScaledDurationField(durationField10, durationFieldType24, 9);
//        long long31 = scaledDurationField28.getMillis((-1), 9676800048L);
//        long long34 = scaledDurationField28.add((-62152628954174L), (-1));
//        boolean boolean35 = scaledDurationField28.isPrecise();
//        long long38 = scaledDurationField28.getMillis(0L, 101L);
//        long long39 = scaledDurationField28.getUnitMillis();
//        long long42 = scaledDurationField28.getMillis((-18470620L), (long) 2067);
//        int int45 = scaledDurationField28.getDifference(0L, (long) 3);
//        int int47 = scaledDurationField28.getValue((long) (-10));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130101L + "'", long6 == 39130101L);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(period15);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertNotNull(period22);
//        org.junit.Assert.assertNotNull(durationFieldType24);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-32400000L) + "'", long31 == (-32400000L));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-62152661354174L) + "'", long34 == (-62152661354174L));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 32400000L + "'", long39 == 32400000L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-598448088000000L) + "'", long42 == (-598448088000000L));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test37");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Days days3 = period2.toStandardDays();
        int int5 = period2.getValue((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        boolean boolean7 = period2.isSupported(durationFieldType6);
        try {
            org.joda.time.DurationFieldType durationFieldType9 = period2.getFieldType(2067);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2067");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(days3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test38");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period2.withMinutes((int) (short) 10);
        org.joda.time.Period period8 = period6.withHours((int) (short) 1);
        int int9 = period8.getMinutes();
        org.joda.time.Period period11 = period8.plusMillis((int) ' ');
        org.joda.time.Days days12 = period11.toStandardDays();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(days12);
    }

//    @Test
//    public void test39() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test39");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.lang.String str9 = offsetDateTimeField7.getAsText((long) (byte) 100);
//        int int10 = offsetDateTimeField7.getOffset();
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = offsetDateTimeField7.getAsText(readablePartial11, (int) (byte) -1, locale13);
//        org.joda.time.ReadablePartial readablePartial15 = null;
//        java.util.TimeZone timeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
//        java.lang.String str19 = dateTimeZone17.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) 'a');
//        long long25 = offsetDateTimeField23.roundHalfCeiling((long) (byte) -1);
//        org.joda.time.ReadablePartial readablePartial26 = null;
//        int[] intArray29 = new int[] { (-1), 292279090 };
//        int int30 = offsetDateTimeField23.getMinimumValue(readablePartial26, intArray29);
//        int int31 = offsetDateTimeField7.getMinimumValue(readablePartial15, intArray29);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-00:00:00.001" + "'", str3.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2067" + "'", str9.equals("2067"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1" + "'", str14.equals("-1"));
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-259199999L) + "'", long25 == (-259199999L));
//        org.junit.Assert.assertNotNull(intArray29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-292274957) + "'", int30 == (-292274957));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-292274957) + "'", int31 == (-292274957));
//    }
//}

