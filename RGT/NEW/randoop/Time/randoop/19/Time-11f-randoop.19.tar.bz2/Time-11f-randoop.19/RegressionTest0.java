import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DurationField durationField2 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test004");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560628666035L + "'", long1 == 1560628666035L);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(100L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10000L + "'", long2 == 10000L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        int int5 = period2.getHours();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType9 = periodType8.withYearsRemoved();
        try {
            org.joda.time.Period period10 = new org.joda.time.Period(100, (int) 'a', (int) (short) 0, 0, (int) (short) 100, (int) (short) 10, (int) '4', (int) '4', periodType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10, (java.lang.Number) (-1.0d), (java.lang.Number) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866673600000L) + "'", long1 == (-210866673600000L));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            int[] intArray3 = gregorianChronology0.get(readablePartial1, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            int[] intArray3 = gregorianChronology0.get(readablePartial1, (long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test029");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560628667826L + "'", long0 == 1560628667826L);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant1, readableInstant2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) '4', (java.lang.Object) readableInstant2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.millis();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField3 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 8, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period4.withMinutes((int) (byte) 1);
        int int7 = period6.getYears();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("PT1M9.999S");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'PT1M9.999S' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis((int) (short) 10, (int) (short) 10, (int) '4', (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField3 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) '4', locale3);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str2 = dateTimeZone1.getID();
        long long6 = dateTimeZone1.convertLocalToUTC(9L, false, (-18469900L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "America/Los_Angeles" + "'", str2.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28800009L + "'", long6 == 28800009L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = iSOChronology3.withUTC();
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            long long7 = iSOChronology3.set(readablePartial5, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (byte) 1, (int) (byte) 10, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        int int5 = period4.size();
        org.joda.time.Period period7 = period4.plusMillis(8);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period7.toDurationTo(readableInstant8);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 9L, (java.lang.Number) (short) -1, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField11 = new org.joda.time.field.RemainderDateTimeField(dateTimeField8, dateTimeFieldType9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-18469900L) + "'", long6 == (-18469900L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType3, (int) (short) 0, (-1), (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis((int) (short) 100, 0, (int) (byte) 1, (int) (short) 100, (int) (byte) 100, 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "PT1M9.999S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 0, 9L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        try {
            long long12 = gregorianChronology0.getDateTimeMillis(8, 0, (int) (short) 1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-18469900L) + "'", long6 == (-18469900L));
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(1560628666035L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2458650.3317828127d + "'", double1 == 2458650.3317828127d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (byte) 10, (java.lang.Number) 0, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.halfdayOfDay();
        try {
            long long13 = gregorianChronology0.getDateTimeMillis((int) (short) 10, (int) (byte) -1, (int) (short) 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-18469900L) + "'", long6 == (-18469900L));
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationTo(readableInstant4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period10, periodType11, chronology12);
        org.joda.time.PeriodType periodType14 = periodType11.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = periodType14.withSecondsRemoved();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType14);
        try {
            org.joda.time.Period period18 = period16.withMinutes(100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.minusMinutes(1);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.Period period7 = period4.withField(durationFieldType5, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        try {
//            long long13 = gregorianChronology4.getDateTimeMillis((int) (short) 100, 100, 1, 0, 10, 0, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 28800000L, (java.lang.Number) (-1.0f), (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "2067");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(1001L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1101L + "'", long2 == 1101L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-18469900L), (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-18469890L) + "'", long2 == (-18469890L));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
        org.joda.time.Chronology chronology9 = gregorianChronology0.withUTC();
        try {
            long long17 = gregorianChronology0.getDateTimeMillis((-28800000), (int) (byte) 10, (int) (short) 1, 1, 4, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-18469900L) + "'", long6 == (-18469900L));
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("PT1M9.999S", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PT1M9.999S/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField3, (int) (short) 10, 100, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for clockhourOfHalfday must be in the range [100,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNull(durationFieldType4);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 1, (-210866673600000L), (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField5 = gregorianChronology2.seconds();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField8 = new org.joda.time.field.ScaledDurationField(durationField5, durationFieldType6, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(4);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-28800000), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        try {
            long long12 = gregorianChronology0.getDateTimeMillis((int) (byte) 10, (-1), 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-18469900L) + "'", long6 == (-18469900L));
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis((int) (byte) 100, (int) (byte) 0, 100, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        try {
            long long4 = durationField1.subtract(1560628666035L, 31824000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Magnitude of add amount is too large: -31824000000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationTo(readableInstant5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) period11, periodType12, chronology13);
        org.joda.time.PeriodType periodType15 = periodType12.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = periodType15.withSecondsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration6, periodType15);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant20, readableDuration21);
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period22, periodType23, chronology24);
        org.joda.time.PeriodType periodType26 = periodType23.withYearsRemoved();
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant27, readableInstant28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) 10, 0L, periodType26, chronology29);
        org.joda.time.Period period31 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6, periodType26);
        try {
            org.joda.time.Period period33 = period31.withYears((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(chronology29);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        long long7 = gregorianChronology0.getDateTimeMillis((-1), 8, (int) (byte) 10, 4);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62179660799996L) + "'", long7 == (-62179660799996L));
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(39130100L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 39130100 + "'", int2 == 39130100);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Pacific Standard Time", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Pacific Standard Time/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        java.util.Locale locale11 = null;
//        try {
//            java.lang.String str12 = offsetDateTimeField7.getAsShortText(readablePartial10, locale11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
//        long long11 = durationField8.subtract((long) 1, (-1L));
//        long long14 = durationField8.subtract((long) (-1), (-62166787199990L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1001L + "'", long11 == 1001L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 62166787199989999L + "'", long14 == 62166787199989999L);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        int int12 = offsetDateTimeField7.getLeapAmount((long) (-1));
//        long long15 = offsetDateTimeField7.set((long) (byte) 10, (int) 'a');
//        try {
//            long long18 = offsetDateTimeField7.set((long) (byte) 10, "");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekyear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62166787199990L) + "'", long15 == (-62166787199990L));
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.lang.String str9 = offsetDateTimeField7.getAsText((long) (byte) 100);
//        long long12 = offsetDateTimeField7.add((long) (-28800000), (long) 0);
//        long long15 = offsetDateTimeField7.add((-62179660799996L), 39130100);
//        try {
//            long long18 = offsetDateTimeField7.set((long) 8, "DateTimeField[weekyear]");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[weekyear]\" for weekyear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2067" + "'", str9.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-28800000L) + "'", long12 == (-28800000L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1234764507340800004L + "'", long15 == 1234764507340800004L);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.year();
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.lang.String str13 = dateTimeZone11.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.Chronology chronology15 = gregorianChronology0.withZone(dateTimeZone11);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField4 = gregorianChronology3.millis();
//        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) 1, (-210866673600000L), (org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.DurationField durationField6 = gregorianChronology3.seconds();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long13 = gregorianChronology7.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology7.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology7.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology7.year();
//        java.util.TimeZone timeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        java.lang.String str20 = dateTimeZone18.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.Chronology chronology22 = gregorianChronology7.withZone(dateTimeZone18);
//        org.joda.time.DurationField durationField23 = gregorianChronology7.weeks();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField24 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField6, durationField23);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 39130100L + "'", long13 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) -1, 0, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) 1);
        int int2 = period1.getMonths();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        int int1 = periodType0.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 1, (-210866673600000L), (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField5 = gregorianChronology2.seconds();
        try {
            long long11 = gregorianChronology2.getDateTimeMillis(0L, (int) (byte) 100, 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.year();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType10, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.Period period8 = new org.joda.time.Period((int) 'a', 100, (int) (byte) 0, (int) 'a', (int) ' ', (int) (byte) 100, 1, 1);
        org.joda.time.Period period10 = period8.minusMonths(100);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType12 = periodType11.withYearsRemoved();
        org.joda.time.PeriodType periodType13 = periodType11.withDaysRemoved();
        try {
            org.joda.time.Period period14 = period10.normalizedStandard(periodType11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(10000L, "");
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) period2, periodType3, chronology4);
        org.joda.time.Period period7 = period2.plusMinutes(39130100);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period7);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant3, readableDuration4);
//        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.seconds();
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) period5, periodType6, chronology7);
//        org.joda.time.PeriodType periodType9 = periodType6.withYearsRemoved();
//        org.joda.time.ReadableInstant readableInstant10 = null;
//        org.joda.time.ReadableInstant readableInstant11 = null;
//        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
//        org.joda.time.Period period13 = new org.joda.time.Period((long) (byte) 10, 0L, periodType9, chronology12);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone16 = dateTimeZone15.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
//        java.util.TimeZone timeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
//        java.lang.String str21 = dateTimeZone19.getName(0L);
//        java.lang.String str23 = dateTimeZone19.getName((long) '4');
//        org.joda.time.Chronology chronology24 = iSOChronology17.withZone(dateTimeZone19);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
//        org.joda.time.Chronology chronology30 = iSOChronology17.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone29);
//        org.joda.time.Period period31 = new org.joda.time.Period((long) 3, periodType9, chronology30);
//        org.junit.Assert.assertNotNull(periodType6);
//        org.junit.Assert.assertNotNull(periodType9);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Coordinated Universal Time" + "'", str21.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Coordinated Universal Time" + "'", str23.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(chronology30);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, chronology6);
        org.joda.time.Period period8 = period2.withFields((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period10 = period2.minusMonths((int) '#');
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-1L));
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str2 = dateTimeZone1.getID();
//        java.lang.String str4 = dateTimeZone1.getName((long) 10);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        int int5 = dateTimeZone1.getOffset(readableInstant4);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(292279090, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period2.withMinutes((int) (short) 10);
        org.joda.time.Period period8 = period6.withHours((int) (short) 1);
        int int9 = period8.getMinutes();
        org.joda.time.Period period11 = period8.plusMillis((int) ' ');
        try {
            org.joda.time.DurationFieldType durationFieldType13 = period8.getFieldType((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(period11);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        int int12 = offsetDateTimeField7.getLeapAmount((long) (-1));
//        long long15 = offsetDateTimeField7.set((long) (byte) 10, (int) 'a');
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        java.util.Locale locale17 = null;
//        try {
//            java.lang.String str18 = offsetDateTimeField7.getAsShortText(readablePartial16, locale17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62166787199990L) + "'", long15 == (-62166787199990L));
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(1560628667826L);
        long long8 = fixedDateTimeZone4.nextTransition((long) 292279090);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 292279090L + "'", long8 == 292279090L);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.lang.String str9 = offsetDateTimeField7.getAsText((long) (byte) 100);
//        long long12 = offsetDateTimeField7.add((long) (-28800000), (long) 0);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        int[] intArray19 = new int[] { (-28800000), (byte) 0, (short) 0, 3, (byte) 1 };
//        int int20 = offsetDateTimeField7.getMinimumValue(readablePartial13, intArray19);
//        org.joda.time.ReadablePartial readablePartial21 = null;
//        org.joda.time.ReadableInstant readableInstant23 = null;
//        org.joda.time.ReadableDuration readableDuration24 = null;
//        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant23, readableDuration24);
//        org.joda.time.Days days26 = period25.toStandardDays();
//        org.joda.time.Period period28 = period25.plusHours(8);
//        int[] intArray29 = period25.getValues();
//        java.util.Locale locale31 = null;
//        try {
//            int[] intArray32 = offsetDateTimeField7.set(readablePartial21, 4, intArray29, "America/Los_Angeles", locale31);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for weekyear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2067" + "'", str9.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-28800000L) + "'", long12 == (-28800000L));
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-292274957) + "'", int20 == (-292274957));
//        org.junit.Assert.assertNotNull(days26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertNotNull(intArray29);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(10L, "America/Los_Angeles");
        java.lang.String str3 = illegalInstantException2.toString();
        java.lang.Throwable[] throwableArray4 = illegalInstantException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.010 (America/Los_Angeles)" + "'", str3.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.010 (America/Los_Angeles)"));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "weekyear");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType9 = periodType8.withYearsRemoved();
        org.joda.time.PeriodType periodType10 = periodType9.withMillisRemoved();
        try {
            org.joda.time.Period period11 = new org.joda.time.Period(0, 4, 4, 39130100, (int) 'a', 10, 97, 10, periodType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
//        org.joda.time.DurationFieldType durationFieldType9 = null;
//        try {
//            org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField8, durationFieldType9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        int int5 = period4.size();
        org.joda.time.Period period7 = period4.plusMillis(8);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period12.toDurationTo(readableInstant13);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) period19, periodType20, chronology21);
        org.joda.time.PeriodType periodType23 = periodType20.withYearsRemoved();
        org.joda.time.PeriodType periodType24 = periodType23.withSecondsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant9, (org.joda.time.ReadableDuration) duration14, periodType23);
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType27 = periodType26.withYearsRemoved();
        org.joda.time.PeriodType periodType28 = periodType27.withMillisRemoved();
        org.joda.time.Period period29 = new org.joda.time.Period(readableInstant8, (org.joda.time.ReadableDuration) duration14, periodType28);
        try {
            org.joda.time.Period period30 = period7.withPeriodType(periodType28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'millis'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
//        org.joda.time.Chronology chronology9 = gregorianChronology0.withUTC();
//        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance(chronology9);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
//        boolean boolean17 = fixedDateTimeZone15.isStandardOffset(1560628667826L);
//        org.joda.time.LocalDateTime localDateTime18 = null;
//        boolean boolean19 = fixedDateTimeZone15.isLocalDateTimeGap(localDateTime18);
//        boolean boolean20 = fixedDateTimeZone15.isFixed();
//        org.joda.time.Chronology chronology21 = lenientChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        long long23 = fixedDateTimeZone15.nextTransition(31824000000L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(lenientChronology10);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 31824000000L + "'", long23 == 31824000000L);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.String str8 = illegalFieldValueException7.getIllegalValueAsString();
        java.lang.String str9 = illegalFieldValueException7.getIllegalValueAsString();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        java.lang.Class<?> wildcardClass11 = illegalFieldValueException2.getClass();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.String str15 = illegalFieldValueException14.getFieldName();
        java.lang.Throwable[] throwableArray16 = illegalFieldValueException14.getSuppressed();
        java.lang.Number number17 = illegalFieldValueException14.getUpperBound();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException14);
        java.lang.Number number19 = illegalFieldValueException14.getLowerBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertNull(number19);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        java.lang.Object obj2 = null;
        boolean boolean3 = gregorianChronology0.equals(obj2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.lang.String str13 = dateTimeZone11.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) 'a');
//        java.lang.String str19 = offsetDateTimeField17.getAsText((long) (byte) 100);
//        long long22 = offsetDateTimeField17.add((long) (-28800000), (long) 0);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        int[] intArray29 = new int[] { (-28800000), (byte) 0, (short) 0, 3, (byte) 1 };
//        int int30 = offsetDateTimeField17.getMinimumValue(readablePartial23, intArray29);
//        try {
//            int[] intArray32 = offsetDateTimeField7.add(readablePartial8, (int) (byte) -1, intArray29, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2067" + "'", str19.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-28800000L) + "'", long22 == (-28800000L));
//        org.junit.Assert.assertNotNull(intArray29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-292274957) + "'", int30 == (-292274957));
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(10, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1000 + "'", int2 == 1000);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.Period period5 = period2.withFieldAdded(durationFieldType3, 1000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(100L, (long) 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 800 + "'", int2 == 800);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.lang.String str9 = offsetDateTimeField7.getAsText((long) (byte) 100);
//        long long12 = offsetDateTimeField7.add(28800000L, (long) 8);
//        long long14 = offsetDateTimeField7.roundHalfFloor(0L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType15, (int) ' ', (int) (byte) 100, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2067" + "'", str9.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 252835200000L + "'", long12 == 252835200000L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200000L) + "'", long14 == (-259200000L));
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period2.withMinutes((int) (short) 10);
        org.joda.time.Period period8 = period6.withHours((int) (short) 1);
        int int9 = period8.getMinutes();
        int int10 = period8.getMonths();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        long long14 = offsetDateTimeField7.set(1560628667826L, (int) 'a');
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField7.getAsText((long) (short) 100, locale16);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField7.getDurationField();
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        java.util.Locale locale20 = null;
//        try {
//            java.lang.String str21 = offsetDateTimeField7.getAsText(readablePartial19, locale20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62152632132174L) + "'", long14 == (-62152632132174L));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2067" + "'", str17.equals("2067"));
//        org.junit.Assert.assertNotNull(durationField18);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        java.lang.String str5 = dateTimeZone1.getName((-62152632132174L));
//        java.lang.String str7 = dateTimeZone1.getShortName((-62152628954174L));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant1, readableDuration2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) period3, periodType4, chronology5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.millis();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.secondOfDay();
        org.joda.time.Period period10 = new org.joda.time.Period((-1L), periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology7);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology11);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
//        try {
//            long long16 = gregorianChronology0.getDateTimeMillis(3, 6, 39130100, 0, 97, (int) (short) -1, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        long long14 = offsetDateTimeField7.set(1560628667826L, (int) 'a');
//        java.lang.String str15 = offsetDateTimeField7.toString();
//        java.util.Locale locale18 = null;
//        try {
//            long long19 = offsetDateTimeField7.set(0L, "GregorianChronology[UTC]", locale18);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[UTC]\" for weekyear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62152632132174L) + "'", long14 == (-62152632132174L));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[weekyear]" + "'", str15.equals("DateTimeField[weekyear]"));
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt(1234826687606400003L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1234826687606400003");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', periodType2);
        int int4 = period3.getMinutes();
        org.joda.time.Period period5 = period3.toPeriod();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) period2, periodType3, chronology4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period2.indexOf(durationFieldType6);
        int int8 = period2.getHours();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis((int) (short) 100, 6, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', periodType2);
        int int4 = period3.getMinutes();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant5, readableInstant6);
        org.joda.time.DurationFieldType[] durationFieldTypeArray8 = period7.getFieldTypes();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.forFields(durationFieldTypeArray8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.util.TimeZone timeZone12 = dateTimeZone11.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.Chronology chronology14 = iSOChronology13.withUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.util.TimeZone timeZone17 = dateTimeZone16.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.Chronology chronology20 = iSOChronology13.withZone(dateTimeZone19);
        try {
            org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) int4, periodType9, chronology20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(durationFieldTypeArray8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.days();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        int[] intArray3 = period2.getValues();
        org.joda.time.Days days4 = period2.toStandardDays();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(days4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration4, readableInstant5);
        long long7 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration4);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-90L) + "'", long7 == (-90L));
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone1.getShortName(9L, locale5);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) 1);
        int int2 = period1.getYears();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long8 = gregorianChronology2.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.Chronology chronology9 = gregorianChronology2.withUTC();
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.lang.String str13 = dateTimeZone11.getName(0L);
//        org.joda.time.Chronology chronology14 = gregorianChronology2.withZone(dateTimeZone11);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology2.halfdayOfDay();
//        org.joda.time.Period period16 = new org.joda.time.Period(0L, (long) 39130100, (org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DurationField durationField17 = gregorianChronology2.days();
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 39130100L + "'", long8 == 39130100L);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(durationField17);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-62152632132174L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-9223372036854775808L) + "'", long1 == (-9223372036854775808L));
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.lang.String str8 = dateTimeZone6.getName(0L);
//        boolean boolean10 = dateTimeZone6.isStandardOffset(9L);
//        long long12 = dateTimeZone4.getMillisKeepLocal(dateTimeZone6, 0L);
//        java.lang.String str13 = dateTimeZone4.getID();
//        java.lang.String str14 = dateTimeZone4.getID();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        java.util.TimeZone timeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
//        java.lang.String str8 = dateTimeZone6.getName(0L);
//        boolean boolean10 = dateTimeZone6.isStandardOffset(9L);
//        long long12 = dateTimeZone4.getMillisKeepLocal(dateTimeZone6, 0L);
//        java.lang.String str13 = dateTimeZone4.getID();
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        long long14 = offsetDateTimeField7.set(1560628667826L, (int) 'a');
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField7.getAsText((long) (short) 100, locale16);
//        java.util.Locale locale18 = null;
//        int int19 = offsetDateTimeField7.getMaximumTextLength(locale18);
//        try {
//            long long22 = offsetDateTimeField7.set(31824000000L, "hi!");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for weekyear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62152632132174L) + "'", long14 == (-62152632132174L));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2067" + "'", str17.equals("2067"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period4.withMinutes((int) (byte) 1);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = period8.get(durationFieldType9);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, chronology6);
        org.joda.time.Period period8 = period2.withFields((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period10 = period8.plusHours(0);
        org.joda.time.Duration duration11 = period8.toStandardDuration();
        long long12 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration11);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period2.withMinutes((int) (short) 10);
        org.joda.time.Period period8 = period6.withHours((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.Period period11 = period8.withField(durationFieldType9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period4.withMinutes((int) (byte) 1);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.Period period10 = period8.minusWeeks(97);
        org.joda.time.MutablePeriod mutablePeriod11 = period8.toMutablePeriod();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(mutablePeriod11);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
        long long12 = gregorianChronology0.add(1560628667826L, 100L, 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560628667826L + "'", long12 == 1560628667826L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.weekyearOfCentury();
        try {
            long long15 = gregorianChronology0.getDateTimeMillis(0, 6, (int) (byte) 0, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-292274957), number2, (java.lang.Number) (-18469900L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period4.withMinutes((int) (byte) 1);
        org.joda.time.Period period8 = period6.minusSeconds((int) (byte) 100);
        org.joda.time.Period period10 = period8.plusMonths((int) (byte) 100);
        org.joda.time.MutablePeriod mutablePeriod11 = period10.toMutablePeriod();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(mutablePeriod11);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (byte) 100);
        int int2 = period1.getMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance(chronology4);
        org.joda.time.Period period6 = new org.joda.time.Period(94953600032L, (long) (byte) -1, chronology4);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(lenientChronology5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.lang.String str7 = dateTimeZone5.getName(0L);
//        java.lang.String str9 = dateTimeZone5.getName((long) '4');
//        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology3.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType12, 1000, 0, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(152917906603501L, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 15291790660350100");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
        java.lang.String str3 = periodType2.toString();
        try {
            org.joda.time.Period period4 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PeriodType[YearMonthDayTime]" + "'", str3.equals("PeriodType[YearMonthDayTime]"));
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.lang.String str7 = dateTimeZone5.getName(0L);
//        java.lang.String str9 = dateTimeZone5.getName((long) '4');
//        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone5);
//        java.lang.String str12 = dateTimeZone5.getShortName((long) 3);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (-28800000));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -28800000");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology1.days();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField6 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(39130100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        long long12 = offsetDateTimeField7.roundCeiling((long) (byte) -1);
//        int int14 = offsetDateTimeField7.getLeapAmount((-1L));
//        long long17 = offsetDateTimeField7.set((-210866673600000L), 0);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        java.util.Locale locale19 = null;
//        try {
//            java.lang.String str20 = offsetDateTimeField7.getAsShortText(readablePartial18, locale19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31795200000L + "'", long12 == 31795200000L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-65199988800000L) + "'", long17 == (-65199988800000L));
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1L, "100");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period4.withMinutes((int) (byte) 1);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.Period period10 = period8.minusWeeks(97);
        org.joda.time.Period period12 = period10.withMillis(3);
        org.joda.time.Period period14 = period10.multipliedBy(800);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.Period period3 = period2.toPeriod();
        int int4 = period2.getHours();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withSecondsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long9 = gregorianChronology3.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.secondOfMinute();
        try {
            org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) periodType2, (org.joda.time.Chronology) gregorianChronology3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 39130100L + "'", long9 == 39130100L);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period4.withMinutes((int) (byte) 1);
        int[] intArray7 = period4.getValues();
        try {
            int int9 = period4.getValue(39130100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 39130100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(intArray7);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        java.util.TimeZone timeZone4 = dateTimeZone1.toTimeZone();
//        long long7 = dateTimeZone1.convertLocalToUTC((-62152628954174L), true);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62152628954174L) + "'", long7 == (-62152628954174L));
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.Period period8 = new org.joda.time.Period(0, 10, 100, 0, (int) (short) 0, 0, (int) (byte) 0, (int) ' ');
        org.joda.time.Period period10 = period8.withYears((-1));
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period8.toDurationFrom(readableInstant11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant13);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration12);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(4L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', periodType2);
        int int4 = period3.getMinutes();
        int int5 = period3.getYears();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.Period period3 = period2.toPeriod();
        int int4 = period3.getSeconds();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.weekyear();
        try {
            long long16 = gregorianChronology0.getDateTimeMillis((int) (short) 10, (int) (short) -1, 0, (-292274957), 292279090, 8, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292274957 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("weekyear");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'weekyear' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(9, (int) (byte) 10, 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) period2, periodType3, chronology4);
        org.joda.time.PeriodType periodType6 = periodType3.withYearsRemoved();
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType6, (java.lang.Object) true);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        boolean boolean10 = periodType6.isSupported(durationFieldType9);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', periodType2);
        java.lang.Class<?> wildcardClass4 = period3.getClass();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
//        org.joda.time.Chronology chronology9 = gregorianChronology0.withUTC();
//        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance(chronology9);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
//        boolean boolean17 = fixedDateTimeZone15.isStandardOffset(1560628667826L);
//        org.joda.time.LocalDateTime localDateTime18 = null;
//        boolean boolean19 = fixedDateTimeZone15.isLocalDateTimeGap(localDateTime18);
//        boolean boolean20 = fixedDateTimeZone15.isFixed();
//        org.joda.time.Chronology chronology21 = lenientChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        org.joda.time.ReadableInstant readableInstant22 = null;
//        org.joda.time.ReadableInstant readableInstant23 = null;
//        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableInstant23);
//        int[] intArray25 = period24.getValues();
//        org.joda.time.Period period27 = period24.minusHours(0);
//        java.util.TimeZone timeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forTimeZone(timeZone28);
//        java.lang.String str31 = dateTimeZone29.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.weekyear();
//        boolean boolean34 = period27.equals((java.lang.Object) dateTimeField33);
//        int[] intArray36 = lenientChronology10.get((org.joda.time.ReadablePeriod) period27, 39130100L);
//        org.joda.time.PeriodType periodType37 = org.joda.time.PeriodType.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long44 = gregorianChronology38.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology38.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology38.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology38.year();
//        org.joda.time.DurationField durationField48 = gregorianChronology38.seconds();
//        try {
//            org.joda.time.Period period49 = new org.joda.time.Period((java.lang.Object) intArray36, periodType37, (org.joda.time.Chronology) gregorianChronology38);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: [I");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(lenientChronology10);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Coordinated Universal Time" + "'", str31.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(intArray36);
//        org.junit.Assert.assertNotNull(periodType37);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 39130100L + "'", long44 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(durationField48);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(1000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(1560628667826L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray13 = new int[] { (-28800000), (short) -1, (byte) 1, (short) 10 };
        try {
            iSOChronology7.validate(readablePartial8, intArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period4.withMinutes((int) (byte) 1);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.Period period10 = period8.minusWeeks(97);
        org.joda.time.Period period12 = period8.multipliedBy(0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, 10);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        long long9 = offsetDateTimeField7.roundHalfCeiling((long) (byte) -1);
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        int[] intArray13 = new int[] { (-1), 292279090 };
//        int int14 = offsetDateTimeField7.getMinimumValue(readablePartial10, intArray13);
//        java.lang.String str15 = offsetDateTimeField7.getName();
//        org.joda.time.DurationField durationField16 = offsetDateTimeField7.getDurationField();
//        long long18 = offsetDateTimeField7.roundHalfEven(252547200000L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292274957) + "'", int14 == (-292274957));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "weekyear" + "'", str15.equals("weekyear"));
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 252547200000L + "'", long18 == 252547200000L);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType9 = periodType8.withYearsRemoved();
        try {
            org.joda.time.Period period10 = new org.joda.time.Period((int) (short) 10, (int) (short) -1, (-292274957), (int) (byte) -1, 97, 9, (int) (short) -1, 100, periodType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 97, (int) '4', 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1L, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(1560628667826L);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.lang.String str9 = offsetDateTimeField7.getAsText((long) (byte) 100);
//        long long12 = offsetDateTimeField7.add(28800000L, (long) 8);
//        boolean boolean14 = offsetDateTimeField7.isLeap(1234764507340800004L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2067" + "'", str9.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 252835200000L + "'", long12 == 252835200000L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        long long14 = offsetDateTimeField7.set(1560628667826L, (int) 'a');
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField7.getAsText((long) (short) 100, locale16);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField7.getDurationField();
//        try {
//            long long21 = offsetDateTimeField7.add(1001L, (-210863779200000L));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -210863779200000");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62152632132174L) + "'", long14 == (-62152632132174L));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2067" + "'", str17.equals("2067"));
//        org.junit.Assert.assertNotNull(durationField18);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(1560628667826L);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        long long10 = fixedDateTimeZone4.nextTransition((long) (short) 0);
        int int12 = fixedDateTimeZone4.getStandardOffset((long) 'a');
        long long14 = fixedDateTimeZone4.previousTransition((-9223372036854775808L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-9223372036854775808L) + "'", long14 == (-9223372036854775808L));
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        int int12 = offsetDateTimeField7.getLeapAmount((long) (-1));
//        long long14 = offsetDateTimeField7.roundHalfCeiling((long) (short) 10);
//        int int16 = offsetDateTimeField7.getLeapAmount(1234764507340800004L);
//        long long18 = offsetDateTimeField7.roundHalfCeiling((long) 97);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200000L) + "'", long14 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-259200000L) + "'", long18 == (-259200000L));
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, chronology6);
        org.joda.time.Period period8 = period2.withFields((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period10 = period8.plusHours(0);
        org.joda.time.Period period12 = period10.minusMinutes(0);
        org.joda.time.Period period14 = period10.withWeeks(4);
        int int15 = period10.getYears();
        org.joda.time.Period period17 = period10.plusSeconds((int) (short) 0);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(period17);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        java.util.TimeZone timeZone4 = dateTimeZone1.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
        org.joda.time.Chronology chronology9 = gregorianChronology0.withUTC();
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance(chronology9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
        boolean boolean17 = fixedDateTimeZone15.isStandardOffset(1560628667826L);
        org.joda.time.LocalDateTime localDateTime18 = null;
        boolean boolean19 = fixedDateTimeZone15.isLocalDateTimeGap(localDateTime18);
        boolean boolean20 = fixedDateTimeZone15.isFixed();
        org.joda.time.Chronology chronology21 = lenientChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DurationField durationField22 = lenientChronology10.weekyears();
        long long25 = durationField22.subtract((-65199988800000L), 97);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-68260881600000L) + "'", long25 == (-68260881600000L));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(1000);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt((-210863779200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -210863779200000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Days days3 = period2.toStandardDays();
        int int5 = period2.getValue((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.Period period8 = period2.withFieldAdded(durationFieldType6, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(days3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
//        java.lang.String str3 = illegalFieldValueException2.getFieldName();
//        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
//        java.lang.Number number5 = illegalFieldValueException2.getUpperBound();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        java.lang.String str9 = dateTimeZone7.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.weekyear();
//        org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) number5, (org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.Period period15 = new org.joda.time.Period((long) 100, (long) (byte) 10);
//        org.joda.time.Period period16 = period15.toPeriod();
//        org.joda.time.Period period18 = period16.withYears(3);
//        long long21 = gregorianChronology10.add((org.joda.time.ReadablePeriod) period16, (-18469900L), 8);
//        org.joda.time.ReadableInstant readableInstant22 = null;
//        org.joda.time.ReadableDuration readableDuration23 = null;
//        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
//        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.seconds();
//        org.joda.time.Chronology chronology26 = null;
//        org.joda.time.Period period27 = new org.joda.time.Period((java.lang.Object) period24, periodType25, chronology26);
//        org.joda.time.PeriodType periodType28 = periodType25.withYearsRemoved();
//        org.joda.time.PeriodType periodType29 = periodType25.withMillisRemoved();
//        org.joda.time.PeriodType periodType30 = periodType29.withHoursRemoved();
//        org.joda.time.IllegalInstantException illegalInstantException33 = new org.joda.time.IllegalInstantException(10L, "America/Los_Angeles");
//        java.lang.String str34 = illegalInstantException33.toString();
//        boolean boolean35 = periodType29.equals((java.lang.Object) illegalInstantException33);
//        try {
//            org.joda.time.Period period36 = new org.joda.time.Period((java.lang.Object) long21, periodType29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
//        org.junit.Assert.assertNotNull(throwableArray4);
//        org.junit.Assert.assertNull(number5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-18470620L) + "'", long21 == (-18470620L));
//        org.junit.Assert.assertNotNull(periodType25);
//        org.junit.Assert.assertNotNull(periodType28);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertNotNull(periodType30);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.010 (America/Los_Angeles)" + "'", str34.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.010 (America/Los_Angeles)"));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) 'a');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.minutes();
        try {
            long long11 = gregorianChronology2.getDateTimeMillis(10, (-39128121), 292279090, (int) 'a', 292279090, 0, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("PT1M9.999S");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"PT1M9.999S\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"PT1M9.999S\")"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) 10);
        org.joda.time.MutablePeriod mutablePeriod2 = period1.toMutablePeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(mutablePeriod2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = periodType1.indexOf(durationFieldType2);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField11 = new org.joda.time.field.RemainderDateTimeField(dateTimeField8, dateTimeFieldType9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-62152632132174L), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.lang.String str9 = offsetDateTimeField7.getAsText((long) (byte) 100);
//        int int10 = offsetDateTimeField7.getOffset();
//        int int12 = offsetDateTimeField7.getLeapAmount(1101L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2067" + "'", str9.equals("2067"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.010 (America/Los_Angeles)");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withMillisRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) 'a');
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.Period period4 = period1.withFieldAdded(durationFieldType2, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        long long14 = offsetDateTimeField7.set(1560628667826L, (int) 'a');
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField7.getAsText((long) (short) 100, locale16);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField7.getLeapDurationField();
//        try {
//            long long21 = offsetDateTimeField7.add((long) 6, 292279090);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292281060 for weekyear must be in the range [-292275054,292278993]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62152632132174L) + "'", long14 == (-62152632132174L));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2067" + "'", str17.equals("2067"));
//        org.junit.Assert.assertNotNull(durationField18);
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        long long14 = offsetDateTimeField7.set(1560628667826L, (int) 'a');
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType15, (-292274957));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62152632132174L) + "'", long14 == (-62152632132174L));
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.lang.String str7 = dateTimeZone5.getName(0L);
//        java.lang.String str9 = dateTimeZone5.getName((long) '4');
//        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology3.weekyear();
//        org.joda.time.Chronology chronology12 = iSOChronology3.withUTC();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(chronology12);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 9L, "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.010 (America/Los_Angeles)");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap3);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.lang.String str11 = dateTimeZone9.getName(0L);
//        org.joda.time.Chronology chronology12 = gregorianChronology0.withZone(dateTimeZone9);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        int[] intArray14 = null;
//        try {
//            gregorianChronology0.validate(readablePartial13, intArray14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology12);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period5.toDurationTo(readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period12, periodType13, chronology14);
        org.joda.time.PeriodType periodType16 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType17 = periodType16.withSecondsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration7, periodType16);
        org.joda.time.Period period19 = new org.joda.time.Period((long) 10, 0L, periodType16);
        java.lang.Object obj20 = null;
        boolean boolean21 = periodType16.equals(obj20);
        org.joda.time.PeriodType periodType22 = periodType16.withMillisRemoved();
        try {
            org.joda.time.Period period23 = new org.joda.time.Period((java.lang.Object) periodType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(periodType22);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period4.withMinutes((int) (byte) 1);
        org.joda.time.Period period8 = period6.plusDays(0);
        try {
            int int10 = period6.getValue(39130100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        long long9 = offsetDateTimeField7.roundHalfCeiling((long) (byte) -1);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField7.getAsShortText(28800009L, locale11);
//        java.lang.String str14 = offsetDateTimeField7.getAsText(1560628666035L);
//        long long16 = offsetDateTimeField7.roundHalfEven((long) 'a');
//        try {
//            long long19 = offsetDateTimeField7.add((long) 100, 1234764507340800004L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1234764507340800004");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2067" + "'", str12.equals("2067"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2116" + "'", str14.equals("2116"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200000L) + "'", long16 == (-259200000L));
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant2, readableDuration3);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) period4, periodType5, chronology6);
        org.joda.time.PeriodType periodType8 = periodType5.withYearsRemoved();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) (byte) 10, 0L, periodType8, chronology11);
        try {
            org.joda.time.Period period14 = period12.plusMonths((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "PeriodType[Time]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 1, (-210866673600000L), (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField5 = gregorianChronology2.seconds();
        try {
            long long10 = gregorianChronology2.getDateTimeMillis(97, 6, (int) (short) 100, 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(1000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1000) + "'", int1 == (-1000));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (short) 100, 1, 97, 39130100, 100, (int) ' ', (int) (short) 100, (int) (short) 1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("DateTimeField[weekyear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[weekyear]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PT1M9.999S", (java.lang.Number) (byte) 0, (java.lang.Number) (-62179660799996L), (java.lang.Number) (-1L));
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0" + "'", str5.equals("0"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (short) 0);
        org.joda.time.Weeks weeks2 = period1.toStandardWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(weeks2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period6.toDurationTo(readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant11, readableDuration12);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((java.lang.Object) period13, periodType14, chronology15);
        org.joda.time.PeriodType periodType17 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType18 = periodType17.withSecondsRemoved();
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant3, (org.joda.time.ReadableDuration) duration8, periodType17);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableDuration23);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period((java.lang.Object) period24, periodType25, chronology26);
        org.joda.time.PeriodType periodType28 = periodType25.withYearsRemoved();
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant29, readableInstant30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 10, 0L, periodType28, chronology31);
        org.joda.time.Period period33 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration8, periodType28);
        try {
            org.joda.time.Period period34 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(chronology31);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (-292274957));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-292274957) + "'", int1 == (-292274957));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.junit.Assert.assertNotNull(periodType0);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        long long9 = offsetDateTimeField7.roundHalfCeiling((long) (byte) -1);
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        int[] intArray13 = new int[] { (-1), 292279090 };
//        int int14 = offsetDateTimeField7.getMinimumValue(readablePartial10, intArray13);
//        org.joda.time.DurationField durationField15 = offsetDateTimeField7.getRangeDurationField();
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        java.util.Locale locale17 = null;
//        try {
//            java.lang.String str18 = offsetDateTimeField7.getAsShortText(readablePartial16, locale17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292274957) + "'", int14 == (-292274957));
//        org.junit.Assert.assertNull(durationField15);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(10L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray3 = period2.getFieldTypes();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.forFields(durationFieldTypeArray3);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.forFields(durationFieldTypeArray3);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.forFields(durationFieldTypeArray3);
        org.junit.Assert.assertNotNull(durationFieldTypeArray3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        long long14 = offsetDateTimeField7.set(1560628667826L, (int) 'a');
//        java.lang.String str15 = offsetDateTimeField7.toString();
//        long long18 = offsetDateTimeField7.addWrapField(31795200000L, (-292274957));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62152632132174L) + "'", long14 == (-62152632132174L));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[weekyear]" + "'", str15.equals("DateTimeField[weekyear]"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-9223306757136000000L) + "'", long18 == (-9223306757136000000L));
//    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        long long14 = offsetDateTimeField7.set(1560628667826L, (int) 'a');
//        java.lang.String str15 = offsetDateTimeField7.toString();
//        long long17 = offsetDateTimeField7.roundHalfCeiling((long) 800);
//        java.lang.String str19 = offsetDateTimeField7.getAsShortText((long) 39130100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField21 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62152632132174L) + "'", long14 == (-62152632132174L));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[weekyear]" + "'", str15.equals("DateTimeField[weekyear]"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-259200000L) + "'", long17 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2067" + "'", str19.equals("2067"));
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long7 = gregorianChronology1.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.Chronology chronology8 = gregorianChronology1.withUTC();
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        java.lang.String str12 = dateTimeZone10.getName(0L);
//        org.joda.time.Chronology chronology13 = gregorianChronology1.withZone(dateTimeZone10);
//        org.joda.time.Chronology chronology14 = iSOChronology0.withZone(dateTimeZone10);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 39130100L + "'", long7 == 39130100L);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(chronology14);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) period2, periodType3, chronology4);
        org.joda.time.PeriodType periodType6 = periodType3.withYearsRemoved();
        org.joda.time.PeriodType periodType7 = periodType6.withDaysRemoved();
        org.joda.time.PeriodType periodType8 = periodType7.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.lang.String str9 = offsetDateTimeField7.getAsText((long) (byte) 100);
//        long long12 = offsetDateTimeField7.add(28800000L, (long) 8);
//        org.joda.time.DurationField durationField13 = offsetDateTimeField7.getDurationField();
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField7.getAsText(readablePartial14, 0, locale16);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2067" + "'", str9.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 252835200000L + "'", long12 == 252835200000L);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField3 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis(4, 3, (int) (short) 1, (int) '#', (int) (byte) -1, (int) ' ', 39130100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) 'a', 39130100, (-292274957), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-253144762) + "'", int4 == (-253144762));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType4, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) 'a');
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder0.writeTo("Days", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(1L, (-9223306757136000000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223306757136000001L + "'", long2 == 9223306757136000001L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(39130100, (-1000), (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-900) + "'", int3 == (-900));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationTo(readableInstant4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period10, periodType11, chronology12);
        org.joda.time.PeriodType periodType14 = periodType11.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = periodType14.withSecondsRemoved();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType14);
        java.lang.String str17 = periodType14.toString();
        try {
            org.joda.time.DurationFieldType durationFieldType19 = periodType14.getFieldType(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PeriodType[Seconds]" + "'", str17.equals("PeriodType[Seconds]"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.days();
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(31795200000L, (-62152632132174L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62120836932174L) + "'", long2 == (-62120836932174L));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', periodType3);
        org.joda.time.PeriodType periodType5 = periodType3.withWeeksRemoved();
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) 152917906603501L, periodType3, chronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.lang.String str7 = dateTimeZone5.getName(0L);
//        java.lang.String str9 = dateTimeZone5.getName((long) '4');
//        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone5);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
//        org.joda.time.Chronology chronology16 = iSOChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        long long18 = fixedDateTimeZone15.convertUTCToLocal((long) (short) 0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        boolean boolean21 = fixedDateTimeZone15.isStandardOffset((-230400000L));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-9223372036854775808L), (java.lang.Number) 1529179066035L, (java.lang.Number) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-9223372036854775808L), 9223306757136000001L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -9223372036854775808 * 9223306757136000001");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.Period period2 = new org.joda.time.Period(1560628666035L, (long) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str5 = illegalFieldValueException2.toString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
        org.joda.time.Chronology chronology9 = gregorianChronology0.withUTC();
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance(chronology9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
        boolean boolean17 = fixedDateTimeZone15.isStandardOffset(1560628667826L);
        org.joda.time.LocalDateTime localDateTime18 = null;
        boolean boolean19 = fixedDateTimeZone15.isLocalDateTimeGap(localDateTime18);
        boolean boolean20 = fixedDateTimeZone15.isFixed();
        org.joda.time.Chronology chronology21 = lenientChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        java.util.Locale locale23 = null;
        java.lang.String str24 = fixedDateTimeZone15.getName((long) 0, locale23);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "-00:00:00.001" + "'", str24.equals("-00:00:00.001"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.Period period8 = new org.joda.time.Period(10, 8, (-1000), (-900), 4, 32, (int) (short) 1, 292279090);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
        org.joda.time.Chronology chronology9 = gregorianChronology0.withUTC();
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance(chronology9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
        boolean boolean17 = fixedDateTimeZone15.isStandardOffset(1560628667826L);
        org.joda.time.LocalDateTime localDateTime18 = null;
        boolean boolean19 = fixedDateTimeZone15.isLocalDateTimeGap(localDateTime18);
        boolean boolean20 = fixedDateTimeZone15.isFixed();
        org.joda.time.Chronology chronology21 = lenientChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DurationField durationField22 = lenientChronology10.months();
        java.lang.String str23 = lenientChronology10.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str23.equals("LenientChronology[GregorianChronology[UTC]]"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, chronology6);
        org.joda.time.Period period8 = period2.withFields((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period10 = period8.plusHours(0);
        org.joda.time.Period period12 = period10.minusMinutes(0);
        org.joda.time.Period period14 = period10.withWeeks(4);
        org.joda.time.MutablePeriod mutablePeriod15 = period14.toMutablePeriod();
        try {
            org.joda.time.DurationFieldType durationFieldType17 = period14.getFieldType(39130100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(mutablePeriod15);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.year();
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.lang.String str13 = dateTimeZone11.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.Chronology chronology15 = gregorianChronology0.withZone(dateTimeZone11);
//        org.joda.time.DurationField durationField16 = gregorianChronology0.weeks();
//        java.lang.String str17 = gregorianChronology0.toString();
//        int int18 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology0.hourOfHalfday();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[UTC]" + "'", str17.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long10 = gregorianChronology4.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.Chronology chronology11 = gregorianChronology4.withUTC();
//        java.util.TimeZone timeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
//        java.lang.String str15 = dateTimeZone13.getName(0L);
//        org.joda.time.Chronology chronology16 = gregorianChronology4.withZone(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology4.halfdayOfDay();
//        org.joda.time.Period period18 = new org.joda.time.Period(0L, (long) 39130100, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.Period period19 = new org.joda.time.Period((-210866673600000L), (long) (short) 1, (org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DurationField durationField20 = gregorianChronology4.weeks();
//        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology4.getZone();
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 39130100L + "'", long10 == 39130100L);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) 'a');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray3 = period2.getFieldTypes();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = period2.get(durationFieldType4);
        org.junit.Assert.assertNotNull(durationFieldTypeArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withWeeksRemoved();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.Period period1 = org.joda.time.Period.hours(0);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.Chronology chronology4 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone7 = dateTimeZone6.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone9);
//        java.lang.String str12 = dateTimeZone9.getShortName(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.withMillis(0);
        org.joda.time.Period period5 = period2.toPeriod();
        org.joda.time.Weeks weeks6 = period2.toStandardWeeks();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(weeks6);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.year();
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.lang.String str13 = dateTimeZone11.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.Chronology chronology15 = gregorianChronology0.withZone(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology0.getZone();
//        org.joda.time.DurationField durationField17 = gregorianChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology0.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology0.yearOfEra();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        long long9 = offsetDateTimeField7.roundHalfCeiling((long) (byte) -1);
//        boolean boolean10 = offsetDateTimeField7.isLenient();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField7.getAsShortText((-90L), locale12);
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField7.getAsText(readablePartial14, (-28800000), locale16);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2067" + "'", str13.equals("2067"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-28800000" + "'", str17.equals("-28800000"));
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.millis();
        org.joda.time.DurationField durationField5 = gregorianChronology3.days();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.clockhourOfHalfday();
        boolean boolean7 = iSOChronology2.equals((java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology3.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period4.withMinutes((int) (byte) 1);
        org.joda.time.Period period8 = period6.plusDays(0);
        java.lang.Object obj9 = null;
        boolean boolean10 = period8.equals(obj9);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        java.lang.String str5 = dateTimeZone1.getName((long) '4');
//        long long8 = dateTimeZone1.convertLocalToUTC((-9223306757136000000L), true);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9223306757136000000L) + "'", long8 == (-9223306757136000000L));
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        long long13 = gregorianChronology0.add(readablePeriod10, (long) (-292274957), 39130100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-292274957L) + "'", long13 == (-292274957L));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PeriodType[Time]", (java.lang.Number) 9223306757136000001L, (java.lang.Number) 28800000L, (java.lang.Number) (-62152632132174L));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField5 = gregorianChronology4.millis();
        org.joda.time.DurationField durationField6 = gregorianChronology4.days();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.clockhourOfHalfday();
        boolean boolean8 = iSOChronology3.equals((java.lang.Object) gregorianChronology4);
        org.joda.time.Period period9 = new org.joda.time.Period((-64912579199996L), (org.joda.time.Chronology) iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.Period period1 = org.joda.time.Period.hours(10);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
//        org.joda.time.Chronology chronology9 = gregorianChronology0.withUTC();
//        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance(chronology9);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
//        boolean boolean17 = fixedDateTimeZone15.isStandardOffset(1560628667826L);
//        org.joda.time.LocalDateTime localDateTime18 = null;
//        boolean boolean19 = fixedDateTimeZone15.isLocalDateTimeGap(localDateTime18);
//        boolean boolean20 = fixedDateTimeZone15.isFixed();
//        org.joda.time.Chronology chronology21 = lenientChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        org.joda.time.ReadableInstant readableInstant22 = null;
//        org.joda.time.ReadableInstant readableInstant23 = null;
//        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableInstant23);
//        int[] intArray25 = period24.getValues();
//        org.joda.time.Period period27 = period24.minusHours(0);
//        java.util.TimeZone timeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forTimeZone(timeZone28);
//        java.lang.String str31 = dateTimeZone29.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.weekyear();
//        boolean boolean34 = period27.equals((java.lang.Object) dateTimeField33);
//        int[] intArray36 = lenientChronology10.get((org.joda.time.ReadablePeriod) period27, 39130100L);
//        org.joda.time.DateTimeField dateTimeField37 = lenientChronology10.era();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(lenientChronology10);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Coordinated Universal Time" + "'", str31.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(intArray36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.lang.String str9 = offsetDateTimeField7.getAsText((long) (byte) 100);
//        long long12 = offsetDateTimeField7.add((long) (-28800000), (long) 0);
//        long long15 = offsetDateTimeField7.add((-62179660799996L), 39130100);
//        org.joda.time.DurationField durationField16 = offsetDateTimeField7.getLeapDurationField();
//        org.joda.time.DurationFieldType durationFieldType17 = null;
//        try {
//            org.joda.time.field.DecoratedDurationField decoratedDurationField18 = new org.joda.time.field.DecoratedDurationField(durationField16, durationFieldType17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2067" + "'", str9.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-28800000L) + "'", long12 == (-28800000L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1234764507340800004L + "'", long15 == 1234764507340800004L);
//        org.junit.Assert.assertNotNull(durationField16);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.Period period4 = new org.joda.time.Period(32, 292279090, (int) (short) 0, (int) '4');
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        boolean boolean12 = offsetDateTimeField7.isLeap((long) 4);
//        long long14 = offsetDateTimeField7.roundHalfFloor((-18469890L));
//        org.joda.time.DurationField durationField15 = offsetDateTimeField7.getRangeDurationField();
//        boolean boolean17 = offsetDateTimeField7.isLeap(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200000L) + "'", long14 == (-259200000L));
//        org.junit.Assert.assertNull(durationField15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("PT9.999S", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("UTC");
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        long long14 = offsetDateTimeField7.set(1560628667826L, (int) 'a');
//        java.lang.String str15 = offsetDateTimeField7.toString();
//        long long17 = offsetDateTimeField7.remainder((-210863519999948L));
//        org.joda.time.DurationField durationField18 = offsetDateTimeField7.getDurationField();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62152632132174L) + "'", long14 == (-62152632132174L));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[weekyear]" + "'", str15.equals("DateTimeField[weekyear]"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 259200052L + "'", long17 == 259200052L);
//        org.junit.Assert.assertNotNull(durationField18);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period4.withMinutes((int) (byte) 1);
        org.joda.time.Period period8 = period6.minusSeconds((int) (byte) 100);
        org.joda.time.Period period10 = period8.plusMonths((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period8.toDurationTo(readableInstant11);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration12);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationTo(readableInstant5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) period11, periodType12, chronology13);
        org.joda.time.PeriodType periodType15 = periodType12.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = periodType15.withSecondsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration6, periodType15);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant20, readableDuration21);
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period22, periodType23, chronology24);
        org.joda.time.PeriodType periodType26 = periodType23.withYearsRemoved();
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant27, readableInstant28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) 10, 0L, periodType26, chronology29);
        org.joda.time.Period period31 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6, periodType26);
        long long32 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration6);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-90L) + "'", long32 == (-90L));
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        java.lang.String str4 = dateTimeZone2.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) 'a');
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField8.getAsShortText((long) (byte) 1, locale10);
//        boolean boolean13 = offsetDateTimeField8.isLeap((long) 4);
//        long long15 = offsetDateTimeField8.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField8.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType16, (int) (short) 1, (int) (short) 1, (int) (short) 1);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2067" + "'", str11.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(97);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationTo(readableInstant5);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) -1, chronology8);
        org.joda.time.Period period10 = period4.withFields((org.joda.time.ReadablePeriod) period9);
        org.joda.time.Period period12 = period10.plusHours(0);
        org.joda.time.Duration duration13 = period10.toStandardDuration();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = periodType14.withSecondsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration13, periodType14);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField19 = gregorianChronology18.months();
        try {
            org.joda.time.Period period20 = new org.joda.time.Period((-210863519999948L), periodType14, (org.joda.time.Chronology) gregorianChronology18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -210863519999");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, chronology6);
        org.joda.time.Period period8 = period2.withFields((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period10 = period8.plusHours(0);
        org.joda.time.Period period12 = period10.minusMinutes(0);
        org.joda.time.Period period14 = period10.withWeeks(4);
        org.joda.time.Period period16 = period10.plusDays(8);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        boolean boolean18 = period16.isSupported(durationFieldType17);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.halfdayOfDay();
        org.joda.time.chrono.LenientChronology lenientChronology9 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.hourOfDay();
        org.joda.time.Chronology chronology11 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(lenientChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(chronology11);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.year();
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.lang.String str13 = dateTimeZone11.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.Chronology chronology15 = gregorianChronology0.withZone(dateTimeZone11);
//        org.joda.time.DurationField durationField16 = gregorianChronology0.weeks();
//        java.lang.String str17 = gregorianChronology0.toString();
//        org.joda.time.DurationField durationField18 = gregorianChronology0.seconds();
//        java.lang.String str19 = gregorianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology0.weekyear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[UTC]" + "'", str17.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "GregorianChronology[UTC]" + "'", str19.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField20);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', periodType2);
        org.joda.time.Seconds seconds4 = period3.toStandardSeconds();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(seconds4);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.withMillis(0);
        org.joda.time.Period period5 = period2.toPeriod();
        org.joda.time.format.PeriodFormatter periodFormatter6 = null;
        java.lang.String str7 = period2.toString(periodFormatter6);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0S" + "'", str7.equals("PT0S"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.String str8 = illegalFieldValueException7.getIllegalValueAsString();
        java.lang.String str9 = illegalFieldValueException7.getIllegalValueAsString();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        java.lang.Class<?> wildcardClass11 = illegalFieldValueException2.getClass();
        java.lang.Number number12 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
        org.joda.time.Chronology chronology9 = gregorianChronology0.withUTC();
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance(chronology9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
        boolean boolean17 = fixedDateTimeZone15.isStandardOffset(1560628667826L);
        org.joda.time.LocalDateTime localDateTime18 = null;
        boolean boolean19 = fixedDateTimeZone15.isLocalDateTimeGap(localDateTime18);
        boolean boolean20 = fixedDateTimeZone15.isFixed();
        org.joda.time.Chronology chronology21 = lenientChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DurationField durationField22 = lenientChronology10.months();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone24);
        org.joda.time.Chronology chronology26 = lenientChronology10.withZone(dateTimeZone24);
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler27 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file28 = null;
        java.io.File[] fileArray29 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap30 = zoneInfoCompiler27.compile(file28, fileArray29);
        boolean boolean31 = lenientChronology10.equals((java.lang.Object) file28);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(fileArray29);
        org.junit.Assert.assertNotNull(strMap30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number5 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period4.withMinutes((int) (byte) 1);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.Period period10 = period8.withMillis((int) (short) -1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
        org.joda.time.Chronology chronology9 = gregorianChronology0.withUTC();
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance(chronology9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
        boolean boolean17 = fixedDateTimeZone15.isStandardOffset(1560628667826L);
        org.joda.time.LocalDateTime localDateTime18 = null;
        boolean boolean19 = fixedDateTimeZone15.isLocalDateTimeGap(localDateTime18);
        boolean boolean20 = fixedDateTimeZone15.isFixed();
        org.joda.time.Chronology chronology21 = lenientChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DurationField durationField22 = lenientChronology10.weekyears();
        java.lang.String str23 = lenientChronology10.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str23.equals("LenientChronology[GregorianChronology[UTC]]"));
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.minuteOfHour();
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, (-1), 0, 3);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,3]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        long long12 = offsetDateTimeField7.roundCeiling((long) (byte) -1);
//        java.lang.String str13 = offsetDateTimeField7.toString();
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField7.getAsText(readablePartial14, (int) (byte) 100, locale16);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField7.getLeapDurationField();
//        org.joda.time.DurationFieldType durationFieldType19 = null;
//        try {
//            org.joda.time.field.DecoratedDurationField decoratedDurationField20 = new org.joda.time.field.DecoratedDurationField(durationField18, durationFieldType19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31795200000L + "'", long12 == 31795200000L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[weekyear]" + "'", str13.equals("DateTimeField[weekyear]"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
//        org.junit.Assert.assertNotNull(durationField18);
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        long long14 = offsetDateTimeField7.set(1560628667826L, (int) 'a');
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField7.getAsText((long) (short) 100, locale16);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField7.getDurationField();
//        long long21 = offsetDateTimeField7.getDifferenceAsLong(1L, 10000L);
//        boolean boolean23 = offsetDateTimeField7.isLeap((long) (short) 1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62152632132174L) + "'", long14 == (-62152632132174L));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2067" + "'", str17.equals("2067"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        long long14 = offsetDateTimeField7.set(1560628667826L, (int) 'a');
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField7.getAsText((long) (short) 100, locale16);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField7.getLeapDurationField();
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = offsetDateTimeField7.getAsShortText((long) (short) 1, locale20);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62152632132174L) + "'", long14 == (-62152632132174L));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2067" + "'", str17.equals("2067"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2067" + "'", str21.equals("2067"));
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.String str8 = illegalFieldValueException7.getIllegalValueAsString();
        java.lang.String str9 = illegalFieldValueException7.getIllegalValueAsString();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        java.lang.Number number11 = illegalFieldValueException7.getLowerBound();
        java.lang.Number number12 = illegalFieldValueException7.getIllegalNumberValue();
        java.lang.String str13 = illegalFieldValueException7.getFieldName();
        java.lang.Number number14 = illegalFieldValueException7.getLowerBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(number14);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(1560628667826L);
        long long8 = fixedDateTimeZone4.previousTransition(10L);
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 189302400010L, (java.lang.Number) 1529179066035L, (java.lang.Number) (-62152628954174L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.Chronology chronology4 = iSOChronology3.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone7 = dateTimeZone6.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone14 = dateTimeZone13.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
//        java.util.TimeZone timeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
//        java.lang.String str19 = dateTimeZone17.getName(0L);
//        java.lang.String str21 = dateTimeZone17.getName((long) '4');
//        org.joda.time.Chronology chronology22 = iSOChronology15.withZone(dateTimeZone17);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
//        org.joda.time.Chronology chronology28 = iSOChronology15.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone27);
//        long long30 = fixedDateTimeZone27.convertUTCToLocal((long) (short) 0);
//        long long32 = dateTimeZone11.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone27, 0L);
//        boolean boolean34 = fixedDateTimeZone27.isStandardOffset(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordinated Universal Time" + "'", str19.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Coordinated Universal Time" + "'", str21.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1L) + "'", long30 == (-1L));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        int int12 = offsetDateTimeField7.getLeapAmount((long) (-1));
//        long long15 = offsetDateTimeField7.set((long) (byte) 10, (int) 'a');
//        long long18 = offsetDateTimeField7.add((-90L), (-259200000L));
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        java.lang.String str24 = dateTimeZone22.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) 'a');
//        java.lang.String str30 = offsetDateTimeField28.getAsText((long) (byte) 100);
//        long long33 = offsetDateTimeField28.add(28800000L, (long) 8);
//        org.joda.time.ReadablePartial readablePartial34 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long41 = gregorianChronology35.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.Chronology chronology42 = gregorianChronology35.withUTC();
//        org.joda.time.DurationField durationField43 = gregorianChronology35.seconds();
//        org.joda.time.Chronology chronology44 = gregorianChronology35.withUTC();
//        org.joda.time.chrono.LenientChronology lenientChronology45 = org.joda.time.chrono.LenientChronology.getInstance(chronology44);
//        org.joda.time.DateTimeField dateTimeField46 = lenientChronology45.clockhourOfDay();
//        org.joda.time.Chronology chronology48 = null;
//        org.joda.time.Period period49 = new org.joda.time.Period((long) (short) -1, chronology48);
//        org.joda.time.Period period51 = period49.withSeconds((int) (short) 10);
//        org.joda.time.Period period53 = period51.minusDays((int) (byte) 0);
//        int[] intArray55 = lenientChronology45.get((org.joda.time.ReadablePeriod) period53, (long) (short) 100);
//        int int56 = offsetDateTimeField28.getMaximumValue(readablePartial34, intArray55);
//        try {
//            int[] intArray58 = offsetDateTimeField7.addWrapField(readablePartial19, 100, intArray55, (-292274957));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62166787199990L) + "'", long15 == (-62166787199990L));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-8179561958400000090L) + "'", long18 == (-8179561958400000090L));
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Coordinated Universal Time" + "'", str24.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2067" + "'", str30.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 252835200000L + "'", long33 == 252835200000L);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 39130100L + "'", long41 == 39130100L);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(chronology44);
//        org.junit.Assert.assertNotNull(lenientChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(period51);
//        org.junit.Assert.assertNotNull(period53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 292279090 + "'", int56 == 292279090);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.ReadablePartial readablePartial4 = null;
        int[] intArray5 = null;
        try {
            gregorianChronology0.validate(readablePartial4, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period2.withMinutes((int) (short) 10);
        int int7 = period6.getMonths();
        int int8 = period6.getMinutes();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationTo(readableInstant5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) period11, periodType12, chronology13);
        org.joda.time.PeriodType periodType15 = periodType12.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = periodType15.withSecondsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration6, periodType15);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant20, readableDuration21);
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period22, periodType23, chronology24);
        org.joda.time.PeriodType periodType26 = periodType23.withYearsRemoved();
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant27, readableInstant28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) 10, 0L, periodType26, chronology29);
        org.joda.time.Period period31 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration6, periodType26);
        try {
            org.joda.time.Period period33 = period31.withMinutes(6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(chronology29);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period2.withMinutes((int) (short) 10);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period6.get(durationFieldType7);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.joda.time.PeriodType periodType2 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone5 = dateTimeZone4.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        java.lang.String str10 = dateTimeZone8.getName(0L);
//        java.lang.String str12 = dateTimeZone8.getName((long) '4');
//        org.joda.time.Chronology chronology13 = iSOChronology6.withZone(dateTimeZone8);
//        org.joda.time.Period period14 = new org.joda.time.Period((long) 2066, (long) 1, periodType2, (org.joda.time.Chronology) iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology13);
//    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.lang.String str9 = offsetDateTimeField7.getAsText((long) (byte) 100);
//        long long12 = offsetDateTimeField7.add((long) (-28800000), (long) 0);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = offsetDateTimeField7.getAsShortText((int) (byte) -1, locale14);
//        boolean boolean16 = offsetDateTimeField7.isLenient();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2067" + "'", str9.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-28800000L) + "'", long12 == (-28800000L));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1" + "'", str15.equals("-1"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
//        org.joda.time.Chronology chronology9 = gregorianChronology0.withUTC();
//        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance(chronology9);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
//        boolean boolean17 = fixedDateTimeZone15.isStandardOffset(1560628667826L);
//        org.joda.time.LocalDateTime localDateTime18 = null;
//        boolean boolean19 = fixedDateTimeZone15.isLocalDateTimeGap(localDateTime18);
//        boolean boolean20 = fixedDateTimeZone15.isFixed();
//        org.joda.time.Chronology chronology21 = lenientChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        org.joda.time.ReadableInstant readableInstant22 = null;
//        org.joda.time.ReadableInstant readableInstant23 = null;
//        org.joda.time.Period period24 = new org.joda.time.Period(readableInstant22, readableInstant23);
//        int[] intArray25 = period24.getValues();
//        org.joda.time.Period period27 = period24.minusHours(0);
//        java.util.TimeZone timeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forTimeZone(timeZone28);
//        java.lang.String str31 = dateTimeZone29.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.weekyear();
//        boolean boolean34 = period27.equals((java.lang.Object) dateTimeField33);
//        int[] intArray36 = lenientChronology10.get((org.joda.time.ReadablePeriod) period27, 39130100L);
//        org.joda.time.DateTimeField dateTimeField37 = lenientChronology10.minuteOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(lenientChronology10);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertNotNull(period27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Coordinated Universal Time" + "'", str31.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(intArray36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(8);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.Period period2 = new org.joda.time.Period((-28800000L), 96L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = iSOChronology3.withUTC();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.era();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        long long9 = offsetDateTimeField7.roundHalfCeiling((long) (byte) -1);
//        org.joda.time.ReadablePartial readablePartial10 = null;
//        int[] intArray13 = new int[] { (-1), 292279090 };
//        int int14 = offsetDateTimeField7.getMinimumValue(readablePartial10, intArray13);
//        java.lang.String str15 = offsetDateTimeField7.getName();
//        java.util.Locale locale16 = null;
//        int int17 = offsetDateTimeField7.getMaximumShortTextLength(locale16);
//        try {
//            long long20 = offsetDateTimeField7.set((long) (-28800000), "PT-1M");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PT-1M\" for weekyear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292274957) + "'", int14 == (-292274957));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "weekyear" + "'", str15.equals("weekyear"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PT0S", (java.lang.Number) 62166787199989999L, (java.lang.Number) (byte) -1, (java.lang.Number) 8);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
        org.joda.time.Chronology chronology9 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField10 = gregorianChronology0.weekyears();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField13 = new org.joda.time.field.ScaledDurationField(durationField10, durationFieldType11, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        java.lang.String str3 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        boolean boolean12 = offsetDateTimeField7.isLeap((long) 4);
//        long long14 = offsetDateTimeField7.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField7.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, (int) (short) 1, (int) (short) 1, (int) (short) 1);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, (int) (byte) 100, 292279090, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekyear must be in the range [292279090,-1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200000L) + "'", long14 == (-259200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        java.lang.String str11 = dateTimeZone9.getName(0L);
//        org.joda.time.Chronology chronology12 = gregorianChronology0.withZone(dateTimeZone9);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
//        boolean boolean19 = fixedDateTimeZone17.isStandardOffset(1560628667826L);
//        org.joda.time.LocalDateTime localDateTime20 = null;
//        boolean boolean21 = fixedDateTimeZone17.isLocalDateTimeGap(localDateTime20);
//        long long23 = fixedDateTimeZone17.nextTransition((long) (short) 0);
//        org.joda.time.Chronology chronology24 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone17);
//        int int26 = fixedDateTimeZone17.getOffset((long) (short) 1);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField7.getAsShortText((-1000), locale12);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1000" + "'", str13.equals("-1000"));
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) (-9223372036854775808L), (java.lang.Number) 100.0f, (java.lang.Number) 2458650.3317828127d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        java.lang.String str3 = gregorianChronology0.toString();
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            long long6 = gregorianChronology0.set(readablePartial4, 1001L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period2.withMinutes((int) (short) 10);
        int int7 = period6.getMonths();
        org.joda.time.Period period9 = period6.withSeconds(4);
        org.joda.time.Period period11 = period6.minusMonths((int) (short) 100);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 110L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period4.withMinutes((int) (byte) 1);
        int[] intArray7 = period4.getValues();
        org.joda.time.Period period9 = period4.minusHours(800);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2066");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long8 = gregorianChronology2.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.minuteOfHour();
        org.joda.time.Period period11 = new org.joda.time.Period((long) 97, periodType1, (org.joda.time.Chronology) gregorianChronology2);
        try {
            org.joda.time.Period period13 = period11.plusMillis(4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 39130100L + "'", long8 == 39130100L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(1560628667826L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str9 = fixedDateTimeZone4.getName(1234826687606400003L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-00:00:00.001" + "'", str9.equals("-00:00:00.001"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period4.withMinutes((int) (byte) 1);
        org.joda.time.MutablePeriod mutablePeriod7 = period4.toMutablePeriod();
        org.joda.time.Minutes minutes8 = period4.toStandardMinutes();
        org.joda.time.Period period9 = period4.toPeriod();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(mutablePeriod7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) 0, chronology1);
        org.joda.time.Period period4 = period2.withMillis(0);
        org.joda.time.Period period5 = period2.toPeriod();
        org.joda.time.Period period7 = period2.plusSeconds(2066);
        org.joda.time.Period period9 = period7.minusYears((int) (byte) 0);
        org.joda.time.DurationFieldType[] durationFieldTypeArray10 = period7.getFieldTypes();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(durationFieldTypeArray10);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
        org.joda.time.Chronology chronology9 = gregorianChronology0.withUTC();
        org.joda.time.chrono.LenientChronology lenientChronology10 = org.joda.time.chrono.LenientChronology.getInstance(chronology9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
        boolean boolean17 = fixedDateTimeZone15.isStandardOffset(1560628667826L);
        org.joda.time.LocalDateTime localDateTime18 = null;
        boolean boolean19 = fixedDateTimeZone15.isLocalDateTimeGap(localDateTime18);
        boolean boolean20 = fixedDateTimeZone15.isFixed();
        org.joda.time.Chronology chronology21 = lenientChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.Chronology chronology22 = lenientChronology10.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(lenientChronology10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.Period period8 = new org.joda.time.Period(0, 10, 100, 0, (int) (short) 0, 0, (int) (byte) 0, (int) ' ');
        org.joda.time.Period period10 = period8.withYears((-1));
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period8.toDurationFrom(readableInstant11);
        org.joda.time.Period period14 = period8.withHours((int) 'a');
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(period14);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.lang.String str9 = offsetDateTimeField7.getAsText((long) (byte) 100);
//        java.lang.String str10 = offsetDateTimeField7.getName();
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        int int12 = offsetDateTimeField7.getMaximumValue(readablePartial11);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2067" + "'", str9.equals("2067"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "weekyear" + "'", str10.equals("weekyear"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 292279090 + "'", int12 == 292279090);
//    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        int int12 = offsetDateTimeField7.getLeapAmount((long) (-1));
//        long long15 = offsetDateTimeField7.set((long) (byte) 10, (int) 'a');
//        long long18 = offsetDateTimeField7.add(1560628666035L, (-1));
//        long long20 = offsetDateTimeField7.roundCeiling((-64912579199996L));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62166787199990L) + "'", long15 == (-62166787199990L));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1529179066035L + "'", long18 == 1529179066035L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-64881388800000L) + "'", long20 == (-64881388800000L));
//    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        boolean boolean12 = offsetDateTimeField7.isLeap((long) 4);
//        java.lang.String str14 = offsetDateTimeField7.getAsText(28800000L);
//        int int16 = offsetDateTimeField7.get((long) (-292274957));
//        java.util.TimeZone timeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
//        java.lang.String str20 = dateTimeZone18.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) 'a');
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = offsetDateTimeField24.getAsShortText((long) (byte) 1, locale26);
//        boolean boolean29 = offsetDateTimeField24.isLeap((long) 4);
//        long long31 = offsetDateTimeField24.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField24.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType32, (int) (short) 10, 0, 0);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType32, 100, (int) (short) 0, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekyear must be in the range [0,10]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2067" + "'", str14.equals("2067"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2066 + "'", int16 == 2066);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2067" + "'", str27.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-259200000L) + "'", long31 == (-259200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.Period period6 = period2.minusHours(0);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        long long8 = gregorianChronology4.add((long) (byte) 1, 1529179066035L, (int) (short) 100);
        boolean boolean10 = gregorianChronology4.equals((java.lang.Object) 800);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 152917906603501L + "'", long8 == 152917906603501L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        java.lang.String str7 = dateTimeZone1.getShortName(31795200000L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        long long8 = dateTimeZone4.convertLocalToUTC(189302400010L, true, 1560628666035L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 189302400010L + "'", long8 == 189302400010L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.Period period8 = new org.joda.time.Period((int) 'a', 100, (int) (byte) 0, (int) 'a', (int) ' ', (int) (byte) 100, 1, 1);
        try {
            org.joda.time.Minutes minutes9 = period8.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(1560628667826L);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        long long10 = fixedDateTimeZone4.nextTransition((long) (short) 0);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.TimeZone timeZone12 = fixedDateTimeZone4.toTimeZone();
        boolean boolean13 = fixedDateTimeZone4.isFixed();
        java.util.Locale locale15 = null;
        java.lang.String str16 = fixedDateTimeZone4.getName((long) (-28800000), locale15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-00:00:00.001" + "'", str16.equals("-00:00:00.001"));
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        long long12 = offsetDateTimeField7.roundCeiling((long) (byte) -1);
//        java.lang.String str13 = offsetDateTimeField7.toString();
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField7.getAsText(readablePartial14, (int) (byte) 100, locale16);
//        int int19 = offsetDateTimeField7.getMaximumValue(0L);
//        java.util.Locale locale20 = null;
//        int int21 = offsetDateTimeField7.getMaximumShortTextLength(locale20);
//        org.joda.time.DurationField durationField22 = offsetDateTimeField7.getLeapDurationField();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31795200000L + "'", long12 == 31795200000L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[weekyear]" + "'", str13.equals("DateTimeField[weekyear]"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 292279090 + "'", int19 == 292279090);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
//        org.junit.Assert.assertNotNull(durationField22);
//    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.TimeZone timeZone4 = dateTimeZone3.toTimeZone();
//        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) dateTimeZone3);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone3.getName((long) ' ', locale7);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.year();
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.lang.String str13 = dateTimeZone11.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.Chronology chronology15 = gregorianChronology0.withZone(dateTimeZone11);
//        org.joda.time.DurationField durationField16 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology0.weekyearOfCentury();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, chronology6);
        org.joda.time.Period period8 = period2.withFields((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period10 = period8.plusHours(0);
        org.joda.time.Period period12 = period8.withHours((int) (byte) 100);
        org.joda.time.Period period14 = period8.withMillis(292279090);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        java.lang.String str3 = dateTimeZone1.getName((long) (short) 0);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone1.isLocalDateTimeGap(localDateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.052" + "'", str3.equals("+00:00:00.052"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.lang.String str7 = dateTimeZone5.getName(0L);
//        java.lang.String str9 = dateTimeZone5.getName((long) '4');
//        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone5);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
//        org.joda.time.Chronology chronology16 = iSOChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        java.lang.String str18 = fixedDateTimeZone15.getNameKey(1560628666035L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Coordinated Universal Time" + "'", str18.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, chronology6);
        org.joda.time.Period period8 = period2.withFields((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period10 = period8.plusHours(0);
        org.joda.time.Period period12 = period10.minusMinutes(0);
        org.joda.time.Period period14 = period10.withWeeks(4);
        org.joda.time.DurationFieldType durationFieldType15 = null;
        try {
            org.joda.time.Period period17 = period14.withField(durationFieldType15, 1000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        long long12 = offsetDateTimeField7.roundCeiling((long) (byte) -1);
//        java.lang.String str13 = offsetDateTimeField7.toString();
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField7.getAsText(readablePartial14, (int) (byte) 100, locale16);
//        int int18 = offsetDateTimeField7.getMaximumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31795200000L + "'", long12 == 31795200000L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[weekyear]" + "'", str13.equals("DateTimeField[weekyear]"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292279090 + "'", int18 == 292279090);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) 1);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        long long14 = offsetDateTimeField7.set(1560628667826L, (int) 'a');
//        java.lang.String str15 = offsetDateTimeField7.toString();
//        long long17 = offsetDateTimeField7.roundHalfCeiling((long) 800);
//        boolean boolean18 = offsetDateTimeField7.isSupported();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62152632132174L) + "'", long14 == (-62152632132174L));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[weekyear]" + "'", str15.equals("DateTimeField[weekyear]"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-259200000L) + "'", long17 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        try {
            org.joda.time.Period period4 = new org.joda.time.Period((java.lang.Object) zoneInfoCompiler0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.ZoneInfoCompiler");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 1);
        org.joda.time.DurationField durationField3 = gregorianChronology2.days();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.weekyear();
        try {
            long long10 = gregorianChronology2.getDateTimeMillis(0, 100, 10, 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.lang.String str9 = offsetDateTimeField7.getAsText((long) (byte) 100);
//        long long12 = offsetDateTimeField7.add((long) (-28800000), (long) 0);
//        long long15 = offsetDateTimeField7.add((-62179660799996L), 39130100);
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        int int17 = offsetDateTimeField7.getMinimumValue(readablePartial16);
//        java.util.Locale locale20 = null;
//        try {
//            long long21 = offsetDateTimeField7.set(10000L, "PT1M9.999S", locale20);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PT1M9.999S\" for weekyear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2067" + "'", str9.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-28800000L) + "'", long12 == (-28800000L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1234764507340800004L + "'", long15 == 1234764507340800004L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-292274957) + "'", int17 == (-292274957));
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(3, (-253144762), (-253144762));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.String str7 = illegalFieldValueException6.getIllegalValueAsString();
        java.lang.String str8 = illegalFieldValueException6.getIllegalValueAsString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.String str12 = illegalFieldValueException11.getIllegalValueAsString();
        java.lang.String str13 = illegalFieldValueException11.getIllegalValueAsString();
        illegalFieldValueException6.addSuppressed((java.lang.Throwable) illegalFieldValueException11);
        illegalFieldValueException11.prependMessage("weekyear");
        boolean boolean17 = iSOChronology3.equals((java.lang.Object) "weekyear");
        java.lang.String str18 = iSOChronology3.toString();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology3.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ISOChronology[UTC]" + "'", str18.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.year();
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.lang.String str13 = dateTimeZone11.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.Chronology chronology15 = gregorianChronology0.withZone(dateTimeZone11);
//        org.joda.time.DurationField durationField16 = gregorianChronology0.weeks();
//        java.lang.String str17 = gregorianChronology0.toString();
//        int int18 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology0.weekyearOfCentury();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GregorianChronology[UTC]" + "'", str17.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(1560628667826L);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        boolean boolean11 = fixedDateTimeZone4.equals((java.lang.Object) 8);
        long long13 = fixedDateTimeZone4.nextTransition(292279090L);
        long long16 = fixedDateTimeZone4.convertLocalToUTC((long) '#', false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292279090L + "'", long13 == 292279090L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 36L + "'", long16 == 36L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Minutes minutes3 = period2.toStandardMinutes();
        org.junit.Assert.assertNotNull(minutes3);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis((int) '#', (-39128121), 3, (-900), 0, (int) (byte) 100, 1000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -900 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getMinimumValue((-18470620L));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-292274957) + "'", int9 == (-292274957));
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset(1560628667826L);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime7);
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        long long13 = fixedDateTimeZone4.convertLocalToUTC((long) 97, false, 10L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 98L + "'", long13 == 98L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("PT1M9.999S", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Days days3 = period2.toStandardDays();
        int int5 = period2.getValue((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        boolean boolean7 = period2.isSupported(durationFieldType6);
        org.joda.time.Duration duration8 = period2.toStandardDuration();
        org.junit.Assert.assertNotNull(days3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(duration8);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, chronology6);
        org.joda.time.Period period8 = period2.withFields((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period10 = period8.plusHours(0);
        org.joda.time.Period period12 = period10.minusMinutes(0);
        org.joda.time.Period period14 = period10.withWeeks(4);
        org.joda.time.Period period16 = period10.plusDays(8);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        try {
            org.joda.time.Period period19 = period16.withField(durationFieldType17, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(252547200000L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("PT1M9.999S");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.lang.String str3 = jodaTimePermission1.getName();
        jodaTimePermission1.checkGuard((java.lang.Object) (-292274957));
        java.lang.String str6 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PT1M9.999S" + "'", str3.equals("PT1M9.999S"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"PT1M9.999S\")" + "'", str6.equals("(\"org.joda.time.JodaTimePermission\" \"PT1M9.999S\")"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) 'a');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period2.withMinutes((int) (short) 10);
        org.joda.time.Period period8 = period6.withHours((int) (short) 1);
        org.joda.time.Duration duration9 = period8.toStandardDuration();
        org.joda.time.DurationFieldType[] durationFieldTypeArray10 = period8.getFieldTypes();
        int int11 = period8.size();
        org.joda.time.Period period13 = period8.minusYears((int) 'a');
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(durationFieldTypeArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertNotNull(period13);
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        boolean boolean12 = offsetDateTimeField7.isLeap((long) 4);
//        org.joda.time.DurationField durationField13 = offsetDateTimeField7.getLeapDurationField();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("+00:00:00.010", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+00:00:00.010/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.days();
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField8 = new org.joda.time.field.ScaledDurationField(durationField5, durationFieldType6, 292279090);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.Period period4 = period2.withMonths(6);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long11 = gregorianChronology5.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology5.yearOfEra();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology5.minuteOfHour();
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) period2, (org.joda.time.Chronology) gregorianChronology5);
        try {
            long long19 = gregorianChronology5.getDateTimeMillis(4, 292279090, 0, 2066);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279090 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 39130100L + "'", long11 == 39130100L);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.lang.String str9 = offsetDateTimeField7.getAsText((long) (byte) 100);
//        long long12 = offsetDateTimeField7.add(28800000L, (long) 8);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableInstant16);
//        int[] intArray18 = period17.getValues();
//        try {
//            int[] intArray20 = offsetDateTimeField7.add(readablePartial13, (int) (byte) 100, intArray18, (int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2067" + "'", str9.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 252835200000L + "'", long12 == 252835200000L);
//        org.junit.Assert.assertNotNull(intArray18);
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            long long6 = gregorianChronology0.set(readablePartial4, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.joda.time.DateTimeField dateTimeField0 = null;
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        java.lang.String str4 = dateTimeZone2.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) 'a');
//        java.lang.String str10 = offsetDateTimeField8.getAsText((long) (byte) 100);
//        java.lang.String str11 = offsetDateTimeField8.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField8.getType();
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType12, (-1), (int) (short) 1, (-292274957));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "weekyear" + "'", str11.equals("weekyear"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("weekyear", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"weekyear/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.secondOfMinute();
        try {
            long long16 = gregorianChronology0.getDateTimeMillis((int) (byte) 1, 9, (int) (byte) 10, 0, (-1), (-28800000), 32);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, chronology1);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        int int12 = offsetDateTimeField7.getLeapAmount((long) (-1));
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = offsetDateTimeField7.getAsText((long) 100, locale14);
//        java.lang.String str17 = offsetDateTimeField7.getAsText((-210863779200000L));
//        boolean boolean19 = offsetDateTimeField7.isLeap((long) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial20 = null;
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        java.lang.String str25 = dateTimeZone23.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, (int) 'a');
//        long long31 = offsetDateTimeField29.roundHalfCeiling((long) (byte) -1);
//        org.joda.time.ReadablePartial readablePartial32 = null;
//        int[] intArray35 = new int[] { (-1), 292279090 };
//        int int36 = offsetDateTimeField29.getMinimumValue(readablePartial32, intArray35);
//        try {
//            int[] intArray38 = offsetDateTimeField7.addWrapField(readablePartial20, 97, intArray35, (-253144762));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2067" + "'", str15.equals("2067"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-4615" + "'", str17.equals("-4615"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Coordinated Universal Time" + "'", str25.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-259200000L) + "'", long31 == (-259200000L));
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-292274957) + "'", int36 == (-292274957));
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiply((-292274957), 292279090);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows an int: -292274957 * 292279090");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        java.lang.String str2 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.Period period4 = new org.joda.time.Period(9, (int) (short) 100, 6, 100);
        org.joda.time.format.PeriodFormatter periodFormatter5 = null;
        java.lang.String str6 = period4.toString(periodFormatter5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT9H100M6.100S" + "'", str6.equals("PT9H100M6.100S"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Days days3 = period2.toStandardDays();
        org.joda.time.Period period5 = period2.minusMinutes(0);
        org.joda.time.Duration duration6 = period2.toStandardDuration();
        org.junit.Assert.assertNotNull(days3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration6);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("100", "2067");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2067" + "'", str4.equals("2067"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "-00:00:00.001");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
//        java.util.TimeZone timeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
//        java.lang.String str6 = dateTimeZone4.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) 'a');
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField10.getAsShortText((long) (byte) 1, locale12);
//        boolean boolean15 = offsetDateTimeField10.isLeap((long) 4);
//        long long17 = offsetDateTimeField10.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField10.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported");
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType18, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2067" + "'", str13.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-259200000L) + "'", long17 == (-259200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 1101L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210771633600000L) + "'", long1 == (-210771633600000L));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.util.TimeZone timeZone7 = dateTimeZone6.toTimeZone();
        long long9 = dateTimeZone3.getMillisKeepLocal(dateTimeZone6, 152917906603501L);
        long long13 = dateTimeZone6.convertLocalToUTC((-65228284799903L), true, (long) 292279090);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 152917906603501L + "'", long9 == 152917906603501L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-65228284799903L) + "'", long13 == (-65228284799903L));
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        long long14 = offsetDateTimeField7.set(1560628667826L, (int) 'a');
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField7.getAsText((long) (short) 100, locale16);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField7.getDurationField();
//        long long21 = offsetDateTimeField7.getDifferenceAsLong(1L, 10000L);
//        long long24 = offsetDateTimeField7.add((long) 3, (long) 4);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62152632132174L) + "'", long14 == (-62152632132174L));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2067" + "'", str17.equals("2067"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 126403200003L + "'", long24 == 126403200003L);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.Period period8 = new org.joda.time.Period(1, 0, (int) (byte) 1, (int) (short) 0, 292279090, 9, (int) (short) 100, 100);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.minusMinutes(0);
        org.joda.time.Period period6 = period2.minusDays((int) (short) 1);
        org.joda.time.Period period8 = period2.plusMinutes(32);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant1, readableDuration2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) period3, periodType4, chronology5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.millis();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.secondOfDay();
        org.joda.time.Period period10 = new org.joda.time.Period((-1L), periodType4, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology7.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.centuryOfEra();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant3, readableDuration4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) period5, periodType6, chronology7);
        org.joda.time.PeriodType periodType9 = periodType6.withMillisRemoved();
        boolean boolean10 = gregorianChronology2.equals((java.lang.Object) periodType6);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.lang.String str9 = offsetDateTimeField7.getAsText((long) (byte) 100);
//        long long12 = offsetDateTimeField7.add((long) (-28800000), (long) 0);
//        long long15 = offsetDateTimeField7.add((-62179660799996L), 39130100);
//        long long18 = offsetDateTimeField7.add((long) (byte) 10, (long) 6);
//        try {
//            long long21 = offsetDateTimeField7.set((long) (-1), "LenientChronology[GregorianChronology[UTC]]");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"LenientChronology[GregorianChronology[UTC]]\" for weekyear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2067" + "'", str9.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-28800000L) + "'", long12 == (-28800000L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1234764507340800004L + "'", long15 == 1234764507340800004L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 189302400010L + "'", long18 == 189302400010L);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = iSOChronology3.withUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.util.TimeZone timeZone7 = dateTimeZone6.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology3.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) 1, (-210866673600000L), (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = period4.indexOf(durationFieldType5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType8 = periodType7.withWeeksRemoved();
        try {
            org.joda.time.Period period9 = period4.withPeriodType(periodType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        java.lang.String str5 = dateTimeZone3.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.weekyear();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.era();
//        org.joda.time.Period period9 = new org.joda.time.Period((-259200000L), (long) (-292274957), (org.joda.time.Chronology) gregorianChronology6);
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.lang.String str13 = dateTimeZone11.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone11);
//        org.joda.time.DurationField durationField17 = zonedChronology16.millis();
//        try {
//            long long22 = zonedChronology16.getDateTimeMillis((-39128121), (int) (byte) 0, 292279090, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(zonedChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = gregorianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.Period period1 = org.joda.time.Period.days(1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, chronology6);
        org.joda.time.Period period8 = period2.withFields((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period10 = period8.plusHours(0);
        org.joda.time.Period period12 = period10.minusMinutes(0);
        org.joda.time.Period period14 = period10.plusSeconds((-28800000));
        org.joda.time.Period period16 = period10.plusHours(10);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((long) (short) -1, chronology18);
        org.joda.time.Period period21 = period19.withSeconds((int) (short) 10);
        org.joda.time.Period period23 = period21.withMinutes((int) (byte) 1);
        org.joda.time.Period period25 = period23.plusDays(0);
        org.joda.time.Period period26 = period16.minus((org.joda.time.ReadablePeriod) period23);
        org.joda.time.Period period28 = period23.minusMonths((-1000));
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period3 = period2.toPeriod();
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(9676800048L, (long) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 87091200432");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 36L, (java.lang.Number) (-65199988800000L), (java.lang.Number) (-65199988800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance(chronology2);
        org.joda.time.DateTimeField dateTimeField4 = lenientChronology3.hourOfDay();
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        long long9 = offsetDateTimeField7.roundHalfCeiling((long) (byte) -1);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField7.getAsShortText(28800009L, locale11);
//        java.lang.String str14 = offsetDateTimeField7.getAsText(1560628666035L);
//        long long16 = offsetDateTimeField7.roundHalfEven((long) 'a');
//        try {
//            long long19 = offsetDateTimeField7.add(259199910L, 189302400010L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 189302400010");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2067" + "'", str12.equals("2067"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2116" + "'", str14.equals("2116"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200000L) + "'", long16 == (-259200000L));
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.Period period8 = new org.joda.time.Period((int) 'a', 100, (int) (byte) 0, (int) 'a', (int) ' ', (int) (byte) 100, 1, 1);
        org.joda.time.Period period10 = period8.minusMonths(100);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType12 = periodType11.withWeeksRemoved();
        org.joda.time.PeriodType periodType13 = periodType12.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.util.TimeZone timeZone16 = dateTimeZone15.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        long long22 = gregorianChronology18.add((long) (byte) 1, 1529179066035L, (int) (short) 100);
        org.joda.time.DurationField durationField23 = gregorianChronology18.weekyears();
        try {
            org.joda.time.Period period24 = new org.joda.time.Period((java.lang.Object) 100, periodType12, (org.joda.time.Chronology) gregorianChronology18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 152917906603501L + "'", long22 == 152917906603501L);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.Period period1 = org.joda.time.Period.days(4);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.Period period2 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Duration duration4 = period2.toDurationTo(readableInstant3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, chronology6);
        org.joda.time.Period period8 = period2.withFields((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period10 = period8.plusHours(0);
        org.joda.time.Period period12 = period10.minusMinutes(0);
        org.joda.time.Period period14 = period10.withWeeks(4);
        org.joda.time.Period period16 = period10.plusDays(8);
        org.joda.time.Period period18 = period10.minusSeconds((int) (byte) 1);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(readableInterval4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.halfdayOfDay();
        try {
            long long13 = gregorianChronology0.getDateTimeMillis((-28800000), 6, (int) (byte) 10, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        int int5 = period4.size();
        org.joda.time.Period period7 = period4.plusMillis(8);
        int int8 = period4.getWeeks();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.Period period1 = org.joda.time.Period.parse("PT0S");
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        boolean boolean12 = offsetDateTimeField7.isLeap((long) 4);
//        long long14 = offsetDateTimeField7.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField7.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, (int) (short) 1, (int) (short) 1, (int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long26 = gregorianChronology20.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology20.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology20.minuteOfHour();
//        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DurationField durationField30 = gregorianChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField30);
//        org.joda.time.ReadablePartial readablePartial32 = null;
//        org.joda.time.ReadableInstant readableInstant34 = null;
//        org.joda.time.ReadableInstant readableInstant35 = null;
//        org.joda.time.Period period36 = new org.joda.time.Period(readableInstant34, readableInstant35);
//        int[] intArray37 = period36.getValues();
//        try {
//            int[] intArray39 = unsupportedDateTimeField31.set(readablePartial32, (int) (byte) -1, intArray37, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200000L) + "'", long14 == (-259200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 39130100L + "'", long26 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertNotNull(intArray37);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        boolean boolean12 = offsetDateTimeField7.isLeap((long) 4);
//        long long14 = offsetDateTimeField7.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField7.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, (int) (short) 1, (int) (short) 1, (int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long26 = gregorianChronology20.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology20.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology20.minuteOfHour();
//        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DurationField durationField30 = gregorianChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField30);
//        boolean boolean32 = unsupportedDateTimeField31.isLenient();
//        try {
//            long long34 = unsupportedDateTimeField31.remainder((long) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200000L) + "'", long14 == (-259200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 39130100L + "'", long26 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.year();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.millisOfSecond();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "GregorianChronology[UTC]", (int) (byte) 10, 0);
        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        java.lang.String str18 = fixedDateTimeZone15.getNameKey(1234764507340800004L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "GregorianChronology[UTC]" + "'", str18.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period2.withMinutes((int) (short) 10);
        org.joda.time.Period period8 = period6.withMonths(0);
        org.joda.time.Hours hours9 = period8.toStandardHours();
        int int10 = period8.getDays();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(hours9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        boolean boolean12 = offsetDateTimeField7.isLeap((long) 4);
//        long long14 = offsetDateTimeField7.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField7.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, (int) (short) 1, (int) (short) 1, (int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long26 = gregorianChronology20.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology20.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology20.minuteOfHour();
//        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DurationField durationField30 = gregorianChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField30);
//        boolean boolean32 = unsupportedDateTimeField31.isLenient();
//        org.joda.time.ReadablePartial readablePartial33 = null;
//        try {
//            int int34 = unsupportedDateTimeField31.getMinimumValue(readablePartial33);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200000L) + "'", long14 == (-259200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 39130100L + "'", long26 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        boolean boolean12 = offsetDateTimeField7.isLeap((long) 4);
//        long long14 = offsetDateTimeField7.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField7.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, (int) (short) 1, (int) (short) 1, (int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long26 = gregorianChronology20.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology20.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology20.minuteOfHour();
//        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DurationField durationField30 = gregorianChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField30);
//        try {
//            long long33 = unsupportedDateTimeField31.roundHalfEven(28800000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200000L) + "'", long14 == (-259200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 39130100L + "'", long26 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.lang.String str9 = offsetDateTimeField7.getAsText((long) (byte) 100);
//        long long11 = offsetDateTimeField7.roundCeiling((-18469900L));
//        long long13 = offsetDateTimeField7.roundHalfEven((long) '4');
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        java.lang.String str17 = dateTimeZone15.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) 'a');
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField21.getAsShortText((long) (byte) 1, locale23);
//        boolean boolean26 = offsetDateTimeField21.isLeap((long) 4);
//        long long28 = offsetDateTimeField21.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField21.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType29, (int) (short) 1, (int) (short) 1, (int) (short) 1);
//        boolean boolean34 = org.joda.time.field.FieldUtils.equals((java.lang.Object) '4', (java.lang.Object) (short) 1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2067" + "'", str9.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31795200000L + "'", long11 == 31795200000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-259200000L) + "'", long13 == (-259200000L));
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Coordinated Universal Time" + "'", str17.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2067" + "'", str24.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-259200000L) + "'", long28 == (-259200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) 'a');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setFixedSavings("org.joda.time.IllegalFieldValueException: Value \"hi!\" for  is not supported", (int) '4');
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addCutover(9, '4', 1, 0, (int) ' ', true, (-292274957));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        boolean boolean12 = offsetDateTimeField7.isLeap((long) 4);
//        long long14 = offsetDateTimeField7.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField7.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, (int) (short) 1, (int) (short) 1, (int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long26 = gregorianChronology20.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology20.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology20.minuteOfHour();
//        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DurationField durationField30 = gregorianChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField30);
//        org.joda.time.ReadablePartial readablePartial32 = null;
//        try {
//            int int33 = unsupportedDateTimeField31.getMaximumValue(readablePartial32);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200000L) + "'", long14 == (-259200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 39130100L + "'", long26 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("PeriodType[Time]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PeriodType[Time]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("ZonedChronology[GregorianChronology[UTC], UTC]", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        int int14 = offsetDateTimeField7.getDifference(10000L, (long) (byte) -1);
//        long long16 = offsetDateTimeField7.roundHalfFloor(0L);
//        boolean boolean17 = offsetDateTimeField7.isSupported();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200000L) + "'", long16 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.secondOfDay();
//        java.util.TimeZone timeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
//        java.lang.String str14 = dateTimeZone12.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) 'a');
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = offsetDateTimeField18.getAsShortText((long) (byte) 1, locale20);
//        boolean boolean23 = offsetDateTimeField18.isLeap((long) 4);
//        java.lang.String str25 = offsetDateTimeField18.getAsText(28800000L);
//        int int27 = offsetDateTimeField18.get((long) (-292274957));
//        java.util.TimeZone timeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forTimeZone(timeZone28);
//        java.lang.String str31 = dateTimeZone29.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (int) 'a');
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = offsetDateTimeField35.getAsShortText((long) (byte) 1, locale37);
//        boolean boolean40 = offsetDateTimeField35.isLeap((long) 4);
//        long long42 = offsetDateTimeField35.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField35.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18, dateTimeFieldType43, (int) (short) 10, 0, 0);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField49 = new org.joda.time.field.RemainderDateTimeField(dateTimeField10, dateTimeFieldType43, 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordinated Universal Time" + "'", str14.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2067" + "'", str21.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2067" + "'", str25.equals("2067"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2066 + "'", int27 == 2066);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Coordinated Universal Time" + "'", str31.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2067" + "'", str38.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-259200000L) + "'", long42 == (-259200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        long long12 = offsetDateTimeField7.roundCeiling((long) (byte) -1);
//        java.lang.String str13 = offsetDateTimeField7.toString();
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField7.getAsText(readablePartial14, (int) (byte) 100, locale16);
//        int int19 = offsetDateTimeField7.getMaximumValue(0L);
//        java.util.Locale locale20 = null;
//        int int21 = offsetDateTimeField7.getMaximumTextLength(locale20);
//        long long23 = offsetDateTimeField7.roundHalfCeiling((long) (short) 100);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31795200000L + "'", long12 == 31795200000L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[weekyear]" + "'", str13.equals("DateTimeField[weekyear]"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 292279090 + "'", int19 == 292279090);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-259200000L) + "'", long23 == (-259200000L));
//    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        boolean boolean12 = offsetDateTimeField7.isLeap((long) 4);
//        long long14 = offsetDateTimeField7.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField7.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, (int) (short) 1, (int) (short) 1, (int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long26 = gregorianChronology20.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology20.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology20.minuteOfHour();
//        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DurationField durationField30 = gregorianChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField30);
//        boolean boolean32 = unsupportedDateTimeField31.isLenient();
//        try {
//            boolean boolean34 = unsupportedDateTimeField31.isLeap((long) 97);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200000L) + "'", long14 == (-259200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 39130100L + "'", long26 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 100, (long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationTo(readableInstant5);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) -1, chronology8);
        org.joda.time.Period period10 = period4.withFields((org.joda.time.ReadablePeriod) period9);
        org.joda.time.Period period12 = period10.plusHours(0);
        org.joda.time.Period period14 = period12.minusMinutes(0);
        org.joda.time.Period period16 = period12.plusSeconds((-28800000));
        org.joda.time.Period period18 = period12.plusHours(10);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period12.toDurationFrom(readableInstant19);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType23 = periodType22.withYearsRemoved();
        org.joda.time.Period period24 = new org.joda.time.Period((long) '4', periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMinutesRemoved();
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration20, periodType25);
        org.joda.time.Period period27 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration20);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(97, (-28800000), 9, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Period period2 = new org.joda.time.Period((-65199988800000L), (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.MutablePeriod mutablePeriod3 = period2.toMutablePeriod();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(mutablePeriod3);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period4.withMinutes((int) (byte) 1);
        int[] intArray7 = period4.getValues();
        org.joda.time.Duration duration8 = period4.toStandardDuration();
        org.joda.time.Period period10 = period4.plusWeeks((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period10.toDurationFrom(readableInstant11);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration12);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("-28800000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-28800000\" is malformed at \"28800000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        long long14 = offsetDateTimeField7.set(1560628667826L, (int) 'a');
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField7.getAsText((long) (short) 100, locale16);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField7.getDurationField();
//        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField7.getWrappedField();
//        org.joda.time.ReadablePartial readablePartial20 = null;
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        java.lang.String str25 = dateTimeZone23.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, (int) 'a');
//        long long31 = offsetDateTimeField29.roundHalfCeiling((long) (byte) -1);
//        org.joda.time.ReadablePartial readablePartial32 = null;
//        int[] intArray35 = new int[] { (-1), 292279090 };
//        int int36 = offsetDateTimeField29.getMinimumValue(readablePartial32, intArray35);
//        try {
//            int[] intArray38 = offsetDateTimeField7.set(readablePartial20, (-28800000), intArray35, (int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -28800000");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62152632132174L) + "'", long14 == (-62152632132174L));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2067" + "'", str17.equals("2067"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Coordinated Universal Time" + "'", str25.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-259200000L) + "'", long31 == (-259200000L));
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-292274957) + "'", int36 == (-292274957));
//    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        java.lang.String str5 = dateTimeZone3.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.weekyear();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.era();
//        org.joda.time.Period period9 = new org.joda.time.Period((-259200000L), (long) (-292274957), (org.joda.time.Chronology) gregorianChronology6);
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.lang.String str13 = dateTimeZone11.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone11);
//        try {
//            long long22 = zonedChronology16.getDateTimeMillis((-65228284799903L), (int) (short) 0, (-28800000), 100, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(zonedChronology16);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.halfdayOfDay();
        org.joda.time.Period period3 = new org.joda.time.Period(252806400036L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        boolean boolean12 = offsetDateTimeField7.isLeap((long) 4);
//        long long14 = offsetDateTimeField7.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField7.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, (int) (short) 1, (int) (short) 1, (int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long26 = gregorianChronology20.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology20.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology20.minuteOfHour();
//        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DurationField durationField30 = gregorianChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField30);
//        boolean boolean32 = unsupportedDateTimeField31.isLenient();
//        try {
//            int int34 = unsupportedDateTimeField31.getMaximumValue(230400000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200000L) + "'", long14 == (-259200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 39130100L + "'", long26 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period2.withMinutes((int) (short) 10);
        org.joda.time.Period period8 = period6.withHours((int) (short) 1);
        org.joda.time.Duration duration9 = period8.toStandardDuration();
        org.joda.time.DurationFieldType[] durationFieldTypeArray10 = period8.getFieldTypes();
        int int11 = period8.size();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((java.lang.Object) period14, periodType15, chronology16);
        org.joda.time.PeriodType periodType18 = periodType15.withYearsRemoved();
        org.joda.time.PeriodType periodType19 = periodType18.withSecondsRemoved();
        try {
            org.joda.time.Period period20 = period8.withPeriodType(periodType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'hours'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(durationFieldTypeArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        boolean boolean12 = offsetDateTimeField7.isLeap((long) 4);
//        long long14 = offsetDateTimeField7.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField7.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, (int) (short) 1, (int) (short) 1, (int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long26 = gregorianChronology20.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology20.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology20.minuteOfHour();
//        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DurationField durationField30 = gregorianChronology20.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField30);
//        boolean boolean32 = unsupportedDateTimeField31.isLenient();
//        org.joda.time.ReadablePartial readablePartial33 = null;
//        java.util.TimeZone timeZone34 = null;
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
//        java.lang.String str37 = dateTimeZone35.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35);
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (int) 'a');
//        java.lang.String str43 = offsetDateTimeField41.getAsText((long) (byte) 100);
//        long long46 = offsetDateTimeField41.add((long) (-28800000), (long) 0);
//        org.joda.time.ReadablePartial readablePartial47 = null;
//        int[] intArray53 = new int[] { (-28800000), (byte) 0, (short) 0, 3, (byte) 1 };
//        int int54 = offsetDateTimeField41.getMinimumValue(readablePartial47, intArray53);
//        try {
//            int int55 = unsupportedDateTimeField31.getMinimumValue(readablePartial33, intArray53);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200000L) + "'", long14 == (-259200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 39130100L + "'", long26 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Coordinated Universal Time" + "'", str37.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2067" + "'", str43.equals("2067"));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-28800000L) + "'", long46 == (-28800000L));
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-292274957) + "'", int54 == (-292274957));
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "ZonedChronology[GregorianChronology[UTC], UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        long long9 = offsetDateTimeField7.roundHalfCeiling((long) (byte) -1);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField7.getAsShortText(28800009L, locale11);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = offsetDateTimeField7.getAsShortText(0, locale14);
//        java.util.TimeZone timeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
//        java.lang.String str19 = dateTimeZone17.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) 'a');
//        java.lang.String str25 = offsetDateTimeField23.getAsText((long) (byte) 100);
//        java.lang.String str26 = offsetDateTimeField23.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField23.getType();
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField29 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType27, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-259200000L) + "'", long9 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2067" + "'", str12.equals("2067"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordinated Universal Time" + "'", str19.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2067" + "'", str25.equals("2067"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "weekyear" + "'", str26.equals("weekyear"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, 0L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period4.withMinutes((int) (byte) 1);
        org.joda.time.Period period8 = period6.plusDays(0);
        org.joda.time.Period period10 = period8.minusWeeks(97);
        org.joda.time.Period period12 = period10.minusYears((-292274957));
        org.joda.time.DurationFieldType durationFieldType13 = null;
        int int14 = period10.get(durationFieldType13);
        int int15 = period10.getHours();
        org.joda.time.Period period17 = period10.withSeconds((int) (byte) 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, chronology1);
        org.joda.time.Period period4 = period2.withSeconds((int) (short) 10);
        org.joda.time.Period period6 = period2.withMinutes((int) (short) 10);
        int int7 = period6.getMonths();
        org.joda.time.Period period9 = period6.withSeconds(4);
        org.joda.time.Period period11 = period9.multipliedBy((int) '#');
        org.joda.time.Period period13 = period9.plusWeeks((int) (byte) 100);
        int int14 = period9.size();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        java.lang.String str7 = dateTimeZone5.getName(0L);
//        java.lang.String str9 = dateTimeZone5.getName((long) '4');
//        org.joda.time.Chronology chronology10 = iSOChronology3.withZone(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology3.weekyear();
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology3.hourOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long6 = gregorianChronology0.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfCentury();
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.lang.String str13 = dateTimeZone11.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) 'a');
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField17.getAsShortText((long) (byte) 1, locale19);
//        boolean boolean22 = offsetDateTimeField17.isLeap((long) 4);
//        long long24 = offsetDateTimeField17.roundHalfFloor((-18469890L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField17.getType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType25, (int) (short) 1, (int) (short) 1, (int) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        long long36 = gregorianChronology30.getDateTimeMillis(9L, (int) (byte) 10, (int) '4', (int) (short) 10, (int) (short) 100);
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology30.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology30.minuteOfHour();
//        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology30);
//        org.joda.time.DurationField durationField40 = gregorianChronology30.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField40);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dateTimeField9, dateTimeFieldType25, 292279090);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 39130100L + "'", long6 == 39130100L);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2067" + "'", str20.equals("2067"));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-259200000L) + "'", long24 == (-259200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 39130100L + "'", long36 == 39130100L);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(chronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[UTC]", "GregorianChronology[UTC]", (int) (byte) 10, 0);
        long long6 = fixedDateTimeZone4.convertUTCToLocal((long) (short) 100);
        int int8 = fixedDateTimeZone4.getOffset((-8179561958400000090L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 110L + "'", long6 == 110L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        int int9 = offsetDateTimeField7.getLeapAmount((long) (short) 0);
//        long long11 = offsetDateTimeField7.roundHalfCeiling(9L);
//        long long14 = offsetDateTimeField7.set(1560628667826L, (int) 'a');
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField7.getAsText((long) (short) 100, locale16);
//        java.util.Locale locale18 = null;
//        int int19 = offsetDateTimeField7.getMaximumTextLength(locale18);
//        org.joda.time.DurationField durationField20 = offsetDateTimeField7.getLeapDurationField();
//        long long23 = durationField20.subtract(126403200003L, (long) (-253144762));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200000L) + "'", long11 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62152632132174L) + "'", long14 == (-62152632132174L));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2067" + "'", str17.equals("2067"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 153102078460800003L + "'", long23 == 153102078460800003L);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant4, readableDuration5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.seconds();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) period6, periodType7, chronology8);
        org.joda.time.PeriodType periodType10 = periodType7.withYearsRemoved();
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) 10, 0L, periodType10, chronology13);
        try {
            org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) periodType0, periodType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(chronology13);
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        java.util.TimeZone timeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        java.lang.String str5 = dateTimeZone3.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.weekyear();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.era();
//        org.joda.time.Period period9 = new org.joda.time.Period((-259200000L), (long) (-292274957), (org.joda.time.Chronology) gregorianChronology6);
//        java.util.TimeZone timeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
//        java.lang.String str13 = dateTimeZone11.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
//        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone11);
//        org.joda.time.DurationField durationField17 = zonedChronology16.millis();
//        java.lang.String str18 = zonedChronology16.toString();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("America/Los_Angeles", "Coordinated Universal Time", (int) (short) -1, (int) 'a');
//        boolean boolean25 = fixedDateTimeZone23.isStandardOffset(1560628667826L);
//        org.joda.time.LocalDateTime localDateTime26 = null;
//        boolean boolean27 = fixedDateTimeZone23.isLocalDateTimeGap(localDateTime26);
//        long long29 = fixedDateTimeZone23.nextTransition((long) (short) 0);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone23);
//        java.util.TimeZone timeZone31 = fixedDateTimeZone23.toTimeZone();
//        boolean boolean32 = fixedDateTimeZone23.isFixed();
//        boolean boolean33 = zonedChronology16.equals((java.lang.Object) fixedDateTimeZone23);
//        try {
//            long long38 = zonedChronology16.getDateTimeMillis((-292274957), 1000, 32, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1000 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordinated Universal Time" + "'", str13.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(zonedChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str18.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) 'a');
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = offsetDateTimeField7.getAsShortText((long) (byte) 1, locale9);
//        int int12 = offsetDateTimeField7.getLeapAmount((long) (-1));
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = offsetDateTimeField7.getAsText((long) 100, locale14);
//        java.lang.String str17 = offsetDateTimeField7.getAsText((-210863779200000L));
//        boolean boolean18 = offsetDateTimeField7.isSupported();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2067" + "'", str10.equals("2067"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2067" + "'", str15.equals("2067"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-4615" + "'", str17.equals("-4615"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//    }
//}

