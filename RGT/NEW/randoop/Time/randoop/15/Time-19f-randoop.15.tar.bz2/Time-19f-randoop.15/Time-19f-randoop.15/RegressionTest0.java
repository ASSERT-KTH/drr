import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 1, (java.lang.Object) (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) -1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 10, (int) (byte) 10, (int) (byte) 0, 100, 100, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDateTime localDateTime1 = null;
        try {
            boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.days();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.days();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField5 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField2, durationField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        java.util.Locale locale5 = null;
        try {
            org.joda.time.DateTime dateTime6 = property3.setCopy("hi!", locale5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("hi!", (int) (byte) -1, 1, 1, ' ', (int) '#', (int) (short) 0, (int) '#', false, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DurationField durationField4 = property3.getRangeDurationField();
        org.joda.time.ReadableInstant readableInstant5 = null;
        try {
            int int6 = property3.compareTo(readableInstant5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 0.0d, (java.lang.Number) (byte) 1, (java.lang.Number) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withYear((int) '#');
        try {
            org.joda.time.DateTime dateTime4 = dateTime0.withDayOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (byte) 10, 1L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100, (java.lang.Number) (-1.0f), (java.lang.Number) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.DateTime dateTime7 = dateTime4.withField(dateTimeFieldType5, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.DateTime.Property property3 = dateTime0.property(dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 1, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withYear((int) '#');
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.DateTime dateTime5 = dateTime0.withFieldAdded(durationFieldType3, 891);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
        long long13 = dateTimeZone7.getMillisKeepLocal(dateTimeZone10, (long) (short) -1);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((-1), (int) (short) 100, (int) (short) 100, (int) (byte) -1, 0, (int) (short) 10, (int) '4', dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withYear((int) '#');
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.withDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        boolean boolean2 = dateTime0.isSupported(dateTimeFieldType1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.DateTime.Property property4 = dateTime0.property(dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 100, (int) ' ', (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test038");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        int int3 = dateTime0.getMinuteOfDay();
//        int int4 = dateTime0.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 891 + "'", int3 == 891);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 51 + "'", int4 == 51);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
        java.util.Date date6 = dateTime5.toDate();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField6 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType4, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getMonthOfYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) (short) 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateMidnight4);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(365, 891);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 325215 + "'", int2 == 325215);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.DateTime dateTime15 = dateTime6.withField(dateTimeFieldType13, 365);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test055");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560635475676L + "'", long0 == 1560635475676L);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1.0d), "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        java.io.Writer writer5 = null;
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            dateTimeFormatter3.printTo(writer5, readablePartial6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.YearMonthDay yearMonthDay4 = dateTime2.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) yearMonthDay4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(yearMonthDay4);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        java.util.Date date4 = dateTime3.toDate();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadablePartial) yearMonthDay5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType3, 51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = iSOChronology0.get(readablePeriod2, 28799999L, (long) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        java.util.Locale locale6 = null;
        try {
            java.lang.String str7 = dateMidnight4.toString("2019-06-15T14:51:12.401", locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.io.Writer writer2 = null;
        try {
            dateTimeFormatter0.printTo(writer2, (long) 51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str1 = dateTimeZone0.toString();
        java.lang.String str2 = dateTimeZone0.getID();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withYear((int) '#');
        try {
            java.lang.String str4 = dateTime2.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.util.Collection<org.joda.time.DateTimeFieldType> dateTimeFieldTypeCollection0 = null;
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.forFields(dateTimeFieldTypeCollection0, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
        long long8 = dateTimeZone2.convertLocalToUTC((long) (short) 10, true);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(0);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withLocale(locale4);
        java.io.Writer writer6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        java.util.Date date8 = dateTime7.toDate();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime7.toYearMonthDay();
        org.joda.time.DateTime.Property property10 = dateTime7.hourOfDay();
        org.joda.time.DateTime dateTime11 = property10.getDateTime();
        org.joda.time.DateMidnight dateMidnight12 = dateTime11.toDateMidnight();
        try {
            dateTimeFormatter5.printTo(writer6, (org.joda.time.ReadableInstant) dateTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateMidnight12);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        java.util.Date date2 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withZone(dateTimeZone3);
        java.lang.String str7 = dateTimeZone3.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime8 = dateTime4.withDurationAdded((long) 365, (int) (byte) 100);
        org.joda.time.DateTime.Property property9 = dateTime4.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = iSOChronology0.add(readablePeriod3, (long) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfWeek();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        try {
            int[] intArray10 = iSOChronology0.get(readablePeriod8, 28800010L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(14);
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.withEra(10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) '#', 6, (int) (byte) 100);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField9 = iSOChronology8.halfdays();
        java.lang.String str10 = iSOChronology8.toString();
        org.joda.time.DurationField durationField11 = iSOChronology8.years();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        java.util.Date date13 = dateTime12.toDate();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTime(dateTimeZone14);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology8, dateTimeZone14);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 0, (org.joda.time.Chronology) iSOChronology8);
        long long21 = iSOChronology8.add(0L, (long) (byte) -1, (int) (byte) 100);
        try {
            org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(51, (int) (byte) 0, (int) (byte) 10, 10, (int) (short) 100, (int) (short) 0, 52, (org.joda.time.Chronology) iSOChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-100L) + "'", long21 == (-100L));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(624097L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 624097 + "'", int1 == 624097);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime14 = property13.roundHalfFloorCopy();
        boolean boolean16 = dateTime14.isEqual((long) 0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DurationField durationField4 = property3.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property3.getFieldType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType5, (int) (byte) -1, (int) (byte) 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "2019-06-15T14:51:14.819");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime14 = property13.roundHalfFloorCopy();
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = dateTime14.toString("UTC", locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: U");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        org.joda.time.ReadableInstant readableInstant4 = null;
        try {
            java.lang.String str5 = dateTimeFormatter2.print(readableInstant4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(dateTimeZone3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        boolean boolean2 = dateTime0.isSupported(dateTimeFieldType1);
        int int3 = dateTime0.getMinuteOfHour();
        try {
            org.joda.time.DateTime dateTime5 = dateTime0.withYearOfCentury(936);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 936 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        long long1 = dateTime0.getMillis();
        try {
            org.joda.time.DateTime dateTime3 = dateTime0.withSecondOfMinute(325215);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 325215 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfSecond();
        java.lang.String str2 = property1.toString();
        org.joda.time.ReadableInstant readableInstant3 = null;
        try {
            int int4 = property1.compareTo(readableInstant3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[millisOfSecond]" + "'", str2.equals("Property[millisOfSecond]"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField3 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) (short) 1, 0);
        org.joda.time.DateTime dateTime9 = dateTime0.toDateTime((org.joda.time.Chronology) iSOChronology2);
        try {
            org.joda.time.DateTime dateTime11 = dateTime0.withEra(52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.minus(readablePeriod8);
        org.joda.time.DateTime.Property property10 = dateTime6.centuryOfEra();
        try {
            org.joda.time.DateTime dateTime12 = dateTime6.withYearOfCentury(936);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 936 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime.Property property2 = dateTime0.hourOfDay();
        org.joda.time.DateTime.Property property3 = dateTime0.dayOfYear();
        int int4 = property3.getMaximumValue();
        int int5 = property3.getMinimumValueOverall();
        try {
            org.joda.time.DateTime dateTime7 = property3.setCopy(936);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 936 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime.Property property2 = dateTime0.hourOfDay();
        org.joda.time.DateTime.Property property3 = dateTime0.dayOfYear();
        long long4 = property3.remainder();
        java.lang.String str5 = property3.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[dayOfYear]" + "'", str5.equals("Property[dayOfYear]"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1560635475676L, 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 81153044735152L + "'", long2 == 81153044735152L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField5 = iSOChronology0.years();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(10, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-10) + "'", int2 == (-10));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.util.Collection<org.joda.time.DateTimeFieldType> dateTimeFieldTypeCollection0 = null;
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.forFields(dateTimeFieldTypeCollection0, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(0);
        java.io.OutputStream outputStream4 = null;
        try {
            dateTimeZoneBuilder0.writeTo("��:��:��", outputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("2019-06-15T14:51:12.401");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-15T14:51:12.401\" is malformed at \"-06-15T14:51:12.401\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        boolean boolean5 = dateTime0.isSupported(dateTimeFieldType4);
        org.joda.time.DateTime dateTime6 = dateTime0.toDateTime();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        long long1 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        int int7 = property3.getDifference((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime8.toDateTime(dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime8.centuryOfEra();
        org.joda.time.DateTime dateTime15 = property14.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime16 = property14.getDateTime();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime16);
        boolean boolean19 = dateTime16.isEqual((long) (short) 1);
        org.joda.time.DateTime.Property property20 = dateTime16.weekOfWeekyear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "��:��:��");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DurationField durationField4 = property3.getRangeDurationField();
        org.joda.time.DateTime dateTime5 = property3.withMinimumValue();
        int int6 = dateTime5.getHourOfDay();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        int int7 = property3.getDifference((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime8.toDateTime(dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime8.centuryOfEra();
        org.joda.time.DateTime dateTime15 = property14.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime16 = property14.getDateTime();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        java.util.Date date19 = dateTime18.toDate();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime21 = dateTime18.toMutableDateTime(dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime18.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime18.withCenturyOfEra(52);
        org.joda.time.DateTime dateTime27 = dateTime18.withWeekyear((int) ' ');
        org.joda.time.DateTime dateTime30 = dateTime27.withDurationAdded((-100L), (int) (byte) -1);
        boolean boolean31 = dateTime16.isEqual((org.joda.time.ReadableInstant) dateTime27);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        java.util.Date date2 = dateTime1.toDate();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTime.Property property4 = dateTime1.hourOfDay();
        org.joda.time.DurationField durationField5 = property4.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property4.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType6, 0, (-1), 0);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField11 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (byte) 100, (long) 22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2200 + "'", int2 == 2200);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime.Property property2 = dateTime0.secondOfMinute();
        java.lang.String str3 = property2.getAsText();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DurationField durationField4 = property3.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property3.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType5, 0, (-1), 0);
        org.joda.time.DurationField durationField10 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField11 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField5 = iSOChronology4.days();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = iSOChronology4.add(readablePeriod7, (long) (short) 1, 0);
        org.joda.time.DateTime dateTime11 = dateTime2.toDateTime((org.joda.time.Chronology) iSOChronology4);
        boolean boolean12 = dateTime0.equals((java.lang.Object) dateTime11);
        try {
            org.joda.time.DateTime dateTime14 = dateTime0.withMinuteOfHour(900);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 900 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        int int4 = mutableDateTime3.getEra();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(0);
        java.lang.StringBuffer stringBuffer4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime5.toMutableDateTime(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = dateTime5.toDateTime(dateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime5.centuryOfEra();
        org.joda.time.DateTime dateTime12 = property11.roundHalfCeilingCopy();
        try {
            dateTimeFormatter0.printTo(stringBuffer4, (org.joda.time.ReadableInstant) dateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        long long8 = dateTimeZone6.convertUTCToLocal(1L);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (byte) 100, 2200, (int) (byte) 100, (int) '4', 100, (int) '#', dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime.Property property2 = dateTime0.hourOfDay();
        org.joda.time.DateTime.Property property3 = dateTime0.dayOfYear();
        int int4 = property3.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime7 = dateTime5.minusHours(13);
        org.joda.time.DateTime dateTime9 = dateTime5.plusDays(15);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        java.lang.String str9 = property6.getAsText();
        int int10 = property6.getMinimumValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "19" + "'", str9.equals("19"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime8 = dateTime4.withDurationAdded((long) 365, (int) (byte) 100);
        org.joda.time.DateTime.Property property9 = dateTime4.yearOfCentury();
        org.joda.time.DateTime dateTime11 = property9.addToCopy((-28800000L));
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(0);
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder0.writeTo("hi!", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField3, 0, 19, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for hourOfHalfday must be in the range [19,19]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime0.withCenturyOfEra(52);
        org.joda.time.DateTime dateTime9 = dateTime0.withWeekyear((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime0.withCenturyOfEra(52);
        org.joda.time.DateTime dateTime9 = dateTime0.withWeekyear((int) ' ');
        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded((-100L), (int) (byte) -1);
        try {
            org.joda.time.DateTime dateTime14 = dateTime12.withMinuteOfHour((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.withMinimumValue();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readablePeriod5);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        long long6 = fixedDateTimeZone4.nextTransition(624097L);
        long long8 = fixedDateTimeZone4.nextTransition((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 624097L + "'", long6 == 624097L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        long long2 = dateTime1.getMillis();
        try {
            java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DurationField durationField2 = iSOChronology0.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        java.io.Writer writer3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTime(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime4.toDateTime(dateTimeZone8);
        org.joda.time.DateTime.Property property10 = dateTime4.centuryOfEra();
        org.joda.time.DateTime dateTime11 = property10.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime12 = property10.getDateTime();
        org.joda.time.DateTime dateTime14 = dateTime12.withYearOfCentury(0);
        try {
            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadableInstant) dateTime14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField7 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType5, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField6 = iSOChronology5.halfdays();
        java.lang.String str7 = iSOChronology5.toString();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.dayOfYear();
        org.joda.time.DurationField durationField9 = iSOChronology5.eras();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(1, 624097, 10, 4, 624097, (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 624097 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[UTC]" + "'", str7.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        int int6 = dateMidnight5.getSecondOfDay();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = unsupportedDateTimeField22.getAsShortText(624097, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        boolean boolean4 = dateTimeFormatter2.isOffsetParsed();
        java.lang.Integer int5 = dateTimeFormatter2.getPivotYear();
        org.junit.Assert.assertNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(int5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone6.getUncachedZone();
        long long9 = cachedDateTimeZone6.previousTransition(0L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property13 = dateTime5.millisOfDay();
        int int14 = dateTime5.getSecondOfDay();
        org.joda.time.DateTime dateTime16 = dateTime5.plusYears((int) (short) 0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = unsupportedDateTimeField22.getAsText(0L, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 15, 900);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        try {
            long long24 = unsupportedDateTimeField22.roundHalfCeiling(624097L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        java.util.Date date24 = dateTime23.toDate();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime26 = dateTime23.toMutableDateTime(dateTimeZone25);
        org.joda.time.DateTime dateTime28 = dateTime23.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        java.util.Date date30 = dateTime29.toDate();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime32 = dateTime29.toMutableDateTime(dateTimeZone31);
        org.joda.time.DateTime dateTime34 = dateTime29.plusDays((int) (short) 10);
        boolean boolean35 = dateTime28.isAfter((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime();
        java.util.Date date37 = dateTime36.toDate();
        org.joda.time.YearMonthDay yearMonthDay38 = dateTime36.toYearMonthDay();
        org.joda.time.DateTime dateTime39 = dateTime29.withFields((org.joda.time.ReadablePartial) yearMonthDay38);
        int[] intArray41 = new int[] {};
        try {
            int[] intArray43 = unsupportedDateTimeField22.set((org.joda.time.ReadablePartial) yearMonthDay38, (int) (short) 1, intArray41, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(mutableDateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(yearMonthDay38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(intArray41);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        try {
            boolean boolean24 = unsupportedDateTimeField22.isLeap(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField3 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) (short) 1, 0);
        org.joda.time.DateTime dateTime9 = dateTime0.toDateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.weekyear();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology2.yearOfEra();
        org.joda.time.DurationField durationField12 = iSOChronology2.seconds();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = iSOChronology0.add(readablePeriod3, (long) (byte) 0, (int) '4');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfCentury(0);
        org.joda.time.DateTime dateTime12 = dateTime8.plusMinutes(900);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime14 = property13.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime16 = dateTime14.plusMillis((int) (byte) 1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        java.util.Date date2 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime(dateTimeZone3);
        long long6 = dateTimeZone0.getMillisKeepLocal(dateTimeZone3, (long) (short) -1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) dateTimeZone0, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(iSOChronology12);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 1);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeFormatter4.getZone();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        java.util.Date date13 = dateTime12.toDate();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime12.plusDays((int) (short) 10);
        boolean boolean18 = dateTime11.isAfter((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
        java.util.Date date20 = dateTime19.toDate();
        org.joda.time.YearMonthDay yearMonthDay21 = dateTime19.toYearMonthDay();
        org.joda.time.DateTime dateTime22 = dateTime12.withFields((org.joda.time.ReadablePartial) yearMonthDay21);
        java.lang.String str23 = dateTimeFormatter4.print((org.joda.time.ReadablePartial) yearMonthDay21);
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadablePartial) yearMonthDay21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(yearMonthDay21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "��:��:��" + "'", str23.equals("��:��:��"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        try {
            org.joda.time.LocalTime localTime5 = dateTimeFormatter2.parseLocalTime("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(dateTimePrinter3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone24 = dateTimeFormatter23.getZone();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
        java.util.Date date26 = dateTime25.toDate();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime25.toMutableDateTime(dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime25.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime();
        java.util.Date date32 = dateTime31.toDate();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime34 = dateTime31.toMutableDateTime(dateTimeZone33);
        org.joda.time.DateTime dateTime36 = dateTime31.plusDays((int) (short) 10);
        boolean boolean37 = dateTime30.isAfter((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime();
        java.util.Date date39 = dateTime38.toDate();
        org.joda.time.YearMonthDay yearMonthDay40 = dateTime38.toYearMonthDay();
        org.joda.time.DateTime dateTime41 = dateTime31.withFields((org.joda.time.ReadablePartial) yearMonthDay40);
        java.lang.String str42 = dateTimeFormatter23.print((org.joda.time.ReadablePartial) yearMonthDay40);
        try {
            int int43 = unsupportedDateTimeField22.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay40);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(yearMonthDay40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "��:��:��" + "'", str42.equals("��:��:��"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 2200, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime.Property property2 = dateTime0.secondOfMinute();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField3 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) (short) 1, 0);
        org.joda.time.DateTime dateTime9 = dateTime0.toDateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.weekyear();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology2.weekyear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(0);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withLocale(locale4);
        try {
            long long7 = dateTimeFormatter3.parseMillis("2019-06-15T14:51:12.401");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-15T14:51:12.401\" is malformed at \"-06-15T14:51:12.401\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withWeekOfWeekyear(891);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 891 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(81153044735152L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DurationField durationField3 = iSOChronology0.years();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTime(dateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone6);
        org.joda.time.DurationField durationField9 = zonedChronology8.seconds();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) zonedChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ZonedChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(durationField9);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        boolean boolean5 = dateTime0.isSupported(dateTimeFieldType4);
//        org.joda.time.DateTime dateTime7 = dateTime0.minusSeconds(6);
//        int int8 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
//        java.util.Date date10 = dateTime9.toDate();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime9.toMutableDateTime(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        java.util.Date date14 = dateTime13.toDate();
//        org.joda.time.YearMonthDay yearMonthDay15 = dateTime13.toYearMonthDay();
//        org.joda.time.DateTime.Property property16 = dateTime13.hourOfDay();
//        org.joda.time.DurationField durationField17 = property16.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType18, 0, (-1), 0);
//        org.joda.time.DateTime dateTime24 = dateTime9.withField(dateTimeFieldType18, 4);
//        try {
//            org.joda.time.DateTime dateTime26 = dateTime0.withField(dateTimeFieldType18, 52);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(yearMonthDay15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime4, dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusYears(365);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) 53473645L, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField6 = iSOChronology3.days();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(1, 0, 14, 100, 19, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        int int3 = dateTimeFormatter2.getDefaultYear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        java.util.Date date2 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withZone(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField8 = iSOChronology7.days();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        long long13 = iSOChronology7.add(readablePeriod10, (long) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology7.dayOfWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology7.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        try {
            int int24 = unsupportedDateTimeField22.getMaximumValue((long) 22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withYear((int) '#');
//        int int3 = dateTime0.getMillisOfSecond();
//        org.joda.time.DateTime dateTime5 = dateTime0.withMillisOfDay((int) (short) 100);
//        org.joda.time.DateTime dateTime7 = dateTime0.withYearOfEra(325215);
//        long long8 = dateTime0.getMillis();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 405 + "'", int3 == 405);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 82713680228405L + "'", long8 == 82713680228405L);
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getSecondOfMinute();
//        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        org.joda.time.DateTime dateTime5 = dateTime0.withDurationAdded(readableDuration3, 6);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime8 = dateTime4.withDurationAdded((long) 365, (int) (byte) 100);
        org.joda.time.DateTime.Property property9 = dateTime4.yearOfCentury();
        org.joda.time.DateTime dateTime11 = property9.addToCopy(51);
        java.util.Locale locale12 = null;
        java.lang.String str13 = property9.getAsShortText(locale12);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "91" + "'", str13.equals("91"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        java.util.Date date4 = dateTime3.toDate();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime3.hourOfDay();
        org.joda.time.DateMidnight dateMidnight7 = dateTime3.toDateMidnight();
        org.joda.time.DateTime dateTime9 = dateTime3.minusMillis(891);
        org.joda.time.DateTime dateTime11 = dateTime9.minusYears(14);
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadableInstant) dateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        java.util.Date date24 = dateTime23.toDate();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime26 = dateTime23.toMutableDateTime(dateTimeZone25);
        boolean boolean28 = dateTime23.isBefore((long) (short) 0);
        org.joda.time.TimeOfDay timeOfDay29 = dateTime23.toTimeOfDay();
        int[] intArray33 = new int[] { (byte) 100, ' ' };
        java.util.Locale locale35 = null;
        try {
            int[] intArray36 = unsupportedDateTimeField22.set((org.joda.time.ReadablePartial) timeOfDay29, (int) (byte) 10, intArray33, "2019-06-15T14:51:14.482", locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeOfDay29);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        long long8 = cachedDateTimeZone6.previousTransition((long) 624097);
        int int10 = cachedDateTimeZone6.getOffset(0L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 624097L + "'", long8 == 624097L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        int int3 = dateTimeFormatter0.getDefaultYear();
        try {
            org.joda.time.DateTime dateTime5 = dateTimeFormatter0.parseDateTime("(\"org.joda.time.JodaTimePermission\" \"2019-06-15T14:51:14.482\")");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"(\"org.joda.time.JodaTimePermissi...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("19", (int) (short) 100, (int) (byte) 10, 4, 'a', 325215, 2000, (int) ' ', false, 51);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfYear();
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        try {
            long long7 = durationField4.subtract((-1L), 891);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField3 = iSOChronology2.days();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        long long8 = iSOChronology2.add(readablePeriod5, (long) (short) 1, 0);
//        org.joda.time.DateTime dateTime9 = dateTime0.toDateTime((org.joda.time.Chronology) iSOChronology2);
//        org.joda.time.DateTime dateTime11 = dateTime0.plusMillis(52);
//        int int12 = dateTime0.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(0);
        java.io.OutputStream outputStream4 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", outputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        java.util.Date date2 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime(dateTimeZone3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withZone(dateTimeZone3);
        boolean boolean7 = dateTimeFormatter6.isPrinter();
        boolean boolean8 = dateTimeFormatter6.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 900, (long) (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-900) + "'", int2 == (-900));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfSecond();
        org.joda.time.DateTime dateTime3 = dateTime0.plusYears((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("Property[millisOfSecond]", (-10), (int) ' ', (int) (byte) 1, 'a', 100, 0, (int) (byte) 1, false, (int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeZoneBuilder0.toDateTimeZone("2019-06-15T14:51:12.401", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DurationField durationField3 = iSOChronology0.years();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTime(dateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone6);
        org.joda.time.DurationField durationField9 = zonedChronology8.seconds();
        java.lang.String str10 = zonedChronology8.toString();
        org.joda.time.JodaTimePermission jodaTimePermission12 = new org.joda.time.JodaTimePermission("2019-06-15T14:51:14.482");
        java.lang.String str13 = jodaTimePermission12.getActions();
        java.lang.String str14 = jodaTimePermission12.toString();
        java.lang.String str15 = jodaTimePermission12.toString();
        boolean boolean16 = zonedChronology8.equals((java.lang.Object) str15);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str10.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"2019-06-15T14:51:14.482\")" + "'", str14.equals("(\"org.joda.time.JodaTimePermission\" \"2019-06-15T14:51:14.482\")"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"2019-06-15T14:51:14.482\")" + "'", str15.equals("(\"org.joda.time.JodaTimePermission\" \"2019-06-15T14:51:14.482\")"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField3 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) (short) 1, 0);
        org.joda.time.DateTime dateTime9 = dateTime0.toDateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime.Property property10 = dateTime0.dayOfMonth();
        boolean boolean11 = property10.isLeap();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.year();
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            long long7 = iSOChronology0.set(readablePartial5, 28799999L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("4591-04-14T06");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '4591-04-14T06' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime8 = dateTime4.withDurationAdded((long) 365, (int) (byte) 100);
        org.joda.time.DateTime.Property property9 = dateTime4.yearOfCentury();
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime4);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        long long25 = unsupportedDateTimeField22.add(0L, (int) (byte) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone27 = dateTimeFormatter26.getZone();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
        java.util.Date date29 = dateTime28.toDate();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime31 = dateTime28.toMutableDateTime(dateTimeZone30);
        org.joda.time.DateTime dateTime33 = dateTime28.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime();
        java.util.Date date35 = dateTime34.toDate();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime37 = dateTime34.toMutableDateTime(dateTimeZone36);
        org.joda.time.DateTime dateTime39 = dateTime34.plusDays((int) (short) 10);
        boolean boolean40 = dateTime33.isAfter((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime();
        java.util.Date date42 = dateTime41.toDate();
        org.joda.time.YearMonthDay yearMonthDay43 = dateTime41.toYearMonthDay();
        org.joda.time.DateTime dateTime44 = dateTime34.withFields((org.joda.time.ReadablePartial) yearMonthDay43);
        java.lang.String str45 = dateTimeFormatter26.print((org.joda.time.ReadablePartial) yearMonthDay43);
        int[] intArray48 = new int[] { 936 };
        try {
            int[] intArray50 = unsupportedDateTimeField22.addWrapField((org.joda.time.ReadablePartial) yearMonthDay43, (int) (short) -1, intArray48, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31536000000L) + "'", long25 == (-31536000000L));
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(yearMonthDay43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "��:��:��" + "'", str45.equals("��:��:��"));
        org.junit.Assert.assertNotNull(intArray48);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        java.util.Date date3 = dateTime2.toDate();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime2.plusDays((int) (short) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        java.util.Date date9 = dateTime8.toDate();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = dateTime8.plusDays((int) (short) 10);
//        boolean boolean14 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime17 = dateTime8.withDurationAdded((long) (byte) 100, (int) (byte) 1);
//        org.joda.time.DateTime dateTime19 = dateTime8.withWeekyear((int) (short) 0);
//        org.joda.time.DateTime dateTime21 = dateTime8.plusWeeks((int) (short) 10);
//        java.lang.String str22 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime21);
//        boolean boolean23 = gregorianChronology0.equals((java.lang.Object) dateTimeFormatter1);
//        org.joda.time.Chronology chronology24 = gregorianChronology0.withUTC();
//        try {
//            long long29 = gregorianChronology0.getDateTimeMillis(15, 0, 0, 9);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "4591-04-14T06" + "'", str22.equals("4591-04-14T06"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(chronology24);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property13 = dateTime5.dayOfMonth();
        org.joda.time.DateTime.Property property14 = dateTime5.yearOfEra();
        java.lang.String str15 = property14.getAsShortText();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "4591" + "'", str15.equals("4591"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime.Property property2 = dateTime0.hourOfDay();
        java.util.Locale locale3 = null;
        int int4 = property2.getMaximumShortTextLength(locale3);
        org.joda.time.DateTime dateTime5 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime7 = dateTime5.plus(100L);
        org.joda.time.DateTime dateTime8 = dateTime5.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.MutableDateTime mutableDateTime2 = dateTime0.toMutableDateTime();
//        int int3 = dateTime0.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 377 + "'", int3 == 377);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime4, dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime4.withPeriodAdded(readablePeriod8, (int) ' ');
        org.joda.time.DateTime.Property property11 = dateTime10.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime10.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(14, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(14);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.minus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime0.minusYears(22);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 6, 325215);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(51L, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 510L + "'", long2 == 510L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime5.toMutableDateTime(dateTimeZone7);
        long long10 = dateTimeZone4.getMillisKeepLocal(dateTimeZone7, (long) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone7);
        org.joda.time.DurationField durationField13 = iSOChronology0.hours();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
        java.util.Date date15 = dateTime14.toDate();
        org.joda.time.YearMonthDay yearMonthDay16 = dateTime14.toYearMonthDay();
        int[] intArray17 = null;
        try {
            iSOChronology0.validate((org.joda.time.ReadablePartial) yearMonthDay16, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(yearMonthDay16);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime.Property property2 = dateTime0.hourOfDay();
        org.joda.time.DateTime.Property property3 = dateTime0.dayOfYear();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime0.toDateTime(dateTimeZone6);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime6.withDurationAdded(readableDuration13, 4);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(0);
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("2019-06-15T14:51:14.819", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        boolean boolean5 = dateTime0.isSupported(dateTimeFieldType4);
//        org.joda.time.DateTime dateTime7 = dateTime0.minusSeconds(6);
//        int int8 = dateTime0.getDayOfWeek();
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime0.withYearOfCentury((-900));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -900 for yearOfCentury must be in the range [0,99]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime5.toMutableDateTime(dateTimeZone7);
        long long10 = dateTimeZone4.getMillisKeepLocal(dateTimeZone7, (long) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone7);
        long long18 = zonedChronology12.getDateTimeMillis((long) 0, 0, (int) (byte) 10, 24, (int) 'a');
        org.joda.time.DateTimeField dateTimeField19 = zonedChronology12.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 624097L + "'", long18 == 624097L);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        long long25 = unsupportedDateTimeField22.add(0L, (int) (byte) -1);
        java.util.Locale locale26 = null;
        try {
            int int27 = unsupportedDateTimeField22.getMaximumTextLength(locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31536000000L) + "'", long25 == (-31536000000L));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property13 = dateTime5.dayOfMonth();
        org.joda.time.DateTime.Property property14 = dateTime5.yearOfEra();
        int int15 = property14.getMinimumValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(15, 405, 22, (int) 'a', 52, 100, 377);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DurationField durationField3 = iSOChronology0.years();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTime(dateTimeZone6);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone6);
        org.joda.time.DurationField durationField9 = zonedChronology8.seconds();
        java.lang.String str10 = zonedChronology8.toString();
        java.lang.String str11 = zonedChronology8.toString();
        try {
            long long16 = zonedChronology8.getDateTimeMillis((-10), 2200, 2000, 377);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2200 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str10.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str11.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter4, dateTimeParser5);
        try {
            org.joda.time.LocalDateTime localDateTime8 = dateTimeFormatter6.parseLocalDateTime("4591-04-14T06");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime.Property property2 = dateTime0.hourOfDay();
        java.util.Locale locale3 = null;
        int int4 = property2.getMaximumShortTextLength(locale3);
        boolean boolean5 = property2.isLeap();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("00:00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"00:00:00\" is malformed at \":00:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        int int3 = dateTime0.getMinuteOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime0.minus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime5.withSecondOfMinute(0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 377 + "'", int3 == 377);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("ZonedChronology[ISOChronology[UTC], UTC]", "1970-03-12T00");
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        java.util.Date date2 = dateTime1.toDate();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTime.Property property4 = dateTime1.hourOfDay();
        org.joda.time.DurationField durationField5 = property4.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property4.getFieldType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField7 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DurationField durationField4 = iSOChronology1.years();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime5.toMutableDateTime(dateTimeZone7);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 0, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology1.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) iSOChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime5);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        int int9 = fixedDateTimeZone4.getOffset(1560635475676L);
        int int11 = fixedDateTimeZone4.getOffsetFromLocal((long) '#');
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 365, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = iSOChronology1.get(readablePeriod3, 0L, (long) 325215);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
        org.joda.time.DateTime dateTime8 = dateTime6.minusYears(14);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
        java.util.Date date10 = dateTime9.toDate();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime9.toMutableDateTime(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        java.util.Date date14 = dateTime13.toDate();
        org.joda.time.YearMonthDay yearMonthDay15 = dateTime13.toYearMonthDay();
        org.joda.time.DateTime.Property property16 = dateTime13.hourOfDay();
        org.joda.time.DurationField durationField17 = property16.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType18, 0, (-1), 0);
        org.joda.time.DateTime dateTime24 = dateTime9.withField(dateTimeFieldType18, 4);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField26 = iSOChronology25.days();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology25.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology25.dayOfMonth();
        org.joda.time.DurationField durationField30 = iSOChronology25.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = unsupportedDateTimeField31.getType();
        long long35 = unsupportedDateTimeField31.getDifferenceAsLong((long) 377, (long) (byte) -1);
        try {
            int int36 = dateTime8.get((org.joda.time.DateTimeField) unsupportedDateTimeField31);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(yearMonthDay15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime8.toYearMonthDay();
        org.joda.time.DateTime.Property property11 = dateTime8.hourOfDay();
        org.joda.time.DurationField durationField12 = property11.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField15 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType13, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        try {
            long long26 = unsupportedDateTimeField22.add(624097L, 82713680228405L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 82713680228405");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("2019-06-15T14:51:14.482");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-15T14:51:14.482\" is malformed at \"19-06-15T14:51:14.482\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime5.toMutableDateTime(dateTimeZone7);
        long long10 = dateTimeZone4.getMillisKeepLocal(dateTimeZone7, (long) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone7);
        org.joda.time.DurationField durationField13 = iSOChronology0.hours();
        long long16 = durationField13.subtract((-28800000L), (long) 9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61200000L) + "'", long16 == (-61200000L));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) '4', (int) (byte) 100);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime0.withCenturyOfEra(52);
        org.joda.time.DateTime dateTime9 = dateTime0.withWeekyear((int) ' ');
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        java.util.Date date14 = dateTime13.toDate();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime13.toMutableDateTime(dateTimeZone15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter12.withZone(dateTimeZone15);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField20 = iSOChronology19.days();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        long long25 = iSOChronology19.add(readablePeriod22, (long) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology19.dayOfWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter12.withChronology((org.joda.time.Chronology) iSOChronology19);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 891, (org.joda.time.Chronology) iSOChronology19);
        boolean boolean29 = property10.equals((java.lang.Object) 891);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime.Property property2 = dateTime0.secondOfMinute();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime5 = dateTime3.plusMinutes(14);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readablePeriod6);
        int int8 = property2.compareTo((org.joda.time.ReadableInstant) dateTime7);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime.Property property5 = dateTime0.millisOfDay();
//        int int6 = dateTime0.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateMidnight4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        try {
            boolean boolean24 = unsupportedDateTimeField22.isLeap((-28800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        java.util.TimeZone timeZone11 = dateTimeZone8.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(0, 0, (int) (byte) 100, 15, 2000, (int) (short) 0, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) '#');
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        long long25 = unsupportedDateTimeField22.add(0L, (int) (byte) -1);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime();
        java.util.Date date27 = dateTime26.toDate();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime29 = dateTime26.toMutableDateTime(dateTimeZone28);
        org.joda.time.DateTime dateTime31 = dateTime26.plusDays((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime26.minus(readablePeriod32);
        org.joda.time.DateTime dateTime34 = dateTime33.withLaterOffsetAtOverlap();
        org.joda.time.LocalDateTime localDateTime35 = dateTime34.toLocalDateTime();
        int[] intArray39 = new int[] { 14, 9 };
        try {
            int[] intArray41 = unsupportedDateTimeField22.addWrapField((org.joda.time.ReadablePartial) localDateTime35, 52, intArray39, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31536000000L) + "'", long25 == (-31536000000L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDateTime35);
        org.junit.Assert.assertNotNull(intArray39);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        boolean boolean5 = dateTime0.isBefore((long) (short) 0);
        org.joda.time.DateTime.Property property6 = dateTime0.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime9 = property6.addWrapFieldToCopy((int) (short) -1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        boolean boolean24 = unsupportedDateTimeField22.isSupported();
        try {
            boolean boolean26 = unsupportedDateTimeField22.isLeap((long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (long) 2000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15T14:51:14.482");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"2019-06-15T14:51:14.482\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"2019-06-15T14:51:14.482\")"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.minuteOfHour();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, 100, 6, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [6,2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime0.minus(readablePeriod6);
        org.joda.time.DateTime dateTime8 = dateTime7.withLaterOffsetAtOverlap();
        int int9 = dateTime8.getCenturyOfEra();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        java.util.Date date12 = dateTime11.toDate();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime11.toMutableDateTime(dateTimeZone13);
        long long16 = dateTimeZone10.getMillisKeepLocal(dateTimeZone13, (long) (short) -1);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.ReadableInstant readableInstant18 = null;
        int int19 = dateTimeZone10.getOffset(readableInstant18);
        long long21 = dateTimeZone10.convertUTCToLocal((long) 51);
        org.joda.time.DateTime dateTime22 = dateTime8.toDateTime(dateTimeZone10);
        long long26 = dateTimeZone10.convertLocalToUTC((-1L), false, (long) 900);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 51L + "'", long21 == 51L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DateMidnight dateMidnight8 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime10 = dateTime4.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.minus(readablePeriod12);
        org.joda.time.DateTime dateTime15 = dateTime13.minusDays(936);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        java.util.Date date17 = dateTime16.toDate();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime19 = dateTime16.toMutableDateTime(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
        java.util.Date date21 = dateTime20.toDate();
        org.joda.time.YearMonthDay yearMonthDay22 = dateTime20.toYearMonthDay();
        org.joda.time.DateTime.Property property23 = dateTime20.hourOfDay();
        org.joda.time.DurationField durationField24 = property23.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType25, 0, (-1), 0);
        org.joda.time.DateTime dateTime31 = dateTime16.withField(dateTimeFieldType25, 4);
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField33 = iSOChronology32.days();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology32.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology32.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology32.dayOfMonth();
        org.joda.time.DurationField durationField37 = iSOChronology32.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField38 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = unsupportedDateTimeField38.getType();
        org.joda.time.DateTime dateTime41 = dateTime13.withField(dateTimeFieldType39, 15);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType39, (int) (byte) -1);
        org.joda.time.DateTimeField dateTimeField44 = offsetDateTimeField43.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(yearMonthDay22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeField44);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        boolean boolean5 = dateTime0.isSupported(dateTimeFieldType4);
//        org.joda.time.DateTime dateTime7 = dateTime0.minusSeconds(6);
//        int int8 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime.Property property9 = dateTime0.minuteOfDay();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(property9);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1.0d), (java.lang.Number) 4, (java.lang.Number) 14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(14);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.minus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime0.withYearOfCentury((int) (byte) 0);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        java.util.Date date8 = dateTime7.toDate();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime7.toMutableDateTime(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        java.util.Date date12 = dateTime11.toDate();
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
        org.joda.time.DateTime.Property property14 = dateTime11.hourOfDay();
        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType16, 0, (-1), 0);
        org.joda.time.DateTime dateTime22 = dateTime7.withField(dateTimeFieldType16, 4);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.days();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.dayOfMonth();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField29 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField28);
        boolean boolean30 = dateTime6.isSupported(dateTimeFieldType16);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime();
        java.util.Date date32 = dateTime31.toDate();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime34 = dateTime31.toMutableDateTime(dateTimeZone33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime();
        java.util.Date date36 = dateTime35.toDate();
        org.joda.time.YearMonthDay yearMonthDay37 = dateTime35.toYearMonthDay();
        org.joda.time.DateTime.Property property38 = dateTime35.hourOfDay();
        org.joda.time.DurationField durationField39 = property38.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property38.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType40, 0, (-1), 0);
        org.joda.time.DateTime dateTime46 = dateTime31.withField(dateTimeFieldType40, 4);
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField48 = iSOChronology47.days();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology47.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology47.dayOfMonth();
        org.joda.time.DurationField durationField52 = iSOChronology47.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField53 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType40, durationField52);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = unsupportedDateTimeField53.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType54, (java.lang.Number) 377, (java.lang.Number) 82713680228405L, (java.lang.Number) 100.0d);
        try {
            org.joda.time.DateTime dateTime60 = dateTime6.withField(dateTimeFieldType54, 24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(yearMonthDay37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
        int int7 = dateMidnight6.getMinuteOfHour();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(28, (-900), (-10), 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-3) + "'", int4 == (-3));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        java.lang.String str9 = property6.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[centuryOfEra]" + "'", str9.equals("Property[centuryOfEra]"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField3 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) (short) 1, 0);
        org.joda.time.DateTime dateTime9 = dateTime0.toDateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology2.weekyear();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology2.yearOfEra();
        org.joda.time.DurationField durationField12 = iSOChronology2.days();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime8 = dateTime4.withDurationAdded((long) 365, (int) (byte) 100);
        org.joda.time.DateTime.Property property9 = dateTime4.yearOfCentury();
        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMillis(52);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime16 = dateTime14.plusMinutes(14);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime14.minus(readablePeriod17);
        org.joda.time.DateTime dateTime20 = dateTime18.withYearOfCentury((int) '#');
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, (int) ' ');
        boolean boolean24 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime23);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        java.util.Date date3 = dateTime2.toDate();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime2.plusDays((int) (short) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        java.util.Date date9 = dateTime8.toDate();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = dateTime8.plusDays((int) (short) 10);
//        boolean boolean14 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime17 = dateTime8.withDurationAdded((long) (byte) 100, (int) (byte) 1);
//        org.joda.time.DateTime dateTime19 = dateTime8.withWeekyear((int) (short) 0);
//        org.joda.time.DateTime dateTime21 = dateTime8.plusWeeks((int) (short) 10);
//        java.lang.String str22 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime21);
//        boolean boolean23 = gregorianChronology0.equals((java.lang.Object) dateTimeFormatter1);
//        try {
//            long long28 = gregorianChronology0.getDateTimeMillis(19, 51, (int) ' ', 4);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 51 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019-08-24T21" + "'", str22.equals("2019-08-24T21"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
//        java.util.Locale locale6 = null;
//        java.util.Calendar calendar7 = dateTime5.toCalendar(locale6);
//        long long8 = dateTime5.getMillis();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(calendar7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561499507302L + "'", long8 == 1561499507302L);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        int int7 = property3.getDifference((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime8.toDateTime(dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime8.centuryOfEra();
        org.joda.time.DateTime dateTime15 = property14.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime16 = property14.getDateTime();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime16);
        boolean boolean19 = dateTime16.isEqual((long) (short) 1);
        org.joda.time.DateTime dateTime21 = dateTime16.plusHours(2200);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        org.joda.time.LocalDateTime localDateTime27 = null;
        boolean boolean28 = fixedDateTimeZone26.isLocalDateTimeGap(localDateTime27);
        java.util.TimeZone timeZone29 = fixedDateTimeZone26.toTimeZone();
        int int31 = fixedDateTimeZone26.getOffset(1560635475676L);
        long long33 = fixedDateTimeZone26.previousTransition((long) (short) 10);
        java.lang.String str35 = fixedDateTimeZone26.getNameKey((long) 900);
        org.joda.time.DateTime dateTime36 = dateTime21.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019-06-15T14:51:14.819" + "'", str35.equals("2019-06-15T14:51:14.819"));
        org.junit.Assert.assertNotNull(dateTime36);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        long long25 = unsupportedDateTimeField22.add(0L, (int) (byte) -1);
        java.util.Locale locale26 = null;
        try {
            int int27 = unsupportedDateTimeField22.getMaximumShortTextLength(locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31536000000L) + "'", long25 == (-31536000000L));
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(14);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime0.minus(readablePeriod3);
//        int int5 = dateTime0.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 51 + "'", int5 == 51);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        boolean boolean5 = dateTime0.isBefore((long) (short) 0);
        org.joda.time.DateTime.Property property6 = dateTime0.millisOfSecond();
        org.joda.time.DateTime dateTime8 = property6.setCopy((int) (byte) 0);
        org.joda.time.DateTime dateTime9 = property6.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime5);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField8 = iSOChronology7.days();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        java.util.Date date13 = dateTime12.toDate();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTime(dateTimeZone14);
        long long17 = dateTimeZone11.getMillisKeepLocal(dateTimeZone14, (long) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology7, dateTimeZone14);
        org.joda.time.DurationField durationField20 = iSOChronology7.hours();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology7.halfdayOfDay();
        boolean boolean22 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 365, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.minus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays(936);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        java.util.Date date13 = dateTime12.toDate();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        java.util.Date date17 = dateTime16.toDate();
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime16.toYearMonthDay();
        org.joda.time.DateTime.Property property19 = dateTime16.hourOfDay();
        org.joda.time.DurationField durationField20 = property19.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property19.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 0, (-1), 0);
        org.joda.time.DateTime dateTime27 = dateTime12.withField(dateTimeFieldType21, 4);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField29 = iSOChronology28.days();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology28.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology28.dayOfMonth();
        org.joda.time.DurationField durationField33 = iSOChronology28.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = unsupportedDateTimeField34.getType();
        org.joda.time.DateTime dateTime37 = dateTime9.withField(dateTimeFieldType35, 15);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray38 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType35 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList39 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList39, dateTimeFieldTypeArray38);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList39, false, true);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(yearMonthDay18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.MutableDateTime mutableDateTime2 = dateTime0.toMutableDateTime();
        org.joda.time.DateTime.Property property3 = dateTime0.dayOfYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        long long26 = unsupportedDateTimeField22.getDifferenceAsLong((long) 377, (long) (byte) -1);
        try {
            long long28 = unsupportedDateTimeField22.roundHalfEven((long) 325215);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
//        int int7 = property3.getDifference((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        java.util.Date date9 = dateTime8.toDate();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime8.toDateTime(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime8.centuryOfEra();
//        org.joda.time.DateTime dateTime15 = property14.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime16 = property14.getDateTime();
//        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime16);
//        boolean boolean19 = dateTime16.isEqual((long) (short) 1);
//        org.joda.time.DateTime dateTime21 = dateTime16.plusHours(2200);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField23 = iSOChronology22.days();
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.minuteOfHour();
//        int int26 = dateTime16.get(dateTimeField25);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 51 + "'", int26 == 51);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) -1, chronology1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(3600000L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        java.util.Date date3 = dateTime2.toDate();
//        org.joda.time.YearMonthDay yearMonthDay4 = dateTime2.toYearMonthDay();
//        int int5 = dateTime2.getMinuteOfDay();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(yearMonthDay4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1311 + "'", int5 == 1311);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property13 = dateTime5.dayOfMonth();
        org.joda.time.DateTime.Property property14 = dateTime5.yearOfEra();
        org.joda.time.DateTime.Property property15 = dateTime5.dayOfYear();
        int int16 = dateTime5.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("UnsupportedDateTimeField", 900, (int) (short) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 900 for UnsupportedDateTimeField must be in the range [-1,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(int3);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) 'a', 624097);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60537409 + "'", int2 == 60537409);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        boolean boolean23 = unsupportedDateTimeField22.isSupported();
        java.util.Locale locale25 = null;
        try {
            java.lang.String str26 = unsupportedDateTimeField22.getAsShortText(845, locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime0.plusHours(28);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        boolean boolean7 = dateTime4.isBefore(0L);
        try {
            org.joda.time.DateTime dateTime9 = dateTime4.withHourOfDay(876);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 876 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.minus(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        long long25 = unsupportedDateTimeField22.add(0L, (int) (byte) -1);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime();
        java.util.Date date27 = dateTime26.toDate();
        org.joda.time.YearMonthDay yearMonthDay28 = dateTime26.toYearMonthDay();
        java.util.Locale locale30 = null;
        try {
            java.lang.String str31 = unsupportedDateTimeField22.getAsText((org.joda.time.ReadablePartial) yearMonthDay28, 1, locale30);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31536000000L) + "'", long25 == (-31536000000L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(yearMonthDay28);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        try {
            java.lang.String str2 = dateTimeFormatter0.print((-62103283199949L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        long long10 = offsetDateTimeField7.add((long) 405, (long) 0);
        java.lang.String str12 = offsetDateTimeField7.getAsText(510L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 405L + "'", long10 == 405L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime0.centuryOfEra();
        org.joda.time.Interval interval7 = property6.toInterval();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(interval7);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter4, dateTimeParser5);
        java.lang.StringBuffer stringBuffer7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime8.plusDays((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime8.minus(readablePeriod14);
        try {
            dateTimeFormatter6.printTo(stringBuffer7, (org.joda.time.ReadableInstant) dateTime15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfDay();
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            long long7 = iSOChronology0.set(readablePartial5, (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime.Property property5 = dateTime0.centuryOfEra();
//        boolean boolean6 = dateTime0.isEqualNow();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateMidnight4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime.Property property2 = dateTime0.hourOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.dayOfYear();
//        long long4 = property3.remainder();
//        org.joda.time.DateTime dateTime5 = property3.roundFloorCopy();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 78716511L + "'", long4 == 78716511L);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        boolean boolean23 = unsupportedDateTimeField22.isSupported();
        try {
            long long25 = unsupportedDateTimeField22.roundHalfCeiling(78716511L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime0.minus(readablePeriod6);
        org.joda.time.DateTime dateTime8 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.LocalDateTime localDateTime9 = dateTime8.toLocalDateTime();
        org.joda.time.DateTime dateTime11 = dateTime8.withCenturyOfEra(365);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (-10));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
//        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
//        boolean boolean3 = dateTimeFormatter0.isParser();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        java.util.Date date5 = dateTime4.toDate();
//        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
//        org.joda.time.DateTime dateTime8 = property7.getDateTime();
//        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) dateTime8, dateTimeZone10);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime8.withPeriodAdded(readablePeriod12, (int) ' ');
//        boolean boolean15 = dateTime14.isBeforeNow();
//        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(yearMonthDay6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "21:51:56Z" + "'", str16.equals("21:51:56Z"));
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField3 = iSOChronology2.halfdays();
        java.lang.String str4 = iSOChronology2.toString();
        org.joda.time.DurationField durationField5 = iSOChronology2.years();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology2, dateTimeZone8);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 0, (org.joda.time.Chronology) iSOChronology2);
        long long15 = iSOChronology2.add(0L, (long) (byte) -1, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone16 = iSOChronology2.getZone();
        long long19 = dateTimeZone16.adjustOffset(81153044735152L, true);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(0L, dateTimeZone16);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-100L) + "'", long15 == (-100L));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 81153044735152L + "'", long19 == 81153044735152L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15T14:51:14.482");
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.YearMonthDay yearMonthDay4 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
        org.joda.time.DateMidnight dateMidnight6 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime8 = dateTime2.minusMillis(891);
        org.joda.time.DateTime.Property property9 = dateTime2.secondOfDay();
        jodaTimePermission1.checkGuard((java.lang.Object) property9);
        java.security.PermissionCollection permissionCollection11 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(yearMonthDay4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(permissionCollection11);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.minus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusDays(936);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField13 = iSOChronology12.halfdays();
//        java.lang.String str14 = iSOChronology12.toString();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology12.year();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology12.dayOfMonth();
//        int int18 = dateTime9.get(dateTimeField17);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateMidnight4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ISOChronology[UTC]" + "'", str14.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        java.util.Date date4 = dateTime3.toDate();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime3.hourOfDay();
        org.joda.time.DurationField durationField7 = property6.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField10 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTime dateTime5 = property3.roundFloorCopy();
        java.lang.String str6 = property3.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[hourOfDay]" + "'", str6.equals("Property[hourOfDay]"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(14);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.minus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime0.withYearOfCentury((int) (byte) 0);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        java.util.Date date8 = dateTime7.toDate();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime7.toMutableDateTime(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        java.util.Date date12 = dateTime11.toDate();
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
        org.joda.time.DateTime.Property property14 = dateTime11.hourOfDay();
        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType16, 0, (-1), 0);
        org.joda.time.DateTime dateTime22 = dateTime7.withField(dateTimeFieldType16, 4);
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField24 = iSOChronology23.days();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.dayOfMonth();
        org.joda.time.DurationField durationField28 = iSOChronology23.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField29 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField28);
        boolean boolean30 = dateTime6.isSupported(dateTimeFieldType16);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType16, 936, 2000, 22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 936 for hourOfDay must be in the range [2000,22]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        long long10 = offsetDateTimeField7.set((long) 377, (int) (short) 1);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        java.util.Date date12 = dateTime11.toDate();
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
        org.joda.time.DateTime.Property property14 = dateTime11.hourOfDay();
        org.joda.time.DateMidnight dateMidnight15 = dateTime11.toDateMidnight();
        org.joda.time.DateTime dateTime17 = dateTime11.minusMillis(891);
        org.joda.time.DateTime dateTime19 = dateTime11.minusWeeks(2);
        org.joda.time.YearMonthDay yearMonthDay20 = dateTime11.toYearMonthDay();
        int[] intArray23 = new int[] { 28, 2000 };
        int int24 = offsetDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay20, intArray23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone26 = dateTimeFormatter25.getZone();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime();
        java.util.Date date28 = dateTime27.toDate();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime30 = dateTime27.toMutableDateTime(dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime27.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime();
        java.util.Date date34 = dateTime33.toDate();
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime36 = dateTime33.toMutableDateTime(dateTimeZone35);
        org.joda.time.DateTime dateTime38 = dateTime33.plusDays((int) (short) 10);
        boolean boolean39 = dateTime32.isAfter((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime();
        java.util.Date date41 = dateTime40.toDate();
        org.joda.time.YearMonthDay yearMonthDay42 = dateTime40.toYearMonthDay();
        org.joda.time.DateTime dateTime43 = dateTime33.withFields((org.joda.time.ReadablePartial) yearMonthDay42);
        java.lang.String str44 = dateTimeFormatter25.print((org.joda.time.ReadablePartial) yearMonthDay42);
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime();
        java.util.Date date47 = dateTime46.toDate();
        org.joda.time.YearMonthDay yearMonthDay48 = dateTime46.toYearMonthDay();
        org.joda.time.DateTime.Property property49 = dateTime46.hourOfDay();
        int int50 = property49.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField51 = property49.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) (short) 1);
        long long56 = offsetDateTimeField53.set((long) 377, (int) (short) 1);
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime();
        java.util.Date date58 = dateTime57.toDate();
        org.joda.time.YearMonthDay yearMonthDay59 = dateTime57.toYearMonthDay();
        org.joda.time.DateTime.Property property60 = dateTime57.hourOfDay();
        org.joda.time.DateMidnight dateMidnight61 = dateTime57.toDateMidnight();
        org.joda.time.DateTime dateTime63 = dateTime57.minusMillis(891);
        org.joda.time.DateTime dateTime65 = dateTime57.minusWeeks(2);
        org.joda.time.YearMonthDay yearMonthDay66 = dateTime57.toYearMonthDay();
        int[] intArray69 = new int[] { 28, 2000 };
        int int70 = offsetDateTimeField53.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay66, intArray69);
        try {
            int[] intArray72 = offsetDateTimeField7.addWrapField((org.joda.time.ReadablePartial) yearMonthDay42, (int) (short) 0, intArray69, 325215);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 377L + "'", long10 == 377L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateMidnight15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(yearMonthDay20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(mutableDateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(yearMonthDay42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "��:��:��" + "'", str44.equals("��:��:��"));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(yearMonthDay48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 377L + "'", long56 == 377L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(yearMonthDay59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(dateMidnight61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(yearMonthDay66);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 24 + "'", int70 == 24);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(13, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.minus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusDays(936);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        java.util.Date date13 = dateTime12.toDate();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTime(dateTimeZone14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        java.util.Date date17 = dateTime16.toDate();
//        org.joda.time.YearMonthDay yearMonthDay18 = dateTime16.toYearMonthDay();
//        org.joda.time.DateTime.Property property19 = dateTime16.hourOfDay();
//        org.joda.time.DurationField durationField20 = property19.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property19.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 0, (-1), 0);
//        org.joda.time.DateTime dateTime27 = dateTime12.withField(dateTimeFieldType21, 4);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField29 = iSOChronology28.days();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology28.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField32 = iSOChronology28.dayOfMonth();
//        org.joda.time.DurationField durationField33 = iSOChronology28.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = unsupportedDateTimeField34.getType();
//        org.joda.time.DateTime dateTime37 = dateTime9.withField(dateTimeFieldType35, 15);
//        org.joda.time.DateTime.Property property38 = dateTime37.minuteOfDay();
//        int int39 = dateTime37.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateMidnight4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(yearMonthDay18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 195 + "'", int39 == 195);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property13 = dateTime5.millisOfDay();
        org.joda.time.DateTime dateTime14 = property13.withMinimumValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        int int3 = dateTime0.getMinuteOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime0.minus(readablePeriod4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.YearMonthDay yearMonthDay8 = dateTime6.toYearMonthDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight10 = dateTime6.toDateMidnight();
//        org.joda.time.DateTime dateTime12 = dateTime6.minusMillis(891);
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime12.toMutableDateTime();
//        int int14 = mutableDateTime13.getHourOfDay();
//        int int15 = dateTime0.compareTo((org.joda.time.ReadableInstant) mutableDateTime13);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1311 + "'", int3 == 1311);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(yearMonthDay8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 21 + "'", int14 == 21);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime4, dateTimeZone6);
        boolean boolean9 = dateTime4.isBefore((long) 24);
        int int10 = dateTime4.getWeekyear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        long long8 = cachedDateTimeZone6.previousTransition((long) 624097);
        int int10 = cachedDateTimeZone6.getStandardOffset((long) 936);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone6.getUncachedZone();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 624097L + "'", long8 == 624097L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "UTC");
        java.lang.String str3 = illegalFieldValueException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"UTC\" for  is not supported" + "'", str3.equals("org.joda.time.IllegalFieldValueException: Value \"UTC\" for  is not supported"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime5);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        long long10 = fixedDateTimeZone4.convertLocalToUTC(405L, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 404L + "'", long10 == 404L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.util.Collection<org.joda.time.DateTimeFieldType> dateTimeFieldTypeCollection0 = null;
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.forFields(dateTimeFieldTypeCollection0, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime4, dateTimeZone6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime10 = dateTime4.withPeriodAdded(readablePeriod8, (int) ' ');
//        boolean boolean11 = dateTime10.isBeforeNow();
//        org.joda.time.DateTime.Property property12 = dateTime10.minuteOfHour();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(property12);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 60537409);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(51L, (long) 624097);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 31828947L + "'", long2 == 31828947L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        long long25 = unsupportedDateTimeField22.add(0L, (int) (byte) -1);
        boolean boolean26 = unsupportedDateTimeField22.isSupported();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        java.util.TimeZone timeZone28 = dateTimeZone27.toTimeZone();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        java.util.Date date30 = dateTime29.toDate();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime32 = dateTime29.toMutableDateTime(dateTimeZone31);
        org.joda.time.DateTime dateTime34 = dateTime29.plusDays((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime29.minus(readablePeriod35);
        org.joda.time.DateTime dateTime37 = dateTime36.withLaterOffsetAtOverlap();
        org.joda.time.LocalDateTime localDateTime38 = dateTime37.toLocalDateTime();
        boolean boolean39 = dateTimeZone27.isLocalDateTimeGap(localDateTime38);
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime();
        java.util.Date date42 = dateTime41.toDate();
        org.joda.time.YearMonthDay yearMonthDay43 = dateTime41.toYearMonthDay();
        org.joda.time.DateTime.Property property44 = dateTime41.hourOfDay();
        int int45 = property44.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField46 = property44.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, (int) (short) 1);
        long long51 = offsetDateTimeField48.set((long) 377, (int) (short) 1);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime();
        java.util.Date date53 = dateTime52.toDate();
        org.joda.time.YearMonthDay yearMonthDay54 = dateTime52.toYearMonthDay();
        org.joda.time.DateTime.Property property55 = dateTime52.hourOfDay();
        org.joda.time.DateMidnight dateMidnight56 = dateTime52.toDateMidnight();
        org.joda.time.DateTime dateTime58 = dateTime52.minusMillis(891);
        org.joda.time.DateTime dateTime60 = dateTime52.minusWeeks(2);
        org.joda.time.YearMonthDay yearMonthDay61 = dateTime52.toYearMonthDay();
        int[] intArray64 = new int[] { 28, 2000 };
        int int65 = offsetDateTimeField48.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay61, intArray64);
        try {
            int[] intArray67 = unsupportedDateTimeField22.addWrapField((org.joda.time.ReadablePartial) localDateTime38, 1311, intArray64, (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31536000000L) + "'", long25 == (-31536000000L));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(mutableDateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(localDateTime38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(yearMonthDay43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 377L + "'", long51 == 377L);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(yearMonthDay54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(dateMidnight56);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(yearMonthDay61);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 24 + "'", int65 == 24);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfSecond(0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        java.util.Date date5 = dateTime4.toDate();
//        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
//        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
//        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField17 = iSOChronology16.days();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
//        org.joda.time.DurationField durationField21 = iSOChronology16.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
//        java.lang.String str23 = unsupportedDateTimeField22.toString();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
//        java.util.Date date25 = dateTime24.toDate();
//        int int26 = dateTime24.getWeekOfWeekyear();
//        org.joda.time.LocalDateTime localDateTime27 = dateTime24.toLocalDateTime();
//        java.util.Locale locale28 = null;
//        try {
//            java.lang.String str29 = unsupportedDateTimeField22.getAsText((org.joda.time.ReadablePartial) localDateTime27, locale28);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(yearMonthDay6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UnsupportedDateTimeField" + "'", str23.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 24 + "'", int26 == 24);
//        org.junit.Assert.assertNotNull(localDateTime27);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        long long11 = dateTimeZone5.getMillisKeepLocal(dateTimeZone8, (long) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(730, 2000, (int) '#', 377, 876, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 377 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(iSOChronology12);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "UTC");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(durationFieldType5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long11 = offsetDateTimeField7.remainder((long) (short) 100);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField7.getWrappedField();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-1), 0, (int) (byte) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.minus(readablePeriod8);
        org.joda.time.DateTime.Property property10 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime12 = dateTime6.minusDays(0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(6);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("Property[centuryOfEra]", 60537409, 1, 10, 'a', 100, 624097, 0, true, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfYear();
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        try {
            long long7 = durationField4.subtract((long) 24, 1561499507302L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime.Property property5 = dateTime0.millisOfDay();
//        boolean boolean6 = dateTime0.isBeforeNow();
//        org.joda.time.DateTime dateTime8 = dateTime0.withDayOfYear(22);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateMidnight4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 1560635475050L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        long long26 = unsupportedDateTimeField22.getDifferenceAsLong((long) 377, (long) (byte) -1);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime();
        java.util.Date date28 = dateTime27.toDate();
        org.joda.time.YearMonthDay yearMonthDay29 = dateTime27.toYearMonthDay();
        int[] intArray34 = new int[] { 891, 365, 'a' };
        try {
            int[] intArray36 = unsupportedDateTimeField22.add((org.joda.time.ReadablePartial) yearMonthDay29, 19, intArray34, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(yearMonthDay29);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        java.util.Date date2 = dateTime1.toDate();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime(dateTimeZone3);
        long long6 = dateTimeZone0.getMillisKeepLocal(dateTimeZone3, (long) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        try {
            long long12 = iSOChronology7.getDateTimeMillis(936, (int) (short) 0, 624097, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(iSOChronology7);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime2 = dateTime0.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfCentury(0);
        org.joda.time.DateTime.Property property11 = dateTime8.dayOfWeek();
        int int12 = property11.getLeapAmount();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) 891, (long) 1);
        long long15 = offsetDateTimeField7.add(0L, (long) (-1));
        int int17 = offsetDateTimeField7.get(405L);
        int int19 = offsetDateTimeField7.getMinimumValue((long) '#');
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3600891L + "'", long12 == 3600891L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-3600000L) + "'", long15 == (-3600000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
        long long12 = offsetDateTimeField7.add((long) 891, (long) 1);
        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField7.getWrappedField();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3600891L + "'", long12 == 3600891L);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.minus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusDays(936);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        java.util.Date date13 = dateTime12.toDate();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTime(dateTimeZone14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        java.util.Date date17 = dateTime16.toDate();
//        org.joda.time.YearMonthDay yearMonthDay18 = dateTime16.toYearMonthDay();
//        org.joda.time.DateTime.Property property19 = dateTime16.hourOfDay();
//        org.joda.time.DurationField durationField20 = property19.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property19.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 0, (-1), 0);
//        org.joda.time.DateTime dateTime27 = dateTime12.withField(dateTimeFieldType21, 4);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField29 = iSOChronology28.days();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology28.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField32 = iSOChronology28.dayOfMonth();
//        org.joda.time.DurationField durationField33 = iSOChronology28.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = unsupportedDateTimeField34.getType();
//        org.joda.time.DateTime dateTime37 = dateTime9.withField(dateTimeFieldType35, 15);
//        org.joda.time.DateTime.Property property38 = dateTime37.minuteOfDay();
//        java.lang.String str39 = property38.getAsString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateMidnight4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(yearMonthDay18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "952" + "'", str39.equals("952"));
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime0.withCenturyOfEra(52);
        org.joda.time.DateTime dateTime9 = dateTime0.withWeekyear((int) ' ');
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime12 = dateTime9.withDayOfMonth(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        long long10 = offsetDateTimeField7.set((long) 377, (int) (short) 1);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        java.util.Date date12 = dateTime11.toDate();
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
        org.joda.time.DateTime.Property property14 = dateTime11.hourOfDay();
        org.joda.time.DateMidnight dateMidnight15 = dateTime11.toDateMidnight();
        org.joda.time.DateTime dateTime17 = dateTime11.minusMillis(891);
        org.joda.time.DateTime dateTime19 = dateTime11.minusWeeks(2);
        org.joda.time.YearMonthDay yearMonthDay20 = dateTime11.toYearMonthDay();
        int[] intArray23 = new int[] { 28, 2000 };
        int int24 = offsetDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay20, intArray23);
        java.util.Locale locale27 = null;
        try {
            long long28 = offsetDateTimeField7.set((long) 1, "Property[hourOfDay]", locale27);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[hourOfDay]\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 377L + "'", long10 == 377L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateMidnight15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(yearMonthDay20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
//        boolean boolean7 = dateTime6.isAfterNow();
//        int int8 = dateTime6.getSecondOfDay();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateMidnight4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78720 + "'", int8 == 78720);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("Property[millisOfSecond]", (-10), (int) ' ', (int) (byte) 1, 'a', 100, 0, (int) (byte) 1, false, (int) (short) 10);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder21 = dateTimeZoneBuilder13.addCutover(0, '#', 52, (int) (short) 100, 0, true, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime0.minus(readablePeriod6);
        org.joda.time.DateTime dateTime8 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime9 = dateTime7.withEarlierOffsetAtOverlap();
        try {
            java.lang.String str11 = dateTime7.toString("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: I");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        java.util.Date date2 = dateTime1.toDate();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime(dateTimeZone3);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withZone(dateTimeZone3);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) (short) 10);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
//        java.util.Date date10 = dateTime9.toDate();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime9.toMutableDateTime(dateTimeZone11);
//        org.joda.time.DateTime dateTime14 = dateTime9.plusDays((int) (short) 10);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
//        java.util.Date date16 = dateTime15.toDate();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime18 = dateTime15.toMutableDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime15.plusDays((int) (short) 10);
//        boolean boolean21 = dateTime14.isAfter((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime24 = dateTime15.withDurationAdded((long) (byte) 100, (int) (byte) 1);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
//        java.util.Date date26 = dateTime25.toDate();
//        org.joda.time.YearMonthDay yearMonthDay27 = dateTime25.toYearMonthDay();
//        org.joda.time.DateTime.Property property28 = dateTime25.hourOfDay();
//        org.joda.time.DateTime dateTime29 = property28.withMinimumValue();
//        org.joda.time.DateTime dateTime31 = dateTime29.withYear((int) '#');
//        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime24, (org.joda.time.ReadableInstant) dateTime31);
//        java.lang.String str33 = dateTimeFormatter6.print((org.joda.time.ReadableInstant) dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(yearMonthDay27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "00:52:01" + "'", str33.equals("00:52:01"));
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        org.joda.time.DateTime dateTime9 = property6.roundCeilingCopy();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 60537409, (-10), 9, 9, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 60537409 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        boolean boolean5 = dateTime0.isBefore((long) (short) 0);
        org.joda.time.DateTime.Property property6 = dateTime0.millisOfSecond();
        int int7 = property6.getLeapAmount();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        java.util.Date date3 = dateTime2.toDate();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField5 = iSOChronology4.days();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        long long10 = iSOChronology4.add(readablePeriod7, (long) (short) 1, 0);
//        org.joda.time.DateTime dateTime11 = dateTime2.toDateTime((org.joda.time.Chronology) iSOChronology4);
//        boolean boolean12 = dateTime0.equals((java.lang.Object) dateTime11);
//        int int13 = dateTime0.getMinuteOfDay();
//        long long14 = dateTime0.getMillis();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1312 + "'", int13 == 1312);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560635522377L + "'", long14 == 1560635522377L);
//    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
//        boolean boolean2 = dateTime0.isSupported(dateTimeFieldType1);
//        int int3 = dateTime0.getMinuteOfHour();
//        org.joda.time.LocalDate localDate4 = dateTime0.toLocalDate();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
//        org.junit.Assert.assertNotNull(localDate4);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(876);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime4, dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime4.withPeriodAdded(readablePeriod8, (int) ' ');
        org.joda.time.DateTime.Property property11 = dateTime10.dayOfWeek();
        int int12 = property11.getLeapAmount();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime5);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal((-86399987L));
        long long13 = fixedDateTimeZone4.adjustOffset((long) 1312, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1312L + "'", long13 == 1312L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime0.minus(readablePeriod6);
        org.joda.time.DateTime dateTime8 = dateTime7.withLaterOffsetAtOverlap();
        org.joda.time.LocalDateTime localDateTime9 = dateTime8.toLocalDateTime();
        try {
            org.joda.time.DateTime dateTime14 = dateTime8.withTime(100, 1, 900, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDateTime9);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (short) -1, 15, 2, 195, (int) '4', 2200, 19, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 195 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear(2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        java.util.Date date4 = dateTime3.toDate();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTime.Property property6 = dateTime3.hourOfDay();
        org.joda.time.DurationField durationField7 = property6.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType8, 0, (-1), 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder2.appendSignedDecimal(dateTimeFieldType8, (int) (short) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        boolean boolean24 = unsupportedDateTimeField22.isSupported();
        java.util.Locale locale27 = null;
        try {
            long long28 = unsupportedDateTimeField22.set((long) 1311, "ISOChronology[UTC]", locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.YearMonthDay yearMonthDay8 = dateTime6.toYearMonthDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.hourOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        boolean boolean11 = dateTime6.isSupported(dateTimeFieldType10);
//        org.joda.time.DateTime dateTime13 = dateTime6.minusSeconds(6);
//        int int14 = dateTime6.getDayOfWeek();
//        boolean boolean15 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(yearMonthDay8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        java.util.Locale locale25 = null;
        try {
            java.lang.String str26 = unsupportedDateTimeField22.getAsShortText((-1), locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        int int7 = property3.getDifference((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime8.toDateTime(dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime8.centuryOfEra();
        org.joda.time.DateTime dateTime15 = property14.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime16 = property14.getDateTime();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime16);
        boolean boolean19 = dateTime16.isEqual((long) (short) 1);
        org.joda.time.DateTime dateTime21 = dateTime16.plusHours(2200);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
        java.util.Date date23 = dateTime22.toDate();
        org.joda.time.DateTime.Property property24 = dateTime22.hourOfDay();
        java.util.Locale locale25 = null;
        int int26 = property24.getMaximumShortTextLength(locale25);
        org.joda.time.DateTime dateTime27 = property24.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime29 = dateTime27.plus(100L);
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime16, (org.joda.time.ReadableInstant) dateTime29);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(chronology30);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime5.toMutableDateTime(dateTimeZone7);
        long long10 = dateTimeZone4.getMillisKeepLocal(dateTimeZone7, (long) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone7);
        org.joda.time.DurationField durationField13 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.dayOfMonth();
        org.joda.time.DurationField durationField5 = iSOChronology0.days();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime.Property property2 = dateTime0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime5);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        int int9 = fixedDateTimeZone4.getOffset(1560635475676L);
        long long11 = fixedDateTimeZone4.previousTransition((long) (short) 10);
        java.lang.String str13 = fixedDateTimeZone4.getNameKey((long) 900);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
        java.util.Date date15 = dateTime14.toDate();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime14.toMutableDateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime14.plusDays((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.minus(readablePeriod20);
        org.joda.time.DateTime dateTime22 = dateTime21.withLaterOffsetAtOverlap();
        org.joda.time.LocalDateTime localDateTime23 = dateTime22.toLocalDateTime();
        boolean boolean24 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime23);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019-06-15T14:51:14.819" + "'", str13.equals("2019-06-15T14:51:14.819"));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = property1.addToCopy((long) 15);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("org.joda.time.IllegalFieldValueException: Value \"UTC\" for  is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = iSOChronology0.get(readablePeriod5, (long) 730, (long) 22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime8.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
        java.util.Date date15 = dateTime14.toDate();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime14.toMutableDateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime14.plusDays((int) (short) 10);
        boolean boolean20 = dateTime13.isAfter((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
        java.util.Date date22 = dateTime21.toDate();
        org.joda.time.YearMonthDay yearMonthDay23 = dateTime21.toYearMonthDay();
        org.joda.time.DateTime dateTime24 = dateTime14.withFields((org.joda.time.ReadablePartial) yearMonthDay23);
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField7.getAsText((org.joda.time.ReadablePartial) yearMonthDay23, (int) (short) 1, locale26);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(yearMonthDay23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1" + "'", str27.equals("1"));
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withYear((int) '#');
//        int int3 = dateTime0.getMillisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime0.year();
//        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
//        org.joda.time.Interval interval6 = property4.toInterval();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(interval6);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime5.toYearMonthDay();
        org.joda.time.DateTime.Property property8 = dateTime5.hourOfDay();
        org.joda.time.DateMidnight dateMidnight9 = dateTime5.toDateMidnight();
        org.joda.time.DateTime dateTime11 = dateTime5.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime11.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.minus(readablePeriod13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusDays(936);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
        java.util.Date date18 = dateTime17.toDate();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime20 = dateTime17.toMutableDateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
        java.util.Date date22 = dateTime21.toDate();
        org.joda.time.YearMonthDay yearMonthDay23 = dateTime21.toYearMonthDay();
        org.joda.time.DateTime.Property property24 = dateTime21.hourOfDay();
        org.joda.time.DurationField durationField25 = property24.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType26, 0, (-1), 0);
        org.joda.time.DateTime dateTime32 = dateTime17.withField(dateTimeFieldType26, 4);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField34 = iSOChronology33.days();
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology33.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology33.dayOfMonth();
        org.joda.time.DurationField durationField38 = iSOChronology33.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = unsupportedDateTimeField39.getType();
        org.joda.time.DateTime dateTime42 = dateTime14.withField(dateTimeFieldType40, 15);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType40, (int) (byte) -1);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField45 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(yearMonthDay7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(yearMonthDay23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTime42);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.minus((long) (short) 1);
        org.joda.time.DateTime dateTime11 = dateTime6.minusMinutes(24);
        boolean boolean13 = dateTime11.isAfter((long) 8);
        org.joda.time.DateTime dateTime15 = dateTime11.minusHours(325215);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        try {
            int int24 = unsupportedDateTimeField22.get(53473645L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear(21);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        int int2 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.LocalDateTime localDateTime3 = dateTime0.toLocalDateTime();
//        org.joda.time.Instant instant4 = dateTime0.toInstant();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(localDateTime3);
//        org.junit.Assert.assertNotNull(instant4);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.year();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        java.util.Date date8 = dateTime7.toDate();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime7.toMutableDateTime(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.secondOfDay();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.secondOfMinute();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(2019, 21, 624097, 365, (int) (byte) 10, 2200, 14, (org.joda.time.Chronology) iSOChronology11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral("Property[dayOfYear]");
        boolean boolean4 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.minus(readableDuration7);
        org.joda.time.DateTime dateTime10 = dateTime4.withWeekyear(730);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField7 = iSOChronology6.halfdays();
        java.lang.String str8 = iSOChronology6.toString();
        org.joda.time.DurationField durationField9 = iSOChronology6.years();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        java.util.Date date11 = dateTime10.toDate();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime10.toMutableDateTime(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology6, dateTimeZone12);
        org.joda.time.DurationField durationField15 = zonedChronology14.seconds();
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology14.yearOfEra();
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(0, 0, 891, 624097, 2000, 0, (org.joda.time.Chronology) zonedChronology14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 624097 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ISOChronology[UTC]" + "'", str8.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        boolean boolean3 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeFormatter4.getZone();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        java.util.Date date13 = dateTime12.toDate();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime12.plusDays((int) (short) 10);
        boolean boolean18 = dateTime11.isAfter((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
        java.util.Date date20 = dateTime19.toDate();
        org.joda.time.YearMonthDay yearMonthDay21 = dateTime19.toYearMonthDay();
        org.joda.time.DateTime dateTime22 = dateTime12.withFields((org.joda.time.ReadablePartial) yearMonthDay21);
        java.lang.String str23 = dateTimeFormatter4.print((org.joda.time.ReadablePartial) yearMonthDay21);
        java.lang.String str24 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) yearMonthDay21);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter0.withChronology(chronology25);
        try {
            long long28 = dateTimeFormatter0.parseMillis("00:52:01");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"00:52:01\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(yearMonthDay21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "��:��:��" + "'", str23.equals("��:��:��"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "��:��:��" + "'", str24.equals("��:��:��"));
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        long long8 = cachedDateTimeZone6.previousTransition((long) 624097);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        try {
            long long17 = gregorianChronology9.getDateTimeMillis(9, (int) 'a', 8, 876, (int) (byte) 1, (int) '#', 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 876 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 624097L + "'", long8 == 624097L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime5.toMutableDateTime(dateTimeZone7);
        long long10 = dateTimeZone4.getMillisKeepLocal(dateTimeZone7, (long) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone7);
        org.joda.time.DurationField durationField13 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology0.year();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField3 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) (short) 1, 0);
        org.joda.time.DateTime dateTime9 = dateTime0.toDateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime11 = dateTime0.withYear(45);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = unsupportedDateTimeField22.getAsText((int) 'a', locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfDay();
        java.lang.String str6 = iSOChronology4.toString();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.yearOfCentury();
        long long11 = iSOChronology4.add((long) 405, (long) 'a', 2);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[UTC]" + "'", str6.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 599L + "'", long11 == 599L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime5.toMutableDateTime(dateTimeZone7);
        long long10 = dateTimeZone4.getMillisKeepLocal(dateTimeZone7, (long) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone7);
        org.joda.time.DurationField durationField13 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField15 = iSOChronology0.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("00:00:00", (java.lang.Number) 45, (java.lang.Number) (byte) 0, (java.lang.Number) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertNull(dateTimeFieldType6);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(510L);
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        java.util.Date date3 = dateTime2.toDate();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime2.plusDays((int) (short) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        java.util.Date date9 = dateTime8.toDate();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = dateTime8.plusDays((int) (short) 10);
//        boolean boolean14 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime17 = dateTime8.withDurationAdded((long) (byte) 100, (int) (byte) 1);
//        org.joda.time.DateTime dateTime19 = dateTime8.withWeekyear((int) (short) 0);
//        org.joda.time.DateTime dateTime21 = dateTime8.plusWeeks((int) (short) 10);
//        java.lang.String str22 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime21);
//        boolean boolean23 = gregorianChronology0.equals((java.lang.Object) dateTimeFormatter1);
//        long long28 = gregorianChronology0.getDateTimeMillis(2000, 3, 14, (int) (short) 0);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019-08-24T21" + "'", str22.equals("2019-08-24T21"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 952992000000L + "'", long28 == 952992000000L);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15T14:51:14.482");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("2019-06-15T14:51:14.482");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.YearMonthDay yearMonthDay8 = dateTime6.toYearMonthDay();
        org.joda.time.DateTime.Property property9 = dateTime6.hourOfDay();
        org.joda.time.DateMidnight dateMidnight10 = dateTime6.toDateMidnight();
        org.joda.time.DateTime dateTime12 = dateTime6.minusMillis(891);
        org.joda.time.DateTime.Property property13 = dateTime6.secondOfDay();
        jodaTimePermission5.checkGuard((java.lang.Object) property13);
        boolean boolean15 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"2019-06-15T14:51:14.482\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"2019-06-15T14:51:14.482\")"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(yearMonthDay8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        java.lang.String str23 = unsupportedDateTimeField22.toString();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
        java.util.Date date25 = dateTime24.toDate();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime27 = dateTime24.toMutableDateTime(dateTimeZone26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime24.toDateTime(dateTimeZone28);
        org.joda.time.LocalTime localTime30 = dateTime24.toLocalTime();
        boolean boolean31 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime30);
        int[] intArray39 = new int[] { 10, (-900), (byte) 100, 2000, 22, 22 };
        try {
            int[] intArray41 = unsupportedDateTimeField22.addWrapField((org.joda.time.ReadablePartial) localTime30, (-1), intArray39, 2200);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UnsupportedDateTimeField" + "'", str23.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(intArray39);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 100, (-3), 78720, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        boolean boolean23 = unsupportedDateTimeField22.isSupported();
        try {
            int int25 = unsupportedDateTimeField22.getMinimumValue((long) 900);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime8 = dateTime4.withDurationAdded((long) 365, (int) (byte) 100);
        org.joda.time.DateTime.Property property9 = dateTime4.yearOfCentury();
        org.joda.time.DateTime dateTime11 = dateTime4.withYearOfCentury(20);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        long long26 = unsupportedDateTimeField22.getDifferenceAsLong((long) 377, (long) (byte) -1);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime();
        java.util.Date date28 = dateTime27.toDate();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime30 = dateTime27.toMutableDateTime(dateTimeZone29);
        boolean boolean32 = dateTime27.isBefore((long) (short) 0);
        org.joda.time.TimeOfDay timeOfDay33 = dateTime27.toTimeOfDay();
        try {
            int int34 = unsupportedDateTimeField22.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(timeOfDay33);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime.Property property2 = dateTime0.hourOfDay();
        org.joda.time.DateTime.Property property3 = dateTime0.dayOfWeek();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DurationField durationField4 = property3.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = property3.getFieldType();
        org.joda.time.DateTime dateTime6 = property3.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        boolean boolean23 = unsupportedDateTimeField22.isSupported();
        try {
            java.lang.String str25 = unsupportedDateTimeField22.getAsShortText((long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("Property[millisOfSecond]", (-10), (int) ' ', (int) (byte) 1, 'a', 100, 0, (int) (byte) 1, false, (int) (short) 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder24 = dateTimeZoneBuilder13.addRecurringSavings("", 845, 78720, 0, ' ', 100, 876, 1, true, 1312);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder24);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) (byte) 10, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("4591-04-14T06", (java.lang.Number) (-3600000L), (java.lang.Number) 936, (java.lang.Number) 0.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        int int8 = offsetDateTimeField7.getMinimumValue();
        long long10 = offsetDateTimeField7.roundHalfEven((-100L));
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(1, locale12);
        long long15 = offsetDateTimeField7.roundHalfFloor(81153044735152L);
        long long18 = offsetDateTimeField7.add((long) (-10), 0L);
        long long21 = offsetDateTimeField7.add((long) (byte) 100, 0L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 81153043200000L + "'", long15 == 81153043200000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-10L) + "'", long18 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = iSOChronology0.add(readablePeriod3, (long) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.dayOfWeek();
        try {
            long long13 = iSOChronology0.getDateTimeMillis((long) (byte) -1, 0, 28, 2000, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        boolean boolean24 = unsupportedDateTimeField22.isSupported();
        try {
            long long26 = unsupportedDateTimeField22.roundHalfFloor(82713680228405L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        long long8 = cachedDateTimeZone6.previousTransition((long) 624097);
//        java.lang.String str10 = cachedDateTimeZone6.getName(81153043200000L);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 624097L + "'", long8 == 624097L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime5.toMutableDateTime(dateTimeZone7);
        long long10 = dateTimeZone4.getMillisKeepLocal(dateTimeZone7, (long) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone7);
        org.joda.time.DurationField durationField13 = iSOChronology0.hours();
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray15 = null;
        try {
            iSOChronology0.validate(readablePartial14, intArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(durationField13);
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        java.util.Date date5 = dateTime4.toDate();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) iSOChronology8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 53473645L, (org.joda.time.Chronology) iSOChronology8);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime4.toMutableDateTime((org.joda.time.Chronology) iSOChronology8);
//        int int12 = mutableDateTime11.getMillisOfDay();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 78729964 + "'", int12 == 78729964);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        boolean boolean23 = unsupportedDateTimeField22.isSupported();
        try {
            long long25 = unsupportedDateTimeField22.roundHalfEven((long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
        org.joda.time.DateTime.Property property6 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfCentury(0);
        org.joda.time.DateTime.Property property11 = dateTime8.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime13 = property11.setCopy((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long2 = dateTimeZone0.convertUTCToLocal(0L);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1312);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1312");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.withYear((int) '#');
        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadablePartial) localDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        java.util.Locale locale25 = null;
        try {
            java.lang.String str26 = unsupportedDateTimeField22.getAsShortText(readablePartial23, 45, locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.DateTime.Property property5 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 325215, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(0);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withLocale(locale4);
        java.lang.StringBuffer stringBuffer6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        java.util.Date date8 = dateTime7.toDate();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime7.toYearMonthDay();
        org.joda.time.DateTime.Property property10 = dateTime7.hourOfDay();
        org.joda.time.DateMidnight dateMidnight11 = dateTime7.toDateMidnight();
        org.joda.time.DateTime dateTime13 = dateTime7.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime13.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        java.util.Date date17 = dateTime16.toDate();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime19 = dateTime16.toMutableDateTime(dateTimeZone18);
        long long21 = dateTimeZone15.getMillisKeepLocal(dateTimeZone18, (long) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField23 = iSOChronology22.millis();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) dateTime13, (org.joda.time.Chronology) iSOChronology22);
        try {
            dateTimeFormatter3.printTo(stringBuffer6, (org.joda.time.ReadableInstant) dateTime24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        int int8 = offsetDateTimeField7.getMinimumValue();
        long long10 = offsetDateTimeField7.roundHalfEven((-100L));
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(1, locale12);
        long long15 = offsetDateTimeField7.roundHalfFloor(81153044735152L);
        int int17 = offsetDateTimeField7.getMaximumValue((long) 78729964);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 81153043200000L + "'", long15 == 81153043200000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        org.joda.time.DurationField durationField2 = iSOChronology0.years();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime.Property property2 = dateTime0.secondOfMinute();
        org.joda.time.DateTime dateTime4 = property2.addToCopy(1);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.DateTime dateTime7 = dateTime4.withFieldAdded(durationFieldType5, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '#');
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 365, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.minusWeeks((int) (short) 1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withPivotYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.append(dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendTimeZoneShortName();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        java.util.Date date14 = dateTime13.toDate();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime13.toMutableDateTime(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
        java.util.Date date18 = dateTime17.toDate();
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime17.toYearMonthDay();
        org.joda.time.DateTime.Property property20 = dateTime17.hourOfDay();
        org.joda.time.DurationField durationField21 = property20.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType22, 0, (-1), 0);
        org.joda.time.DateTime dateTime28 = dateTime13.withField(dateTimeFieldType22, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder12.appendFraction(dateTimeFieldType22, (int) ' ', 325215);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
//        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime15 = dateTime6.withDurationAdded((long) (byte) 100, (int) (byte) 1);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        java.util.Date date17 = dateTime16.toDate();
//        org.joda.time.YearMonthDay yearMonthDay18 = dateTime16.toYearMonthDay();
//        org.joda.time.DateTime.Property property19 = dateTime16.hourOfDay();
//        org.joda.time.DateTime dateTime20 = property19.withMinimumValue();
//        org.joda.time.DateTime dateTime22 = dateTime20.withYear((int) '#');
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime15, (org.joda.time.ReadableInstant) dateTime22);
//        int int24 = dateTime15.getMinuteOfDay();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
//        java.util.Date date26 = dateTime25.toDate();
//        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField28 = iSOChronology27.days();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod30 = null;
//        long long33 = iSOChronology27.add(readablePeriod30, (long) (short) 1, 0);
//        org.joda.time.DateTime dateTime34 = dateTime25.toDateTime((org.joda.time.Chronology) iSOChronology27);
//        org.joda.time.DateTime dateTime36 = dateTime25.plusMillis(52);
//        boolean boolean37 = dateTime15.equals((java.lang.Object) dateTime25);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(yearMonthDay18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1312 + "'", int24 == 1312);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(iSOChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1L + "'", long33 == 1L);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(14);
//        int int3 = dateTime2.getHourOfDay();
//        int int4 = dateTime2.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 22 + "'", int3 == 22);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
//    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withYear((int) '#');
//        int int3 = dateTime0.getMillisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime0.year();
//        org.joda.time.DateTime dateTime5 = property4.withMinimumValue();
//        int int6 = property4.getMaximumValue();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 244 + "'", int3 == 244);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long2 = dateTimeZone0.convertUTCToLocal(1L);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 13");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15T14:51:14.482");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.lang.String str3 = jodaTimePermission1.toString();
        java.lang.String str4 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"2019-06-15T14:51:14.482\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"2019-06-15T14:51:14.482\")"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019-06-15T14:51:14.482" + "'", str4.equals("2019-06-15T14:51:14.482"));
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.minus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusDays(936);
//        int int12 = dateTime11.getWeekOfWeekyear();
//        java.util.GregorianCalendar gregorianCalendar13 = dateTime11.toGregorianCalendar();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateMidnight4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 47 + "'", int12 == 47);
//        org.junit.Assert.assertNotNull(gregorianCalendar13);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.minus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis((int) (byte) 1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField3 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) (short) 1, 0);
        org.joda.time.DateTime dateTime9 = dateTime0.toDateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        boolean boolean24 = unsupportedDateTimeField22.isSupported();
        try {
            long long26 = unsupportedDateTimeField22.roundFloor((long) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime0.withCenturyOfEra(52);
        org.joda.time.DateTime dateTime9 = dateTime0.withWeekyear((int) ' ');
        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded((-100L), (int) (byte) -1);
        try {
            org.joda.time.DateTime dateTime14 = dateTime12.withDayOfYear((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,366]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DurationField durationField4 = iSOChronology1.years();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime5.toMutableDateTime(dateTimeZone7);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 0, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
        org.joda.time.DateTime.Property property7 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime9 = dateTime0.plusHours(900);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        long long6 = fixedDateTimeZone4.nextTransition(624097L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.clockhourOfDay();
        boolean boolean9 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeField8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        java.util.Date date11 = dateTime10.toDate();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime10.toMutableDateTime(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime10.plusDays((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime10.minus(readablePeriod16);
        org.joda.time.DateTime dateTime18 = dateTime17.withLaterOffsetAtOverlap();
        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
        boolean boolean20 = fixedDateTimeZone4.equals((java.lang.Object) localDateTime19);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 624097L + "'", long6 == 624097L);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime(dateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withZone(dateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField9 = iSOChronology8.days();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        long long14 = iSOChronology8.add(readablePeriod11, (long) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology8.dayOfWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 891, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime17.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(mutableDateTime18);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral("Property[dayOfYear]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfHour(1311, 8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        long long8 = cachedDateTimeZone6.previousTransition((long) 624097);
        int int10 = cachedDateTimeZone6.getOffset((long) (-1));
        long long12 = cachedDateTimeZone6.nextTransition(81153044735152L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 624097L + "'", long8 == 624097L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 81153044735152L + "'", long12 == 81153044735152L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property13 = dateTime5.dayOfMonth();
        org.joda.time.DateTime.Property property14 = dateTime5.yearOfEra();
        org.joda.time.DateTime.Property property15 = dateTime5.dayOfYear();
        org.joda.time.DateTime dateTime17 = property15.setCopy("19");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(1L);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
        int int3 = dateTime2.getMillisOfDay();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime0.withCenturyOfEra(52);
        org.joda.time.DateTime dateTime9 = dateTime0.withWeekyear((int) ' ');
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        org.joda.time.DateTime dateTime12 = dateTime9.withMillisOfDay(730);
        boolean boolean14 = dateTime9.isBefore((long) (byte) 100);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        int int16 = dateTime15.getYearOfEra();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1970 + "'", int16 == 1970);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        java.util.Date date2 = dateTime1.toDate();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTime.Property property4 = dateTime1.hourOfDay();
        org.joda.time.DateTime dateTime5 = property4.getDateTime();
        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfDay();
        org.joda.time.DateTime dateTime10 = dateTime5.plusYears(1311);
        try {
            org.joda.time.DateTime dateTime12 = dateTime5.withYearOfEra((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01T00:00:00.001" + "'", str7.equals("1970-01-01T00:00:00.001"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15T14:51:14.482");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        long long10 = fixedDateTimeZone8.nextTransition(1L);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) str3, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"(\"org.joda.time.JodaTimePermissi...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"2019-06-15T14:51:14.482\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"2019-06-15T14:51:14.482\")"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours(458);
        org.joda.time.DateTime dateTime6 = dateTime4.plusMinutes((int) (byte) 10);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(365, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 364 + "'", int2 == 364);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        long long8 = cachedDateTimeZone6.previousTransition((long) 624097);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 624097L + "'", long8 == 624097L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField8 = iSOChronology7.days();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        long long13 = iSOChronology7.add(readablePeriod10, (long) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology7.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime6.toMutableDateTime((org.joda.time.Chronology) iSOChronology7);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        long long8 = cachedDateTimeZone6.previousTransition((long) 624097);
        int int10 = cachedDateTimeZone6.getStandardOffset((long) 936);
        int int12 = cachedDateTimeZone6.getStandardOffset((-10L));
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 624097L + "'", long8 == 624097L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime.Property property2 = dateTime0.hourOfDay();
        org.joda.time.DateTime.Property property3 = dateTime0.dayOfYear();
        int int4 = property3.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property3.roundCeilingCopy();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        long long10 = offsetDateTimeField7.add((long) (short) 0, (int) (short) 1);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumTextLength(locale11);
        org.joda.time.DurationField durationField13 = offsetDateTimeField7.getRangeDurationField();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3600000L + "'", long10 == 3600000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15T14:51:14.482");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTime(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime4.toDateTime(dateTimeZone8);
        org.joda.time.DateTime.Property property10 = dateTime4.centuryOfEra();
        org.joda.time.DateTime dateTime11 = property10.roundHalfCeilingCopy();
        java.lang.String str12 = property10.toString();
        jodaTimePermission1.checkGuard((java.lang.Object) str12);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019-06-15T14:51:14.482" + "'", str3.equals("2019-06-15T14:51:14.482"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[centuryOfEra]" + "'", str12.equals("Property[centuryOfEra]"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(14);
        java.util.Date date3 = dateTime0.toDate();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("00:52:01");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"00:52:01\" is malformed at \":52:01\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        try {
            int int24 = unsupportedDateTimeField22.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(78729964);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-78729964) + "'", int1 == (-78729964));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(14);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.minus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.withYearOfCentury((int) '#');
        org.joda.time.DateTime.Property property7 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime8.toYearMonthDay();
        org.joda.time.DateTime.Property property11 = dateTime8.hourOfDay();
        org.joda.time.DateMidnight dateMidnight12 = dateTime8.toDateMidnight();
        int int13 = property7.getDifference((org.joda.time.ReadableInstant) dateTime8);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear(1970, 244);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
        java.util.Date date25 = dateTime24.toDate();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime27 = dateTime24.toMutableDateTime(dateTimeZone26);
        org.joda.time.DateTime dateTime29 = dateTime24.plusDays((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.DateTime dateTime31 = dateTime24.minus(readablePeriod30);
        org.joda.time.DateTime dateTime32 = dateTime31.withLaterOffsetAtOverlap();
        org.joda.time.LocalDateTime localDateTime33 = dateTime32.toLocalDateTime();
        java.util.Locale locale35 = null;
        try {
            java.lang.String str36 = unsupportedDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) localDateTime33, 3, locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDateTime33);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone6.getUncachedZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.field.FieldUtils.verifyValueBounds("4591-04-14T06", 24, 6, 364);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withPivotYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.append(dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendTwoDigitWeekyear((int) '4', true);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime4, dateTimeZone6);
        int int8 = dateTime7.getMillisOfDay();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime5);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        long long11 = fixedDateTimeZone4.convertLocalToUTC((long) (-3), false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-4L) + "'", long11 == (-4L));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("952");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour(405);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTwoDigitYear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendLiteral('4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.YearMonthDay yearMonthDay4 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
        org.joda.time.DateMidnight dateMidnight6 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime8 = dateTime2.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTime();
        int int10 = mutableDateTime9.getHourOfDay();
        int int13 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "ISOChronology[UTC]", 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(yearMonthDay4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 23 + "'", int10 == 23);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
        int int8 = mutableDateTime7.getHourOfDay();
        int int9 = mutableDateTime7.getYearOfEra();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 23 + "'", int8 == 23);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField8 = iSOChronology7.halfdays();
        java.lang.String str9 = iSOChronology7.toString();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology7.millisOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.dayOfYear();
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((int) (byte) 100, 325215, 78729964, 0, 0, 365, 9, (org.joda.time.Chronology) iSOChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[UTC]" + "'", str9.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        long long10 = offsetDateTimeField7.add((long) (short) 0, (int) (short) 1);
        long long12 = offsetDateTimeField7.roundHalfEven((long) (short) 10);
        int int14 = offsetDateTimeField7.getMaximumValue((long) 24);
        long long17 = offsetDateTimeField7.addWrapField((long) (short) 1, 2200);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3600000L + "'", long10 == 3600000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 57600001L + "'", long17 == 57600001L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 365, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.hourOfDay();
        int int4 = dateTime2.getWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
    }
}

