import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime0.minus(readablePeriod6);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        boolean boolean7 = cachedDateTimeZone6.isFixed();
//        org.joda.time.DateTimeZone dateTimeZone8 = cachedDateTimeZone6.getUncachedZone();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.year();
//        java.util.Locale locale11 = dateTimeFormatter10.getLocale();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter10.withPivotYear(0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter13.getPrinter();
//        org.joda.time.format.DateTimeParser dateTimeParser15 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter14, dateTimeParser15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
//        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter14, dateTimeParser18);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder9.append(dateTimeParser18);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendClockhourOfHalfday(876);
//        boolean boolean23 = cachedDateTimeZone6.equals((java.lang.Object) 876);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNull(locale11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(dateTimePrinter14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeParser18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withPivotYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.append(dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfHalfday(876);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendSecondOfDay((-3));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        long long10 = offsetDateTimeField7.add((long) (short) 0, (int) (short) 1);
        long long12 = offsetDateTimeField7.roundHalfEven((long) (short) 10);
        int int14 = offsetDateTimeField7.getMaximumValue((long) 24);
        org.joda.time.DurationField durationField15 = offsetDateTimeField7.getLeapDurationField();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3600000L + "'", long10 == 3600000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
        org.junit.Assert.assertNull(durationField15);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        java.util.Date date5 = dateTime4.toDate();
//        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
//        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
//        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField17 = iSOChronology16.days();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
//        org.joda.time.DurationField durationField21 = iSOChronology16.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.DateTimeZone dateTimeZone25 = dateTimeFormatter24.getZone();
//        boolean boolean26 = dateTimeFormatter24.isOffsetParsed();
//        boolean boolean27 = dateTimeFormatter24.isParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.DateTimeZone dateTimeZone29 = dateTimeFormatter28.getZone();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime();
//        java.util.Date date31 = dateTime30.toDate();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime33 = dateTime30.toMutableDateTime(dateTimeZone32);
//        org.joda.time.DateTime dateTime35 = dateTime30.plusDays((int) (short) 10);
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime();
//        java.util.Date date37 = dateTime36.toDate();
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime39 = dateTime36.toMutableDateTime(dateTimeZone38);
//        org.joda.time.DateTime dateTime41 = dateTime36.plusDays((int) (short) 10);
//        boolean boolean42 = dateTime35.isAfter((org.joda.time.ReadableInstant) dateTime36);
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime();
//        java.util.Date date44 = dateTime43.toDate();
//        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
//        org.joda.time.DateTime dateTime46 = dateTime36.withFields((org.joda.time.ReadablePartial) yearMonthDay45);
//        java.lang.String str47 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) yearMonthDay45);
//        java.lang.String str48 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) yearMonthDay45);
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField50 = iSOChronology49.halfdays();
//        java.lang.String str51 = iSOChronology49.toString();
//        org.joda.time.DateTimeField dateTimeField52 = iSOChronology49.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField53 = iSOChronology49.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField54 = iSOChronology49.millisOfSecond();
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime();
//        java.util.Date date56 = dateTime55.toDate();
//        org.joda.time.YearMonthDay yearMonthDay57 = dateTime55.toYearMonthDay();
//        org.joda.time.DateTime.Property property58 = dateTime55.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight59 = dateTime55.toDateMidnight();
//        org.joda.time.DateTime dateTime61 = dateTime55.minusMillis(891);
//        org.joda.time.DateTime dateTime63 = dateTime55.minusWeeks(2);
//        org.joda.time.YearMonthDay yearMonthDay64 = dateTime55.toYearMonthDay();
//        int[] intArray66 = iSOChronology49.get((org.joda.time.ReadablePartial) yearMonthDay64, 0L);
//        try {
//            int int67 = unsupportedDateTimeField22.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay45, intArray66);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(yearMonthDay6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(mutableDateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(yearMonthDay45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "��:��:��" + "'", str47.equals("��:��:��"));
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "��:��:��" + "'", str48.equals("��:��:��"));
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "ISOChronology[UTC]" + "'", str51.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(yearMonthDay57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateMidnight59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(yearMonthDay64);
//        org.junit.Assert.assertNotNull(intArray66);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 19, 730);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime.Property property2 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property2.addToCopy(22);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime5.toYearMonthDay();
        org.joda.time.DateTime.Property property8 = dateTime5.hourOfDay();
        org.joda.time.DateMidnight dateMidnight9 = dateTime5.toDateMidnight();
        org.joda.time.DateTime dateTime11 = dateTime5.minusMillis(891);
        org.joda.time.DateTime dateTime13 = dateTime5.minusWeeks(2);
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime5.toYearMonthDay();
        org.joda.time.DateTime dateTime15 = dateTime4.withFields((org.joda.time.ReadablePartial) yearMonthDay14);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(yearMonthDay7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime8 = dateTime4.withDurationAdded((long) 365, (int) (byte) 100);
        org.joda.time.DateTime.Property property9 = dateTime4.yearOfCentury();
        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMillis(52);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.withPeriodAdded(readablePeriod14, 15);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        java.util.Date date2 = dateTime1.toDate();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.hourOfDay();
//        org.joda.time.DateTime dateTime5 = property4.getDateTime();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
//        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.Chronology chronology8 = dateTimeFormatter0.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeFormatter0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTimeFormatter0.getZone();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01T00:00:00.001" + "'", str7.equals("1970-01-01T00:00:00.001"));
//        org.junit.Assert.assertNull(chronology8);
//        org.junit.Assert.assertNull(dateTimeZone9);
//        org.junit.Assert.assertNull(dateTimeZone10);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15T14:51:14.482");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15T14:51:14.482" + "'", str2.equals("2019-06-15T14:51:14.482"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        boolean boolean3 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeFormatter4.getZone();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        java.util.Date date13 = dateTime12.toDate();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime12.plusDays((int) (short) 10);
        boolean boolean18 = dateTime11.isAfter((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
        java.util.Date date20 = dateTime19.toDate();
        org.joda.time.YearMonthDay yearMonthDay21 = dateTime19.toYearMonthDay();
        org.joda.time.DateTime dateTime22 = dateTime12.withFields((org.joda.time.ReadablePartial) yearMonthDay21);
        java.lang.String str23 = dateTimeFormatter4.print((org.joda.time.ReadablePartial) yearMonthDay21);
        java.lang.String str24 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) yearMonthDay21);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter0.withChronology(chronology25);
        try {
            org.joda.time.LocalTime localTime28 = dateTimeFormatter26.parseLocalTime("91");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"91\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(yearMonthDay21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "��:��:��" + "'", str23.equals("��:��:��"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "��:��:��" + "'", str24.equals("��:��:��"));
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(78720, 2200, 2, 15, 100, 624097, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        boolean boolean4 = dateTimeFormatter2.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter2.withDefaultYear(51);
        org.junit.Assert.assertNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
//        java.lang.String str2 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField3 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.minuteOfHour();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-61200000L), (long) 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-489600000) + "'", int2 == (-489600000));
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone2.getShortName((long) 51, locale6);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHourOfDay((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
//        java.lang.String str2 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.hourOfDay();
//        org.joda.time.Chronology chronology6 = iSOChronology0.withUTC();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(chronology6);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime5.toMutableDateTime(dateTimeZone7);
        long long10 = dateTimeZone4.getMillisKeepLocal(dateTimeZone7, (long) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone7);
        org.joda.time.DurationField durationField13 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime5.toMutableDateTime(dateTimeZone7);
        long long10 = dateTimeZone4.getMillisKeepLocal(dateTimeZone7, (long) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone7);
        org.joda.time.DurationField durationField13 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.year();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        long long10 = offsetDateTimeField7.add((long) (short) 0, (int) (short) 1);
        int int12 = offsetDateTimeField7.getMaximumValue(0L);
        try {
            long long15 = offsetDateTimeField7.set(57600001L, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [1,24]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3600000L + "'", long10 == 3600000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        java.util.Date date14 = dateTime13.toDate();
        org.joda.time.YearMonthDay yearMonthDay15 = dateTime13.toYearMonthDay();
        org.joda.time.DateTime dateTime16 = dateTime6.withFields((org.joda.time.ReadablePartial) yearMonthDay15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTime16.toString("4591", locale18);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(yearMonthDay15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "4591" + "'", str19.equals("4591"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        org.joda.time.DurationField durationField24 = unsupportedDateTimeField22.getLeapDurationField();
        java.util.Locale locale26 = null;
        try {
            java.lang.String str27 = unsupportedDateTimeField22.getAsShortText((-10L), locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNull(durationField24);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 53473645L, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField5 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.year();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        int int4 = property3.getLeapAmount();
//        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
//        java.util.Locale locale8 = null;
//        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
//        long long12 = offsetDateTimeField7.add((long) 891, (long) 1);
//        long long15 = offsetDateTimeField7.add(0L, (long) (-1));
//        int int17 = offsetDateTimeField7.get(405L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeFormatter18.getZone();
//        boolean boolean20 = dateTimeFormatter18.isOffsetParsed();
//        boolean boolean21 = dateTimeFormatter18.isParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.DateTimeZone dateTimeZone23 = dateTimeFormatter22.getZone();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
//        java.util.Date date25 = dateTime24.toDate();
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime24.toMutableDateTime(dateTimeZone26);
//        org.joda.time.DateTime dateTime29 = dateTime24.plusDays((int) (short) 10);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime();
//        java.util.Date date31 = dateTime30.toDate();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime33 = dateTime30.toMutableDateTime(dateTimeZone32);
//        org.joda.time.DateTime dateTime35 = dateTime30.plusDays((int) (short) 10);
//        boolean boolean36 = dateTime29.isAfter((org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
//        java.util.Date date38 = dateTime37.toDate();
//        org.joda.time.YearMonthDay yearMonthDay39 = dateTime37.toYearMonthDay();
//        org.joda.time.DateTime dateTime40 = dateTime30.withFields((org.joda.time.ReadablePartial) yearMonthDay39);
//        java.lang.String str41 = dateTimeFormatter22.print((org.joda.time.ReadablePartial) yearMonthDay39);
//        java.lang.String str42 = dateTimeFormatter18.print((org.joda.time.ReadablePartial) yearMonthDay39);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime();
//        java.util.Date date45 = dateTime44.toDate();
//        org.joda.time.YearMonthDay yearMonthDay46 = dateTime44.toYearMonthDay();
//        org.joda.time.DateTime.Property property47 = dateTime44.hourOfDay();
//        int int48 = property47.getLeapAmount();
//        org.joda.time.DateTimeField dateTimeField49 = property47.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, (int) (short) 1);
//        long long54 = offsetDateTimeField51.set((long) 377, (int) (short) 1);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime();
//        java.util.Date date56 = dateTime55.toDate();
//        org.joda.time.YearMonthDay yearMonthDay57 = dateTime55.toYearMonthDay();
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime();
//        java.util.Date date59 = dateTime58.toDate();
//        org.joda.time.YearMonthDay yearMonthDay60 = dateTime58.toYearMonthDay();
//        org.joda.time.DateTime.Property property61 = dateTime58.hourOfDay();
//        int int62 = property61.getLeapAmount();
//        org.joda.time.DateTimeField dateTimeField63 = property61.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, (int) (short) 1);
//        long long68 = offsetDateTimeField65.set((long) 377, (int) (short) 1);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime();
//        java.util.Date date70 = dateTime69.toDate();
//        org.joda.time.YearMonthDay yearMonthDay71 = dateTime69.toYearMonthDay();
//        org.joda.time.DateTime.Property property72 = dateTime69.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight73 = dateTime69.toDateMidnight();
//        org.joda.time.DateTime dateTime75 = dateTime69.minusMillis(891);
//        org.joda.time.DateTime dateTime77 = dateTime69.minusWeeks(2);
//        org.joda.time.YearMonthDay yearMonthDay78 = dateTime69.toYearMonthDay();
//        int[] intArray81 = new int[] { 28, 2000 };
//        int int82 = offsetDateTimeField65.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay78, intArray81);
//        int int83 = offsetDateTimeField51.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay57, intArray81);
//        try {
//            int[] intArray85 = offsetDateTimeField7.add((org.joda.time.ReadablePartial) yearMonthDay39, 377, intArray81, 325215);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 377");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3600891L + "'", long12 == 3600891L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-3600000L) + "'", long15 == (-3600000L));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(mutableDateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(yearMonthDay39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "��:��:��" + "'", str41.equals("��:��:��"));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "��:��:��" + "'", str42.equals("��:��:��"));
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(yearMonthDay46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 377L + "'", long54 == 377L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(yearMonthDay57);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(yearMonthDay60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 377L + "'", long68 == 377L);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(yearMonthDay71);
//        org.junit.Assert.assertNotNull(property72);
//        org.junit.Assert.assertNotNull(dateMidnight73);
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(yearMonthDay78);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 24 + "'", int82 == 24);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 24 + "'", int83 == 24);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 325215);
        long long9 = fixedDateTimeZone4.convertLocalToUTC(82713680228405L, true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019-06-15T14:51:14.819" + "'", str6.equals("2019-06-15T14:51:14.819"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 82713680228404L + "'", long9 == 82713680228404L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        int int8 = offsetDateTimeField7.getMinimumValue();
        long long10 = offsetDateTimeField7.roundHalfEven((-100L));
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsText(1, locale12);
        long long15 = offsetDateTimeField7.roundHalfFloor(81153044735152L);
        long long18 = offsetDateTimeField7.add((long) 4, (int) (short) 1);
        int int19 = offsetDateTimeField7.getOffset();
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField7.getAsShortText(1, locale21);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 81153043200000L + "'", long15 == 81153043200000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3600004L + "'", long18 == 3600004L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1" + "'", str22.equals("1"));
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        java.util.Date date9 = dateTime8.toDate();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = dateTime8.plusDays((int) (short) 10);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
//        java.util.Date date15 = dateTime14.toDate();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime17 = dateTime14.toMutableDateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = dateTime14.plusDays((int) (short) 10);
//        boolean boolean20 = dateTime13.isAfter((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime23 = dateTime14.withDurationAdded((long) (byte) 100, (int) (byte) 1);
//        org.joda.time.DateTime dateTime25 = dateTime14.withWeekyear((int) (short) 0);
//        org.joda.time.DateTime dateTime27 = dateTime14.plusWeeks((int) (short) 10);
//        java.lang.String str28 = dateTimeFormatter7.print((org.joda.time.ReadableInstant) dateTime27);
//        boolean boolean29 = gregorianChronology6.equals((java.lang.Object) dateTimeFormatter7);
//        org.joda.time.Chronology chronology30 = gregorianChronology6.withUTC();
//        try {
//            org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(13, 2000, 2200, 8, 2000, (int) (short) 1, (org.joda.time.Chronology) gregorianChronology6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970-03-12T00" + "'", str28.equals("1970-03-12T00"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(chronology30);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
//        java.lang.String str2 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.YearMonthDay yearMonthDay8 = dateTime6.toYearMonthDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight10 = dateTime6.toDateMidnight();
//        org.joda.time.DateTime dateTime12 = dateTime6.minusMillis(891);
//        org.joda.time.DateTime dateTime14 = dateTime6.minusWeeks(2);
//        org.joda.time.YearMonthDay yearMonthDay15 = dateTime6.toYearMonthDay();
//        int[] intArray17 = iSOChronology0.get((org.joda.time.ReadablePartial) yearMonthDay15, 0L);
//        org.joda.time.DurationField durationField18 = iSOChronology0.days();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(yearMonthDay8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(yearMonthDay15);
//        org.junit.Assert.assertNotNull(intArray17);
//        org.junit.Assert.assertNotNull(durationField18);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
//        boolean boolean7 = dateTime4.isBefore(0L);
//        java.util.Date date8 = dateTime4.toDate();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
//        java.util.Date date11 = dateTime10.toDate();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime10.toMutableDateTime(dateTimeZone12);
//        long long15 = dateTimeZone9.getMillisKeepLocal(dateTimeZone12, (long) (short) -1);
//        long long19 = dateTimeZone9.convertLocalToUTC((-1L), true, 53473645L);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) date8, dateTimeZone9);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        java.lang.String str23 = unsupportedDateTimeField22.toString();
        try {
            boolean boolean25 = unsupportedDateTimeField22.isLeap(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UnsupportedDateTimeField" + "'", str23.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.minus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays(936);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        java.util.Date date13 = dateTime12.toDate();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        java.util.Date date17 = dateTime16.toDate();
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime16.toYearMonthDay();
        org.joda.time.DateTime.Property property19 = dateTime16.hourOfDay();
        org.joda.time.DurationField durationField20 = property19.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property19.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 0, (-1), 0);
        org.joda.time.DateTime dateTime27 = dateTime12.withField(dateTimeFieldType21, 4);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField29 = iSOChronology28.days();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology28.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology28.dayOfMonth();
        org.joda.time.DurationField durationField33 = iSOChronology28.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = unsupportedDateTimeField34.getType();
        org.joda.time.DateTime dateTime37 = dateTime9.withField(dateTimeFieldType35, 15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "1970-03-12T00");
        java.lang.String str40 = illegalFieldValueException39.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(yearMonthDay18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1970-03-12T00" + "'", str40.equals("1970-03-12T00"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        boolean boolean23 = unsupportedDateTimeField22.isSupported();
        try {
            int int25 = unsupportedDateTimeField22.getMinimumValue(952992000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
        java.util.GregorianCalendar gregorianCalendar8 = dateTime6.toGregorianCalendar();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(gregorianCalendar8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.plusSeconds(52);
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = dateTime5.toString("UnsupportedDateTimeField", locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: U");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTime.Property property2 = dateTime0.hourOfDay();
        org.joda.time.DateTime.Property property3 = dateTime0.dayOfYear();
        int int4 = property3.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property3.withMaximumValue();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readablePeriod6);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour(405);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfMonth((-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        java.util.Locale locale26 = null;
        try {
            long long27 = unsupportedDateTimeField22.set(3600891L, "2019-06-15T21:52:09.240", locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.plusSeconds(52);
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime5.toMutableDateTimeISO();
        java.lang.String str18 = dateTime5.toString("0");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime4, dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime4.withPeriodAdded(readablePeriod8, (int) ' ');
        boolean boolean11 = dateTime10.isBeforeNow();
        try {
            org.joda.time.DateTime dateTime15 = dateTime10.withDate(936, 14, 20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 14 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear(2);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        java.util.Date date4 = dateTime3.toDate();
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime3.hourOfDay();
//        org.joda.time.DateTime dateTime7 = property6.getDateTime();
//        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) dateTime7, dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime7.withPeriodAdded(readablePeriod11, (int) ' ');
//        boolean boolean14 = dateTime13.isBeforeNow();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField16 = iSOChronology15.halfdays();
//        java.lang.String str17 = iSOChronology15.toString();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.minuteOfDay();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
//        java.util.Date date20 = dateTime19.toDate();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime19.toYearMonthDay();
//        org.joda.time.DateTime.Property property22 = dateTime19.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight23 = dateTime19.toDateMidnight();
//        org.joda.time.DateTime dateTime25 = dateTime19.minusMillis(891);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime25.toMutableDateTime();
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.minus(readablePeriod27);
//        org.joda.time.DateTime dateTime30 = dateTime28.minusDays(936);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime();
//        java.util.Date date32 = dateTime31.toDate();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime34 = dateTime31.toMutableDateTime(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime();
//        java.util.Date date36 = dateTime35.toDate();
//        org.joda.time.YearMonthDay yearMonthDay37 = dateTime35.toYearMonthDay();
//        org.joda.time.DateTime.Property property38 = dateTime35.hourOfDay();
//        org.joda.time.DurationField durationField39 = property38.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property38.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType40, 0, (-1), 0);
//        org.joda.time.DateTime dateTime46 = dateTime31.withField(dateTimeFieldType40, 4);
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField48 = iSOChronology47.days();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology47.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology47.dayOfMonth();
//        org.joda.time.DurationField durationField52 = iSOChronology47.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField53 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType40, durationField52);
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = unsupportedDateTimeField53.getType();
//        org.joda.time.DateTime dateTime56 = dateTime28.withField(dateTimeFieldType54, 15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType54, (int) (byte) -1);
//        org.joda.time.DateTime dateTime60 = dateTime13.withField(dateTimeFieldType54, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType54, 51);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder62.appendClockhourOfHalfday(1312);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder70 = dateTimeFormatterBuilder62.appendTimeZoneOffset("(\"org.joda.time.JodaTimePermission\" \"2019-06-15T14:51:14.482\")", "4591-04-14T06", true, 20, 876);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateMidnight23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(yearMonthDay37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField53);
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder70);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        org.joda.time.DurationField durationField24 = unsupportedDateTimeField22.getLeapDurationField();
        java.util.Locale locale25 = null;
        try {
            int int26 = unsupportedDateTimeField22.getMaximumShortTextLength(locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNull(durationField24);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        long long8 = cachedDateTimeZone6.previousTransition((long) 624097);
//        java.lang.String str10 = cachedDateTimeZone6.getNameKey(82713680228404L);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 624097L + "'", long8 == 624097L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        long long8 = cachedDateTimeZone6.previousTransition((long) 624097);
//        int int10 = cachedDateTimeZone6.getStandardOffset((long) 936);
//        boolean boolean11 = cachedDateTimeZone6.isFixed();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 624097L + "'", long8 == 624097L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withYear((int) '#');
//        int int3 = dateTime0.getMillisOfSecond();
//        org.joda.time.DateTime.Property property4 = dateTime0.year();
//        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
//        java.util.TimeZone timeZone11 = dateTimeZone8.toTimeZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
//        boolean boolean13 = cachedDateTimeZone12.isFixed();
//        org.joda.time.DateTimeZone dateTimeZone14 = cachedDateTimeZone12.getUncachedZone();
//        org.joda.time.DateTime dateTime15 = dateTime5.withZoneRetainFields(dateTimeZone14);
//        org.joda.time.DateTime dateTime17 = dateTime5.withWeekyear(891);
//        org.joda.time.DateTime dateTime19 = dateTime5.plusYears(325215);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        int int4 = property3.getLeapAmount();
//        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
//        long long10 = offsetDateTimeField7.add((long) 405, (long) 0);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField7.getAsShortText(0L, locale12);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 405L + "'", long10 == 405L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withPivotYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.append(dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder0.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMillisOfDay(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendCenturyOfEra((-78729964), 458);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        java.util.Date date3 = dateTime2.toDate();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime2.plusDays((int) (short) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        java.util.Date date9 = dateTime8.toDate();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = dateTime8.plusDays((int) (short) 10);
//        boolean boolean14 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime17 = dateTime8.withDurationAdded((long) (byte) 100, (int) (byte) 1);
//        org.joda.time.DateTime dateTime19 = dateTime8.withWeekyear((int) (short) 0);
//        org.joda.time.DateTime dateTime21 = dateTime8.plusWeeks((int) (short) 10);
//        java.lang.String str22 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime21);
//        boolean boolean23 = gregorianChronology0.equals((java.lang.Object) dateTimeFormatter1);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
//        java.util.Date date25 = dateTime24.toDate();
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime24.toMutableDateTime(dateTimeZone26);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
//        java.util.TimeZone timeZone29 = dateTimeZone26.toTimeZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone30 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone26);
//        boolean boolean31 = cachedDateTimeZone30.isFixed();
//        org.joda.time.DateTimeZone dateTimeZone32 = cachedDateTimeZone30.getUncachedZone();
//        boolean boolean33 = gregorianChronology0.equals((java.lang.Object) dateTimeZone32);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970-03-12T00" + "'", str22.equals("1970-03-12T00"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        java.util.Date date3 = dateTime2.toDate();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime2.plusDays((int) (short) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        java.util.Date date9 = dateTime8.toDate();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = dateTime8.plusDays((int) (short) 10);
//        boolean boolean14 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime17 = dateTime8.withDurationAdded((long) (byte) 100, (int) (byte) 1);
//        org.joda.time.DateTime dateTime19 = dateTime8.withWeekyear((int) (short) 0);
//        org.joda.time.DateTime dateTime21 = dateTime8.plusWeeks((int) (short) 10);
//        java.lang.String str22 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime21);
//        boolean boolean23 = gregorianChronology0.equals((java.lang.Object) dateTimeFormatter1);
//        org.joda.time.Chronology chronology24 = gregorianChronology0.withUTC();
//        try {
//            long long32 = gregorianChronology0.getDateTimeMillis((int) ' ', 292278993, (-1), 1311, 876, 6, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1311 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970-03-12T00" + "'", str22.equals("1970-03-12T00"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(chronology24);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        java.lang.StringBuffer stringBuffer4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.DateTime.Property property7 = dateTime5.hourOfDay();
        org.joda.time.DateTime.Property property8 = dateTime5.dayOfYear();
        int int9 = property8.getMaximumValue();
        org.joda.time.DateTime dateTime10 = property8.withMaximumValue();
        org.joda.time.DateTime dateTime12 = dateTime10.minusHours(13);
        try {
            dateTimeFormatter2.printTo(stringBuffer4, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (byte) 10, 730, 876, (-3), (-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        boolean boolean5 = dateTime0.isSupported(dateTimeFieldType4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime0.plus(readablePeriod6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime0.withFieldAdded(durationFieldType8, (-489600000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour(405);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTwoDigitYear(3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        java.util.Date date6 = dateTime5.toDate();
//        org.joda.time.YearMonthDay yearMonthDay7 = dateTime5.toYearMonthDay();
//        org.joda.time.DateTime.Property property8 = dateTime5.hourOfDay();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        boolean boolean11 = dateTime9.isSupported(dateTimeFieldType10);
//        int int12 = property8.getDifference((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        java.util.Date date14 = dateTime13.toDate();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime16 = dateTime13.toMutableDateTime(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime13.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime.Property property19 = dateTime13.centuryOfEra();
//        org.joda.time.DateTime dateTime20 = property19.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime21 = property19.getDateTime();
//        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) dateTime21);
//        boolean boolean24 = dateTime21.isEqual((long) (short) 1);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
//        java.util.Date date26 = dateTime25.toDate();
//        org.joda.time.YearMonthDay yearMonthDay27 = dateTime25.toYearMonthDay();
//        org.joda.time.DateTime.Property property28 = dateTime25.hourOfDay();
//        org.joda.time.DurationField durationField29 = property28.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property28.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType30, 0, (-1), 0);
//        boolean boolean35 = dateTime21.isSupported(dateTimeFieldType30);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType30);
//        dateTimeFormatterBuilder4.clear();
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime();
//        java.util.Date date39 = dateTime38.toDate();
//        org.joda.time.YearMonthDay yearMonthDay40 = dateTime38.toYearMonthDay();
//        org.joda.time.DateTime.Property property41 = dateTime38.hourOfDay();
//        org.joda.time.DurationField durationField42 = property41.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property41.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder4.appendFixedDecimal(dateTimeFieldType43, 1969);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(yearMonthDay7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(yearMonthDay27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(yearMonthDay40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 377, (java.lang.Number) 82713680228405L, (java.lang.Number) 100.0d);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
        java.util.Date date29 = dateTime28.toDate();
        org.joda.time.YearMonthDay yearMonthDay30 = dateTime28.toYearMonthDay();
        org.joda.time.DateTime.Property property31 = dateTime28.hourOfDay();
        org.joda.time.DurationField durationField32 = property31.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField33 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField32);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(yearMonthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField33);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(14);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime0.minus(readablePeriod3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withYearOfCentury((int) '#');
//        java.lang.String str7 = dateTime6.toString();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1935-01-01T00:00:00.001Z" + "'", str7.equals("1935-01-01T00:00:00.001Z"));
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        boolean boolean5 = dateTime0.isBefore((long) (short) 0);
        org.joda.time.DateTime.Property property6 = dateTime0.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded(readableDuration8, 23);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        java.lang.String str23 = unsupportedDateTimeField22.toString();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
        java.util.Date date25 = dateTime24.toDate();
        org.joda.time.YearMonthDay yearMonthDay26 = dateTime24.toYearMonthDay();
        org.joda.time.DateTime.Property property27 = dateTime24.hourOfDay();
        int int28 = property27.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField29 = property27.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) (short) 1);
        long long34 = offsetDateTimeField31.add((long) (short) 0, (int) (short) 1);
        int int36 = offsetDateTimeField31.getMaximumValue(0L);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime39 = dateTime37.withYear((int) '#');
        org.joda.time.LocalDate localDate40 = dateTime39.toLocalDate();
        java.util.Locale locale42 = null;
        java.lang.String str43 = offsetDateTimeField31.getAsShortText((org.joda.time.ReadablePartial) localDate40, 1970, locale42);
        java.util.Locale locale44 = null;
        try {
            java.lang.String str45 = unsupportedDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) localDate40, locale44);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UnsupportedDateTimeField" + "'", str23.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(yearMonthDay26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3600000L + "'", long34 == 3600000L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 24 + "'", int36 == 24);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1970" + "'", str43.equals("1970"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "952");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField2 = iSOChronology1.halfdays();
//        java.lang.String str3 = iSOChronology1.toString();
//        org.joda.time.DurationField durationField4 = iSOChronology1.years();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        java.util.Date date6 = dateTime5.toDate();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime5.toMutableDateTime(dateTimeZone7);
//        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone7);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 0, (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DurationField durationField11 = iSOChronology1.centuries();
//        org.joda.time.DurationField durationField12 = iSOChronology1.years();
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(zonedChronology9);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(durationField12);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime4.isSupported(dateTimeFieldType5);
        int int7 = property3.getDifference((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        java.util.Date date9 = dateTime8.toDate();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime8.toDateTime(dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime8.centuryOfEra();
        org.joda.time.DateTime dateTime15 = property14.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime16 = property14.getDateTime();
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime.Property property18 = dateTime16.year();
        int int19 = property18.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 292278993 + "'", int19 == 292278993);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        long long25 = unsupportedDateTimeField22.add(0L, (int) (byte) -1);
        boolean boolean26 = unsupportedDateTimeField22.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField22.getType();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31536000000L) + "'", long25 == (-31536000000L));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        long long8 = cachedDateTimeZone6.previousTransition((long) 624097);
//        int int10 = cachedDateTimeZone6.getStandardOffset((long) 936);
//        long long12 = cachedDateTimeZone6.previousTransition((long) 1);
//        long long14 = cachedDateTimeZone6.nextTransition((long) '#');
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 624097L + "'", long8 == 624097L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        java.lang.String str23 = unsupportedDateTimeField22.toString();
        long long26 = unsupportedDateTimeField22.getDifferenceAsLong((long) (-489600000), 624097L);
        try {
            long long28 = unsupportedDateTimeField22.roundHalfFloor(1560635475050L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UnsupportedDateTimeField" + "'", str23.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        int int8 = offsetDateTimeField7.getMinimumValue();
        long long10 = offsetDateTimeField7.roundHalfEven((-100L));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumTextLength(locale11);
        org.joda.time.DurationField durationField13 = offsetDateTimeField7.getLeapDurationField();
        long long15 = offsetDateTimeField7.roundHalfFloor(1561499507302L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561500000000L + "'", long15 == 1561500000000L);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        boolean boolean7 = cachedDateTimeZone6.isFixed();
//        java.lang.String str9 = cachedDateTimeZone6.getNameKey(81153044735152L);
//        long long11 = cachedDateTimeZone6.nextTransition((long) (short) -1);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        int int4 = property3.getLeapAmount();
//        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
//        java.util.Locale locale8 = null;
//        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
//        java.lang.String str11 = offsetDateTimeField7.getAsText((long) 78720);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        java.util.Date date5 = dateTime4.toDate();
//        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
//        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
//        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField17 = iSOChronology16.days();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
//        org.joda.time.DurationField durationField21 = iSOChronology16.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        java.util.Date date24 = dateTime23.toDate();
//        org.joda.time.YearMonthDay yearMonthDay25 = dateTime23.toYearMonthDay();
//        org.joda.time.DateTime.Property property26 = dateTime23.hourOfDay();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = null;
//        boolean boolean29 = dateTime27.isSupported(dateTimeFieldType28);
//        int int30 = property26.getDifference((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime();
//        java.util.Date date32 = dateTime31.toDate();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime34 = dateTime31.toMutableDateTime(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime31.toDateTime(dateTimeZone35);
//        org.joda.time.DateTime.Property property37 = dateTime31.centuryOfEra();
//        org.joda.time.DateTime dateTime38 = property37.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime39 = property37.getDateTime();
//        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime27, (org.joda.time.ReadableInstant) dateTime39);
//        boolean boolean42 = dateTime39.isEqual((long) (short) 1);
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime();
//        java.util.Date date44 = dateTime43.toDate();
//        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
//        org.joda.time.DateTime.Property property46 = dateTime43.hourOfDay();
//        org.joda.time.DurationField durationField47 = property46.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = property46.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType48, 0, (-1), 0);
//        boolean boolean53 = dateTime39.isSupported(dateTimeFieldType48);
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime();
//        java.util.Date date55 = dateTime54.toDate();
//        org.joda.time.YearMonthDay yearMonthDay56 = dateTime54.toYearMonthDay();
//        org.joda.time.DateTime.Property property57 = dateTime54.hourOfDay();
//        int int58 = property57.getLeapAmount();
//        org.joda.time.DateTime dateTime60 = property57.addToCopy((long) 28);
//        org.joda.time.DateTimeFieldType dateTimeFieldType61 = property57.getFieldType();
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray62 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType9, dateTimeFieldType48, dateTimeFieldType61 };
//        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList63 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
//        boolean boolean64 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList63, dateTimeFieldTypeArray62);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter67 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList63, true, true);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(yearMonthDay6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(yearMonthDay25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(yearMonthDay45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeFieldType48);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(yearMonthDay56);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(dateTimeFieldType61);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray62);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter67);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        int int4 = property3.getLeapAmount();
//        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
//        java.util.Locale locale8 = null;
//        int int9 = offsetDateTimeField7.getMaximumTextLength(locale8);
//        long long12 = offsetDateTimeField7.add((long) 891, (long) 1);
//        long long15 = offsetDateTimeField7.add(0L, (long) (-1));
//        int int17 = offsetDateTimeField7.get(405L);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
//        java.util.Date date19 = dateTime18.toDate();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime21 = dateTime18.toMutableDateTime(dateTimeZone20);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
//        java.util.Date date23 = dateTime22.toDate();
//        org.joda.time.YearMonthDay yearMonthDay24 = dateTime22.toYearMonthDay();
//        org.joda.time.DateTime.Property property25 = dateTime22.hourOfDay();
//        org.joda.time.DurationField durationField26 = property25.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property25.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 0, (-1), 0);
//        org.joda.time.DateTime dateTime33 = dateTime18.withField(dateTimeFieldType27, 4);
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField35 = iSOChronology34.days();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology34.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology34.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology34.dayOfMonth();
//        org.joda.time.DurationField durationField39 = iSOChronology34.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField40 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField39);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = unsupportedDateTimeField40.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType41, (int) 'a');
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3600891L + "'", long12 == 3600891L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-3600000L) + "'", long15 == (-3600000L));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(yearMonthDay24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1970", (java.lang.Number) 1311, (java.lang.Number) 730, (java.lang.Number) 1312);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1312 + "'", number5.equals(1312));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        int int8 = offsetDateTimeField7.getMinimumValue();
        long long10 = offsetDateTimeField7.roundHalfEven((-100L));
        boolean boolean12 = offsetDateTimeField7.isLeap(51L);
        long long14 = offsetDateTimeField7.roundHalfEven(1561499507302L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1561500000000L + "'", long14 == 1561500000000L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour(405);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("2019-08-24T21");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYearOfEra(0, 365);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        int int8 = offsetDateTimeField7.getMinimumValue();
        long long10 = offsetDateTimeField7.roundHalfEven((-100L));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumTextLength(locale11);
        org.joda.time.DurationField durationField13 = offsetDateTimeField7.getLeapDurationField();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField7, 0, 78729964, 60537409);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for hourOfDay must be in the range [78729964,60537409]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNull(durationField13);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        long long25 = unsupportedDateTimeField22.add(0L, (int) (byte) -1);
        boolean boolean26 = unsupportedDateTimeField22.isSupported();
        try {
            int int27 = unsupportedDateTimeField22.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31536000000L) + "'", long25 == (-31536000000L));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear(2);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        java.util.Date date4 = dateTime3.toDate();
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime3.hourOfDay();
//        org.joda.time.DateTime dateTime7 = property6.getDateTime();
//        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) dateTime7, dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime7.withPeriodAdded(readablePeriod11, (int) ' ');
//        boolean boolean14 = dateTime13.isBeforeNow();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField16 = iSOChronology15.halfdays();
//        java.lang.String str17 = iSOChronology15.toString();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.minuteOfDay();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
//        java.util.Date date20 = dateTime19.toDate();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime19.toYearMonthDay();
//        org.joda.time.DateTime.Property property22 = dateTime19.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight23 = dateTime19.toDateMidnight();
//        org.joda.time.DateTime dateTime25 = dateTime19.minusMillis(891);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime25.toMutableDateTime();
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.minus(readablePeriod27);
//        org.joda.time.DateTime dateTime30 = dateTime28.minusDays(936);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime();
//        java.util.Date date32 = dateTime31.toDate();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime34 = dateTime31.toMutableDateTime(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime();
//        java.util.Date date36 = dateTime35.toDate();
//        org.joda.time.YearMonthDay yearMonthDay37 = dateTime35.toYearMonthDay();
//        org.joda.time.DateTime.Property property38 = dateTime35.hourOfDay();
//        org.joda.time.DurationField durationField39 = property38.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property38.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType40, 0, (-1), 0);
//        org.joda.time.DateTime dateTime46 = dateTime31.withField(dateTimeFieldType40, 4);
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField48 = iSOChronology47.days();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology47.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology47.dayOfMonth();
//        org.joda.time.DurationField durationField52 = iSOChronology47.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField53 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType40, durationField52);
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = unsupportedDateTimeField53.getType();
//        org.joda.time.DateTime dateTime56 = dateTime28.withField(dateTimeFieldType54, 15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType54, (int) (byte) -1);
//        org.joda.time.DateTime dateTime60 = dateTime13.withField(dateTimeFieldType54, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType54, 51);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder62.appendClockhourOfHalfday(1312);
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder62.appendPattern("hi!");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateMidnight23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(yearMonthDay37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField53);
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
//        java.lang.String str2 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        java.util.Date date5 = dateTime4.toDate();
//        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight8 = dateTime4.toDateMidnight();
//        org.joda.time.DateTime dateTime10 = dateTime4.minusMillis(891);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.minus(readablePeriod12);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusDays(936);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        java.util.Date date17 = dateTime16.toDate();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime19 = dateTime16.toMutableDateTime(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
//        java.util.Date date21 = dateTime20.toDate();
//        org.joda.time.YearMonthDay yearMonthDay22 = dateTime20.toYearMonthDay();
//        org.joda.time.DateTime.Property property23 = dateTime20.hourOfDay();
//        org.joda.time.DurationField durationField24 = property23.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType25, 0, (-1), 0);
//        org.joda.time.DateTime dateTime31 = dateTime16.withField(dateTimeFieldType25, 4);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField33 = iSOChronology32.days();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology32.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology32.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology32.dayOfMonth();
//        org.joda.time.DurationField durationField37 = iSOChronology32.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField38 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = unsupportedDateTimeField38.getType();
//        org.joda.time.DateTime dateTime41 = dateTime13.withField(dateTimeFieldType39, 15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType39, (int) (byte) -1);
//        java.util.Locale locale44 = null;
//        int int45 = offsetDateTimeField43.getMaximumShortTextLength(locale44);
//        long long48 = offsetDateTimeField43.set((long) 22, (int) (short) 1);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(yearMonthDay6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(yearMonthDay22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 120022L + "'", long48 == 120022L);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        java.lang.String str23 = unsupportedDateTimeField22.toString();
        long long26 = unsupportedDateTimeField22.getDifferenceAsLong((long) (-489600000), 624097L);
        try {
            long long28 = unsupportedDateTimeField22.roundHalfFloor((long) 20);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UnsupportedDateTimeField" + "'", str23.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        java.util.Date date2 = dateTime1.toDate();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.hourOfDay();
//        org.joda.time.DateTime dateTime5 = property4.getDateTime();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
//        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime.Property property8 = dateTime5.millisOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime5.plusYears(1311);
//        int int11 = dateTime10.getMillisOfSecond();
//        int int12 = dateTime10.getYearOfCentury();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01T00:00:00.001" + "'", str7.equals("1970-01-01T00:00:00.001"));
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 81 + "'", int12 == 81);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime4, dateTimeZone6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime10 = dateTime4.withPeriodAdded(readablePeriod8, (int) ' ');
//        int int11 = dateTime10.getDayOfMonth();
//        try {
//            org.joda.time.DateTime dateTime13 = dateTime10.withMinuteOfHour(2000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral("Property[dayOfYear]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay(20, 195);
        dateTimeFormatterBuilder6.clear();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime15 = dateTime6.withDurationAdded((long) (byte) 100, (int) (byte) 1);
        org.joda.time.DateTime dateTime17 = dateTime6.withWeekyear((int) (short) 0);
        org.joda.time.DateTime dateTime19 = dateTime6.plusWeeks((int) (short) 10);
        boolean boolean21 = dateTime6.isEqual((long) ' ');
        try {
            org.joda.time.DateTime dateTime23 = dateTime6.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 845, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 845L + "'", long2 == 845L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime15 = dateTime6.withDurationAdded((long) (byte) 100, (int) (byte) 1);
        java.util.Locale locale16 = null;
        java.util.Calendar calendar17 = dateTime15.toCalendar(locale16);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(calendar17);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("��:��:��", "");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        int int4 = property3.getLeapAmount();
//        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
//        long long10 = offsetDateTimeField7.add((long) (short) 0, (int) (short) 1);
//        long long12 = offsetDateTimeField7.roundHalfEven((long) (short) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField14 = iSOChronology13.halfdays();
//        java.lang.String str15 = iSOChronology13.toString();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology13.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology13.millisOfSecond();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
//        java.util.Date date20 = dateTime19.toDate();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime19.toYearMonthDay();
//        org.joda.time.DateTime.Property property22 = dateTime19.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight23 = dateTime19.toDateMidnight();
//        org.joda.time.DateTime dateTime25 = dateTime19.minusMillis(891);
//        org.joda.time.DateTime dateTime27 = dateTime19.minusWeeks(2);
//        org.joda.time.YearMonthDay yearMonthDay28 = dateTime19.toYearMonthDay();
//        int[] intArray30 = iSOChronology13.get((org.joda.time.ReadablePartial) yearMonthDay28, 0L);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField33 = iSOChronology32.halfdays();
//        java.lang.String str34 = iSOChronology32.toString();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology32.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology32.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology32.millisOfSecond();
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime();
//        java.util.Date date39 = dateTime38.toDate();
//        org.joda.time.YearMonthDay yearMonthDay40 = dateTime38.toYearMonthDay();
//        org.joda.time.DateTime.Property property41 = dateTime38.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight42 = dateTime38.toDateMidnight();
//        org.joda.time.DateTime dateTime44 = dateTime38.minusMillis(891);
//        org.joda.time.DateTime dateTime46 = dateTime38.minusWeeks(2);
//        org.joda.time.YearMonthDay yearMonthDay47 = dateTime38.toYearMonthDay();
//        int[] intArray49 = iSOChronology32.get((org.joda.time.ReadablePartial) yearMonthDay47, 0L);
//        try {
//            int[] intArray51 = offsetDateTimeField7.set((org.joda.time.ReadablePartial) yearMonthDay28, (int) (short) 0, intArray49, 2019);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [1,24]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3600000L + "'", long10 == 3600000L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ISOChronology[UTC]" + "'", str15.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateMidnight23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(yearMonthDay28);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "ISOChronology[UTC]" + "'", str34.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(yearMonthDay40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateMidnight42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(yearMonthDay47);
//        org.junit.Assert.assertNotNull(intArray49);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        java.util.Date date2 = dateTime1.toDate();
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField4 = iSOChronology3.days();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        long long9 = iSOChronology3.add(readablePeriod6, (long) (short) 1, 0);
//        org.joda.time.DateTime dateTime10 = dateTime1.toDateTime((org.joda.time.Chronology) iSOChronology3);
//        org.joda.time.DateTime.Property property11 = dateTime1.dayOfMonth();
//        org.joda.time.DateMidnight dateMidnight12 = dateTime1.toDateMidnight();
//        java.lang.String str13 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateMidnight12);
//        java.io.Writer writer14 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField16 = iSOChronology15.halfdays();
//        java.lang.String str17 = iSOChronology15.toString();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology15.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology15.millisOfSecond();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
//        java.util.Date date22 = dateTime21.toDate();
//        org.joda.time.YearMonthDay yearMonthDay23 = dateTime21.toYearMonthDay();
//        org.joda.time.DateTime.Property property24 = dateTime21.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight25 = dateTime21.toDateMidnight();
//        org.joda.time.DateTime dateTime27 = dateTime21.minusMillis(891);
//        org.joda.time.DateTime dateTime29 = dateTime21.minusWeeks(2);
//        org.joda.time.YearMonthDay yearMonthDay30 = dateTime21.toYearMonthDay();
//        int[] intArray32 = iSOChronology15.get((org.joda.time.ReadablePartial) yearMonthDay30, 0L);
//        try {
//            dateTimeFormatter0.printTo(writer14, (org.joda.time.ReadablePartial) yearMonthDay30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateMidnight12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "00:00:00" + "'", str13.equals("00:00:00"));
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(yearMonthDay23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateMidnight25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(yearMonthDay30);
//        org.junit.Assert.assertNotNull(intArray32);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.TimeZone timeZone1 = dateTimeZone0.toTimeZone();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = dateTimeZone0.getName((long) 60537409, locale4);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withYear((int) '#');
        org.joda.time.LocalDate localDate3 = dateTime2.toLocalDate();
        org.joda.time.DateTime dateTime5 = dateTime2.minus((long) 13);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
//        org.junit.Assert.assertNotNull(chronology2);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = dateTime0.toDateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime0.withCenturyOfEra(52);
        org.joda.time.DateTime dateTime9 = dateTime0.withWeekyear((int) ' ');
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
        int int11 = property10.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.minus(readableDuration7);
        org.joda.time.DateTime dateTime9 = dateTime4.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.plusSeconds(52);
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime5.toMutableDateTimeISO();
        boolean boolean18 = dateTime5.isEqual((long) 1970);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(891);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        java.util.Date date4 = dateTime3.toDate();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
//        java.util.Date date6 = dateTime5.toDate();
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField8 = iSOChronology7.days();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        long long13 = iSOChronology7.add(readablePeriod10, (long) (short) 1, 0);
//        org.joda.time.DateTime dateTime14 = dateTime5.toDateTime((org.joda.time.Chronology) iSOChronology7);
//        boolean boolean15 = dateTime3.equals((java.lang.Object) dateTime14);
//        java.lang.String str16 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1970-001" + "'", str16.equals("1970-001"));
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(6);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setFixedSavings("2019-06-15T14:51:12.401", 365);
        java.io.DataOutput dataOutput7 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", dataOutput7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.minus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays(936);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        java.util.Date date13 = dateTime12.toDate();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        java.util.Date date17 = dateTime16.toDate();
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime16.toYearMonthDay();
        org.joda.time.DateTime.Property property19 = dateTime16.hourOfDay();
        org.joda.time.DurationField durationField20 = property19.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property19.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 0, (-1), 0);
        org.joda.time.DateTime dateTime27 = dateTime12.withField(dateTimeFieldType21, 4);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField29 = iSOChronology28.days();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology28.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology28.dayOfMonth();
        org.joda.time.DurationField durationField33 = iSOChronology28.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = unsupportedDateTimeField34.getType();
        org.joda.time.DateTime dateTime37 = dateTime9.withField(dateTimeFieldType35, 15);
        org.joda.time.DateTime dateTime39 = dateTime9.withYearOfCentury((int) '#');
        org.joda.time.DateTime dateTime41 = dateTime39.withCenturyOfEra((int) 'a');
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(yearMonthDay18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour(405);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("2019-08-24T21");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendSecondOfMinute((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        boolean boolean5 = dateTime0.isSupported(dateTimeFieldType4);
        org.joda.time.DateTime dateTime7 = dateTime0.minusSeconds(6);
        int int8 = dateTime0.getDayOfWeek();
        org.joda.time.DateTime dateTime10 = dateTime0.plusMonths((-1));
        org.joda.time.DateTime.Property property11 = dateTime10.dayOfMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long2 = dateTimeZone0.convertUTCToLocal(1L);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        long long10 = fixedDateTimeZone8.nextTransition(624097L);
        long long12 = dateTimeZone0.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone8, (long) 364);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 624097L + "'", long10 == 624097L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 363L + "'", long12 == 363L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        boolean boolean3 = dateTimeFormatter2.isParser();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 'a');
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
//        java.lang.String str2 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField3 = iSOChronology0.years();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        java.util.Date date5 = dateTime4.toDate();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTime(dateTimeZone6);
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone6);
//        org.joda.time.DurationField durationField9 = zonedChronology8.seconds();
//        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.yearOfEra();
//        long long15 = zonedChronology8.getDateTimeMillis(2, 1, (int) (byte) 10, 51);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
//        org.joda.time.LocalDateTime localDateTime21 = null;
//        boolean boolean22 = fixedDateTimeZone20.isLocalDateTimeGap(localDateTime21);
//        org.joda.time.Chronology chronology23 = zonedChronology8.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62103283199949L) + "'", long15 == (-62103283199949L));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(chronology23);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(28799999L, chronology1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfYear();
//        int int5 = property4.get();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28799999L + "'", long3 == 28799999L);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        org.joda.time.DurationField durationField24 = unsupportedDateTimeField22.getLeapDurationField();
        org.joda.time.DurationField durationField25 = unsupportedDateTimeField22.getRangeDurationField();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertNull(durationField25);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime15 = dateTime6.withDurationAdded((long) (byte) 100, (int) (byte) 1);
        org.joda.time.DateTime dateTime17 = dateTime6.withWeekyear((int) (short) 0);
        org.joda.time.DateTime.Property property18 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime19 = property18.withMaximumValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime5);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        boolean boolean8 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property13 = dateTime5.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
        java.util.Date date16 = dateTime15.toDate();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime15.toMutableDateTime(dateTimeZone17);
        long long20 = dateTimeZone14.getMillisKeepLocal(dateTimeZone17, (long) (short) -1);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.DurationField durationField22 = iSOChronology21.millis();
        org.joda.time.DateTime dateTime23 = dateTime5.withChronology((org.joda.time.Chronology) iSOChronology21);
        org.joda.time.DateTime dateTime24 = dateTime5.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        java.util.Date date2 = dateTime1.toDate();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime(dateTimeZone3);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        java.util.TimeZone timeZone6 = dateTimeZone3.toTimeZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(599L, dateTimeZone3);
//        java.lang.String str10 = dateTimeZone3.getName(0L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = unsupportedDateTimeField22.getAsShortText((long) (byte) -1, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        int int4 = property3.getLeapAmount();
//        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
//        int int8 = offsetDateTimeField7.getMinimumValue();
//        long long10 = offsetDateTimeField7.roundHalfEven((-100L));
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField7.getAsText(1, locale12);
//        long long15 = offsetDateTimeField7.roundHalfFloor(81153044735152L);
//        long long18 = offsetDateTimeField7.add((long) 4, (int) (short) 1);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = offsetDateTimeField7.getAsText(405L, locale20);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 81153043200000L + "'", long15 == 81153043200000L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3600004L + "'", long18 == 3600004L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.minus((long) (short) 1);
        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded(10L, 0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 14, (-31536000000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-31535999986L) + "'", long2 == (-31535999986L));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour(405);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendCenturyOfEra(81, 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        boolean boolean24 = unsupportedDateTimeField22.isSupported();
        java.util.Locale locale26 = null;
        try {
            java.lang.String str27 = unsupportedDateTimeField22.getAsShortText(0L, locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long2 = dateTimeZone0.convertUTCToLocal(1L);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        org.joda.time.DurationField durationField5 = property4.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 22, 2200, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime14 = property13.roundHalfFloorCopy();
        org.joda.time.DateTime.Property property15 = dateTime14.millisOfDay();
        org.joda.time.DurationField durationField16 = property15.getLeapDurationField();
        boolean boolean17 = property15.isLeap();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        java.util.Date date3 = dateTime2.toDate();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime2.plusDays((int) (short) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        java.util.Date date9 = dateTime8.toDate();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = dateTime8.plusDays((int) (short) 10);
//        boolean boolean14 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime17 = dateTime8.withDurationAdded((long) (byte) 100, (int) (byte) 1);
//        org.joda.time.DateTime dateTime19 = dateTime8.withWeekyear((int) (short) 0);
//        org.joda.time.DateTime dateTime21 = dateTime8.plusWeeks((int) (short) 10);
//        java.lang.String str22 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime21);
//        boolean boolean23 = gregorianChronology0.equals((java.lang.Object) dateTimeFormatter1);
//        try {
//            long long31 = gregorianChronology0.getDateTimeMillis(78720, 195, 0, 0, 730, 28, 1970);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 730 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019-08-24T21" + "'", str22.equals("2019-08-24T21"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        long long10 = offsetDateTimeField7.add((long) 405, (long) 0);
        long long13 = offsetDateTimeField7.add(3600004L, (-1));
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
        java.util.Date date15 = dateTime14.toDate();
        org.joda.time.YearMonthDay yearMonthDay16 = dateTime14.toYearMonthDay();
        org.joda.time.DateTime.Property property17 = dateTime14.hourOfDay();
        int int18 = property17.getLeapAmount();
        org.joda.time.DateTime dateTime20 = property17.addToCopy((long) 28);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property17.getFieldType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, (int) (short) 100, 78729964, (-3));
        org.joda.time.DurationField durationField26 = offsetDateTimeField25.getDurationField();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 405L + "'", long10 == 405L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 4L + "'", long13 == 4L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(yearMonthDay16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(durationField26);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(14);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime0.minus(readablePeriod3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withYearOfCentury((int) '#');
//        org.joda.time.DateTime.Property property7 = dateTime4.secondOfDay();
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime4.plus(readableDuration8);
//        int int10 = dateTime4.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1312 + "'", int10 == 1312);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("��:��:��", "ISOChronology[America/Los_Angeles]", 6, (int) (byte) 10);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateTime dateTime7 = dateTime4.plusHours((int) (short) -1);
        boolean boolean9 = dateTime7.isEqual((-28800000L));
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        int int4 = property3.getLeapAmount();
//        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
//        long long10 = offsetDateTimeField7.set((long) 377, (int) (short) 1);
//        java.util.Locale locale13 = null;
//        try {
//            long long14 = offsetDateTimeField7.set((long) 10, "", locale13);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for hourOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 377L + "'", long10 == 377L);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "UTC");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("", "UTC");
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException6.getSuppressed();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException6);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear(2);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        java.util.Date date4 = dateTime3.toDate();
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
//        org.joda.time.DateTime.Property property6 = dateTime3.hourOfDay();
//        org.joda.time.DateTime dateTime7 = property6.getDateTime();
//        org.joda.time.DateMidnight dateMidnight8 = dateTime7.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) dateTime7, dateTimeZone9);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime7.withPeriodAdded(readablePeriod11, (int) ' ');
//        boolean boolean14 = dateTime13.isBeforeNow();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField16 = iSOChronology15.halfdays();
//        java.lang.String str17 = iSOChronology15.toString();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.minuteOfDay();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
//        java.util.Date date20 = dateTime19.toDate();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime19.toYearMonthDay();
//        org.joda.time.DateTime.Property property22 = dateTime19.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight23 = dateTime19.toDateMidnight();
//        org.joda.time.DateTime dateTime25 = dateTime19.minusMillis(891);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime25.toMutableDateTime();
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime25.minus(readablePeriod27);
//        org.joda.time.DateTime dateTime30 = dateTime28.minusDays(936);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime();
//        java.util.Date date32 = dateTime31.toDate();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime34 = dateTime31.toMutableDateTime(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime();
//        java.util.Date date36 = dateTime35.toDate();
//        org.joda.time.YearMonthDay yearMonthDay37 = dateTime35.toYearMonthDay();
//        org.joda.time.DateTime.Property property38 = dateTime35.hourOfDay();
//        org.joda.time.DurationField durationField39 = property38.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property38.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType40, 0, (-1), 0);
//        org.joda.time.DateTime dateTime46 = dateTime31.withField(dateTimeFieldType40, 4);
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField48 = iSOChronology47.days();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField50 = iSOChronology47.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology47.dayOfMonth();
//        org.joda.time.DurationField durationField52 = iSOChronology47.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField53 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType40, durationField52);
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = unsupportedDateTimeField53.getType();
//        org.joda.time.DateTime dateTime56 = dateTime28.withField(dateTimeFieldType54, 15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType54, (int) (byte) -1);
//        org.joda.time.DateTime dateTime60 = dateTime13.withField(dateTimeFieldType54, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType54, 51);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ISOChronology[UTC]" + "'", str17.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateMidnight23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(yearMonthDay37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField53);
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        int int8 = offsetDateTimeField7.getMinimumValue();
        long long10 = offsetDateTimeField7.roundHalfEven((-100L));
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumTextLength(locale11);
        org.joda.time.DurationField durationField13 = offsetDateTimeField7.getDurationField();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
//        java.lang.String str2 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfSecond();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.YearMonthDay yearMonthDay8 = dateTime6.toYearMonthDay();
//        org.joda.time.DateTime.Property property9 = dateTime6.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight10 = dateTime6.toDateMidnight();
//        org.joda.time.DateTime dateTime12 = dateTime6.minusMillis(891);
//        org.joda.time.DateTime dateTime14 = dateTime6.minusWeeks(2);
//        org.joda.time.YearMonthDay yearMonthDay15 = dateTime6.toYearMonthDay();
//        int[] intArray17 = iSOChronology0.get((org.joda.time.ReadablePartial) yearMonthDay15, 0L);
//        try {
//            long long22 = iSOChronology0.getDateTimeMillis(1969, (int) (byte) 0, 364, 28);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(yearMonthDay8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(yearMonthDay15);
//        org.junit.Assert.assertNotNull(intArray17);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("1970");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
        org.joda.time.DateTime dateTime9 = dateTime6.minus((long) (short) 1);
        org.joda.time.DateTime dateTime11 = dateTime6.minusMinutes(24);
        boolean boolean13 = dateTime11.isEqual((-28800000L));
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime14 = property13.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
        java.util.Date date16 = dateTime15.toDate();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime15.toMutableDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime15.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
        java.util.Date date22 = dateTime21.toDate();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime21.toMutableDateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime21.plusDays((int) (short) 10);
        boolean boolean27 = dateTime20.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
        java.util.Date date29 = dateTime28.toDate();
        org.joda.time.YearMonthDay yearMonthDay30 = dateTime28.toYearMonthDay();
        org.joda.time.DateTime dateTime31 = dateTime21.withFields((org.joda.time.ReadablePartial) yearMonthDay30);
        org.joda.time.DateTime dateTime33 = dateTime21.plus(3600891L);
        int int34 = property13.compareTo((org.joda.time.ReadableInstant) dateTime21);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(yearMonthDay30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        java.util.Date date7 = dateTime6.toDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
//        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property13 = dateTime5.millisOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime5.minus((long) '#');
//        org.joda.time.DateTime dateTime16 = dateTime5.toDateTimeISO();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        java.util.Date date18 = dateTime17.toDate();
//        org.joda.time.YearMonthDay yearMonthDay19 = dateTime17.toYearMonthDay();
//        org.joda.time.DateTime.Property property20 = dateTime17.hourOfDay();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
//        boolean boolean23 = dateTime21.isSupported(dateTimeFieldType22);
//        int int24 = property20.getDifference((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
//        java.util.Date date26 = dateTime25.toDate();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime28 = dateTime25.toMutableDateTime(dateTimeZone27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime25.toDateTime(dateTimeZone29);
//        org.joda.time.DateTime.Property property31 = dateTime25.centuryOfEra();
//        org.joda.time.DateTime dateTime32 = property31.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime33 = property31.getDateTime();
//        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime21, (org.joda.time.ReadableInstant) dateTime33);
//        boolean boolean36 = dateTime33.isEqual((long) (short) 1);
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
//        java.util.Date date38 = dateTime37.toDate();
//        org.joda.time.YearMonthDay yearMonthDay39 = dateTime37.toYearMonthDay();
//        org.joda.time.DateTime.Property property40 = dateTime37.hourOfDay();
//        org.joda.time.DurationField durationField41 = property40.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property40.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType42, 0, (-1), 0);
//        boolean boolean47 = dateTime33.isSupported(dateTimeFieldType42);
//        int int48 = dateTime33.getDayOfMonth();
//        org.joda.time.Chronology chronology49 = null;
//        org.joda.time.DateTime dateTime50 = dateTime33.toDateTime(chronology49);
//        int int51 = dateTime16.compareTo((org.joda.time.ReadableInstant) dateTime33);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(yearMonthDay19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(yearMonthDay39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 15 + "'", int48 == 15);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withPivotYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.append(dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale14 = dateTimeFormatter13.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter13.withPivotYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatter16.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder12.append(dateTimePrinter17, dateTimeParser19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder12.appendSecondOfMinute(845);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale24 = dateTimeFormatter23.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter23.withPivotYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter27 = dateTimeFormatter26.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser28 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter27, dateTimeParser28);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser31 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter27, dateTimeParser31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale34 = dateTimeFormatter33.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter33.withPivotYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter37 = dateTimeFormatter36.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser38 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter37, dateTimeParser38);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser41 = dateTimeFormatter40.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter37, dateTimeParser41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.append(dateTimePrinter27, dateTimeParser41);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNull(locale14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimePrinter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNull(locale24);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimePrinter27);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeParser31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNull(locale34);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimePrinter37);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimeParser41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.minus(readablePeriod8);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusDays(936);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
//        java.util.Date date13 = dateTime12.toDate();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTime(dateTimeZone14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        java.util.Date date17 = dateTime16.toDate();
//        org.joda.time.YearMonthDay yearMonthDay18 = dateTime16.toYearMonthDay();
//        org.joda.time.DateTime.Property property19 = dateTime16.hourOfDay();
//        org.joda.time.DurationField durationField20 = property19.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property19.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 0, (-1), 0);
//        org.joda.time.DateTime dateTime27 = dateTime12.withField(dateTimeFieldType21, 4);
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField29 = iSOChronology28.days();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology28.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField32 = iSOChronology28.dayOfMonth();
//        org.joda.time.DurationField durationField33 = iSOChronology28.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = unsupportedDateTimeField34.getType();
//        org.joda.time.DateTime dateTime37 = dateTime9.withField(dateTimeFieldType35, 15);
//        org.joda.time.DateTime.Property property38 = dateTime37.minuteOfDay();
//        org.joda.time.ReadablePeriod readablePeriod39 = null;
//        org.joda.time.DateTime dateTime40 = dateTime37.minus(readablePeriod39);
//        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField43 = iSOChronology42.halfdays();
//        java.lang.String str44 = iSOChronology42.toString();
//        org.joda.time.DurationField durationField45 = iSOChronology42.years();
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime();
//        java.util.Date date47 = dateTime46.toDate();
//        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime49 = dateTime46.toMutableDateTime(dateTimeZone48);
//        org.joda.time.chrono.ZonedChronology zonedChronology50 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology42, dateTimeZone48);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (short) 0, (org.joda.time.Chronology) iSOChronology42);
//        long long55 = iSOChronology42.add(0L, (long) (byte) -1, (int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone56 = iSOChronology42.getZone();
//        long long59 = dateTimeZone56.adjustOffset(81153044735152L, true);
//        long long62 = dateTimeZone56.adjustOffset((long) (byte) 100, false);
//        org.joda.time.DateTime dateTime63 = dateTime40.withZoneRetainFields(dateTimeZone56);
//        org.joda.time.ReadableDuration readableDuration64 = null;
//        org.joda.time.DateTime dateTime65 = dateTime40.plus(readableDuration64);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateMidnight4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(yearMonthDay18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(iSOChronology42);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "ISOChronology[UTC]" + "'", str44.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertNotNull(mutableDateTime49);
//        org.junit.Assert.assertNotNull(zonedChronology50);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-100L) + "'", long55 == (-100L));
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 81153044735152L + "'", long59 == 81153044735152L);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 100L + "'", long62 == 100L);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime65);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime5);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        int int9 = fixedDateTimeZone4.getOffset(1560635475676L);
        long long11 = fixedDateTimeZone4.previousTransition((long) (short) 10);
        java.lang.String str13 = fixedDateTimeZone4.getNameKey((long) 900);
        long long15 = fixedDateTimeZone4.previousTransition((-1L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019-06-15T14:51:14.819" + "'", str13.equals("2019-06-15T14:51:14.819"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
//        java.lang.String str2 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField3 = iSOChronology0.years();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        java.lang.String str13 = fixedDateTimeZone11.getNameKey((long) 325215);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone14);
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(0, 365, (int) (short) 10, (-78729964), 1, 900, (int) '#', dateTimeZone15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -78729964 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019-06-15T14:51:14.819" + "'", str13.equals("2019-06-15T14:51:14.819"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        long long6 = fixedDateTimeZone4.nextTransition(624097L);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 624097L + "'", long6 == 624097L);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withPivotYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.append(dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendFractionOfDay(0, 2);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        long long10 = offsetDateTimeField7.add((long) (short) 0, (int) (short) 1);
        int int12 = offsetDateTimeField7.getMaximumValue(0L);
        boolean boolean14 = offsetDateTimeField7.isLeap((long) 100);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField7.getAsShortText((int) (byte) 0, locale16);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField7.getAsShortText(845, locale19);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3600000L + "'", long10 == 3600000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "845" + "'", str20.equals("845"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.weekyears();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) ' ', (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField4 = gregorianChronology1.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField4);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        java.util.Date date4 = dateTime3.toDate();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTime(dateTimeZone5);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone(dateTimeZone5);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField10 = iSOChronology9.days();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.centuryOfEra();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        long long15 = iSOChronology9.add(readablePeriod12, (long) (short) 1, 0);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology9.dayOfWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 891, (org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DateTime dateTime20 = dateTime18.plusMonths(4);
//        java.lang.String str21 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime20);
//        java.lang.String str23 = dateTimeFormatter0.print((long) (-10));
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "00:00:00" + "'", str21.equals("00:00:00"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "23:59:59" + "'", str23.equals("23:59:59"));
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateTime dateTime4 = property3.getDateTime();
//        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime4, dateTimeZone6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime10 = dateTime4.withPeriodAdded(readablePeriod8, (int) ' ');
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        java.util.Date date12 = dateTime11.toDate();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime14 = dateTime11.toMutableDateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime11.plusDays((int) (short) 10);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        java.util.Date date18 = dateTime17.toDate();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime20 = dateTime17.toMutableDateTime(dateTimeZone19);
//        org.joda.time.DateTime dateTime22 = dateTime17.plusDays((int) (short) 10);
//        boolean boolean23 = dateTime16.isAfter((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime26 = dateTime17.withDurationAdded((long) (byte) 100, (int) (byte) 1);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime();
//        java.util.Date date28 = dateTime27.toDate();
//        org.joda.time.YearMonthDay yearMonthDay29 = dateTime27.toYearMonthDay();
//        org.joda.time.DateTime.Property property30 = dateTime27.hourOfDay();
//        org.joda.time.DateTime dateTime31 = property30.withMinimumValue();
//        org.joda.time.DateTime dateTime33 = dateTime31.withYear((int) '#');
//        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime26, (org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField37 = iSOChronology36.halfdays();
//        java.lang.String str38 = iSOChronology36.toString();
//        org.joda.time.DurationField durationField39 = iSOChronology36.years();
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime();
//        java.util.Date date41 = dateTime40.toDate();
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime43 = dateTime40.toMutableDateTime(dateTimeZone42);
//        org.joda.time.chrono.ZonedChronology zonedChronology44 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology36, dateTimeZone42);
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) (short) 0, (org.joda.time.Chronology) iSOChronology36);
//        long long49 = iSOChronology36.add(0L, (long) (byte) -1, (int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone50 = iSOChronology36.getZone();
//        long long53 = dateTimeZone50.adjustOffset(81153044735152L, true);
//        long long56 = dateTimeZone50.adjustOffset((long) (byte) 100, false);
//        org.joda.time.DateTime dateTime57 = dateTime26.toDateTime(dateTimeZone50);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = dateTimeZone50.getShortName((long) (-900), locale59);
//        org.joda.time.DateTime dateTime61 = dateTime4.withZoneRetainFields(dateTimeZone50);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateMidnight5);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(yearMonthDay29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ISOChronology[UTC]" + "'", str38.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(mutableDateTime43);
//        org.junit.Assert.assertNotNull(zonedChronology44);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-100L) + "'", long49 == (-100L));
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 81153044735152L + "'", long53 == 81153044735152L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 100L + "'", long56 == 100L);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "UTC" + "'", str60.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTime61);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withPivotYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.append(dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder0.appendFractionOfDay(0, 24);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime19 = dateTime17.plusMinutes(14);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime17.minus(readablePeriod20);
        org.joda.time.DateTime dateTime23 = dateTime17.withYearOfCentury((int) (byte) 0);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
        java.util.Date date25 = dateTime24.toDate();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime27 = dateTime24.toMutableDateTime(dateTimeZone26);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
        java.util.Date date29 = dateTime28.toDate();
        org.joda.time.YearMonthDay yearMonthDay30 = dateTime28.toYearMonthDay();
        org.joda.time.DateTime.Property property31 = dateTime28.hourOfDay();
        org.joda.time.DurationField durationField32 = property31.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property31.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType33, 0, (-1), 0);
        org.joda.time.DateTime dateTime39 = dateTime24.withField(dateTimeFieldType33, 4);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField41 = iSOChronology40.days();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology40.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology40.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology40.dayOfMonth();
        org.joda.time.DurationField durationField45 = iSOChronology40.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField45);
        boolean boolean47 = dateTime23.isSupported(dateTimeFieldType33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType33, 81);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(yearMonthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        boolean boolean5 = dateTime0.isSupported(dateTimeFieldType4);
//        org.joda.time.DateTime dateTime7 = dateTime0.minusSeconds(6);
//        int int8 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime dateTime10 = dateTime0.plusMonths((-1));
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField12 = iSOChronology11.days();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        java.util.Date date17 = dateTime16.toDate();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime19 = dateTime16.toMutableDateTime(dateTimeZone18);
//        long long21 = dateTimeZone15.getMillisKeepLocal(dateTimeZone18, (long) (short) -1);
//        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
//        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology11, dateTimeZone18);
//        org.joda.time.DurationField durationField24 = iSOChronology11.hours();
//        org.joda.time.MutableDateTime mutableDateTime25 = dateTime10.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
//        org.junit.Assert.assertNotNull(iSOChronology22);
//        org.junit.Assert.assertNotNull(zonedChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (short) 10);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime6.plusDays((int) (short) 10);
        boolean boolean12 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property13 = dateTime5.millisOfDay();
        org.joda.time.DateTime dateTime15 = dateTime5.minus((long) '#');
        org.joda.time.DateTime dateTime16 = dateTime5.toDateTimeISO();
        try {
            org.joda.time.DateTime dateTime18 = dateTime5.withEra(624097);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 624097 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(6);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("hi!", (-489600000), 244, 364, ' ', 0, 10, 21, false, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.secondOfMinute();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        java.util.Date date8 = dateTime7.toDate();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime7.toYearMonthDay();
        org.joda.time.DateTime.Property property10 = dateTime7.hourOfDay();
        org.joda.time.DateMidnight dateMidnight11 = dateTime7.toDateMidnight();
        org.joda.time.DateTime dateTime13 = dateTime7.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime13.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.minus(readablePeriod15);
        org.joda.time.DateTime dateTime18 = dateTime16.minusDays(936);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
        java.util.Date date20 = dateTime19.toDate();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime22 = dateTime19.toMutableDateTime(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        java.util.Date date24 = dateTime23.toDate();
        org.joda.time.YearMonthDay yearMonthDay25 = dateTime23.toYearMonthDay();
        org.joda.time.DateTime.Property property26 = dateTime23.hourOfDay();
        org.joda.time.DurationField durationField27 = property26.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property26.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType28, 0, (-1), 0);
        org.joda.time.DateTime dateTime34 = dateTime19.withField(dateTimeFieldType28, 4);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField36 = iSOChronology35.days();
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology35.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology35.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology35.dayOfMonth();
        org.joda.time.DurationField durationField40 = iSOChronology35.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = unsupportedDateTimeField41.getType();
        org.joda.time.DateTime dateTime44 = dateTime16.withField(dateTimeFieldType42, 15);
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) iSOChronology47);
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((java.lang.Object) 53473645L, (org.joda.time.Chronology) iSOChronology47);
        org.joda.time.DurationField durationField50 = iSOChronology47.days();
        long long53 = durationField50.subtract((long) 13, (long) (byte) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField54 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField50);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField56 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType42, 19);
        try {
            long long59 = dividedDateTimeField56.set(4L, (-78729964));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -78729964 for hourOfDay must be in the range [0,3]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(yearMonthDay25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-86399987L) + "'", long53 == (-86399987L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField54);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) 53473645L, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime4.toMutableDateTime((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DurationField durationField12 = iSOChronology8.millis();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour(405);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        boolean boolean4 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15T14:51:14.482");
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.YearMonthDay yearMonthDay4 = dateTime2.toYearMonthDay();
        org.joda.time.DateTime.Property property5 = dateTime2.hourOfDay();
        org.joda.time.DateMidnight dateMidnight6 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime8 = dateTime2.minusMillis(891);
        org.joda.time.DateTime.Property property9 = dateTime2.secondOfDay();
        jodaTimePermission1.checkGuard((java.lang.Object) property9);
        java.lang.String str11 = jodaTimePermission1.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(yearMonthDay4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"2019-06-15T14:51:14.482\")" + "'", str11.equals("(\"org.joda.time.JodaTimePermission\" \"2019-06-15T14:51:14.482\")"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("ZonedChronology[ISOChronology[UTC], UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'ZonedChronology[ISOChronology[UTC], UTC]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusYears(14);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
//        java.util.Date date10 = dateTime9.toDate();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime9.toMutableDateTime(dateTimeZone11);
//        org.joda.time.DateTime dateTime14 = dateTime9.plusDays((int) (short) 10);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
//        java.util.Date date16 = dateTime15.toDate();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime18 = dateTime15.toMutableDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime15.plusDays((int) (short) 10);
//        boolean boolean21 = dateTime14.isAfter((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime24 = dateTime15.withDurationAdded((long) (byte) 100, (int) (byte) 1);
//        org.joda.time.DateTime dateTime26 = dateTime15.withWeekyear((int) (short) 0);
//        boolean boolean27 = dateTime6.isEqual((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime29 = dateTime6.plusMonths(0);
//        int int30 = dateTime6.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateMidnight4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 24 + "'", int30 == 24);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
//        java.lang.String str2 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.dayOfYear();
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        try {
//            int[] intArray9 = iSOChronology0.get(readablePeriod6, 0L, 28799999L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = unsupportedDateTimeField22.getType();
        long long26 = unsupportedDateTimeField22.getDifferenceAsLong((long) 377, (long) (byte) -1);
        java.util.Locale locale29 = null;
        try {
            long long30 = unsupportedDateTimeField22.set((long) 876, "21:51:56Z", locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
//        java.lang.String str2 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField3 = iSOChronology0.years();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        java.util.Date date5 = dateTime4.toDate();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTime(dateTimeZone6);
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone6);
//        org.joda.time.DurationField durationField9 = zonedChronology8.seconds();
//        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.yearOfEra();
//        try {
//            long long16 = zonedChronology8.getDateTimeMillis((long) (short) 1, 876, 19, (int) (byte) 1, 900);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 876 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        int int4 = property3.getLeapAmount();
//        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
//        long long10 = offsetDateTimeField7.set((long) 377, (int) (short) 1);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        java.util.Date date12 = dateTime11.toDate();
//        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
//        java.util.Date date15 = dateTime14.toDate();
//        org.joda.time.YearMonthDay yearMonthDay16 = dateTime14.toYearMonthDay();
//        org.joda.time.DateTime.Property property17 = dateTime14.hourOfDay();
//        int int18 = property17.getLeapAmount();
//        org.joda.time.DateTimeField dateTimeField19 = property17.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (short) 1);
//        long long24 = offsetDateTimeField21.set((long) 377, (int) (short) 1);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
//        java.util.Date date26 = dateTime25.toDate();
//        org.joda.time.YearMonthDay yearMonthDay27 = dateTime25.toYearMonthDay();
//        org.joda.time.DateTime.Property property28 = dateTime25.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight29 = dateTime25.toDateMidnight();
//        org.joda.time.DateTime dateTime31 = dateTime25.minusMillis(891);
//        org.joda.time.DateTime dateTime33 = dateTime25.minusWeeks(2);
//        org.joda.time.YearMonthDay yearMonthDay34 = dateTime25.toYearMonthDay();
//        int[] intArray37 = new int[] { 28, 2000 };
//        int int38 = offsetDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay34, intArray37);
//        int int39 = offsetDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay13, intArray37);
//        int int42 = offsetDateTimeField7.getDifference(3600004L, (long) 81);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 377L + "'", long10 == 377L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(yearMonthDay13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(yearMonthDay16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 377L + "'", long24 == 377L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(yearMonthDay27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateMidnight29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(yearMonthDay34);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 24 + "'", int38 == 24);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 24 + "'", int39 == 24);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        java.util.Date date3 = dateTime2.toDate();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime2.plusDays((int) (short) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        java.util.Date date9 = dateTime8.toDate();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime8.toMutableDateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = dateTime8.plusDays((int) (short) 10);
//        boolean boolean14 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime17 = dateTime8.withDurationAdded((long) (byte) 100, (int) (byte) 1);
//        org.joda.time.DateTime dateTime19 = dateTime8.withWeekyear((int) (short) 0);
//        org.joda.time.DateTime dateTime21 = dateTime8.plusWeeks((int) (short) 10);
//        java.lang.String str22 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime21);
//        boolean boolean23 = gregorianChronology0.equals((java.lang.Object) dateTimeFormatter1);
//        java.io.Writer writer24 = null;
//        try {
//            dateTimeFormatter1.printTo(writer24, (long) 21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019-08-24T21" + "'", str22.equals("2019-08-24T21"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField3 = iSOChronology2.days();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = iSOChronology2.add(readablePeriod5, (long) (short) 1, 0);
        org.joda.time.DateTime dateTime9 = dateTime0.toDateTime((org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField10 = iSOChronology2.months();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        long long14 = fixedDateTimeZone12.nextTransition(624097L);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) dateTime6, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 624097L + "'", long14 == 624097L);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
//        org.joda.time.DateTime.Property property7 = dateTime0.secondOfDay();
//        java.lang.String str8 = property7.getAsShortText();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateMidnight4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "78762" + "'", str8.equals("78762"));
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime6.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.minus(readablePeriod8);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays(936);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        java.util.Date date13 = dateTime12.toDate();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        java.util.Date date17 = dateTime16.toDate();
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime16.toYearMonthDay();
        org.joda.time.DateTime.Property property19 = dateTime16.hourOfDay();
        org.joda.time.DurationField durationField20 = property19.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property19.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 0, (-1), 0);
        org.joda.time.DateTime dateTime27 = dateTime12.withField(dateTimeFieldType21, 4);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField29 = iSOChronology28.days();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology28.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology28.dayOfMonth();
        org.joda.time.DurationField durationField33 = iSOChronology28.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = unsupportedDateTimeField34.getType();
        org.joda.time.DateTime dateTime37 = dateTime9.withField(dateTimeFieldType35, 15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, "1970-03-12T00");
        java.lang.String str40 = illegalFieldValueException39.getFieldName();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(yearMonthDay18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hourOfDay" + "'", str40.equals("hourOfDay"));
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        int int3 = dateTime0.getMinuteOfDay();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime0.minus(readablePeriod4);
//        org.joda.time.DateTime.Property property6 = dateTime0.dayOfYear();
//        org.joda.time.DateTime dateTime8 = dateTime0.minusMinutes((int) (short) 100);
//        org.joda.time.DateTime.Property property9 = dateTime0.millisOfDay();
//        java.lang.String str10 = property9.getName();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1312 + "'", int3 == 1312);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "millisOfDay" + "'", str10.equals("millisOfDay"));
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[America/Los_Angeles]", "2019-06-15T14:51:14.819", (int) (short) 1, 936);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime5);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        int int9 = fixedDateTimeZone4.getOffset(1560635475676L);
        long long11 = fixedDateTimeZone4.previousTransition((long) (short) 10);
        int int13 = fixedDateTimeZone4.getStandardOffset((long) 405);
        boolean boolean14 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 936 + "'", int13 == 936);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        boolean boolean5 = dateTime0.isSupported(dateTimeFieldType4);
        org.joda.time.DateTime dateTime7 = dateTime0.plusHours(2200);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("23:59:59");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"23:59:59\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        int int4 = property3.getLeapAmount();
        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
        long long10 = offsetDateTimeField7.add((long) (short) 0, (int) (short) 1);
        long long12 = offsetDateTimeField7.roundHalfEven((long) (short) 10);
        int int14 = offsetDateTimeField7.getMaximumValue((long) 24);
        long long16 = offsetDateTimeField7.roundHalfCeiling((long) 14);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3600000L + "'", long10 == 3600000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DurationField durationField8 = property7.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 0, (-1), 0);
        org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType9, 4);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField17 = iSOChronology16.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.dayOfMonth();
        org.joda.time.DurationField durationField21 = iSOChronology16.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField21);
        long long25 = unsupportedDateTimeField22.add(0L, (int) (byte) -1);
        long long28 = unsupportedDateTimeField22.getDifferenceAsLong((long) 891, (long) (short) 0);
        try {
            long long30 = unsupportedDateTimeField22.roundHalfCeiling(28800010L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hourOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31536000000L) + "'", long25 == (-31536000000L));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 0, 2, 28, (int) '4', (-489600000), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        java.util.Date date1 = dateTime0.toDate();
//        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
//        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
//        int int4 = property3.getLeapAmount();
//        org.joda.time.DateTimeField dateTimeField5 = property3.getField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) 1);
//        long long10 = offsetDateTimeField7.add((long) (short) 0, (int) (short) 1);
//        int int12 = offsetDateTimeField7.getMaximumValue(0L);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime15 = dateTime13.withYear((int) '#');
//        org.joda.time.LocalDate localDate16 = dateTime15.toLocalDate();
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = offsetDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) localDate16, 1970, locale18);
//        int int21 = offsetDateTimeField7.get((-4L));
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(yearMonthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3600000L + "'", long10 == 3600000L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970" + "'", str19.equals("1970"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 24 + "'", int21 == 24);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        java.util.Date date3 = dateTime2.toDate();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime(dateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter1.withZone(dateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField9 = iSOChronology8.days();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        long long14 = iSOChronology8.add(readablePeriod11, (long) (short) 1, 0);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology8.dayOfWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 891, (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTime dateTime19 = dateTime17.minusMillis((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral("Property[dayOfYear]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay(20, 195);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHourOfHalfday(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear(22);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.secondOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.secondOfMinute();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        java.util.Date date8 = dateTime7.toDate();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime7.toYearMonthDay();
        org.joda.time.DateTime.Property property10 = dateTime7.hourOfDay();
        org.joda.time.DateMidnight dateMidnight11 = dateTime7.toDateMidnight();
        org.joda.time.DateTime dateTime13 = dateTime7.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime13.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.minus(readablePeriod15);
        org.joda.time.DateTime dateTime18 = dateTime16.minusDays(936);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
        java.util.Date date20 = dateTime19.toDate();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime22 = dateTime19.toMutableDateTime(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        java.util.Date date24 = dateTime23.toDate();
        org.joda.time.YearMonthDay yearMonthDay25 = dateTime23.toYearMonthDay();
        org.joda.time.DateTime.Property property26 = dateTime23.hourOfDay();
        org.joda.time.DurationField durationField27 = property26.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property26.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType28, 0, (-1), 0);
        org.joda.time.DateTime dateTime34 = dateTime19.withField(dateTimeFieldType28, 4);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField36 = iSOChronology35.days();
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology35.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology35.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology35.dayOfMonth();
        org.joda.time.DurationField durationField40 = iSOChronology35.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = unsupportedDateTimeField41.getType();
        org.joda.time.DateTime dateTime44 = dateTime16.withField(dateTimeFieldType42, 15);
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) iSOChronology47);
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((java.lang.Object) 53473645L, (org.joda.time.Chronology) iSOChronology47);
        org.joda.time.DurationField durationField50 = iSOChronology47.days();
        long long53 = durationField50.subtract((long) 13, (long) (byte) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField54 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField50);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField56 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType42, 19);
        long long59 = dividedDateTimeField56.addWrapField((long) 78720, 0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(yearMonthDay25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-86399987L) + "'", long53 == (-86399987L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField54);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 78720L + "'", long59 == 78720L);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(14);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime0.minus(readablePeriod3);
//        org.joda.time.DateTime dateTime6 = dateTime0.withYearOfCentury((int) (byte) 0);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        java.util.Date date8 = dateTime7.toDate();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime7.toMutableDateTime(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        java.util.Date date12 = dateTime11.toDate();
//        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
//        org.joda.time.DateTime.Property property14 = dateTime11.hourOfDay();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType16, 0, (-1), 0);
//        org.joda.time.DateTime dateTime22 = dateTime7.withField(dateTimeFieldType16, 4);
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField24 = iSOChronology23.days();
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology23.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology23.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology23.dayOfMonth();
//        org.joda.time.DurationField durationField28 = iSOChronology23.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField29 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField28);
//        boolean boolean30 = dateTime6.isSupported(dateTimeFieldType16);
//        int int31 = dateTime6.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(yearMonthDay13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 24 + "'", int31 == 24);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withPivotYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.append(dateTimeParser9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.year();
        java.util.Locale locale14 = dateTimeFormatter13.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter13.withPivotYear(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatter16.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser19 = dateTimeFormatter18.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder12.append(dateTimePrinter17, dateTimeParser19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder12.appendSecondOfMinute(845);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        java.util.Date date24 = dateTime23.toDate();
        org.joda.time.YearMonthDay yearMonthDay25 = dateTime23.toYearMonthDay();
        org.joda.time.DateTime.Property property26 = dateTime23.hourOfDay();
        org.joda.time.DateMidnight dateMidnight27 = dateTime23.toDateMidnight();
        org.joda.time.DateTime dateTime29 = dateTime23.minusMillis(891);
        org.joda.time.MutableDateTime mutableDateTime30 = dateTime29.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime32 = dateTime29.minus(readablePeriod31);
        org.joda.time.DateTime dateTime34 = dateTime32.minusDays(936);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime();
        java.util.Date date36 = dateTime35.toDate();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime38 = dateTime35.toMutableDateTime(dateTimeZone37);
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime();
        java.util.Date date40 = dateTime39.toDate();
        org.joda.time.YearMonthDay yearMonthDay41 = dateTime39.toYearMonthDay();
        org.joda.time.DateTime.Property property42 = dateTime39.hourOfDay();
        org.joda.time.DurationField durationField43 = property42.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property42.getFieldType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType44, 0, (-1), 0);
        org.joda.time.DateTime dateTime50 = dateTime35.withField(dateTimeFieldType44, 4);
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField52 = iSOChronology51.days();
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology51.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology51.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField55 = iSOChronology51.dayOfMonth();
        org.joda.time.DurationField durationField56 = iSOChronology51.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField56);
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = unsupportedDateTimeField57.getType();
        org.joda.time.DateTime dateTime60 = dateTime32.withField(dateTimeFieldType58, 15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException62 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType58, "1970-03-12T00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder12.appendFixedSignedDecimal(dateTimeFieldType58, 22);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNull(locale14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimePrinter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeParser19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(yearMonthDay25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateMidnight27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(mutableDateTime38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(yearMonthDay41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.YearMonthDay yearMonthDay2 = dateTime0.toYearMonthDay();
        org.joda.time.DateTime.Property property3 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.getDateTime();
        java.util.Date date5 = dateTime4.toDate();
        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
        org.joda.time.DateTime.Property property7 = dateTime4.minuteOfDay();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(yearMonthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour(405);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear(1311, 78720);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfDay(51, 60537409);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.halfdays();
//        java.lang.String str2 = iSOChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        java.util.Date date5 = dateTime4.toDate();
//        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
//        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
//        org.joda.time.DateMidnight dateMidnight8 = dateTime4.toDateMidnight();
//        org.joda.time.DateTime dateTime10 = dateTime4.minusMillis(891);
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTime();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.minus(readablePeriod12);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusDays(936);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        java.util.Date date17 = dateTime16.toDate();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.MutableDateTime mutableDateTime19 = dateTime16.toMutableDateTime(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
//        java.util.Date date21 = dateTime20.toDate();
//        org.joda.time.YearMonthDay yearMonthDay22 = dateTime20.toYearMonthDay();
//        org.joda.time.DateTime.Property property23 = dateTime20.hourOfDay();
//        org.joda.time.DurationField durationField24 = property23.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType25, 0, (-1), 0);
//        org.joda.time.DateTime dateTime31 = dateTime16.withField(dateTimeFieldType25, 4);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField33 = iSOChronology32.days();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology32.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology32.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology32.dayOfMonth();
//        org.joda.time.DurationField durationField37 = iSOChronology32.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField38 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = unsupportedDateTimeField38.getType();
//        org.joda.time.DateTime dateTime41 = dateTime13.withField(dateTimeFieldType39, 15);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType39, (int) (byte) -1);
//        java.util.Locale locale44 = null;
//        int int45 = offsetDateTimeField43.getMaximumShortTextLength(locale44);
//        int int46 = offsetDateTimeField43.getOffset();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(yearMonthDay6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(mutableDateTime19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(yearMonthDay22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
//    }
//}

