import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        int int14 = julianChronology13.getMinimumDaysInFirstWeek();
        try {
            long long22 = julianChronology13.getDateTimeMillis((int) (short) -1, 49483, 999, 57120, 0, (-292275054), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57120 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        int int2 = dateTime1.getMinuteOfHour();
        int int3 = dateTime1.getYearOfCentury();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
        org.joda.time.Chronology chronology7 = gJChronology2.withUTC();
        org.joda.time.DurationField durationField8 = gJChronology2.days();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology2.monthOfYear();
        org.joda.time.DurationField durationField10 = gJChronology2.months();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
//        org.joda.time.DateTime.Property property13 = dateTime11.centuryOfEra();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology16);
//        int int19 = dateTime18.getYear();
//        int int20 = property13.getDifference((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime22 = dateTime18.withMillisOfSecond(4);
//        int int23 = dateTime18.getDayOfYear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3121278298463L + "'", long3 == 3121278298463L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3121278298464L + "'", long7 == 3121278298464L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2068 + "'", int19 == 2068);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 332 + "'", int23 == 332);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
        java.lang.String str9 = skipUndoDateTimeField6.getName();
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipUndoDateTimeField6.getAsText(1560639117444L, locale11);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "millisOfSecond" + "'", str9.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "444" + "'", str12.equals("444"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        long long29 = unsupportedDateTimeField26.add((long) 20, (int) (byte) 1);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone32);
//        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone32);
//        org.joda.time.DateTimeField[] dateTimeFieldArray35 = localDate34.getFields();
//        int int36 = localDate34.getEra();
//        org.joda.time.LocalDate localDate38 = localDate34.withYearOfEra((int) ' ');
//        org.joda.time.LocalDate.Property property39 = localDate34.weekOfWeekyear();
//        org.joda.time.LocalDate localDate40 = property39.roundCeilingCopy();
//        org.joda.time.LocalDate localDate42 = localDate40.minusMonths((-25200000));
//        try {
//            int int43 = unsupportedDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localDate40);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278299277L + "'", long14 == 3121278299277L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278299278L + "'", long18 == 3121278299278L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1020L + "'", long29 == 1020L);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(localDate42);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.DateMidnight dateMidnight6 = localDate4.toDateMidnight();
        org.joda.time.DateTime dateTime7 = localDate4.toDateTimeAtMidnight();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime7.withFieldAdded(durationFieldType8, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField3, 0);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology0.millisOfSecond();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds((int) (byte) -1);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
//        org.joda.time.DateTime.Property property13 = dateTime11.centuryOfEra();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology16);
//        int int19 = dateTime18.getYear();
//        int int20 = property13.getDifference((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime22 = dateTime18.withMillisOfSecond(4);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone25 = dateTime24.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone29);
//        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone29);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray32 = localDate31.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight33 = localDate31.toDateMidnight();
//        boolean boolean34 = julianChronology26.equals((java.lang.Object) localDate31);
//        org.joda.time.DateTimeField dateTimeField35 = julianChronology26.era();
//        org.joda.time.DateTimeField dateTimeField36 = julianChronology26.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.ReadableInstant readableInstant38 = null;
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
//        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology41.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField43 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology39, dateTimeField42);
//        int int45 = skipUndoDateTimeField43.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField47 = buddhistChronology46.seconds();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeUtils.getZone(dateTimeZone48);
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime(dateTimeZone49);
//        long long51 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeUtils.getZone(dateTimeZone52);
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone53);
//        long long55 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime54);
//        boolean boolean56 = dateTime50.isEqual((org.joda.time.ReadableInstant) dateTime54);
//        org.joda.time.DateTime.Property property57 = dateTime54.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = property57.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField60 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField43, durationField47, dateTimeFieldType58, 2000);
//        org.joda.time.DateTimeZone dateTimeZone61 = null;
//        org.joda.time.ReadableInstant readableInstant62 = null;
//        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone61, readableInstant62);
//        org.joda.time.DateTimeField dateTimeField64 = gJChronology63.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology65 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField66 = buddhistChronology65.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField67 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology63, dateTimeField66);
//        int int69 = skipUndoDateTimeField67.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology70 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField71 = buddhistChronology70.seconds();
//        org.joda.time.DateTimeZone dateTimeZone72 = null;
//        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeUtils.getZone(dateTimeZone72);
//        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime(dateTimeZone73);
//        long long75 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime74);
//        org.joda.time.DateTimeZone dateTimeZone76 = null;
//        org.joda.time.DateTimeZone dateTimeZone77 = org.joda.time.DateTimeUtils.getZone(dateTimeZone76);
//        org.joda.time.DateTime dateTime78 = new org.joda.time.DateTime(dateTimeZone77);
//        long long79 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime78);
//        boolean boolean80 = dateTime74.isEqual((org.joda.time.ReadableInstant) dateTime78);
//        org.joda.time.DateTime.Property property81 = dateTime78.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType82 = property81.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField84 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField67, durationField71, dateTimeFieldType82, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField86 = new org.joda.time.field.RemainderDateTimeField(dateTimeField36, durationField47, dateTimeFieldType82, 9);
//        org.joda.time.DateTime.Property property87 = dateTime18.property(dateTimeFieldType82);
//        org.joda.time.DateTime dateTime88 = property87.roundHalfEvenCopy();
//        boolean boolean89 = dateTime88.isAfterNow();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3121278299538L + "'", long3 == 3121278299538L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3121278299539L + "'", long7 == 3121278299539L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2068 + "'", int19 == 2068);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(julianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray32);
//        org.junit.Assert.assertNotNull(dateMidnight33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(buddhistChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 999 + "'", int45 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 3121278299545L + "'", long51 == 3121278299545L);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 3121278299546L + "'", long55 == 3121278299546L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertNotNull(gJChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(buddhistChronology65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 999 + "'", int69 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology70);
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertNotNull(dateTimeZone73);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 3121278299569L + "'", long75 == 3121278299569L);
//        org.junit.Assert.assertNotNull(dateTimeZone77);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 3121278299570L + "'", long79 == 3121278299570L);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(property81);
//        org.junit.Assert.assertNotNull(dateTimeFieldType82);
//        org.junit.Assert.assertNotNull(property87);
//        org.junit.Assert.assertNotNull(dateTime88);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
//        org.joda.time.DateTime.Property property13 = dateTime11.centuryOfEra();
//        org.joda.time.DateTime dateTime14 = property13.roundHalfCeilingCopy();
//        org.joda.time.Chronology chronology15 = dateTime14.getChronology();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendEraText();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.ReadableInstant readableInstant20 = null;
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
//        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology18, dateTimeField22);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = skipUndoDateTimeField23.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder17.appendFixedDecimal(dateTimeFieldType24, (int) (short) 10);
//        org.joda.time.DateTime.Property property27 = dateTime14.property(dateTimeFieldType24);
//        org.joda.time.DateTime dateTime28 = property27.roundHalfFloorCopy();
//        org.joda.time.ReadableDuration readableDuration29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.minus(readableDuration29);
//        org.joda.time.DateTime dateTime32 = dateTime30.minusMillis((-25200000));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3121278300532L + "'", long3 == 3121278300532L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3121278300533L + "'", long7 == 3121278300533L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.days();
        org.joda.time.DurationField durationField4 = gJChronology2.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("Pacific Daylight Time", "1969", 3, (int) (byte) 1);
        org.joda.time.Chronology chronology10 = gJChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str5 = cachedDateTimeZone3.getNameKey(1560639118769L);
        java.util.TimeZone timeZone6 = cachedDateTimeZone3.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PDT" + "'", str5.equals("PDT"));
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime5 = dateTime3.minusYears((-1));
        try {
            java.lang.String str7 = dateTime3.toString("June");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(15);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime5.toMutableDateTimeISO();
//        int int10 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime7, "Pacific Daylight Time", (-25200000));
//        int int11 = dateTimeFormatter0.getDefaultYear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3121278300916L + "'", long6 == 3121278300916L);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2000 + "'", int11 == 2000);
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        long long29 = unsupportedDateTimeField26.add(1560639135743L, 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = unsupportedDateTimeField26.getType();
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278301290L + "'", long14 == 3121278301290L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278301291L + "'", long18 == 3121278301291L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560639136743L + "'", long29 == 1560639136743L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.LocalDate localDate7 = localDate4.withWeekOfWeekyear(10);
        int int8 = localDate4.getWeekyear();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("", false);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        org.joda.time.DateTime dateTime15 = localDate4.toDateTimeAtCurrentTime(dateTimeZone14);
        java.util.Date date16 = dateTime15.toDate();
        org.joda.time.DateTime.Property property17 = dateTime15.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(property17);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-1));
//        org.joda.time.DateTimeField dateTimeField12 = property9.getField();
//        org.joda.time.DateTime dateTime13 = property9.roundHalfEvenCopy();
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property9.getAsShortText(locale14);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3121278301662L + "'", long3 == 3121278301662L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3121278301662L + "'", long7 == 3121278301662L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "662" + "'", str15.equals("662"));
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        long long16 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
//        long long20 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime19);
//        boolean boolean21 = dateTime15.isEqual((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime.Property property22 = dateTime19.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, durationField12, dateTimeFieldType23, 2000);
//        boolean boolean26 = buddhistChronology0.equals((java.lang.Object) dateTimeFieldType23);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType23, 4, 292278993, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for millisOfSecond must be in the range [292278993,100]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3121278301732L + "'", long16 == 3121278301732L);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 3121278301732L + "'", long20 == 3121278301732L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, readableInstant10);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.year();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField14);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField17 = buddhistChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology16.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone20);
        org.joda.time.Chronology chronology22 = buddhistChronology16.withZone(dateTimeZone20);
        org.joda.time.Chronology chronology23 = gJChronology11.withZone(dateTimeZone20);
        org.joda.time.DateMidnight dateMidnight24 = localDate8.toDateMidnight(dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime26 = localDate8.toDateTimeAtMidnight(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = dateTime1.withZone(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateMidnight24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField4);
        long long8 = skipUndoDateTimeField5.add((long) (short) 10, (long) (short) 10);
        boolean boolean9 = skipUndoDateTimeField5.isSupported();
        long long12 = skipUndoDateTimeField5.set((long) 10, (int) (short) 10);
        int int14 = skipUndoDateTimeField5.getMinimumValue(1560639114556L);
        org.joda.time.DateTimeField dateTimeField15 = skipUndoDateTimeField5.getWrappedField();
        org.joda.time.DateTimeField dateTimeField16 = skipUndoDateTimeField5.getWrappedField();
        long long18 = skipUndoDateTimeField5.roundFloor(3121278283980L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 315532800010L + "'", long8 == 315532800010L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61820237221990L) + "'", long12 == (-61820237221990L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292275054) + "'", int14 == (-292275054));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3092630400000L + "'", long18 == 3092630400000L);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
//        org.joda.time.DateTime.Property property13 = dateTime11.centuryOfEra();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology16);
//        int int19 = dateTime18.getYear();
//        int int20 = property13.getDifference((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime21 = dateTime18.withEarlierOffsetAtOverlap();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.hourMinute();
//        boolean boolean23 = dateTimeFormatter22.isParser();
//        boolean boolean24 = dateTimeFormatter22.isParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter22.withZoneUTC();
//        java.lang.String str26 = dateTime18.toString(dateTimeFormatter25);
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime29 = dateTime18.withPeriodAdded(readablePeriod27, (int) '#');
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3121278302083L + "'", long3 == 3121278302083L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3121278302083L + "'", long7 == 3121278302083L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2068 + "'", int19 == 2068);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "21:45" + "'", str26.equals("21:45"));
//        org.junit.Assert.assertNotNull(dateTime29);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField3, 0);
        int int7 = skipDateTimeField5.get(1560639122018L);
        int int8 = skipDateTimeField5.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 18 + "'", int7 == 18);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ');
        int int5 = dateTime4.getMinuteOfHour();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime4, 3);
        org.joda.time.Instant instant8 = gJChronology7.getGregorianCutover();
        org.joda.time.MutableDateTime mutableDateTime9 = instant8.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField4);
//        long long8 = skipUndoDateTimeField5.add((long) (short) 10, (long) (short) 10);
//        boolean boolean9 = skipUndoDateTimeField5.isSupported();
//        long long12 = skipUndoDateTimeField5.set((long) 10, (int) (short) 10);
//        int int14 = skipUndoDateTimeField5.getMinimumValue(1560639114556L);
//        int int16 = skipUndoDateTimeField5.get(1560639116927L);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.ReadableInstant readableInstant18 = null;
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, readableInstant18);
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology19, dateTimeField22);
//        int int25 = skipUndoDateTimeField23.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField27 = buddhistChronology26.seconds();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
//        long long31 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
//        long long35 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime34);
//        boolean boolean36 = dateTime30.isEqual((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTime.Property property37 = dateTime34.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, durationField27, dateTimeFieldType38, 2000);
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = dividedDateTimeField40.getAsText(0, locale42);
//        org.joda.time.DurationField durationField44 = dividedDateTimeField40.getRangeDurationField();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.ReadableInstant readableInstant46 = null;
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone45, readableInstant46);
//        org.joda.time.DateTimeField dateTimeField48 = gJChronology47.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology49 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField50 = buddhistChronology49.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField51 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology47, dateTimeField50);
//        int int53 = skipUndoDateTimeField51.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField55 = buddhistChronology54.seconds();
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeUtils.getZone(dateTimeZone56);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime(dateTimeZone57);
//        long long59 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime58);
//        org.joda.time.DateTimeZone dateTimeZone60 = null;
//        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeUtils.getZone(dateTimeZone60);
//        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(dateTimeZone61);
//        long long63 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime62);
//        boolean boolean64 = dateTime58.isEqual((org.joda.time.ReadableInstant) dateTime62);
//        org.joda.time.DateTime.Property property65 = dateTime62.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property65.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField51, durationField55, dateTimeFieldType66, 2000);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField69 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, durationField44, dateTimeFieldType66);
//        java.lang.String str70 = delegatedDateTimeField69.getName();
//        org.joda.time.ReadablePartial readablePartial71 = null;
//        org.joda.time.DateTimeZone dateTimeZone72 = null;
//        org.joda.time.ReadableInstant readableInstant73 = null;
//        org.joda.time.chrono.GJChronology gJChronology74 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone72, readableInstant73);
//        org.joda.time.DateTimeField dateTimeField75 = gJChronology74.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology76 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField77 = buddhistChronology76.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField78 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology74, dateTimeField77);
//        org.joda.time.DateTimeZone dateTimeZone80 = null;
//        org.joda.time.DateTimeZone dateTimeZone81 = org.joda.time.DateTimeUtils.getZone(dateTimeZone80);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone81);
//        org.joda.time.LocalDate localDate83 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone81);
//        org.joda.time.LocalDate.Property property84 = localDate83.monthOfYear();
//        int int85 = localDate83.size();
//        org.joda.time.LocalDate localDate87 = localDate83.withYear(51);
//        int[] intArray89 = gJChronology74.get((org.joda.time.ReadablePartial) localDate83, 1560639134593L);
//        try {
//            int int90 = delegatedDateTimeField69.getMaximumValue(readablePartial71, intArray89);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 315532800010L + "'", long8 == 315532800010L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61820237221990L) + "'", long12 == (-61820237221990L));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292275054) + "'", int14 == (-292275054));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(buddhistChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 999 + "'", int25 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 3121278302293L + "'", long31 == 3121278302293L);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 3121278302294L + "'", long35 == 3121278302294L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "0" + "'", str43.equals("0"));
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(buddhistChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 999 + "'", int53 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology54);
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 3121278302297L + "'", long59 == 3121278302297L);
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 3121278302297L + "'", long63 == 3121278302297L);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(dateTimeFieldType66);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "millisOfSecond" + "'", str70.equals("millisOfSecond"));
//        org.junit.Assert.assertNotNull(gJChronology74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertNotNull(buddhistChronology76);
//        org.junit.Assert.assertNotNull(dateTimeField77);
//        org.junit.Assert.assertNotNull(dateTimeZone81);
//        org.junit.Assert.assertNotNull(property84);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 3 + "'", int85 == 3);
//        org.junit.Assert.assertNotNull(localDate87);
//        org.junit.Assert.assertNotNull(intArray89);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.LocalDate.Property property5 = localDate4.monthOfYear();
        boolean boolean6 = property5.isLeap();
        org.joda.time.DurationField durationField7 = property5.getDurationField();
        java.util.Locale locale8 = null;
        int int9 = property5.getMaximumTextLength(locale8);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.LocalDateTime localDateTime1 = null;
        try {
            boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = skipUndoDateTimeField6.getType();
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime2.toMutableDateTimeISO();
//        java.util.Locale locale5 = null;
//        java.util.Calendar calendar6 = dateTime2.toCalendar(locale5);
//        org.joda.time.DateTime dateTime8 = dateTime2.plusWeeks((int) '4');
//        org.joda.time.DateTime.Property property9 = dateTime2.secondOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3121278302397L + "'", long3 == 3121278302397L);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(calendar6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        boolean boolean3 = dateTimeFormatter2.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField2 = buddhistChronology1.weeks();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(1560639114555L, (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (-1));
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime6.toYearMonthDay();
        org.joda.time.DateTime.Property property8 = dateTime6.minuteOfDay();
        org.joda.time.DateTime dateTime10 = dateTime6.withCenturyOfEra(57120);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(yearMonthDay7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        long long29 = unsupportedDateTimeField26.add((long) 20, (int) (byte) 1);
//        org.joda.time.DurationField durationField30 = unsupportedDateTimeField26.getLeapDurationField();
//        long long33 = unsupportedDateTimeField26.getDifferenceAsLong(28800000L, (long) 999);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeUtils.getZone(dateTimeZone35);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone36);
//        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone36);
//        org.joda.time.DateTimeField[] dateTimeFieldArray39 = localDate38.getFields();
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Interval interval41 = localDate38.toInterval(dateTimeZone40);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone46 = new org.joda.time.tz.FixedDateTimeZone("Pacific Daylight Time", "1969", 3, (int) (byte) 1);
//        boolean boolean47 = org.joda.time.field.FieldUtils.equals((java.lang.Object) localDate38, (java.lang.Object) "1969");
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.ReadableInstant readableInstant50 = null;
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49, readableInstant50);
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField54 = buddhistChronology53.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField55 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology51, dateTimeField54);
//        long long57 = skipUndoDateTimeField55.roundHalfEven((-1L));
//        org.joda.time.DateTimeZone dateTimeZone59 = null;
//        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeUtils.getZone(dateTimeZone59);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone60);
//        org.joda.time.LocalDate localDate62 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone60);
//        org.joda.time.DateTimeField[] dateTimeFieldArray63 = localDate62.getFields();
//        org.joda.time.LocalDate localDate65 = localDate62.withWeekOfWeekyear(10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.String str68 = gregorianChronology67.toString();
//        org.joda.time.DateTimeZone dateTimeZone70 = null;
//        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeUtils.getZone(dateTimeZone70);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone71);
//        org.joda.time.LocalDate localDate73 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone71);
//        org.joda.time.DateTimeField[] dateTimeFieldArray74 = localDate73.getFields();
//        int int75 = localDate73.getEra();
//        org.joda.time.LocalDate localDate77 = localDate73.withYearOfEra((int) ' ');
//        org.joda.time.LocalDate.Property property78 = localDate73.weekOfWeekyear();
//        int[] intArray80 = gregorianChronology67.get((org.joda.time.ReadablePartial) localDate73, 1560639122741L);
//        int[] intArray82 = skipUndoDateTimeField55.addWrapPartial((org.joda.time.ReadablePartial) localDate65, (int) (short) 0, intArray80, (int) (short) 0);
//        try {
//            int[] intArray84 = unsupportedDateTimeField26.add((org.joda.time.ReadablePartial) localDate38, 0, intArray80, 12);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278302522L + "'", long14 == 3121278302522L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278302522L + "'", long18 == 3121278302522L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1020L + "'", long29 == 1020L);
//        org.junit.Assert.assertNull(durationField30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 28799L + "'", long33 == 28799L);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray39);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(interval41);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(buddhistChronology53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-1L) + "'", long57 == (-1L));
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray63);
//        org.junit.Assert.assertNotNull(localDate65);
//        org.junit.Assert.assertNotNull(gregorianChronology67);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "GregorianChronology[UTC]" + "'", str68.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone71);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
//        org.junit.Assert.assertNotNull(localDate77);
//        org.junit.Assert.assertNotNull(property78);
//        org.junit.Assert.assertNotNull(intArray80);
//        org.junit.Assert.assertNotNull(intArray82);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology7 = gregorianChronology6.withUTC();
        org.joda.time.ReadablePartial readablePartial8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, readableInstant10);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.year();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField14);
        long long17 = skipUndoDateTimeField15.roundHalfEven((-1L));
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone20);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone20);
        org.joda.time.DateTimeField[] dateTimeFieldArray23 = localDate22.getFields();
        org.joda.time.LocalDate localDate25 = localDate22.withWeekOfWeekyear(10);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str28 = gregorianChronology27.toString();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone(dateTimeZone30);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone31);
        org.joda.time.LocalDate localDate33 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone31);
        org.joda.time.DateTimeField[] dateTimeFieldArray34 = localDate33.getFields();
        int int35 = localDate33.getEra();
        org.joda.time.LocalDate localDate37 = localDate33.withYearOfEra((int) ' ');
        org.joda.time.LocalDate.Property property38 = localDate33.weekOfWeekyear();
        int[] intArray40 = gregorianChronology27.get((org.joda.time.ReadablePartial) localDate33, 1560639122741L);
        int[] intArray42 = skipUndoDateTimeField15.addWrapPartial((org.joda.time.ReadablePartial) localDate25, (int) (short) 0, intArray40, (int) (short) 0);
        try {
            gregorianChronology6.validate(readablePartial8, intArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeFieldArray23);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "GregorianChronology[UTC]" + "'", str28.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTimeFieldArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray42);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = buddhistChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        boolean boolean15 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime.Property property16 = dateTime13.millisOfSecond();
//        org.joda.time.DateTime dateTime18 = property16.addToCopy((long) (-1));
//        org.joda.time.DateTime dateTime19 = property16.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime20 = dateTime19.toDateTimeISO();
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.ReadableDateTime) dateTime20, readableDateTime21);
//        try {
//            long long28 = limitChronology22.getDateTimeMillis(0L, 100, 10, 0, 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 2611-11-27T13:45:02.617-08:00 (BuddhistChronology[America/Los_Angeles])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3121278302617L + "'", long10 == 3121278302617L);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278302617L + "'", long14 == 3121278302617L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(limitChronology22);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("0", number1, (java.lang.Number) 3121278301550L, (java.lang.Number) 1560639151393L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology2 = iSOChronology1.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology(chronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial3 = partial0.withPeriodAdded(readablePeriod1, 7);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.Partial partial6 = partial3.withFieldAdded(durationFieldType4, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(partial3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        java.lang.String str25 = dividedDateTimeField23.getAsShortText(1560639109776L);
//        long long28 = dividedDateTimeField23.getDifferenceAsLong((long) '#', 1560639129056L);
//        org.joda.time.DurationField durationField29 = dividedDateTimeField23.getRangeDurationField();
//        int int31 = dividedDateTimeField23.getMaximumValue(100L);
//        try {
//            long long33 = dividedDateTimeField23.roundFloor(1560639114555L);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278302758L + "'", long14 == 3121278302758L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278302758L + "'", long18 == 3121278302758L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-780319564L) + "'", long28 == (-780319564L));
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfMinute();
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        jodaTimePermission6.checkGuard((java.lang.Object) dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone12);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone12);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        jodaTimePermission6.checkGuard((java.lang.Object) dateTimeZone12);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.weekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField19);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.DurationField durationField24 = skipUndoDateTimeField6.getLeapDurationField();
//        try {
//            long long27 = skipUndoDateTimeField6.set(1560639130920L, 49500);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 49500 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278302854L + "'", long14 == 3121278302854L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278302855L + "'", long18 == 3121278302855L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNull(durationField24);
//    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        long long29 = unsupportedDateTimeField26.add((long) 20, (int) (byte) 1);
//        java.util.Locale locale31 = null;
//        try {
//            java.lang.String str32 = unsupportedDateTimeField26.getAsShortText(1560639128752L, locale31);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278302894L + "'", long14 == 3121278302894L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278302895L + "'", long18 == 3121278302895L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1020L + "'", long29 == 1020L);
//    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        long long29 = unsupportedDateTimeField26.add((long) 20, (int) (byte) 1);
//        org.joda.time.DurationField durationField30 = unsupportedDateTimeField26.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = unsupportedDateTimeField26.getType();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone34);
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone34);
//        org.joda.time.LocalDate.Property property37 = localDate36.monthOfYear();
//        boolean boolean38 = property37.isLeap();
//        org.joda.time.LocalDate localDate39 = property37.roundCeilingCopy();
//        int int40 = localDate39.getYear();
//        int[] intArray42 = new int[] {};
//        java.util.Locale locale44 = null;
//        try {
//            int[] intArray45 = unsupportedDateTimeField26.set((org.joda.time.ReadablePartial) localDate39, 9, intArray42, "6", locale44);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278302916L + "'", long14 == 3121278302916L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278302916L + "'", long18 == 3121278302916L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1020L + "'", long29 == 1020L);
//        org.junit.Assert.assertNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
//        org.junit.Assert.assertNotNull(intArray42);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        int int4 = dateTimeFormatter3.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2000 + "'", int4 == 2000);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
        long long5 = buddhistChronology0.add((long) 1, 1560639109775L, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = buddhistChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology0.yearOfCentury();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology0.monthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField11 = buddhistChronology10.seconds();
        long long14 = durationField11.subtract(1560639119529L, 0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, durationField11, dateTimeFieldType15, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560639109776L + "'", long5 == 1560639109776L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639119529L + "'", long14 == 1560639119529L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
//        org.joda.time.DateTime.Property property13 = dateTime11.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = property13.getAsShortText(locale15);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3121278303093L + "'", long3 == 3121278303093L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3121278303094L + "'", long7 == 3121278303094L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "332" + "'", str16.equals("332"));
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        long long29 = unsupportedDateTimeField26.add(1560639135743L, 1);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone32);
//        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone32);
//        org.joda.time.DateTimeField[] dateTimeFieldArray35 = localDate34.getFields();
//        int int36 = localDate34.getEra();
//        org.joda.time.LocalDate localDate38 = localDate34.withYearOfEra((int) ' ');
//        org.joda.time.LocalDate.Property property39 = localDate34.weekOfWeekyear();
//        org.joda.time.LocalDate localDate41 = localDate34.plusDays((-28800000));
//        java.util.Locale locale42 = null;
//        try {
//            java.lang.String str43 = unsupportedDateTimeField26.getAsShortText((org.joda.time.ReadablePartial) localDate34, locale42);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278303140L + "'", long14 == 3121278303140L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278303141L + "'", long18 == 3121278303141L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560639136743L + "'", long29 == 1560639136743L);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(localDate41);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (short) 10, "Jun");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipUndoDateTimeField7.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder1.appendFraction(dateTimeFieldType8, 20, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder1.appendSecondOfMinute(57120);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendEraText();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField20);
//        int int23 = skipUndoDateTimeField21.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone27);
//        long long29 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone(dateTimeZone30);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(dateTimeZone31);
//        long long33 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime32);
//        boolean boolean34 = dateTime28.isEqual((org.joda.time.ReadableInstant) dateTime32);
//        org.joda.time.DateTime.Property property35 = dateTime32.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property35.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField21, durationField25, dateTimeFieldType36, 2000);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder13.appendSignedDecimal(dateTimeFieldType36, 12, 12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder13.appendMillisOfSecond(9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(buddhistChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 999 + "'", int23 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 3121278303197L + "'", long29 == 3121278303197L);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 3121278303198L + "'", long33 == 3121278303198L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("hi!", 4);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover(80, 'a', (-28800000), 431, 49483, true, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
//        long long27 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.MutableDateTime mutableDateTime28 = dateTime26.toMutableDateTimeISO();
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime31 = dateTime26.withPeriodAdded(readablePeriod29, 0);
//        org.joda.time.LocalTime localTime32 = dateTime31.toLocalTime();
//        int int33 = dividedDateTimeField23.getMinimumValue((org.joda.time.ReadablePartial) localTime32);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = dividedDateTimeField23.getAsShortText(1560639150939L, locale35);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278303329L + "'", long14 == 3121278303329L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278303360L + "'", long18 == 3121278303360L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 3121278303362L + "'", long27 == 3121278303362L);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology2.getZone();
        java.lang.String str5 = dateTimeZone4.getID();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField3, 0);
        int int7 = skipDateTimeField5.get(1560639122018L);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone10);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone10);
        org.joda.time.DateTimeField[] dateTimeFieldArray13 = localDate12.getFields();
        int int14 = localDate12.getEra();
        org.joda.time.LocalDate localDate16 = localDate12.withYearOfEra((int) ' ');
        org.joda.time.LocalDate.Property property17 = localDate12.weekOfWeekyear();
        org.joda.time.LocalDate localDate18 = property17.roundCeilingCopy();
        int int19 = skipDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDate18);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 18 + "'", int7 == 18);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeFieldArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", false);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusHours((-28800000));
//        org.joda.time.DateTime dateTime10 = dateTime6.minusHours(18);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTime12.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone17);
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone17);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray20 = localDate19.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight21 = localDate19.toDateMidnight();
//        boolean boolean22 = julianChronology14.equals((java.lang.Object) localDate19);
//        org.joda.time.DateTimeField dateTimeField23 = julianChronology14.era();
//        org.joda.time.DateTimeField dateTimeField24 = julianChronology14.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25, readableInstant26);
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology29.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField30);
//        int int33 = skipUndoDateTimeField31.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField35 = buddhistChronology34.seconds();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeUtils.getZone(dateTimeZone36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(dateTimeZone37);
//        long long39 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime38);
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone41);
//        long long43 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime42);
//        boolean boolean44 = dateTime38.isEqual((org.joda.time.ReadableInstant) dateTime42);
//        org.joda.time.DateTime.Property property45 = dateTime42.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField31, durationField35, dateTimeFieldType46, 2000);
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.ReadableInstant readableInstant50 = null;
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49, readableInstant50);
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField54 = buddhistChronology53.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField55 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology51, dateTimeField54);
//        int int57 = skipUndoDateTimeField55.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField59 = buddhistChronology58.seconds();
//        org.joda.time.DateTimeZone dateTimeZone60 = null;
//        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeUtils.getZone(dateTimeZone60);
//        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(dateTimeZone61);
//        long long63 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime62);
//        org.joda.time.DateTimeZone dateTimeZone64 = null;
//        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeUtils.getZone(dateTimeZone64);
//        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime(dateTimeZone65);
//        long long67 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime66);
//        boolean boolean68 = dateTime62.isEqual((org.joda.time.ReadableInstant) dateTime66);
//        org.joda.time.DateTime.Property property69 = dateTime66.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType70 = property69.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField72 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField55, durationField59, dateTimeFieldType70, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, durationField35, dateTimeFieldType70, 9);
//        int int75 = dateTime10.get(dateTimeFieldType70);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray20);
//        org.junit.Assert.assertNotNull(dateMidnight21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(buddhistChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 999 + "'", int33 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 3121278303636L + "'", long39 == 3121278303636L);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 3121278303637L + "'", long43 == 3121278303637L);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(buddhistChronology53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 999 + "'", int57 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology58);
//        org.junit.Assert.assertNotNull(durationField59);
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 3121278303639L + "'", long63 == 3121278303639L);
//        org.junit.Assert.assertNotNull(dateTimeZone65);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 3121278303640L + "'", long67 == 3121278303640L);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(property69);
//        org.junit.Assert.assertNotNull(dateTimeFieldType70);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
//    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
//        org.joda.time.DurationField durationField28 = unsupportedDateTimeField26.getRangeDurationField();
//        java.util.Locale locale30 = null;
//        try {
//            java.lang.String str31 = unsupportedDateTimeField26.getAsText(3121278289047L, locale30);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278304518L + "'", long14 == 3121278304518L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278304518L + "'", long18 == 3121278304518L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNull(durationField28);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
        org.joda.time.Chronology chronology12 = julianChronology3.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dividedDateTimeField23.getAsText(0, locale25);
//        org.joda.time.DurationField durationField27 = dividedDateTimeField23.getRangeDurationField();
//        org.joda.time.DurationField durationField28 = dividedDateTimeField23.getDurationField();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = dividedDateTimeField23.getAsText((long) (byte) 0, locale30);
//        org.joda.time.DateTimeField dateTimeField32 = dividedDateTimeField23.getWrappedField();
//        long long35 = dividedDateTimeField23.add(0L, (int) (byte) 10);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278304598L + "'", long14 == 3121278304598L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278304599L + "'", long18 == 3121278304599L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 20000L + "'", long35 == 20000L);
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField26.getRangeDurationField();
//        boolean boolean28 = unsupportedDateTimeField26.isLenient();
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278304704L + "'", long14 == 3121278304704L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278304704L + "'", long18 == 3121278304704L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertNull(durationField27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
//        org.joda.time.DateTime.Property property13 = dateTime11.centuryOfEra();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology16);
//        int int19 = dateTime18.getYear();
//        int int20 = property13.getDifference((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime22 = dateTime18.withMillisOfSecond(4);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone25 = dateTime24.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone29);
//        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone29);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray32 = localDate31.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight33 = localDate31.toDateMidnight();
//        boolean boolean34 = julianChronology26.equals((java.lang.Object) localDate31);
//        org.joda.time.DateTimeField dateTimeField35 = julianChronology26.era();
//        org.joda.time.DateTimeField dateTimeField36 = julianChronology26.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.ReadableInstant readableInstant38 = null;
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
//        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology41.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField43 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology39, dateTimeField42);
//        int int45 = skipUndoDateTimeField43.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField47 = buddhistChronology46.seconds();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeUtils.getZone(dateTimeZone48);
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime(dateTimeZone49);
//        long long51 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeUtils.getZone(dateTimeZone52);
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone53);
//        long long55 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime54);
//        boolean boolean56 = dateTime50.isEqual((org.joda.time.ReadableInstant) dateTime54);
//        org.joda.time.DateTime.Property property57 = dateTime54.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = property57.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField60 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField43, durationField47, dateTimeFieldType58, 2000);
//        org.joda.time.DateTimeZone dateTimeZone61 = null;
//        org.joda.time.ReadableInstant readableInstant62 = null;
//        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone61, readableInstant62);
//        org.joda.time.DateTimeField dateTimeField64 = gJChronology63.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology65 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField66 = buddhistChronology65.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField67 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology63, dateTimeField66);
//        int int69 = skipUndoDateTimeField67.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology70 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField71 = buddhistChronology70.seconds();
//        org.joda.time.DateTimeZone dateTimeZone72 = null;
//        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeUtils.getZone(dateTimeZone72);
//        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime(dateTimeZone73);
//        long long75 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime74);
//        org.joda.time.DateTimeZone dateTimeZone76 = null;
//        org.joda.time.DateTimeZone dateTimeZone77 = org.joda.time.DateTimeUtils.getZone(dateTimeZone76);
//        org.joda.time.DateTime dateTime78 = new org.joda.time.DateTime(dateTimeZone77);
//        long long79 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime78);
//        boolean boolean80 = dateTime74.isEqual((org.joda.time.ReadableInstant) dateTime78);
//        org.joda.time.DateTime.Property property81 = dateTime78.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType82 = property81.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField84 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField67, durationField71, dateTimeFieldType82, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField86 = new org.joda.time.field.RemainderDateTimeField(dateTimeField36, durationField47, dateTimeFieldType82, 9);
//        org.joda.time.DateTime.Property property87 = dateTime18.property(dateTimeFieldType82);
//        org.joda.time.DateTime dateTime88 = property87.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime89 = property87.roundHalfEvenCopy();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3121278304794L + "'", long3 == 3121278304794L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3121278304814L + "'", long7 == 3121278304814L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2068 + "'", int19 == 2068);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(julianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray32);
//        org.junit.Assert.assertNotNull(dateMidnight33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(buddhistChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 999 + "'", int45 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 3121278304820L + "'", long51 == 3121278304820L);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 3121278304821L + "'", long55 == 3121278304821L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertNotNull(gJChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(buddhistChronology65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 999 + "'", int69 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology70);
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertNotNull(dateTimeZone73);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 3121278304823L + "'", long75 == 3121278304823L);
//        org.junit.Assert.assertNotNull(dateTimeZone77);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 3121278304824L + "'", long79 == 3121278304824L);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(property81);
//        org.junit.Assert.assertNotNull(dateTimeFieldType82);
//        org.junit.Assert.assertNotNull(property87);
//        org.junit.Assert.assertNotNull(dateTime88);
//        org.junit.Assert.assertNotNull(dateTime89);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        long long29 = unsupportedDateTimeField26.add((long) 20, (int) (byte) 1);
//        org.joda.time.DurationField durationField30 = unsupportedDateTimeField26.getLeapDurationField();
//        long long33 = unsupportedDateTimeField26.getDifferenceAsLong(28800000L, (long) 999);
//        java.lang.String str34 = unsupportedDateTimeField26.getName();
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeUtils.getZone(dateTimeZone36);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone37);
//        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone37);
//        org.joda.time.DateTimeField[] dateTimeFieldArray40 = localDate39.getFields();
//        int int41 = localDate39.getEra();
//        org.joda.time.LocalDate localDate43 = localDate39.withYearOfEra((int) ' ');
//        org.joda.time.LocalDate.Property property44 = localDate39.weekOfWeekyear();
//        org.joda.time.LocalDate localDate45 = property44.roundCeilingCopy();
//        org.joda.time.LocalDate localDate47 = localDate45.minusMonths((-25200000));
//        try {
//            int int48 = unsupportedDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localDate45);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278305961L + "'", long14 == 3121278305961L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278305961L + "'", long18 == 3121278305961L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1020L + "'", long29 == 1020L);
//        org.junit.Assert.assertNull(durationField30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 28799L + "'", long33 == 28799L);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "millisOfSecond" + "'", str34.equals("millisOfSecond"));
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(localDate47);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
        long long5 = buddhistChronology0.add((long) 1, 1560639109775L, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560639109776L + "'", long5 == 1560639109776L);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-1));
//        org.joda.time.DateTime dateTime12 = property9.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime13 = dateTime12.toDateTimeISO();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTime(dateTimeZone14);
//        int int16 = mutableDateTime15.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3121278306150L + "'", long3 == 3121278306150L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3121278306150L + "'", long7 == 3121278306150L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 48 + "'", int16 == 48);
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField26.getRangeDurationField();
//        try {
//            java.lang.String str29 = unsupportedDateTimeField26.getAsText((-61820237221990L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278306206L + "'", long14 == 3121278306206L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278306206L + "'", long18 == 3121278306206L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertNull(durationField27);
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
//        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology3.era();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField19);
//        int int22 = skipUndoDateTimeField20.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField24 = buddhistChronology23.seconds();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        long long28 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime31);
//        boolean boolean33 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime.Property property34 = dateTime31.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, durationField24, dateTimeFieldType35, 2000);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField43);
//        int int46 = skipUndoDateTimeField44.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField48 = buddhistChronology47.seconds();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
//        long long52 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        long long56 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime55);
//        boolean boolean57 = dateTime51.isEqual((org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DateTime.Property property58 = dateTime55.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField44, durationField48, dateTimeFieldType59, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, durationField24, dateTimeFieldType59, 9);
//        int int64 = remainderDateTimeField63.getMinimumValue();
//        long long66 = remainderDateTimeField63.remainder(1560639150241L);
//        int int67 = remainderDateTimeField63.getDivisor();
//        org.joda.time.DateTimeZone dateTimeZone68 = null;
//        org.joda.time.ReadableInstant readableInstant69 = null;
//        org.joda.time.chrono.GJChronology gJChronology70 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone68, readableInstant69);
//        org.joda.time.DateTimeField dateTimeField71 = gJChronology70.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology72 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField73 = buddhistChronology72.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField74 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology70, dateTimeField73);
//        long long76 = skipUndoDateTimeField74.roundHalfEven((-1L));
//        org.joda.time.DateTimeZone dateTimeZone78 = null;
//        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeUtils.getZone(dateTimeZone78);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone79);
//        org.joda.time.LocalDate localDate81 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone79);
//        int int82 = localDate81.getCenturyOfEra();
//        java.util.Locale locale84 = null;
//        java.lang.String str85 = skipUndoDateTimeField74.getAsShortText((org.joda.time.ReadablePartial) localDate81, (-1), locale84);
//        int int86 = localDate81.getYearOfCentury();
//        java.util.Date date87 = localDate81.toDate();
//        org.joda.time.LocalDate.Property property88 = localDate81.weekyear();
//        int[] intArray90 = null;
//        try {
//            int[] intArray92 = remainderDateTimeField63.add((org.joda.time.ReadablePartial) localDate81, 8, intArray90, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 3121278306857L + "'", long28 == 3121278306857L);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 3121278306858L + "'", long32 == 3121278306858L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 999 + "'", int46 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 3121278306860L + "'", long52 == 3121278306860L);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 3121278306861L + "'", long56 == 3121278306861L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 57150241L + "'", long66 == 57150241L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 9 + "'", int67 == 9);
//        org.junit.Assert.assertNotNull(gJChronology70);
//        org.junit.Assert.assertNotNull(dateTimeField71);
//        org.junit.Assert.assertNotNull(buddhistChronology72);
//        org.junit.Assert.assertNotNull(dateTimeField73);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-1L) + "'", long76 == (-1L));
//        org.junit.Assert.assertNotNull(dateTimeZone79);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 20 + "'", int82 == 20);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "-1" + "'", str85.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 19 + "'", int86 == 19);
//        org.junit.Assert.assertNotNull(date87);
//        org.junit.Assert.assertNotNull(property88);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("0", "UTC", 80, 49500);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.joda.time.DurationField durationField2 = copticChronology0.weekyears();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime2.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) 1560639121597L, dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.plusYears(7);
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (byte) 100);
        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfCentury(20);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        long long29 = unsupportedDateTimeField26.add((long) 20, (int) (byte) 1);
//        org.joda.time.DurationField durationField30 = unsupportedDateTimeField26.getLeapDurationField();
//        java.lang.String str31 = unsupportedDateTimeField26.getName();
//        org.joda.time.DurationField durationField32 = unsupportedDateTimeField26.getRangeDurationField();
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278307278L + "'", long14 == 3121278307278L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278307279L + "'", long18 == 3121278307279L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1020L + "'", long29 == 1020L);
//        org.junit.Assert.assertNull(durationField30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "millisOfSecond" + "'", str31.equals("millisOfSecond"));
//        org.junit.Assert.assertNull(durationField32);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField3, 0);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology0.millisOfSecond();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology0.year();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.DurationField durationField24 = skipUndoDateTimeField6.getLeapDurationField();
//        int int26 = skipUndoDateTimeField6.get(0L);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone29);
//        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone29);
//        org.joda.time.DateTimeField[] dateTimeFieldArray32 = localDate31.getFields();
//        org.joda.time.DateMidnight dateMidnight33 = localDate31.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateMidnight dateMidnight35 = localDate31.toDateMidnight(dateTimeZone34);
//        java.util.Locale locale36 = null;
//        try {
//            java.lang.String str37 = skipUndoDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDate31, locale36);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278307413L + "'", long14 == 3121278307413L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278307414L + "'", long18 == 3121278307414L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNull(durationField24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray32);
//        org.junit.Assert.assertNotNull(dateMidnight33);
//        org.junit.Assert.assertNotNull(dateMidnight35);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology2);
//        int int5 = dateTime4.getYear();
//        int int6 = dateTime4.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2068 + "'", int5 == 2068);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 45 + "'", int6 == 45);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology3.era();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology3.dayOfWeek();
        try {
            long long18 = julianChronology3.getDateTimeMillis(0, 80, 57120, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology2);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        long long8 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime11);
//        boolean boolean13 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime.Property property14 = dateTime11.millisOfSecond();
//        org.joda.time.DateTime dateTime16 = property14.addToCopy((long) (-1));
//        org.joda.time.DateTime dateTime17 = property14.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime18 = dateTime17.toDateTimeISO();
//        boolean boolean19 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime17);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3121278307487L + "'", long8 == 3121278307487L);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3121278307488L + "'", long12 == 3121278307488L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        long long4 = iSOChronology0.add(3121278283995L, 1560639149243L, 1);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4681917433238L + "'", long4 == 4681917433238L);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", false);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfDay((int) (short) 1);
//        int int7 = dateTime4.getYear();
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2068 + "'", int7 == 2068);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField3, 0);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology0.millisOfSecond();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime9 = dateTime7.withYearOfEra(4);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("Pacific Daylight Time", "1969", 3, (int) (byte) 1);
        int int18 = fixedDateTimeZone16.getOffset(0L);
        org.joda.time.Chronology chronology19 = iSOChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DateTime dateTime20 = dateTime7.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.DateTimeZone) cachedDateTimeZone6);
        int int8 = dateTime7.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        try {
//            int int28 = unsupportedDateTimeField26.getMaximumValue(3121278283975L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278307813L + "'", long14 == 3121278307813L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278307813L + "'", long18 == 3121278307813L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
//        org.joda.time.DateTime.Property property13 = dateTime11.centuryOfEra();
//        org.joda.time.DateTime dateTime14 = property13.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime15 = dateTime14.withTimeAtStartOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3121278308000L + "'", long3 == 3121278308000L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3121278308000L + "'", long7 == 3121278308000L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.LocalDate localDate7 = localDate4.withWeekOfWeekyear(10);
        int int8 = localDate4.getWeekyear();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("", false);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        org.joda.time.DateTime dateTime15 = localDate4.toDateTimeAtCurrentTime(dateTimeZone14);
        java.util.Date date16 = dateTime15.toDate();
        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.fromDateFields(date16);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(localDate17);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Jun");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Jun/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(1560639127804L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        try {
//            long long28 = unsupportedDateTimeField26.roundHalfFloor(1560639147971L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278313846L + "'", long14 == 3121278313846L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278313847L + "'", long18 == 3121278313847L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, readableInstant6);
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.year();
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField13 = buddhistChronology12.weeks();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology12.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone16);
        org.joda.time.Chronology chronology18 = buddhistChronology12.withZone(dateTimeZone16);
        org.joda.time.Chronology chronology19 = gJChronology7.withZone(dateTimeZone16);
        org.joda.time.DateMidnight dateMidnight20 = localDate4.toDateMidnight(dateTimeZone16);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateMidnight20);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, (int) (byte) 1, 292278993, 0, 5, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
//        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology3.era();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField19);
//        int int22 = skipUndoDateTimeField20.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField24 = buddhistChronology23.seconds();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        long long28 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime31);
//        boolean boolean33 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime.Property property34 = dateTime31.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, durationField24, dateTimeFieldType35, 2000);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField43);
//        int int46 = skipUndoDateTimeField44.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField48 = buddhistChronology47.seconds();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
//        long long52 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        long long56 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime55);
//        boolean boolean57 = dateTime51.isEqual((org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DateTime.Property property58 = dateTime55.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField44, durationField48, dateTimeFieldType59, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, durationField24, dateTimeFieldType59, 9);
//        long long65 = remainderDateTimeField63.roundFloor(3121278248046166L);
//        int int67 = remainderDateTimeField63.get((-61820237221990L));
//        java.lang.String str69 = remainderDateTimeField63.getAsText(3121278287551L);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 3121278314756L + "'", long28 == 3121278314756L);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 3121278314756L + "'", long32 == 3121278314756L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 999 + "'", int46 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 3121278314759L + "'", long52 == 3121278314759L);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 3121278314760L + "'", long56 == 3121278314760L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 3121278217200000L + "'", long65 == 3121278217200000L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 3 + "'", int67 == 3);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "2" + "'", str69.equals("2"));
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        int int1 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gJChronology0.weekyears();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField3, 0);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.ReadableInstant readableInstant7 = null;
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, readableInstant7);
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.clockhourOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField10, 0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology13, dateTimeField17);
//        long long21 = skipUndoDateTimeField18.add((long) (short) 10, (long) (short) 10);
//        boolean boolean22 = skipUndoDateTimeField18.isSupported();
//        long long25 = skipUndoDateTimeField18.set((long) 10, (int) (short) 10);
//        int int27 = skipUndoDateTimeField18.getMinimumValue(1560639114556L);
//        int int29 = skipUndoDateTimeField18.get(1560639116927L);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.ReadableInstant readableInstant31 = null;
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, readableInstant31);
//        org.joda.time.DateTimeField dateTimeField33 = gJChronology32.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology34.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology32, dateTimeField35);
//        int int38 = skipUndoDateTimeField36.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField40 = buddhistChronology39.seconds();
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeUtils.getZone(dateTimeZone41);
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(dateTimeZone42);
//        long long44 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime43);
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeUtils.getZone(dateTimeZone45);
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(dateTimeZone46);
//        long long48 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime47);
//        boolean boolean49 = dateTime43.isEqual((org.joda.time.ReadableInstant) dateTime47);
//        org.joda.time.DateTime.Property property50 = dateTime47.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField36, durationField40, dateTimeFieldType51, 2000);
//        java.util.Locale locale55 = null;
//        java.lang.String str56 = dividedDateTimeField53.getAsText(0, locale55);
//        org.joda.time.DurationField durationField57 = dividedDateTimeField53.getRangeDurationField();
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.ReadableInstant readableInstant59 = null;
//        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone58, readableInstant59);
//        org.joda.time.DateTimeField dateTimeField61 = gJChronology60.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology62 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField63 = buddhistChronology62.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField64 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology60, dateTimeField63);
//        int int66 = skipUndoDateTimeField64.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology67 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField68 = buddhistChronology67.seconds();
//        org.joda.time.DateTimeZone dateTimeZone69 = null;
//        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeUtils.getZone(dateTimeZone69);
//        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime(dateTimeZone70);
//        long long72 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime71);
//        org.joda.time.DateTimeZone dateTimeZone73 = null;
//        org.joda.time.DateTimeZone dateTimeZone74 = org.joda.time.DateTimeUtils.getZone(dateTimeZone73);
//        org.joda.time.DateTime dateTime75 = new org.joda.time.DateTime(dateTimeZone74);
//        long long76 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime75);
//        boolean boolean77 = dateTime71.isEqual((org.joda.time.ReadableInstant) dateTime75);
//        org.joda.time.DateTime.Property property78 = dateTime75.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType79 = property78.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField81 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField64, durationField68, dateTimeFieldType79, 2000);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField82 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField18, durationField57, dateTimeFieldType79);
//        org.joda.time.DateTimeZone dateTimeZone84 = null;
//        org.joda.time.DateTimeZone dateTimeZone85 = org.joda.time.DateTimeUtils.getZone(dateTimeZone84);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone85);
//        org.joda.time.LocalDate localDate87 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone85);
//        org.joda.time.LocalDate.Property property88 = localDate87.monthOfYear();
//        org.joda.time.LocalDate localDate89 = property88.withMaximumValue();
//        java.util.Locale locale90 = null;
//        java.lang.String str91 = delegatedDateTimeField82.getAsShortText((org.joda.time.ReadablePartial) localDate89, locale90);
//        int int92 = localDate89.getMonthOfYear();
//        long long94 = buddhistChronology0.set((org.joda.time.ReadablePartial) localDate89, 1560639138429L);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 315532800010L + "'", long21 == 315532800010L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61820237221990L) + "'", long25 == (-61820237221990L));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-292275054) + "'", int27 == (-292275054));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(buddhistChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 999 + "'", int38 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 3121278315112L + "'", long44 == 3121278315112L);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 3121278315113L + "'", long48 == 3121278315113L);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "0" + "'", str56.equals("0"));
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(gJChronology60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(buddhistChronology62);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 999 + "'", int66 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology67);
//        org.junit.Assert.assertNotNull(durationField68);
//        org.junit.Assert.assertNotNull(dateTimeZone70);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 3121278315116L + "'", long72 == 3121278315116L);
//        org.junit.Assert.assertNotNull(dateTimeZone74);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 3121278315116L + "'", long76 == 3121278315116L);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
//        org.junit.Assert.assertNotNull(property78);
//        org.junit.Assert.assertNotNull(dateTimeFieldType79);
//        org.junit.Assert.assertNotNull(dateTimeZone85);
//        org.junit.Assert.assertNotNull(property88);
//        org.junit.Assert.assertNotNull(localDate89);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "2019" + "'", str91.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 12 + "'", int92 == 12);
//        org.junit.Assert.assertTrue("'" + long94 + "' != '" + (-15558135283571L) + "'", long94 == (-15558135283571L));
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        try {
            org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.parse("BuddhistChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"BuddhistChronology[America/Los_A...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        int int2 = dateTime1.getMinuteOfHour();
        boolean boolean3 = dateTime1.isBeforeNow();
        org.joda.time.DateTime.Property property4 = dateTime1.era();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(property4);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.DateTimeField dateTimeField0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        long long8 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
//        boolean boolean9 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property10 = dateTime7.millisOfSecond();
//        org.joda.time.DateTime dateTime12 = property10.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
//        org.joda.time.DateTime.Property property14 = dateTime12.centuryOfEra();
//        org.joda.time.DateTime dateTime15 = property14.roundHalfCeilingCopy();
//        boolean boolean16 = dateTime15.isEqualNow();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.ReadableInstant readableInstant18 = null;
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, readableInstant18);
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology19, dateTimeField22);
//        int int25 = skipUndoDateTimeField23.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField27 = buddhistChronology26.seconds();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
//        long long31 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
//        long long35 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime34);
//        boolean boolean36 = dateTime30.isEqual((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTime.Property property37 = dateTime34.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, durationField27, dateTimeFieldType38, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField42 = buddhistChronology41.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField42);
//        long long46 = unsupportedDateTimeField43.add((long) 20, (int) (byte) 1);
//        org.joda.time.DurationField durationField47 = unsupportedDateTimeField43.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = unsupportedDateTimeField43.getType();
//        org.joda.time.DateTime.Property property49 = dateTime15.property(dateTimeFieldType48);
//        try {
//            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType48);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3121278315717L + "'", long4 == 3121278315717L);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3121278315718L + "'", long8 == 3121278315718L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(buddhistChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 999 + "'", int25 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 3121278315721L + "'", long31 == 3121278315721L);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 3121278315721L + "'", long35 == 3121278315721L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(buddhistChronology41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1020L + "'", long46 == 1020L);
//        org.junit.Assert.assertNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeFieldType48);
//        org.junit.Assert.assertNotNull(property49);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        java.util.Date date5 = localDate4.toDate();
        org.joda.time.LocalDate.Property property6 = localDate4.dayOfMonth();
        try {
            org.joda.time.LocalDate localDate8 = property6.setCopy("Jun");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Jun\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt(1560639123311L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1560639123311");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.LocalDate.Property property5 = localDate4.monthOfYear();
        org.joda.time.LocalDate localDate6 = property5.withMaximumValue();
        org.joda.time.LocalDate localDate8 = property5.addWrapFieldToCopy(15);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        int int6 = localDate4.getEra();
        org.joda.time.LocalDate localDate8 = localDate4.withYearOfEra((int) ' ');
        org.joda.time.LocalDate.Property property9 = localDate4.weekOfWeekyear();
        org.joda.time.LocalDate localDate10 = property9.roundCeilingCopy();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone13);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone13);
        org.joda.time.DateTimeField[] dateTimeFieldArray16 = localDate15.getFields();
        org.joda.time.DateMidnight dateMidnight17 = localDate15.toDateMidnight();
        org.joda.time.DateTime dateTime18 = localDate15.toDateTimeAtMidnight();
        org.joda.time.DateTime dateTime20 = dateTime18.withMillis(1560639112800L);
        long long21 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
        java.lang.String str22 = property9.getAsText();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeFieldArray16);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "24" + "'", str22.equals("24"));
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        long long29 = unsupportedDateTimeField26.add((long) 20, (int) (byte) 1);
//        org.joda.time.DurationField durationField30 = unsupportedDateTimeField26.getLeapDurationField();
//        long long33 = unsupportedDateTimeField26.getDifferenceAsLong(28800000L, (long) 999);
//        java.lang.String str34 = unsupportedDateTimeField26.getName();
//        org.joda.time.DurationField durationField35 = unsupportedDateTimeField26.getDurationField();
//        try {
//            long long38 = unsupportedDateTimeField26.set(3121278288638L, 20);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3121278315907L + "'", long14 == 3121278315907L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121278315908L + "'", long18 == 3121278315908L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1020L + "'", long29 == 1020L);
//        org.junit.Assert.assertNull(durationField30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 28799L + "'", long33 == 28799L);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "millisOfSecond" + "'", str34.equals("millisOfSecond"));
//        org.junit.Assert.assertNotNull(durationField35);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(3121278285431L);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField3, 0);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology0.millisOfSecond();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
//        int int8 = dateTime7.getSecondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime7.withWeekOfWeekyear((int) (byte) 1);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 49073 + "'", int8 == 49073);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        int int25 = dividedDateTimeField23.get((long) '#');
//        java.lang.String str27 = dividedDateTimeField23.getAsShortText(1560639124718L);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone30);
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone30);
//        org.joda.time.DateTimeField[] dateTimeFieldArray33 = localDate32.getFields();
//        int int34 = localDate32.getEra();
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.LocalDate localDate37 = localDate32.withPeriodAdded(readablePeriod35, (-292275054));
//        int int38 = dividedDateTimeField23.getMinimumValue((org.joda.time.ReadablePartial) localDate32);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917473611L + "'", long14 == 4681917473611L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917473611L + "'", long18 == 4681917473611L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.DateMidnight dateMidnight6 = localDate4.toDateMidnight();
        org.joda.time.DateTime dateTime7 = localDate4.toDateTimeAtMidnight();
        org.joda.time.DateTime dateTime9 = dateTime7.withMillis(1560639112800L);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendEraText();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, readableInstant14);
        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology12, dateTimeField16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = skipUndoDateTimeField17.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder11.appendFixedDecimal(dateTimeFieldType18, (int) (short) 10);
        org.joda.time.DateTime dateTime22 = dateTime7.withField(dateTimeFieldType18, 292278993);
        org.joda.time.DateTime.Property property23 = dateTime22.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial3 = partial0.withPeriodAdded(readablePeriod1, 7);
        java.lang.String str5 = partial3.toString("1969");
        org.junit.Assert.assertNotNull(partial3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField8 = buddhistChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        org.joda.time.Chronology chronology13 = buddhistChronology7.withZone(dateTimeZone11);
        org.joda.time.Chronology chronology14 = gJChronology2.withZone(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology2.weekOfWeekyear();
        org.joda.time.DurationField durationField16 = gJChronology2.years();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneName();
        dateTimeFormatterBuilder0.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField2 = buddhistChronology1.weeks();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(1560639114555L, (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (-1));
        int int7 = dateTime6.getDayOfMonth();
        org.joda.time.DateTime dateTime9 = dateTime6.withDayOfYear((int) '4');
        org.joda.time.DateTime.Property property10 = dateTime9.weekOfWeekyear();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DurationField durationField14 = julianChronology13.weekyears();
        org.joda.time.Chronology chronology15 = julianChronology13.withUTC();
        java.lang.String str16 = julianChronology13.toString();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "JulianChronology[America/Los_Angeles,mdfw=1]" + "'", str16.equals("JulianChronology[America/Los_Angeles,mdfw=1]"));
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
//        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology3.era();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField19);
//        int int22 = skipUndoDateTimeField20.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField24 = buddhistChronology23.seconds();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        long long28 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime31);
//        boolean boolean33 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime.Property property34 = dateTime31.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, durationField24, dateTimeFieldType35, 2000);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField43);
//        int int46 = skipUndoDateTimeField44.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField48 = buddhistChronology47.seconds();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
//        long long52 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        long long56 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime55);
//        boolean boolean57 = dateTime51.isEqual((org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DateTime.Property property58 = dateTime55.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField44, durationField48, dateTimeFieldType59, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, durationField24, dateTimeFieldType59, 9);
//        long long65 = remainderDateTimeField63.roundFloor(3121278248046166L);
//        int int67 = remainderDateTimeField63.get((-61820237221990L));
//        int int69 = remainderDateTimeField63.getLeapAmount((long) (-3368));
//        org.joda.time.DateTimeZone dateTimeZone71 = null;
//        org.joda.time.DateTimeZone dateTimeZone72 = org.joda.time.DateTimeUtils.getZone(dateTimeZone71);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone72);
//        org.joda.time.LocalDate localDate74 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone72);
//        org.joda.time.LocalDate.Property property75 = localDate74.monthOfYear();
//        int int76 = localDate74.size();
//        org.joda.time.LocalDate localDate78 = localDate74.withYear(51);
//        int int79 = remainderDateTimeField63.getMaximumValue((org.joda.time.ReadablePartial) localDate78);
//        try {
//            long long82 = remainderDateTimeField63.add(0L, 1560639130621L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 1560639130621 * 86400000");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 4681917474118L + "'", long28 == 4681917474118L);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4681917474119L + "'", long32 == 4681917474119L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 999 + "'", int46 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 4681917474143L + "'", long52 == 4681917474143L);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 4681917474144L + "'", long56 == 4681917474144L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 3121278217200000L + "'", long65 == 3121278217200000L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 3 + "'", int67 == 3);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone72);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 3 + "'", int76 == 3);
//        org.junit.Assert.assertNotNull(localDate78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 8 + "'", int79 == 8);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("JulianChronology[America/Los_Angeles,mdfw=1]");
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
//        org.joda.time.DateTime.Property property13 = dateTime11.centuryOfEra();
//        org.joda.time.DateTime dateTime14 = property13.roundHalfCeilingCopy();
//        boolean boolean15 = dateTime14.isEqualNow();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.ReadableInstant readableInstant17 = null;
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, readableInstant17);
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField21);
//        int int24 = skipUndoDateTimeField22.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField26 = buddhistChronology25.seconds();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(dateTimeZone28);
//        long long30 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
//        long long34 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime33);
//        boolean boolean35 = dateTime29.isEqual((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime.Property property36 = dateTime33.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property36.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField22, durationField26, dateTimeFieldType37, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField41 = buddhistChronology40.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField41);
//        long long45 = unsupportedDateTimeField42.add((long) 20, (int) (byte) 1);
//        org.joda.time.DurationField durationField46 = unsupportedDateTimeField42.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = unsupportedDateTimeField42.getType();
//        org.joda.time.DateTime.Property property48 = dateTime14.property(dateTimeFieldType47);
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) ' ');
//        org.joda.time.DateTime dateTime52 = dateTime50.withMonthOfYear((int) (short) 1);
//        org.joda.time.DateTime dateTime54 = dateTime52.minusYears((-1));
//        org.joda.time.DateTime.Property property55 = dateTime54.weekyear();
//        int int56 = property48.compareTo((org.joda.time.ReadableInstant) dateTime54);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4681917474368L + "'", long3 == 4681917474368L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4681917474368L + "'", long7 == 4681917474368L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 999 + "'", int24 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 4681917474394L + "'", long30 == 4681917474394L);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 4681917474395L + "'", long34 == 4681917474395L);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//        org.junit.Assert.assertNotNull(buddhistChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1020L + "'", long45 == 1020L);
//        org.junit.Assert.assertNull(durationField46);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial3 = partial0.withPeriodAdded(readablePeriod1, 7);
        int[] intArray4 = partial3.getValues();
        java.lang.String str5 = partial3.toString();
        org.junit.Assert.assertNotNull(partial3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withYearOfCentury(4);
        org.joda.time.DateTime dateTime4 = dateTime2.plus(1572771600000L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime2.toMutableDateTimeISO();
//        java.util.Locale locale5 = null;
//        java.util.Calendar calendar6 = dateTime2.toCalendar(locale5);
//        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.fromCalendarFields(calendar6);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendEraText();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, readableInstant12);
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology10, dateTimeField14);
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = skipUndoDateTimeField15.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder9.appendFraction(dateTimeFieldType16, 20, 0);
//        org.joda.time.LocalDate localDate21 = localDate7.withField(dateTimeFieldType16, 0);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
//        long long25 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime24.toMutableDateTimeISO();
//        java.util.Locale locale27 = null;
//        java.util.Calendar calendar28 = dateTime24.toCalendar(locale27);
//        org.joda.time.LocalDate localDate29 = org.joda.time.LocalDate.fromCalendarFields(calendar28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder30.appendEraText();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.ReadableInstant readableInstant34 = null;
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33, readableInstant34);
//        org.joda.time.DateTimeField dateTimeField36 = gJChronology35.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology32, dateTimeField36);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipUndoDateTimeField37.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder31.appendFraction(dateTimeFieldType38, 20, 0);
//        org.joda.time.LocalDate localDate43 = localDate29.withField(dateTimeFieldType38, 0);
//        org.joda.time.LocalDate.Property property44 = localDate43.dayOfWeek();
//        boolean boolean45 = localDate7.equals((java.lang.Object) property44);
//        org.joda.time.DateTime dateTime46 = localDate7.toDateTimeAtCurrentTime();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4681917474961L + "'", long3 == 4681917474961L);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(calendar6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 4681917474964L + "'", long25 == 4681917474964L);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(calendar28);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(buddhistChronology32);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(dateTime46);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendDayOfYear((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        long long8 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime11);
//        boolean boolean13 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime.Property property14 = dateTime11.millisOfSecond();
//        org.joda.time.DateTime dateTime16 = property14.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
//        org.joda.time.DateTime.Property property18 = dateTime16.centuryOfEra();
//        org.joda.time.DateTime dateTime19 = property18.roundHalfCeilingCopy();
//        boolean boolean20 = dateTime19.isEqualNow();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.ReadableInstant readableInstant22 = null;
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, readableInstant22);
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology25.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology23, dateTimeField26);
//        int int29 = skipUndoDateTimeField27.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField31 = buddhistChronology30.seconds();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
//        long long35 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeUtils.getZone(dateTimeZone36);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(dateTimeZone37);
//        long long39 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime38);
//        boolean boolean40 = dateTime34.isEqual((org.joda.time.ReadableInstant) dateTime38);
//        org.joda.time.DateTime.Property property41 = dateTime38.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField27, durationField31, dateTimeFieldType42, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField46 = buddhistChronology45.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField46);
//        long long50 = unsupportedDateTimeField47.add((long) 20, (int) (byte) 1);
//        org.joda.time.DurationField durationField51 = unsupportedDateTimeField47.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = unsupportedDateTimeField47.getType();
//        org.joda.time.DateTime.Property property53 = dateTime19.property(dateTimeFieldType52);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder1.appendDecimal(dateTimeFieldType52, 2000, 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 4681917475352L + "'", long8 == 4681917475352L);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 4681917475352L + "'", long12 == 4681917475352L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(buddhistChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 999 + "'", int29 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 4681917475357L + "'", long35 == 4681917475357L);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 4681917475357L + "'", long39 == 4681917475357L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(buddhistChronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1020L + "'", long50 == 1020L);
//        org.junit.Assert.assertNull(durationField51);
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(57120, (int) (short) -1, 19, 0, (int) (byte) 0, 2068, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2068 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        jodaTimePermission3.checkGuard((java.lang.Object) dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        jodaTimePermission3.checkGuard((java.lang.Object) dateTimeZone9);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9, (int) (short) 1);
        boolean boolean16 = dateTime1.equals((java.lang.Object) dateTimeZone9);
        org.joda.time.DateTime dateTime18 = dateTime1.minus(1560639136800L);
        org.joda.time.DateTime dateTime20 = dateTime1.minusMonths(18);
        org.joda.time.DateTime dateTime22 = dateTime1.minusDays((-53));
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
//        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology3.era();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField19);
//        int int22 = skipUndoDateTimeField20.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField24 = buddhistChronology23.seconds();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        long long28 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime31);
//        boolean boolean33 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime.Property property34 = dateTime31.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, durationField24, dateTimeFieldType35, 2000);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField43);
//        int int46 = skipUndoDateTimeField44.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField48 = buddhistChronology47.seconds();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
//        long long52 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        long long56 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime55);
//        boolean boolean57 = dateTime51.isEqual((org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DateTime.Property property58 = dateTime55.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField44, durationField48, dateTimeFieldType59, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, durationField24, dateTimeFieldType59, 9);
//        long long65 = remainderDateTimeField63.roundFloor(3121278248046166L);
//        int int67 = remainderDateTimeField63.get((-61820237221990L));
//        int int69 = remainderDateTimeField63.getLeapAmount((long) (-3368));
//        org.joda.time.DateTimeZone dateTimeZone71 = null;
//        org.joda.time.DateTimeZone dateTimeZone72 = org.joda.time.DateTimeUtils.getZone(dateTimeZone71);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone72);
//        org.joda.time.LocalDate localDate74 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone72);
//        org.joda.time.LocalDate.Property property75 = localDate74.monthOfYear();
//        int int76 = localDate74.size();
//        org.joda.time.LocalDate localDate78 = localDate74.withYear(51);
//        int int79 = remainderDateTimeField63.getMaximumValue((org.joda.time.ReadablePartial) localDate78);
//        long long81 = remainderDateTimeField63.roundHalfEven(1560639131888L);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 4681917475982L + "'", long28 == 4681917475982L);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4681917476004L + "'", long32 == 4681917476004L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 999 + "'", int46 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 4681917476008L + "'", long52 == 4681917476008L);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 4681917476009L + "'", long56 == 4681917476009L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 3121278217200000L + "'", long65 == 3121278217200000L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 3 + "'", int67 == 3);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone72);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 3 + "'", int76 == 3);
//        org.junit.Assert.assertNotNull(localDate78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 8 + "'", int79 == 8);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 1560668400000L + "'", long81 == 1560668400000L);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
//        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology3.era();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField19);
//        int int22 = skipUndoDateTimeField20.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField24 = buddhistChronology23.seconds();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        long long28 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime31);
//        boolean boolean33 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime.Property property34 = dateTime31.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, durationField24, dateTimeFieldType35, 2000);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField43);
//        int int46 = skipUndoDateTimeField44.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField48 = buddhistChronology47.seconds();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
//        long long52 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        long long56 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime55);
//        boolean boolean57 = dateTime51.isEqual((org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DateTime.Property property58 = dateTime55.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField44, durationField48, dateTimeFieldType59, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, durationField24, dateTimeFieldType59, 9);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException66 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType59, (java.lang.Number) 3121278290407L, "6");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException69 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType59, (java.lang.Number) 1560639128453L, "6");
//        java.lang.Throwable[] throwableArray70 = illegalFieldValueException69.getSuppressed();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 4681917476409L + "'", long28 == 4681917476409L);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4681917476409L + "'", long32 == 4681917476409L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 999 + "'", int46 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 4681917476435L + "'", long52 == 4681917476435L);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 4681917476436L + "'", long56 == 4681917476436L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertNotNull(throwableArray70);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone10.getUncachedZone();
        boolean boolean12 = cachedDateTimeZone10.isFixed();
        java.lang.String str14 = cachedDateTimeZone10.getNameKey((long) 999);
        long long16 = cachedDateTimeZone10.nextTransition((long) 80);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(2068, (int) (byte) 10, 0, 20, 45, (org.joda.time.DateTimeZone) cachedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PST" + "'", str14.equals("PST"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime2.getZone();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone7);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray10 = localDate9.getFieldTypes();
        org.joda.time.DateMidnight dateMidnight11 = localDate9.toDateMidnight();
        boolean boolean12 = julianChronology4.equals((java.lang.Object) localDate9);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone15);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone15);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone18.getUncachedZone();
        boolean boolean20 = cachedDateTimeZone18.isFixed();
        org.joda.time.DateTime dateTime21 = localDate9.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) cachedDateTimeZone18);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(1560668400000L, (org.joda.time.DateTimeZone) cachedDateTimeZone18);
        int int23 = localDate22.size();
        try {
            org.joda.time.LocalDate localDate25 = localDate22.withMonthOfYear((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        long long29 = unsupportedDateTimeField26.add((long) 20, (int) (byte) 1);
//        org.joda.time.DurationField durationField30 = unsupportedDateTimeField26.getLeapDurationField();
//        java.lang.String str31 = unsupportedDateTimeField26.getName();
//        org.joda.time.ReadablePartial readablePartial32 = null;
//        org.joda.time.Partial partial34 = new org.joda.time.Partial();
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.Partial partial37 = partial34.withPeriodAdded(readablePeriod35, 7);
//        int[] intArray38 = partial37.getValues();
//        try {
//            int[] intArray40 = unsupportedDateTimeField26.set(readablePartial32, (-53), intArray38, 51);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917477041L + "'", long14 == 4681917477041L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917477041L + "'", long18 == 4681917477041L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1020L + "'", long29 == 1020L);
//        org.junit.Assert.assertNull(durationField30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "millisOfSecond" + "'", str31.equals("millisOfSecond"));
//        org.junit.Assert.assertNotNull(partial37);
//        org.junit.Assert.assertNotNull(intArray38);
//    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        java.lang.String str25 = dividedDateTimeField23.getAsShortText(1560639109776L);
//        long long28 = dividedDateTimeField23.getDifferenceAsLong((long) '#', 1560639129056L);
//        org.joda.time.DurationField durationField29 = dividedDateTimeField23.getRangeDurationField();
//        int int31 = dividedDateTimeField23.getMaximumValue(100L);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = dividedDateTimeField23.getAsText(1560639128752L, locale33);
//        java.util.Locale locale35 = null;
//        int int36 = dividedDateTimeField23.getMaximumShortTextLength(locale35);
//        try {
//            long long38 = dividedDateTimeField23.roundFloor(3121278299569L);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917477060L + "'", long14 == 4681917477060L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917477061L + "'", long18 == 4681917477061L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-780319564L) + "'", long28 == (-780319564L));
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral('#');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfMinute(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMillisOfDay(5);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendEraText();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, readableInstant12);
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology10, dateTimeField14);
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = skipUndoDateTimeField15.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder9.appendFraction(dateTimeFieldType16, 20, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder9.appendSecondOfMinute(57120);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder21.appendMonthOfYearText();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        long long26 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(dateTimeZone28);
//        long long30 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime29);
//        boolean boolean31 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.DateTime.Property property32 = dateTime29.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 1560639129829L, "-1");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder22.appendDecimal(dateTimeFieldType33, 99, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder5.appendFixedSignedDecimal(dateTimeFieldType33, 431);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 4681917477103L + "'", long26 == 4681917477103L);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 4681917477104L + "'", long30 == 4681917477104L);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField4);
        long long8 = skipUndoDateTimeField5.add((long) (short) 10, (long) (short) 10);
        boolean boolean9 = skipUndoDateTimeField5.isSupported();
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipUndoDateTimeField5.getAsText(4681917477103L, locale11);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 315532800010L + "'", long8 == 315532800010L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2118" + "'", str12.equals("2118"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) buddhistChronology0, (org.joda.time.Chronology) gJChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.BuddhistChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        try {
            long long21 = julianChronology13.getDateTimeMillis(100, 10, 5, 51, (int) (byte) 0, (-292275054), 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 51 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(julianChronology13);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.lang.Appendable appendable2 = null;
        org.joda.time.Partial partial3 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial6 = partial3.withPeriodAdded(readablePeriod4, 7);
        int[] intArray7 = partial6.getValues();
        try {
            dateTimeFormatter1.printTo(appendable2, (org.joda.time.ReadablePartial) partial6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(partial6);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("UTC");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"UTC/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ');
        int int5 = dateTime4.getMinuteOfHour();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime4, 3);
        try {
            org.joda.time.DateTime dateTime9 = dateTime4.withHourOfDay(45);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 45 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(gJChronology7);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.plus(readablePeriod4);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
//        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology3.era();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField19);
//        int int22 = skipUndoDateTimeField20.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField24 = buddhistChronology23.seconds();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        long long28 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime31);
//        boolean boolean33 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime.Property property34 = dateTime31.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, durationField24, dateTimeFieldType35, 2000);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField43);
//        int int46 = skipUndoDateTimeField44.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField48 = buddhistChronology47.seconds();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
//        long long52 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        long long56 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime55);
//        boolean boolean57 = dateTime51.isEqual((org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DateTime.Property property58 = dateTime55.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField44, durationField48, dateTimeFieldType59, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, durationField24, dateTimeFieldType59, 9);
//        long long65 = remainderDateTimeField63.roundHalfFloor((long) (short) 100);
//        int int67 = remainderDateTimeField63.getMaximumValue(1560639122018L);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 4681917477728L + "'", long28 == 4681917477728L);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4681917477728L + "'", long32 == 4681917477728L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 999 + "'", int46 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 4681917477731L + "'", long52 == 4681917477731L);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 4681917477732L + "'", long56 == 4681917477732L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 28800000L + "'", long65 == 28800000L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 8 + "'", int67 == 8);
//    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        java.lang.String str25 = dividedDateTimeField23.getAsShortText(1560639109776L);
//        long long28 = dividedDateTimeField23.getDifferenceAsLong((long) '#', 1560639129056L);
//        org.joda.time.DurationField durationField29 = dividedDateTimeField23.getLeapDurationField();
//        int int30 = dividedDateTimeField23.getMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone33);
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone33);
//        org.joda.time.DateTimeField[] dateTimeFieldArray36 = localDate35.getFields();
//        int int37 = localDate35.getEra();
//        org.joda.time.LocalDate localDate39 = localDate35.withYearOfEra((int) ' ');
//        org.joda.time.LocalDate.Property property40 = localDate35.weekOfWeekyear();
//        org.joda.time.LocalDate localDate42 = localDate35.plusDays((-28800000));
//        int int43 = dividedDateTimeField23.getMinimumValue((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.DurationField durationField44 = dividedDateTimeField23.getLeapDurationField();
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917478058L + "'", long14 == 4681917478058L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917478058L + "'", long18 == 4681917478058L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-780319564L) + "'", long28 == (-780319564L));
//        org.junit.Assert.assertNull(durationField29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNull(durationField44);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.DateMidnight dateMidnight6 = localDate4.toDateMidnight();
        org.joda.time.DateTime dateTime7 = localDate4.toDateTimeAtMidnight();
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        java.util.Locale locale10 = null;
        int int11 = property8.getMaximumTextLength(locale10);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 100);
        long long6 = offsetDateTimeField3.add(3121278288639L, (int) (short) 0);
        long long9 = offsetDateTimeField3.add(3121278288635L, 100);
        long long11 = offsetDateTimeField3.roundHalfCeiling(3121278289091L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3121278288639L + "'", long6 == 3121278288639L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3384107088635L + "'", long9 == 3384107088635L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3121545600000L + "'", long11 == 3121545600000L);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
//        try {
//            boolean boolean29 = unsupportedDateTimeField26.isLeap((long) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917478331L + "'", long14 == 4681917478331L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917478332L + "'", long18 == 4681917478332L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.LocalDate.Property property5 = localDate4.monthOfYear();
        java.lang.String str6 = property5.getName();
        int int7 = property5.getMinimumValue();
        org.joda.time.LocalDate localDate8 = property5.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "monthOfYear" + "'", str6.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now(dateTimeZone0);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        jodaTimePermission7.checkGuard((java.lang.Object) dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone13);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone13);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
        jodaTimePermission7.checkGuard((java.lang.Object) dateTimeZone13);
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13, (int) (short) 1);
        boolean boolean20 = dateTime5.equals((java.lang.Object) dateTimeZone13);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime5, 6);
        org.joda.time.DateTime dateTime25 = dateTime5.withDurationAdded(1560639117600L, 1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7, (int) (short) 1);
        org.joda.time.DurationField durationField14 = julianChronology13.weekyears();
        org.joda.time.Chronology chronology15 = julianChronology13.withUTC();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(chronology15);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial2 = partial0.plus(readablePeriod1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, readableInstant7);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = skipUndoDateTimeField10.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder4.appendFraction(dateTimeFieldType11, 20, 0);
        org.joda.time.Partial partial15 = partial0.without(dateTimeFieldType11);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.Partial partial18 = partial0.withPeriodAdded(readablePeriod16, (-53));
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField20 = buddhistChronology19.weeks();
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology19, dateTimeField22, 0);
        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology19.millisOfSecond();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology19);
        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology19.secondOfDay();
        org.joda.time.Partial partial28 = partial0.withChronologyRetainFields((org.joda.time.Chronology) buddhistChronology19);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType30 = partial28.getFieldType(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(partial2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(partial15);
        org.junit.Assert.assertNotNull(partial18);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(partial28);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        java.lang.String str25 = dividedDateTimeField23.getAsShortText(1560639109776L);
//        long long28 = dividedDateTimeField23.getDifferenceAsLong((long) '#', 1560639129056L);
//        org.joda.time.DurationField durationField29 = dividedDateTimeField23.getRangeDurationField();
//        int int31 = dividedDateTimeField23.getMaximumValue(100L);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = dividedDateTimeField23.getAsText(1560639128752L, locale33);
//        java.util.Locale locale35 = null;
//        int int36 = dividedDateTimeField23.getMaximumShortTextLength(locale35);
//        long long39 = dividedDateTimeField23.getDifferenceAsLong(3121278289047L, 3121278289272L);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917478604L + "'", long14 == 4681917478604L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917478605L + "'", long18 == 4681917478605L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-780319564L) + "'", long28 == (-780319564L));
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        int int6 = localDate4.getEra();
        org.joda.time.LocalDate localDate8 = localDate4.withYearOfEra((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone11);
        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
        org.joda.time.LocalDate localDate15 = property14.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
        org.joda.time.LocalDate.Property property17 = localDate4.property(dateTimeFieldType16);
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology18, dateTimeField22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = skipUndoDateTimeField23.getType();
        int int25 = localDate4.get(dateTimeFieldType24);
        java.util.Date date26 = localDate4.toDate();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ');
        int int5 = dateTime4.getMinuteOfHour();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime4, 3);
        org.joda.time.Instant instant8 = gJChronology7.getGregorianCutover();
        boolean boolean10 = instant8.isBefore(3121278306276L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
        org.joda.time.Chronology chronology6 = buddhistChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = cachedDateTimeZone12.getUncachedZone();
        boolean boolean14 = cachedDateTimeZone12.isFixed();
        java.lang.String str16 = cachedDateTimeZone12.getNameKey((long) 999);
        try {
            org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((java.lang.Object) chronology6, (org.joda.time.DateTimeZone) cachedDateTimeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.BuddhistChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PST" + "'", str16.equals("PST"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.Chronology chronology2 = instant1.getChronology();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        java.util.Date date5 = localDate4.toDate();
        org.joda.time.LocalDate.Property property6 = localDate4.dayOfMonth();
        org.joda.time.LocalDate.Property property7 = localDate4.yearOfCentury();
        org.joda.time.LocalDate localDate8 = property7.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.LocalDate localDate7 = localDate4.withWeekOfWeekyear(10);
        int int8 = localDate4.getWeekyear();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("", false);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        org.joda.time.DateTime dateTime15 = localDate4.toDateTimeAtCurrentTime(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withDayOfWeek(7);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.plus(readablePeriod18);
        try {
            org.joda.time.DateTime dateTime21 = dateTime19.withSecondOfMinute((-292269054));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292269054 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((java.lang.Object) 3121278291599L, dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 3121278303360L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 10.0d, (java.lang.Number) 1560639109775L, (java.lang.Number) 0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        illegalFieldValueException4.prependMessage("");
        java.lang.Number number9 = illegalFieldValueException4.getLowerBound();
        illegalFieldValueException4.prependMessage("");
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1560639109775L + "'", number9.equals(1560639109775L));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfMinute();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", false);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addCutover((int) '#', ' ', (-1), (int) (byte) 1, 69, true, (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
//        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology3.era();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField19);
//        int int22 = skipUndoDateTimeField20.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField24 = buddhistChronology23.seconds();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        long long28 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime31);
//        boolean boolean33 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime.Property property34 = dateTime31.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, durationField24, dateTimeFieldType35, 2000);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField43);
//        int int46 = skipUndoDateTimeField44.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField48 = buddhistChronology47.seconds();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
//        long long52 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        long long56 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime55);
//        boolean boolean57 = dateTime51.isEqual((org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DateTime.Property property58 = dateTime55.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField44, durationField48, dateTimeFieldType59, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, durationField24, dateTimeFieldType59, 9);
//        long long65 = remainderDateTimeField63.roundFloor(3121278248046166L);
//        int int67 = remainderDateTimeField63.get((-61820237221990L));
//        int int69 = remainderDateTimeField63.getLeapAmount((long) (-3368));
//        org.joda.time.DateTimeZone dateTimeZone71 = null;
//        org.joda.time.DateTimeZone dateTimeZone72 = org.joda.time.DateTimeUtils.getZone(dateTimeZone71);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone72);
//        org.joda.time.LocalDate localDate74 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone72);
//        org.joda.time.LocalDate.Property property75 = localDate74.monthOfYear();
//        int int76 = localDate74.size();
//        org.joda.time.LocalDate localDate78 = localDate74.withYear(51);
//        int int79 = remainderDateTimeField63.getMaximumValue((org.joda.time.ReadablePartial) localDate78);
//        try {
//            long long82 = remainderDateTimeField63.set((long) (short) 100, 49483);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 49483 for millisOfSecond must be in the range [0,8]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 4681917479208L + "'", long28 == 4681917479208L);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4681917479229L + "'", long32 == 4681917479229L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 999 + "'", int46 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 4681917479232L + "'", long52 == 4681917479232L);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 4681917479233L + "'", long56 == 4681917479233L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 3121278217200000L + "'", long65 == 3121278217200000L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 3 + "'", int67 == 3);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone72);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 3 + "'", int76 == 3);
//        org.junit.Assert.assertNotNull(localDate78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 8 + "'", int79 == 8);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField4);
//        long long8 = skipUndoDateTimeField5.add((long) (short) 10, (long) (short) 10);
//        boolean boolean9 = skipUndoDateTimeField5.isSupported();
//        long long12 = skipUndoDateTimeField5.set((long) 10, (int) (short) 10);
//        int int14 = skipUndoDateTimeField5.getMinimumValue(1560639114556L);
//        int int16 = skipUndoDateTimeField5.get(1560639116927L);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.ReadableInstant readableInstant18 = null;
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, readableInstant18);
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology19, dateTimeField22);
//        int int25 = skipUndoDateTimeField23.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField27 = buddhistChronology26.seconds();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
//        long long31 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
//        long long35 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime34);
//        boolean boolean36 = dateTime30.isEqual((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTime.Property property37 = dateTime34.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, durationField27, dateTimeFieldType38, 2000);
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = dividedDateTimeField40.getAsText(0, locale42);
//        org.joda.time.DurationField durationField44 = dividedDateTimeField40.getRangeDurationField();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.ReadableInstant readableInstant46 = null;
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone45, readableInstant46);
//        org.joda.time.DateTimeField dateTimeField48 = gJChronology47.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology49 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField50 = buddhistChronology49.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField51 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology47, dateTimeField50);
//        int int53 = skipUndoDateTimeField51.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField55 = buddhistChronology54.seconds();
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeUtils.getZone(dateTimeZone56);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime(dateTimeZone57);
//        long long59 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime58);
//        org.joda.time.DateTimeZone dateTimeZone60 = null;
//        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeUtils.getZone(dateTimeZone60);
//        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(dateTimeZone61);
//        long long63 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime62);
//        boolean boolean64 = dateTime58.isEqual((org.joda.time.ReadableInstant) dateTime62);
//        org.joda.time.DateTime.Property property65 = dateTime62.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property65.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField51, durationField55, dateTimeFieldType66, 2000);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField69 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, durationField44, dateTimeFieldType66);
//        org.joda.time.DateTimeZone dateTimeZone71 = null;
//        org.joda.time.DateTimeZone dateTimeZone72 = org.joda.time.DateTimeUtils.getZone(dateTimeZone71);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone72);
//        org.joda.time.LocalDate localDate74 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone72);
//        org.joda.time.LocalDate.Property property75 = localDate74.monthOfYear();
//        org.joda.time.LocalDate localDate76 = property75.withMaximumValue();
//        java.util.Locale locale77 = null;
//        java.lang.String str78 = delegatedDateTimeField69.getAsShortText((org.joda.time.ReadablePartial) localDate76, locale77);
//        int int79 = localDate76.getMonthOfYear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder80 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder80.appendEraText();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology82 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone83 = null;
//        org.joda.time.ReadableInstant readableInstant84 = null;
//        org.joda.time.chrono.GJChronology gJChronology85 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone83, readableInstant84);
//        org.joda.time.DateTimeField dateTimeField86 = gJChronology85.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField87 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology82, dateTimeField86);
//        org.joda.time.DateTimeFieldType dateTimeFieldType88 = skipUndoDateTimeField87.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder91 = dateTimeFormatterBuilder81.appendFraction(dateTimeFieldType88, 20, 0);
//        boolean boolean92 = localDate76.isSupported(dateTimeFieldType88);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 315532800010L + "'", long8 == 315532800010L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61820237221990L) + "'", long12 == (-61820237221990L));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292275054) + "'", int14 == (-292275054));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(buddhistChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 999 + "'", int25 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 4681917479260L + "'", long31 == 4681917479260L);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 4681917479260L + "'", long35 == 4681917479260L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "0" + "'", str43.equals("0"));
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(buddhistChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 999 + "'", int53 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology54);
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 4681917479900L + "'", long59 == 4681917479900L);
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 4681917479900L + "'", long63 == 4681917479900L);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(dateTimeFieldType66);
//        org.junit.Assert.assertNotNull(dateTimeZone72);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNotNull(localDate76);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "2019" + "'", str78.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 12 + "'", int79 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
//        org.junit.Assert.assertNotNull(buddhistChronology82);
//        org.junit.Assert.assertNotNull(gJChronology85);
//        org.junit.Assert.assertNotNull(dateTimeField86);
//        org.junit.Assert.assertNotNull(dateTimeFieldType88);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder91);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
//        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology3.era();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField19);
//        int int22 = skipUndoDateTimeField20.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField24 = buddhistChronology23.seconds();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        long long28 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime31);
//        boolean boolean33 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime.Property property34 = dateTime31.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, durationField24, dateTimeFieldType35, 2000);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField43);
//        int int46 = skipUndoDateTimeField44.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField48 = buddhistChronology47.seconds();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
//        long long52 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        long long56 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime55);
//        boolean boolean57 = dateTime51.isEqual((org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DateTime.Property property58 = dateTime55.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField44, durationField48, dateTimeFieldType59, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, durationField24, dateTimeFieldType59, 9);
//        long long65 = remainderDateTimeField63.roundFloor(3121278248046166L);
//        int int67 = remainderDateTimeField63.get((-61820237221990L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType68 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField72 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField63, dateTimeFieldType68, (-292269054), 57120, 5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 4681917480349L + "'", long28 == 4681917480349L);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4681917480352L + "'", long32 == 4681917480352L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 999 + "'", int46 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 4681917480355L + "'", long52 == 4681917480355L);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 4681917480355L + "'", long56 == 4681917480355L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 3121278217200000L + "'", long65 == 3121278217200000L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 3 + "'", int67 == 3);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime3);
        jodaTimePermission1.checkGuard((java.lang.Object) 1560639140710L);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DurationField durationField2 = gJChronology0.days();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
//        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology3.era();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField19);
//        int int22 = skipUndoDateTimeField20.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField24 = buddhistChronology23.seconds();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        long long28 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime31);
//        boolean boolean33 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime.Property property34 = dateTime31.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, durationField24, dateTimeFieldType35, 2000);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField43);
//        int int46 = skipUndoDateTimeField44.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField48 = buddhistChronology47.seconds();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
//        long long52 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        long long56 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime55);
//        boolean boolean57 = dateTime51.isEqual((org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DateTime.Property property58 = dateTime55.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField44, durationField48, dateTimeFieldType59, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, durationField24, dateTimeFieldType59, 9);
//        long long65 = remainderDateTimeField63.roundFloor(3121278248046166L);
//        int int67 = remainderDateTimeField63.get((-61820237221990L));
//        int int69 = remainderDateTimeField63.getLeapAmount((long) (-3368));
//        int int70 = remainderDateTimeField63.getMaximumValue();
//        java.lang.String str72 = remainderDateTimeField63.getAsText(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 4681917480416L + "'", long28 == 4681917480416L);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4681917480416L + "'", long32 == 4681917480416L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 999 + "'", int46 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 4681917480422L + "'", long52 == 4681917480422L);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 4681917480423L + "'", long56 == 4681917480423L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 3121278217200000L + "'", long65 == 3121278217200000L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 3 + "'", int67 == 3);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 8 + "'", int70 == 8);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "3" + "'", str72.equals("3"));
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipUndoDateTimeField7.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder1.appendFraction(dateTimeFieldType8, 20, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder1.appendSecondOfMinute(57120);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendCenturyOfEra(9, 45);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendMinuteOfDay((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
//        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology3.era();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField19);
//        int int22 = skipUndoDateTimeField20.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField24 = buddhistChronology23.seconds();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        long long28 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime31);
//        boolean boolean33 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime.Property property34 = dateTime31.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, durationField24, dateTimeFieldType35, 2000);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField43);
//        int int46 = skipUndoDateTimeField44.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField48 = buddhistChronology47.seconds();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
//        long long52 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        long long56 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime55);
//        boolean boolean57 = dateTime51.isEqual((org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DateTime.Property property58 = dateTime55.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField44, durationField48, dateTimeFieldType59, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, durationField24, dateTimeFieldType59, 9);
//        long long65 = remainderDateTimeField63.roundHalfEven(0L);
//        java.lang.String str67 = remainderDateTimeField63.getAsShortText(1560639122870L);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 4681917481050L + "'", long28 == 4681917481050L);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4681917481050L + "'", long32 == 4681917481050L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 999 + "'", int46 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 4681917481053L + "'", long52 == 4681917481053L);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 4681917481053L + "'", long56 == 4681917481053L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 28800000L + "'", long65 == 28800000L);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "6" + "'", str67.equals("6"));
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipUndoDateTimeField7.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder1.appendFixedDecimal(dateTimeFieldType8, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder1.appendLiteral('4');
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((java.lang.Integer) (-1));
        int int17 = dateTimeFormatter16.getDefaultYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter16.withPivotYear((int) (short) 100);
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter19.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter21.withPivotYear((java.lang.Integer) (-1));
        int int24 = dateTimeFormatter23.getDefaultYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter23.withPivotYear((int) (short) 100);
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter28.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser31 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser33 = dateTimeFormatter32.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray34 = new org.joda.time.format.DateTimeParser[] { dateTimeParser20, dateTimeParser27, dateTimeParser29, dateTimeParser31, dateTimeParser33 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder12.append(dateTimePrinter13, dateTimeParserArray34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder35.appendYearOfCentury(0, 8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendHourOfDay(166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.format.DateTimePrinter dateTimePrinter42 = dateTimeFormatter41.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder40.append(dateTimePrinter42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2000 + "'", int17 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2000 + "'", int24 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeParser31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimeParser33);
        org.junit.Assert.assertNotNull(dateTimeParserArray34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTimePrinter42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 1560639114556L, (-53));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 3121278307037L, chronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.String str4 = dateTime2.toString(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2068-11" + "'", str4.equals("2068-11"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray5 = localDate4.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone8);
        org.joda.time.DateTimeField[] dateTimeFieldArray11 = localDate10.getFields();
        int int12 = localDate10.getEra();
        org.joda.time.LocalDate localDate14 = localDate10.withYearOfEra((int) ' ');
        org.joda.time.LocalDate.Property property15 = localDate10.weekOfWeekyear();
        org.joda.time.LocalDate.Property property16 = localDate10.yearOfCentury();
        int int17 = localDate4.compareTo((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.LocalDate localDate19 = localDate4.plusDays(999);
        org.joda.time.LocalDate.Property property20 = localDate4.yearOfCentury();
        org.joda.time.DurationField durationField21 = property20.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeFieldArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNull(durationField21);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
//        org.joda.time.DateTime.Property property13 = dateTime11.centuryOfEra();
//        org.joda.time.DateTime dateTime14 = property13.roundHalfCeilingCopy();
//        boolean boolean15 = dateTime14.isEqualNow();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.ReadableInstant readableInstant17 = null;
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, readableInstant17);
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField21);
//        int int24 = skipUndoDateTimeField22.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField26 = buddhistChronology25.seconds();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(dateTimeZone28);
//        long long30 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
//        long long34 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime33);
//        boolean boolean35 = dateTime29.isEqual((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime.Property property36 = dateTime33.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property36.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField22, durationField26, dateTimeFieldType37, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField41 = buddhistChronology40.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField42 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType37, durationField41);
//        long long45 = unsupportedDateTimeField42.add((long) 20, (int) (byte) 1);
//        org.joda.time.DurationField durationField46 = unsupportedDateTimeField42.getLeapDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = unsupportedDateTimeField42.getType();
//        org.joda.time.DateTime.Property property48 = dateTime14.property(dateTimeFieldType47);
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property48.getFieldType();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4681917481710L + "'", long3 == 4681917481710L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4681917481711L + "'", long7 == 4681917481711L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 999 + "'", int24 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 4681917481715L + "'", long30 == 4681917481715L);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 4681917481715L + "'", long34 == 4681917481715L);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//        org.junit.Assert.assertNotNull(buddhistChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField42);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1020L + "'", long45 == 1020L);
//        org.junit.Assert.assertNull(durationField46);
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField4);
        long long8 = skipUndoDateTimeField5.add((long) (short) 10, (long) (short) 10);
        boolean boolean9 = skipUndoDateTimeField5.isSupported();
        long long12 = skipUndoDateTimeField5.set((long) 10, (int) (short) 10);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField5.getAsText(1560639114105L, locale14);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone18);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone18);
        org.joda.time.DateTimeField[] dateTimeFieldArray21 = localDate20.getFields();
        org.joda.time.LocalDate localDate23 = localDate20.withWeekOfWeekyear(10);
        int int24 = localDate20.getWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str27 = gregorianChronology26.toString();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone30);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone30);
        org.joda.time.DateTimeField[] dateTimeFieldArray33 = localDate32.getFields();
        int int34 = localDate32.getEra();
        org.joda.time.LocalDate localDate36 = localDate32.withYearOfEra((int) ' ');
        org.joda.time.LocalDate.Property property37 = localDate32.weekOfWeekyear();
        int[] intArray39 = gregorianChronology26.get((org.joda.time.ReadablePartial) localDate32, 1560639122741L);
        try {
            int[] intArray41 = skipUndoDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) localDate20, 18, intArray39, 68);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 18");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 315532800010L + "'", long8 == 315532800010L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61820237221990L) + "'", long12 == (-61820237221990L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeFieldArray21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "GregorianChronology[UTC]" + "'", str27.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeFieldArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(intArray39);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Pacific Daylight Time", "1969", 3, (int) (byte) 1);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffset(3121278303329L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.lang.Integer int2 = dateTimeFormatter1.getPivotYear();
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("-1", dateTimeFormatter1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant3.minus(readableDuration4);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(int2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str5 = dateTimeZone4.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology3, dateTimeZone4);
        boolean boolean8 = zonedChronology6.equals((java.lang.Object) 1560639129664L);
        try {
            long long13 = zonedChronology6.getDateTimeMillis((int) (short) 100, 15, 2068, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("DateTimeField[year]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[year]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(1560639118264L);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.minus(readableDuration2);
        org.joda.time.Instant instant5 = instant1.plus(1560639123471L);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant1.plus(readableDuration6);
        org.joda.time.DateTime dateTime8 = instant7.toDateTimeISO();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
        org.joda.time.DateTimeField dateTimeField12 = julianChronology3.era();
        org.joda.time.DurationField durationField13 = julianChronology3.centuries();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Pacific Daylight Time", "1969", 3, (int) (byte) 1);
        long long7 = fixedDateTimeZone4.convertLocalToUTC(3121278292100L, false);
        java.lang.String str8 = fixedDateTimeZone4.toString();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3121278292097L + "'", long7 == 3121278292097L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Daylight Time" + "'", str8.equals("Pacific Daylight Time"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "year");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.lang.Integer int2 = dateTimeFormatter1.getPivotYear();
        org.joda.time.Instant instant3 = org.joda.time.Instant.parse("-1", dateTimeFormatter1);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((-1L));
        try {
            java.lang.String str6 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(int2);
        org.junit.Assert.assertNotNull(instant3);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
//        jodaTimePermission1.checkGuard((java.lang.Object) dateTime3);
//        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
//        jodaTimePermission7.checkGuard((java.lang.Object) dateTime9);
//        boolean boolean12 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission7);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField14 = buddhistChronology13.seconds();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField20);
//        int int23 = skipUndoDateTimeField21.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone27);
//        long long29 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone(dateTimeZone30);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(dateTimeZone31);
//        long long33 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime32);
//        boolean boolean34 = dateTime28.isEqual((org.joda.time.ReadableInstant) dateTime32);
//        org.joda.time.DateTime.Property property35 = dateTime32.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property35.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField21, durationField25, dateTimeFieldType36, 2000);
//        boolean boolean39 = buddhistChronology13.equals((java.lang.Object) dateTimeFieldType36);
//        jodaTimePermission7.checkGuard((java.lang.Object) buddhistChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(buddhistChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 999 + "'", int23 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 4681917482296L + "'", long29 == 4681917482296L);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 4681917482297L + "'", long33 == 4681917482297L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        int int5 = dateTime3.getYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.LocalDate.Property property5 = localDate4.monthOfYear();
        boolean boolean6 = property5.isLeap();
        org.joda.time.LocalDate localDate7 = property5.roundCeilingCopy();
        org.joda.time.LocalDate localDate9 = localDate7.withYearOfEra((int) '#');
        int int10 = localDate7.size();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-1));
//        org.joda.time.DateTime dateTime12 = property9.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime13 = dateTime12.toDateTimeISO();
//        java.lang.String str15 = dateTime12.toString("0");
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4681917482556L + "'", long3 == 4681917482556L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4681917482556L + "'", long7 == 4681917482556L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.minuteOfHour();
        org.joda.time.Partial partial4 = new org.joda.time.Partial((org.joda.time.Chronology) gJChronology2);
        try {
            org.joda.time.DateTimeField dateTimeField6 = partial4.getField((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone18 = cachedDateTimeZone17.getUncachedZone();
        boolean boolean19 = cachedDateTimeZone17.isFixed();
        org.joda.time.DateTime dateTime20 = localDate8.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) cachedDateTimeZone17);
        org.joda.time.LocalDate.Property property21 = localDate8.era();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray22 = localDate8.getFieldTypes();
        org.joda.time.LocalTime localTime23 = null;
        org.joda.time.DateTime dateTime24 = localDate8.toDateTime(localTime23);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("monthOfYear");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"monthOfYear\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.LocalDate localDate7 = localDate4.withWeekOfWeekyear(10);
        org.joda.time.LocalDate.Property property8 = localDate4.dayOfYear();
        org.joda.time.LocalDate localDate9 = property8.getLocalDate();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str5 = dateTimeZone4.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology3, dateTimeZone4);
        java.lang.String str7 = dateTimeZone4.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 100);
        long long6 = offsetDateTimeField3.add(1560639145359L, 49500);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 131733125545359L + "'", long6 == 131733125545359L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(1560639135739L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withYearOfCentury(4);
        try {
            org.joda.time.DateTime dateTime4 = dateTime2.withMinuteOfHour(57120);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57120 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray5 = localDate4.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone8);
        org.joda.time.DateTimeField[] dateTimeFieldArray11 = localDate10.getFields();
        int int12 = localDate10.getEra();
        org.joda.time.LocalDate localDate14 = localDate10.withYearOfEra((int) ' ');
        org.joda.time.LocalDate.Property property15 = localDate10.weekOfWeekyear();
        org.joda.time.LocalDate.Property property16 = localDate10.yearOfCentury();
        int int17 = localDate4.compareTo((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.LocalDate localDate19 = localDate4.plusDays(999);
        org.joda.time.LocalDate.Property property20 = localDate4.yearOfCentury();
        org.joda.time.DateTime dateTime21 = localDate4.toDateTimeAtCurrentTime();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeFieldArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 10.0d, (java.lang.Number) 1560639109775L, (java.lang.Number) 0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        illegalFieldValueException4.prependMessage("");
        java.lang.Number number9 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType10 = illegalFieldValueException4.getDurationFieldType();
        java.lang.String str11 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1560639109775L + "'", number9.equals(1560639109775L));
        org.junit.Assert.assertNull(durationFieldType10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        boolean boolean2 = dateTime1.isBeforeNow();
        org.joda.time.DateTime dateTime4 = dateTime1.withMillis(1560639130539L);
        org.joda.time.DateTime dateTime6 = dateTime1.plus(1560639127539L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
        org.joda.time.Chronology chronology6 = buddhistChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.now(dateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipUndoDateTimeField7.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder1.appendFraction(dateTimeFieldType8, 20, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder1.appendSecondOfMinute(57120);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendEraText();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, readableInstant16);
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField20);
//        int int23 = skipUndoDateTimeField21.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone27);
//        long long29 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone(dateTimeZone30);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(dateTimeZone31);
//        long long33 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime32);
//        boolean boolean34 = dateTime28.isEqual((org.joda.time.ReadableInstant) dateTime32);
//        org.joda.time.DateTime.Property property35 = dateTime32.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property35.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField21, durationField25, dateTimeFieldType36, 2000);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder13.appendSignedDecimal(dateTimeFieldType36, 12, 12);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser43 = dateTimeFormatter42.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder13.appendOptional(dateTimeParser43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(buddhistChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 999 + "'", int23 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 4681917483162L + "'", long29 == 4681917483162L);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 4681917483163L + "'", long33 == 4681917483163L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertNotNull(dateTimeParser43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        java.lang.String str25 = dividedDateTimeField23.getAsShortText(1560639109776L);
//        long long28 = dividedDateTimeField23.getDifferenceAsLong((long) '#', 1560639129056L);
//        org.joda.time.DurationField durationField29 = dividedDateTimeField23.getRangeDurationField();
//        int int31 = dividedDateTimeField23.getMaximumValue(100L);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = dividedDateTimeField23.getAsText(1560639128752L, locale33);
//        java.util.Locale locale35 = null;
//        int int36 = dividedDateTimeField23.getMaximumShortTextLength(locale35);
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.ReadableInstant readableInstant38 = null;
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
//        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology41.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField43 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology39, dateTimeField42);
//        int int45 = skipUndoDateTimeField43.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField47 = buddhistChronology46.seconds();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeUtils.getZone(dateTimeZone48);
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime(dateTimeZone49);
//        long long51 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeUtils.getZone(dateTimeZone52);
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone53);
//        long long55 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime54);
//        boolean boolean56 = dateTime50.isEqual((org.joda.time.ReadableInstant) dateTime54);
//        org.joda.time.DateTime.Property property57 = dateTime54.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = property57.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField60 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField43, durationField47, dateTimeFieldType58, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology61 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone62 = null;
//        org.joda.time.ReadableInstant readableInstant63 = null;
//        org.joda.time.chrono.GJChronology gJChronology64 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone62, readableInstant63);
//        org.joda.time.DateTimeField dateTimeField65 = gJChronology64.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField66 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology61, dateTimeField65);
//        org.joda.time.DateTimeFieldType dateTimeFieldType67 = skipUndoDateTimeField66.getType();
//        org.joda.time.DateTimeZone dateTimeZone69 = null;
//        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeUtils.getZone(dateTimeZone69);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone70);
//        org.joda.time.LocalDate localDate72 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone70);
//        org.joda.time.LocalDate.Property property73 = localDate72.monthOfYear();
//        boolean boolean74 = property73.isLeap();
//        org.joda.time.DurationField durationField75 = property73.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType67, durationField75);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField77 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23, durationField47, dateTimeFieldType67);
//        long long79 = remainderDateTimeField77.roundFloor(1560639146167L);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917483388L + "'", long14 == 4681917483388L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917483388L + "'", long18 == 4681917483388L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-780319564L) + "'", long28 == (-780319564L));
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(buddhistChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 999 + "'", int45 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 4681917483392L + "'", long51 == 4681917483392L);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 4681917483393L + "'", long55 == 4681917483393L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertNotNull(buddhistChronology61);
//        org.junit.Assert.assertNotNull(gJChronology64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertNotNull(dateTimeFieldType67);
//        org.junit.Assert.assertNotNull(dateTimeZone70);
//        org.junit.Assert.assertNotNull(property73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(durationField75);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1560639146167L + "'", long79 == 1560639146167L);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
//        org.joda.time.DateTime.Property property13 = dateTime11.centuryOfEra();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology16);
//        int int19 = dateTime18.getYear();
//        int int20 = property13.getDifference((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime21 = dateTime18.withEarlierOffsetAtOverlap();
//        org.joda.time.Instant instant22 = dateTime18.toInstant();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4681917483700L + "'", long3 == 4681917483700L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4681917483700L + "'", long7 == 4681917483700L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2118 + "'", int19 == 2118);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(instant22);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        java.lang.String str25 = dividedDateTimeField23.getAsShortText(1560639109776L);
//        long long28 = dividedDateTimeField23.getDifferenceAsLong((long) '#', 1560639129056L);
//        org.joda.time.DurationField durationField29 = dividedDateTimeField23.getRangeDurationField();
//        java.lang.String str30 = dividedDateTimeField23.getName();
//        org.joda.time.DurationField durationField31 = dividedDateTimeField23.getDurationField();
//        org.joda.time.DurationField durationField32 = dividedDateTimeField23.getRangeDurationField();
//        java.util.Locale locale33 = null;
//        int int34 = dividedDateTimeField23.getMaximumTextLength(locale33);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917483847L + "'", long14 == 4681917483847L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917483848L + "'", long18 == 4681917483848L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-780319564L) + "'", long28 == (-780319564L));
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "millisOfSecond" + "'", str30.equals("millisOfSecond"));
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.monthOfYear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 100);
        long long5 = offsetDateTimeField3.roundHalfEven(4681917475357L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4680806400000L + "'", long5 == 4680806400000L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.LocalDate localDate7 = localDate4.withWeekOfWeekyear(10);
        int int8 = localDate4.getWeekyear();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("", false);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        org.joda.time.DateTime dateTime15 = localDate4.toDateTimeAtCurrentTime(dateTimeZone14);
        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now(dateTimeZone14);
        java.lang.Object obj17 = null;
        boolean boolean18 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone14, obj17);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.LocalDate localDate7 = localDate4.withWeekOfWeekyear(10);
        int int8 = localDate4.getWeekyear();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("", false);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        org.joda.time.DateTime dateTime15 = localDate4.toDateTimeAtCurrentTime(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.DateTimeField dateTimeField11 = property9.getField();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4681917484433L + "'", long3 == 4681917484433L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4681917484433L + "'", long7 == 4681917484433L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        java.lang.String str25 = dividedDateTimeField23.getAsShortText(1560639109776L);
//        long long28 = dividedDateTimeField23.getDifferenceAsLong((long) '#', 1560639129056L);
//        org.joda.time.DurationField durationField29 = dividedDateTimeField23.getRangeDurationField();
//        int int31 = dividedDateTimeField23.getMaximumValue(100L);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = dividedDateTimeField23.getAsText(1560639128752L, locale33);
//        java.util.Locale locale35 = null;
//        int int36 = dividedDateTimeField23.getMaximumShortTextLength(locale35);
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.ReadableInstant readableInstant38 = null;
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
//        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology41.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField43 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology39, dateTimeField42);
//        int int45 = skipUndoDateTimeField43.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField47 = buddhistChronology46.seconds();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeUtils.getZone(dateTimeZone48);
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime(dateTimeZone49);
//        long long51 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeUtils.getZone(dateTimeZone52);
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone53);
//        long long55 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime54);
//        boolean boolean56 = dateTime50.isEqual((org.joda.time.ReadableInstant) dateTime54);
//        org.joda.time.DateTime.Property property57 = dateTime54.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = property57.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField60 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField43, durationField47, dateTimeFieldType58, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology61 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone62 = null;
//        org.joda.time.ReadableInstant readableInstant63 = null;
//        org.joda.time.chrono.GJChronology gJChronology64 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone62, readableInstant63);
//        org.joda.time.DateTimeField dateTimeField65 = gJChronology64.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField66 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology61, dateTimeField65);
//        org.joda.time.DateTimeFieldType dateTimeFieldType67 = skipUndoDateTimeField66.getType();
//        org.joda.time.DateTimeZone dateTimeZone69 = null;
//        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeUtils.getZone(dateTimeZone69);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone70);
//        org.joda.time.LocalDate localDate72 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone70);
//        org.joda.time.LocalDate.Property property73 = localDate72.monthOfYear();
//        boolean boolean74 = property73.isLeap();
//        org.joda.time.DurationField durationField75 = property73.getDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField76 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType67, durationField75);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField77 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23, durationField47, dateTimeFieldType67);
//        org.joda.time.DurationField durationField78 = dividedDateTimeField23.getDurationField();
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917484465L + "'", long14 == 4681917484465L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917484466L + "'", long18 == 4681917484466L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-780319564L) + "'", long28 == (-780319564L));
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(buddhistChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 999 + "'", int45 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 4681917484469L + "'", long51 == 4681917484469L);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 4681917484469L + "'", long55 == 4681917484469L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertNotNull(buddhistChronology61);
//        org.junit.Assert.assertNotNull(gJChronology64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertNotNull(dateTimeFieldType67);
//        org.junit.Assert.assertNotNull(dateTimeZone70);
//        org.junit.Assert.assertNotNull(property73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(durationField75);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField76);
//        org.junit.Assert.assertNotNull(durationField78);
//    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = buddhistChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        boolean boolean15 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime.Property property16 = dateTime13.millisOfSecond();
//        org.joda.time.DateTime dateTime18 = property16.addToCopy((long) (-1));
//        org.joda.time.DateTime dateTime19 = property16.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime20 = dateTime19.toDateTimeISO();
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.ReadableDateTime) dateTime20, readableDateTime21);
//        boolean boolean24 = limitChronology22.equals((java.lang.Object) 3);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 4681917484968L + "'", long10 == 4681917484968L);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917484969L + "'", long14 == 4681917484969L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(limitChronology22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        long long26 = dividedDateTimeField23.getDifferenceAsLong(1560639112800L, 1560639117600L);
//        int int28 = dividedDateTimeField23.getMinimumValue((long) (short) 1);
//        try {
//            long long30 = dividedDateTimeField23.roundFloor(1560639120227L);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917485039L + "'", long14 == 4681917485039L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917485039L + "'", long18 == 4681917485039L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2L) + "'", long26 == (-2L));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
//        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology3.era();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField19);
//        int int22 = skipUndoDateTimeField20.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField24 = buddhistChronology23.seconds();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        long long28 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime31);
//        boolean boolean33 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime.Property property34 = dateTime31.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, durationField24, dateTimeFieldType35, 2000);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField43);
//        int int46 = skipUndoDateTimeField44.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField48 = buddhistChronology47.seconds();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
//        long long52 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        long long56 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime55);
//        boolean boolean57 = dateTime51.isEqual((org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DateTime.Property property58 = dateTime55.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField44, durationField48, dateTimeFieldType59, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, durationField24, dateTimeFieldType59, 9);
//        try {
//            long long66 = durationField24.subtract(1560639125908L, 3121278301291L);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (BuddhistChronology[])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 4681917485074L + "'", long28 == 4681917485074L);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4681917485074L + "'", long32 == 4681917485074L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 999 + "'", int46 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 4681917485077L + "'", long52 == 4681917485077L);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 4681917485077L + "'", long56 == 4681917485077L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime3);
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        jodaTimePermission7.checkGuard((java.lang.Object) dateTime9);
        boolean boolean12 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission7);
        java.lang.String str13 = jodaTimePermission1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str13.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfMonth((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendMillisOfDay((int) (short) 100);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTimeZoneShortName(strMap11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder5.appendTimeZoneShortName(strMap11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(strMap11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.LocalDate.Property property5 = localDate4.monthOfYear();
        int int6 = localDate4.size();
        org.joda.time.LocalDate localDate8 = localDate4.withYear(51);
        org.joda.time.DateTime dateTime9 = localDate8.toDateTimeAtCurrentTime();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dividedDateTimeField23.getAsText(0, locale25);
//        org.joda.time.DurationField durationField27 = dividedDateTimeField23.getRangeDurationField();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.ReadableInstant readableInstant29 = null;
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, readableInstant29);
//        org.joda.time.DateTimeField dateTimeField31 = gJChronology30.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology30, dateTimeField33);
//        org.joda.time.Chronology chronology35 = gJChronology30.withUTC();
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology30);
//        org.joda.time.LocalTime localTime37 = dateTime36.toLocalTime();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = dividedDateTimeField23.getAsText((org.joda.time.ReadablePartial) localTime37, 19, locale39);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917485229L + "'", long14 == 4681917485229L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917485230L + "'", long18 == 4681917485230L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(buddhistChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertNotNull(localTime37);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "19" + "'", str40.equals("19"));
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
        org.joda.time.Chronology chronology6 = buddhistChronology0.withZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipUndoDateTimeField5.getType();
        org.joda.time.DateTimeField dateTimeField7 = skipUndoDateTimeField5.getWrappedField();
        java.lang.String str8 = skipUndoDateTimeField5.toString();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, readableInstant10);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.year();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField14);
        long long17 = skipUndoDateTimeField15.roundHalfEven((-1L));
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone20);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone20);
        int int23 = localDate22.getCenturyOfEra();
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate22, (-1), locale25);
        int int27 = localDate22.getYearOfCentury();
        java.util.Date date28 = localDate22.toDate();
        org.joda.time.LocalDate.Property property29 = localDate22.weekyear();
        java.util.Locale locale31 = null;
        java.lang.String str32 = skipUndoDateTimeField5.getAsText((org.joda.time.ReadablePartial) localDate22, 18062, locale31);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DateTimeField[year]" + "'", str8.equals("DateTimeField[year]"));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 20 + "'", int23 == 20);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "-1" + "'", str26.equals("-1"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 19 + "'", int27 == 19);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "18062" + "'", str32.equals("18062"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
        long long5 = buddhistChronology0.add((long) 1, 1560639109775L, (int) (byte) 1);
        org.joda.time.DurationField durationField6 = buddhistChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology0.yearOfCentury();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560639109776L + "'", long5 == 1560639109776L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Interval interval7 = localDate4.toInterval(dateTimeZone6);
        org.joda.time.LocalDate localDate9 = localDate4.withYearOfEra((int) (byte) 100);
        org.joda.time.DateMidnight dateMidnight10 = localDate9.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(dateMidnight10);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
        org.joda.time.Chronology chronology6 = buddhistChronology0.withZone(dateTimeZone4);
        java.lang.String str7 = dateTimeZone4.getID();
        java.lang.String str8 = dateTimeZone4.getID();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        int int10 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime12 = null;
//        boolean boolean13 = dateTimeZone11.isLocalDateTimeGap(localDateTime12);
//        org.joda.time.LocalDate localDate14 = org.joda.time.LocalDate.now(dateTimeZone11);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ');
//        org.joda.time.JodaTimePermission jodaTimePermission18 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        jodaTimePermission18.checkGuard((java.lang.Object) dateTimeZone19);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone24);
//        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone24);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone27 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone24);
//        jodaTimePermission18.checkGuard((java.lang.Object) dateTimeZone24);
//        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24, (int) (short) 1);
//        boolean boolean31 = dateTime16.equals((java.lang.Object) dateTimeZone24);
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime16, 6);
//        org.joda.time.MutableDateTime mutableDateTime34 = dateTime6.toMutableDateTime(dateTimeZone11);
//        org.joda.time.ReadableDuration readableDuration35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime6.plus(readableDuration35);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4681917485740L + "'", long3 == 4681917485740L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4681917485746L + "'", long7 == 4681917485746L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 74285 + "'", int10 == 74285);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone27);
//        org.junit.Assert.assertNotNull(julianChronology30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
//        org.joda.time.LocalDate.Property property5 = localDate4.monthOfYear();
//        boolean boolean6 = property5.isLeap();
//        org.joda.time.LocalDate localDate7 = property5.roundCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        long long15 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime14);
//        boolean boolean16 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime.Property property17 = dateTime14.millisOfSecond();
//        org.joda.time.DateTime dateTime19 = property17.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate20 = dateTime19.toLocalDate();
//        org.joda.time.DateTime.Property property21 = dateTime19.dayOfYear();
//        boolean boolean22 = property5.equals((java.lang.Object) property21);
//        int int23 = property21.get();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4681917485884L + "'", long11 == 4681917485884L);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 4681917485884L + "'", long15 == 4681917485884L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 133 + "'", int23 == 133);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", false);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeZoneBuilder0.toDateTimeZone("", false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.LocalDate localDate7 = localDate4.withWeekOfWeekyear(10);
        int int8 = localDate7.getDayOfWeek();
        int int9 = localDate7.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20 + "'", int9 == 20);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.DateMidnight dateMidnight6 = localDate4.toDateMidnight();
        org.joda.time.DateTime dateTime7 = localDate4.toDateTimeAtMidnight();
        int int8 = dateTime7.getMinuteOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.minusDays(0);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = dateTime7.toDateTime(chronology11);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField4);
        long long8 = skipUndoDateTimeField5.add((long) (short) 10, (long) (short) 10);
        boolean boolean9 = skipUndoDateTimeField5.isSupported();
        long long12 = skipUndoDateTimeField5.set((long) 10, (int) (short) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField5, 8);
        org.joda.time.DurationField durationField15 = offsetDateTimeField14.getLeapDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 315532800010L + "'", long8 == 315532800010L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61851772799990L) + "'", long12 == (-61851772799990L));
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.secondOfDay();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField4);
        long long8 = skipUndoDateTimeField5.add((long) (short) 10, (long) (short) 10);
        boolean boolean9 = skipUndoDateTimeField5.isSupported();
        long long12 = skipUndoDateTimeField5.set((long) 10, (int) (short) 10);
        int int14 = skipUndoDateTimeField5.getMinimumValue(1560639114556L);
        org.joda.time.DateTimeField dateTimeField15 = skipUndoDateTimeField5.getWrappedField();
        int int17 = skipUndoDateTimeField5.get(1560639114106L);
        org.joda.time.DurationField durationField18 = skipUndoDateTimeField5.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = skipUndoDateTimeField5.getType();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 315532800010L + "'", long8 == 315532800010L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61851772799990L) + "'", long12 == (-61851772799990L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292275054) + "'", int14 == (-292275054));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone14);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone18 = cachedDateTimeZone17.getUncachedZone();
        boolean boolean19 = cachedDateTimeZone17.isFixed();
        org.joda.time.DateTime dateTime20 = localDate8.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) cachedDateTimeZone17);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        try {
            org.joda.time.LocalDate localDate23 = localDate8.withFieldAdded(durationFieldType21, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.LocalDate localDate7 = localDate4.withWeekOfWeekyear(10);
        int int8 = localDate7.getDayOfWeek();
        org.joda.time.LocalDate localDate10 = localDate7.plusDays((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(localDate10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        java.util.Date date5 = localDate4.toDate();
        int int6 = localDate4.size();
        org.joda.time.LocalDate.Property property7 = localDate4.dayOfMonth();
        org.joda.time.LocalDate localDate9 = localDate4.plusWeeks(5);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        long long29 = unsupportedDateTimeField26.add((long) 20, (int) (byte) 1);
//        try {
//            long long31 = unsupportedDateTimeField26.roundHalfFloor(3121278299545L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917487688L + "'", long14 == 4681917487688L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917487688L + "'", long18 == 4681917487688L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1020L + "'", long29 == 1020L);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, (java.lang.Number) 1560639147974L, "June");
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4681917487712L + "'", long3 == 4681917487712L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4681917487712L + "'", long7 == 4681917487712L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
//        org.joda.time.LocalDate.Property property5 = localDate4.monthOfYear();
//        org.joda.time.LocalDate localDate6 = property5.withMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property5.getFieldType();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField9 = buddhistChronology8.seconds();
//        long long12 = durationField9.subtract(1560639119529L, 0L);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField9);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
//        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.MutableDateTime mutableDateTime18 = dateTime16.toMutableDateTimeISO();
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime21 = dateTime16.withPeriodAdded(readablePeriod19, 0);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeUtils.getZone(dateTimeZone22);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22, 1);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime16.toMutableDateTime((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.ReadableInstant readableInstant28 = null;
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, readableInstant28);
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology29, dateTimeField32);
//        int int35 = skipUndoDateTimeField33.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField37 = buddhistChronology36.seconds();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeUtils.getZone(dateTimeZone38);
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(dateTimeZone39);
//        long long41 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeUtils.getZone(dateTimeZone42);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(dateTimeZone43);
//        long long45 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime44);
//        boolean boolean46 = dateTime40.isEqual((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTime.Property property47 = dateTime44.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = property47.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField33, durationField37, dateTimeFieldType48, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology51 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField52 = buddhistChronology51.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField53 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType48, durationField52);
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = unsupportedDateTimeField53.getType();
//        int int55 = mutableDateTime26.get(dateTimeFieldType54);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) unsupportedDateTimeField13, dateTimeFieldType54, 20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560639119529L + "'", long12 == 1560639119529L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4681917487744L + "'", long17 == 4681917487744L);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 999 + "'", int35 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 4681917487747L + "'", long41 == 4681917487747L);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 4681917487748L + "'", long45 == 4681917487748L);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(dateTimeFieldType48);
//        org.junit.Assert.assertNotNull(buddhistChronology51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField53);
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 744 + "'", int55 == 744);
//    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
//        org.joda.time.LocalDate.Property property5 = localDate4.monthOfYear();
//        boolean boolean6 = property5.isLeap();
//        org.joda.time.LocalDate localDate7 = property5.roundCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        long long15 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime14);
//        boolean boolean16 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime.Property property17 = dateTime14.millisOfSecond();
//        org.joda.time.DateTime dateTime19 = property17.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate20 = dateTime19.toLocalDate();
//        org.joda.time.DateTime.Property property21 = dateTime19.dayOfYear();
//        boolean boolean22 = property5.equals((java.lang.Object) property21);
//        org.joda.time.DateTime dateTime23 = property21.withMinimumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4681917487785L + "'", long11 == 4681917487785L);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 4681917487785L + "'", long15 == 4681917487785L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.yearOfEra();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        java.lang.String str25 = dividedDateTimeField23.getAsShortText(1560639109776L);
//        long long28 = dividedDateTimeField23.getDifferenceAsLong((long) '#', 1560639129056L);
//        org.joda.time.DurationField durationField29 = dividedDateTimeField23.getLeapDurationField();
//        int int30 = dividedDateTimeField23.getMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone33);
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone33);
//        org.joda.time.DateTimeField[] dateTimeFieldArray36 = localDate35.getFields();
//        int int37 = localDate35.getEra();
//        org.joda.time.LocalDate localDate39 = localDate35.withYearOfEra((int) ' ');
//        org.joda.time.LocalDate.Property property40 = localDate35.weekOfWeekyear();
//        org.joda.time.LocalDate localDate42 = localDate35.plusDays((-28800000));
//        int int43 = dividedDateTimeField23.getMinimumValue((org.joda.time.ReadablePartial) localDate35);
//        try {
//            org.joda.time.LocalDate localDate45 = localDate35.withEra(2068);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2068 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917487918L + "'", long14 == 4681917487918L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917487919L + "'", long18 == 4681917487919L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0" + "'", str25.equals("0"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-780319564L) + "'", long28 == (-780319564L));
//        org.junit.Assert.assertNull(durationField29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        java.lang.String str5 = property4.toString();
        int int6 = property4.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[millisOfDay]" + "'", str5.equals("Property[millisOfDay]"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.LocalDate.Property property5 = localDate4.monthOfYear();
        org.joda.time.LocalDate localDate6 = property5.withMaximumValue();
        java.lang.String str7 = property5.getAsText();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June" + "'", str7.equals("June"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.LocalDate.Property property5 = localDate4.monthOfYear();
        java.lang.String str6 = property5.getName();
        org.joda.time.LocalDate localDate7 = property5.getLocalDate();
        int int8 = localDate7.getDayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.LocalDate localDate11 = localDate7.withField(dateTimeFieldType9, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "monthOfYear" + "'", str6.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfMinute();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDate6);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
//        org.joda.time.Chronology chronology6 = buddhistChronology0.withZone(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        boolean boolean15 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime.Property property16 = dateTime13.millisOfSecond();
//        org.joda.time.DateTime dateTime18 = property16.addToCopy((long) (-1));
//        org.joda.time.DateTime dateTime19 = property16.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime20 = dateTime19.toDateTimeISO();
//        org.joda.time.ReadableDateTime readableDateTime21 = null;
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.ReadableDateTime) dateTime20, readableDateTime21);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField24 = buddhistChronology23.weeks();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology25.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology23, dateTimeField26, 0);
//        int int29 = skipDateTimeField28.getMinimumValue();
//        int int31 = skipDateTimeField28.get((long) (-75600000));
//        boolean boolean32 = limitChronology22.equals((java.lang.Object) skipDateTimeField28);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 4681917488292L + "'", long10 == 4681917488292L);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917488292L + "'", long14 == 4681917488292L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(limitChronology22);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(buddhistChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendDayOfYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder1.appendYear(99, 68);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("1969");
//        org.joda.time.MutableDateTime mutableDateTime2 = dateTime1.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime4.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone9);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray12 = localDate11.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight13 = localDate11.toDateMidnight();
//        boolean boolean14 = julianChronology6.equals((java.lang.Object) localDate11);
//        org.joda.time.DateTimeField dateTimeField15 = julianChronology6.era();
//        org.joda.time.DateTimeField dateTimeField16 = julianChronology6.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.ReadableInstant readableInstant18 = null;
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, readableInstant18);
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology19, dateTimeField22);
//        int int25 = skipUndoDateTimeField23.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField27 = buddhistChronology26.seconds();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
//        long long31 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
//        long long35 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime34);
//        boolean boolean36 = dateTime30.isEqual((org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTime.Property property37 = dateTime34.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField23, durationField27, dateTimeFieldType38, 2000);
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.ReadableInstant readableInstant42 = null;
//        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, readableInstant42);
//        org.joda.time.DateTimeField dateTimeField44 = gJChronology43.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField46 = buddhistChronology45.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField47 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology43, dateTimeField46);
//        int int49 = skipUndoDateTimeField47.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology50 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField51 = buddhistChronology50.seconds();
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeUtils.getZone(dateTimeZone52);
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone53);
//        long long55 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime54);
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeUtils.getZone(dateTimeZone56);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime(dateTimeZone57);
//        long long59 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime58);
//        boolean boolean60 = dateTime54.isEqual((org.joda.time.ReadableInstant) dateTime58);
//        org.joda.time.DateTime.Property property61 = dateTime58.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField64 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField47, durationField51, dateTimeFieldType62, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dateTimeField16, durationField27, dateTimeFieldType62, 9);
//        long long68 = remainderDateTimeField66.roundHalfEven(0L);
//        org.joda.time.DateTimeField dateTimeField69 = remainderDateTimeField66.getWrappedField();
//        int int70 = dateTime1.get(dateTimeField69);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray12);
//        org.junit.Assert.assertNotNull(dateMidnight13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(buddhistChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 999 + "'", int25 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 4681917488423L + "'", long31 == 4681917488423L);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 4681917488424L + "'", long35 == 4681917488424L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(gJChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(buddhistChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 999 + "'", int49 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology50);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 4681917488427L + "'", long55 == 4681917488427L);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 4681917488427L + "'", long59 == 4681917488427L);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 3 + "'", int70 == 3);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, 7);
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipUndoDateTimeField5.getType();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone9);
        org.joda.time.LocalDate.Property property12 = localDate11.monthOfYear();
        boolean boolean13 = property12.isLeap();
        org.joda.time.DurationField durationField14 = property12.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField14);
        try {
            long long17 = unsupportedDateTimeField15.remainder(3121278286983L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) ' ');
        org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear((int) (short) 1);
        org.joda.time.DateTime dateTime5 = dateTime3.minusYears((-1));
        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property7 = dateTime5.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.LocalDate.Property property5 = localDate4.monthOfYear();
        org.joda.time.LocalDate localDate6 = property5.withMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.year();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField12);
        long long15 = skipUndoDateTimeField13.roundHalfEven((-1L));
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone18);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone18);
        int int21 = localDate20.getCenturyOfEra();
        java.util.Locale locale23 = null;
        java.lang.String str24 = skipUndoDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) localDate20, (-1), locale23);
        int int25 = localDate20.getYearOfCentury();
        int int26 = property5.compareTo((org.joda.time.ReadablePartial) localDate20);
        org.joda.time.LocalDate localDate27 = property5.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 20 + "'", int21 == 20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "-1" + "'", str24.equals("-1"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 19 + "'", int25 == 19);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(localDate27);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        long long29 = unsupportedDateTimeField26.add((long) 20, (int) (byte) 1);
//        org.joda.time.DurationField durationField30 = unsupportedDateTimeField26.getLeapDurationField();
//        long long33 = unsupportedDateTimeField26.getDifferenceAsLong(28800000L, (long) 999);
//        java.lang.String str34 = unsupportedDateTimeField26.getName();
//        org.joda.time.DurationField durationField35 = unsupportedDateTimeField26.getDurationField();
//        org.joda.time.DurationFieldType durationFieldType36 = null;
//        try {
//            org.joda.time.field.DecoratedDurationField decoratedDurationField37 = new org.joda.time.field.DecoratedDurationField(durationField35, durationFieldType36);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917489256L + "'", long14 == 4681917489256L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917489257L + "'", long18 == 4681917489257L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1020L + "'", long29 == 1020L);
//        org.junit.Assert.assertNull(durationField30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 28799L + "'", long33 == 28799L);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "millisOfSecond" + "'", str34.equals("millisOfSecond"));
//        org.junit.Assert.assertNotNull(durationField35);
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
//        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology3.era();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField19);
//        int int22 = skipUndoDateTimeField20.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField24 = buddhistChronology23.seconds();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        long long28 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime31);
//        boolean boolean33 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime.Property property34 = dateTime31.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, durationField24, dateTimeFieldType35, 2000);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField43);
//        int int46 = skipUndoDateTimeField44.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField48 = buddhistChronology47.seconds();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
//        long long52 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        long long56 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime55);
//        boolean boolean57 = dateTime51.isEqual((org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DateTime.Property property58 = dateTime55.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField44, durationField48, dateTimeFieldType59, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, durationField24, dateTimeFieldType59, 9);
//        long long65 = remainderDateTimeField63.roundFloor(3121278248046166L);
//        int int67 = remainderDateTimeField63.get((-61820237221990L));
//        int int69 = remainderDateTimeField63.getLeapAmount((long) (-3368));
//        int int72 = remainderDateTimeField63.getDifference(4681917483392L, 3121278299570L);
//        long long74 = remainderDateTimeField63.roundHalfEven(3121278303093L);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 4681917489291L + "'", long28 == 4681917489291L);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4681917489291L + "'", long32 == 4681917489291L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 999 + "'", int46 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 4681917489293L + "'", long52 == 4681917489293L);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 4681917489294L + "'", long56 == 4681917489294L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 3121278192000000L + "'", long65 == 3121278192000000L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 3 + "'", int67 == 3);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 18062 + "'", int72 == 18062);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 3121286400000L + "'", long74 == 3121286400000L);
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        long long29 = unsupportedDateTimeField26.add((long) 20, (int) (byte) 1);
//        org.joda.time.DurationField durationField30 = unsupportedDateTimeField26.getLeapDurationField();
//        java.lang.String str31 = unsupportedDateTimeField26.getName();
//        java.util.Locale locale33 = null;
//        try {
//            java.lang.String str34 = unsupportedDateTimeField26.getAsShortText(2068, locale33);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917489625L + "'", long14 == 4681917489625L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917489626L + "'", long18 == 4681917489626L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1020L + "'", long29 == 1020L);
//        org.junit.Assert.assertNull(durationField30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "millisOfSecond" + "'", str31.equals("millisOfSecond"));
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = skipUndoDateTimeField5.getType();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone9);
        org.joda.time.LocalDate.Property property12 = localDate11.monthOfYear();
        boolean boolean13 = property12.isLeap();
        org.joda.time.DurationField durationField14 = property12.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField15 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType6, durationField14);
        try {
            long long18 = unsupportedDateTimeField15.addWrapField(3121278307036L, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: year field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField15);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.LocalDate localDate7 = localDate4.withWeekOfWeekyear(10);
        int int8 = localDate4.getWeekyear();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("", false);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        org.joda.time.DateTime dateTime15 = localDate4.toDateTimeAtCurrentTime(dateTimeZone14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.LocalDate localDate17 = localDate4.minus(readablePeriod16);
        org.joda.time.LocalDate.Property property18 = localDate17.dayOfYear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendEraText();
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, readableInstant23);
        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology21, dateTimeField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = skipUndoDateTimeField26.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder20.appendFraction(dateTimeFieldType27, 20, 0);
        boolean boolean31 = localDate17.isSupported(dateTimeFieldType27);
        org.joda.time.LocalDate.Property property32 = localDate17.weekyear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(property32);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
//        java.util.Date date5 = localDate4.toDate();
//        org.joda.time.LocalDate.Property property6 = localDate4.dayOfMonth();
//        org.joda.time.LocalDate.Property property7 = localDate4.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        long long15 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime14);
//        boolean boolean16 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime.Property property17 = dateTime14.millisOfSecond();
//        org.joda.time.DateTime dateTime19 = property17.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate20 = dateTime19.toLocalDate();
//        org.joda.time.DateTime.Property property21 = dateTime19.centuryOfEra();
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.ReadableInstant readableInstant23 = null;
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, readableInstant23);
//        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.year();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology24);
//        int int27 = dateTime26.getYear();
//        int int28 = property21.getDifference((org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.DateTime dateTime30 = dateTime26.withMillisOfSecond(4);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone33 = dateTime32.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone33);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeUtils.getZone(dateTimeZone36);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone37);
//        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone37);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray40 = localDate39.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight41 = localDate39.toDateMidnight();
//        boolean boolean42 = julianChronology34.equals((java.lang.Object) localDate39);
//        org.joda.time.DateTimeField dateTimeField43 = julianChronology34.era();
//        org.joda.time.DateTimeField dateTimeField44 = julianChronology34.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.ReadableInstant readableInstant46 = null;
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone45, readableInstant46);
//        org.joda.time.DateTimeField dateTimeField48 = gJChronology47.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology49 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField50 = buddhistChronology49.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField51 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology47, dateTimeField50);
//        int int53 = skipUndoDateTimeField51.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField55 = buddhistChronology54.seconds();
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeUtils.getZone(dateTimeZone56);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime(dateTimeZone57);
//        long long59 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime58);
//        org.joda.time.DateTimeZone dateTimeZone60 = null;
//        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeUtils.getZone(dateTimeZone60);
//        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(dateTimeZone61);
//        long long63 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime62);
//        boolean boolean64 = dateTime58.isEqual((org.joda.time.ReadableInstant) dateTime62);
//        org.joda.time.DateTime.Property property65 = dateTime62.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType66 = property65.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField68 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField51, durationField55, dateTimeFieldType66, 2000);
//        org.joda.time.DateTimeZone dateTimeZone69 = null;
//        org.joda.time.ReadableInstant readableInstant70 = null;
//        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone69, readableInstant70);
//        org.joda.time.DateTimeField dateTimeField72 = gJChronology71.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology73 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField74 = buddhistChronology73.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField75 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology71, dateTimeField74);
//        int int77 = skipUndoDateTimeField75.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology78 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField79 = buddhistChronology78.seconds();
//        org.joda.time.DateTimeZone dateTimeZone80 = null;
//        org.joda.time.DateTimeZone dateTimeZone81 = org.joda.time.DateTimeUtils.getZone(dateTimeZone80);
//        org.joda.time.DateTime dateTime82 = new org.joda.time.DateTime(dateTimeZone81);
//        long long83 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime82);
//        org.joda.time.DateTimeZone dateTimeZone84 = null;
//        org.joda.time.DateTimeZone dateTimeZone85 = org.joda.time.DateTimeUtils.getZone(dateTimeZone84);
//        org.joda.time.DateTime dateTime86 = new org.joda.time.DateTime(dateTimeZone85);
//        long long87 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime86);
//        boolean boolean88 = dateTime82.isEqual((org.joda.time.ReadableInstant) dateTime86);
//        org.joda.time.DateTime.Property property89 = dateTime86.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType90 = property89.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField92 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField75, durationField79, dateTimeFieldType90, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField94 = new org.joda.time.field.RemainderDateTimeField(dateTimeField44, durationField55, dateTimeFieldType90, 9);
//        org.joda.time.DateTime.Property property95 = dateTime26.property(dateTimeFieldType90);
//        try {
//            org.joda.time.LocalDate localDate97 = localDate4.withField(dateTimeFieldType90, 4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4681917489887L + "'", long11 == 4681917489887L);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 4681917489887L + "'", long15 == 4681917489887L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2118 + "'", int27 == 2118);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(julianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray40);
//        org.junit.Assert.assertNotNull(dateMidnight41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(buddhistChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 999 + "'", int53 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology54);
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 4681917489893L + "'", long59 == 4681917489893L);
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 4681917489894L + "'", long63 == 4681917489894L);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(dateTimeFieldType66);
//        org.junit.Assert.assertNotNull(gJChronology71);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertNotNull(buddhistChronology73);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 999 + "'", int77 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology78);
//        org.junit.Assert.assertNotNull(durationField79);
//        org.junit.Assert.assertNotNull(dateTimeZone81);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 4681917489901L + "'", long83 == 4681917489901L);
//        org.junit.Assert.assertNotNull(dateTimeZone85);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 4681917489902L + "'", long87 == 4681917489902L);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//        org.junit.Assert.assertNotNull(property89);
//        org.junit.Assert.assertNotNull(dateTimeFieldType90);
//        org.junit.Assert.assertNotNull(property95);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusMonths(292278993);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.days();
        org.joda.time.DurationField durationField4 = gJChronology2.millis();
        org.joda.time.DurationField durationField5 = gJChronology2.months();
        org.joda.time.DurationField durationField6 = gJChronology2.minutes();
        try {
            long long11 = gJChronology2.getDateTimeMillis(0, (-28800000), (int) (short) 1, 292278993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-1));
//        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes(5);
//        boolean boolean14 = dateTime13.isBeforeNow();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField16 = buddhistChronology15.weeks();
//        long long20 = buddhistChronology15.add((long) 1, 1560639109775L, (int) (byte) 1);
//        org.joda.time.DurationField durationField21 = buddhistChronology15.centuries();
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology15.yearOfCentury();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology15);
//        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology15.hourOfDay();
//        org.joda.time.MutableDateTime mutableDateTime25 = dateTime13.toMutableDateTime((org.joda.time.Chronology) buddhistChronology15);
//        org.joda.time.DateTime dateTime27 = dateTime13.plus(3121278292097L);
//        int int28 = dateTime13.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4681917489967L + "'", long3 == 4681917489967L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4681917489968L + "'", long7 == 4681917489968L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560639109776L + "'", long20 == 1560639109776L);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 13 + "'", int28 == 13);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        int int9 = dateTime6.getDayOfMonth();
//        org.joda.time.DateTime dateTime11 = dateTime6.withWeekyear(2019);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4681917490143L + "'", long3 == 4681917490143L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4681917490144L + "'", long7 == 4681917490144L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipUndoDateTimeField7.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder1.appendFixedDecimal(dateTimeFieldType8, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder1.appendLiteral('4');
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withPivotYear((java.lang.Integer) (-1));
        int int17 = dateTimeFormatter16.getDefaultYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter16.withPivotYear((int) (short) 100);
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter19.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter21.withPivotYear((java.lang.Integer) (-1));
        int int24 = dateTimeFormatter23.getDefaultYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter23.withPivotYear((int) (short) 100);
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter26.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter28.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser31 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser33 = dateTimeFormatter32.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray34 = new org.joda.time.format.DateTimeParser[] { dateTimeParser20, dateTimeParser27, dateTimeParser29, dateTimeParser31, dateTimeParser33 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder12.append(dateTimePrinter13, dateTimeParserArray34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder35.appendYearOfCentury(0, 8);
        java.lang.Class<?> wildcardClass39 = dateTimeFormatterBuilder38.getClass();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2000 + "'", int17 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2000 + "'", int24 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeParser31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimeParser33);
        org.junit.Assert.assertNotNull(dateTimeParserArray34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(wildcardClass39);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.LocalDate.Property property5 = localDate4.monthOfYear();
        org.joda.time.LocalDate localDate6 = property5.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate7 = property5.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.days();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.yearOfCentury();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
//        org.joda.time.DateTime.Property property13 = dateTime11.centuryOfEra();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology16);
//        int int19 = dateTime18.getYear();
//        int int20 = property13.getDifference((org.joda.time.ReadableInstant) dateTime18);
//        int int21 = dateTime18.getYear();
//        org.joda.time.DateTime.Property property22 = dateTime18.minuteOfDay();
//        org.joda.time.DateTime.Property property23 = dateTime18.yearOfEra();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4681917490411L + "'", long3 == 4681917490411L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4681917490411L + "'", long7 == 4681917490411L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2118 + "'", int19 == 2118);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2118 + "'", int21 == 2118);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(property23);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField8 = buddhistChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        org.joda.time.Chronology chronology13 = buddhistChronology7.withZone(dateTimeZone11);
        org.joda.time.Chronology chronology14 = gJChronology2.withZone(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology2.weekOfWeekyear();
        try {
            long long23 = gJChronology2.getDateTimeMillis(0, 5, 2068, 18, 57120, 13, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57120 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", false);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusHours((-28800000));
//        org.joda.time.DateTime dateTime10 = dateTime6.minusHours(18);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime22 = property20.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
//        org.joda.time.DateTime.Property property24 = dateTime22.centuryOfEra();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25, readableInstant26);
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.year();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology27);
//        int int30 = dateTime29.getYear();
//        int int31 = property24.getDifference((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.DateTime dateTime32 = dateTime29.withEarlierOffsetAtOverlap();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.hourMinute();
//        boolean boolean34 = dateTimeFormatter33.isParser();
//        boolean boolean35 = dateTimeFormatter33.isParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter33.withZoneUTC();
//        java.lang.String str37 = dateTime29.toString(dateTimeFormatter36);
//        int int38 = dateTime10.compareTo((org.joda.time.ReadableInstant) dateTime29);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917490560L + "'", long14 == 4681917490560L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917490560L + "'", long18 == 4681917490560L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2118 + "'", int30 == 2118);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "20:38" + "'", str37.equals("20:38"));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ');
        int int5 = dateTime4.getMinuteOfHour();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime4, 3);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
        org.joda.time.Chronology chronology7 = gJChronology2.withUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology2);
        org.joda.time.LocalDateTime localDateTime9 = dateTime8.toLocalDateTime();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDateTime9);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.DateMidnight dateMidnight6 = localDate4.toDateMidnight();
        org.joda.time.DateTime dateTime7 = localDate4.toDateTimeAtMidnight();
        org.joda.time.DateTime dateTime9 = dateTime7.withMillis(1560639112800L);
        int int10 = dateTime9.getMinuteOfHour();
        int int11 = dateTime9.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 51 + "'", int10 == 51);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", false);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime4.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMinuteOfHour(8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Pacific Daylight Time", "1969", 3, (int) (byte) 1);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long9 = fixedDateTimeZone4.previousTransition(4681917482296L);
        java.util.TimeZone timeZone10 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4681917482296L + "'", long9 == 4681917482296L);
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder2.toDateTimeZone("", false);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfDay((int) (short) 1);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dividedDateTimeField23.getAsText(0, locale25);
//        org.joda.time.DurationField durationField27 = dividedDateTimeField23.getRangeDurationField();
//        int int28 = dividedDateTimeField23.getMaximumValue();
//        int int30 = dividedDateTimeField23.getMinimumValue(1560639134665L);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone33);
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone33);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray36 = localDate35.getFieldTypes();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.ReadableInstant readableInstant38 = null;
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
//        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology41.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField43 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology39, dateTimeField42);
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeUtils.getZone(dateTimeZone45);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone46);
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone46);
//        org.joda.time.LocalDate.Property property49 = localDate48.monthOfYear();
//        int int50 = localDate48.size();
//        org.joda.time.LocalDate localDate52 = localDate48.withYear(51);
//        int[] intArray54 = gJChronology39.get((org.joda.time.ReadablePartial) localDate48, 1560639134593L);
//        int int55 = dividedDateTimeField23.getMaximumValue((org.joda.time.ReadablePartial) localDate35, intArray54);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField56 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField23);
//        long long58 = remainderDateTimeField56.roundHalfCeiling(1560639135154L);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917491117L + "'", long14 == 4681917491117L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917491118L + "'", long18 == 4681917491118L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray36);
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(buddhistChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 3 + "'", int50 == 3);
//        org.junit.Assert.assertNotNull(localDate52);
//        org.junit.Assert.assertNotNull(intArray54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560639135154L + "'", long58 == 1560639135154L);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.LocalDate.Property property5 = localDate4.monthOfYear();
        org.joda.time.LocalDate localDate6 = property5.withMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property5.getFieldType();
        int int8 = property5.get();
        org.joda.time.LocalDate localDate9 = property5.roundCeilingCopy();
        org.joda.time.LocalDate localDate10 = property5.roundHalfFloorCopy();
        org.joda.time.LocalDate.Property property11 = localDate10.era();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withLocale(locale3);
        java.lang.StringBuffer stringBuffer5 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer5, 3121278293400L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.LocalDate.Property property5 = localDate4.monthOfYear();
        org.joda.time.LocalDate localDate6 = property5.withMaximumValue();
        org.joda.time.DateTimeField dateTimeField7 = property5.getField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField10 = buddhistChronology9.seconds();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime.Property property20 = dateTime17.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property20.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField23 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, durationField10, dateTimeFieldType21, 2000);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField25 = buddhistChronology24.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField25);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField26.getType();
//        org.joda.time.DurationField durationField28 = unsupportedDateTimeField26.getRangeDurationField();
//        org.joda.time.DurationField durationField29 = unsupportedDateTimeField26.getDurationField();
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4681917491419L + "'", long14 == 4681917491419L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917491419L + "'", long18 == 4681917491419L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(buddhistChronology24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNull(durationField28);
//        org.junit.Assert.assertNotNull(durationField29);
//    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
//        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
//        org.joda.time.LocalDate.Property property5 = localDate4.monthOfYear();
//        org.joda.time.LocalDate localDate6 = property5.withMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property5.getFieldType();
//        int int8 = property5.get();
//        org.joda.time.LocalDate localDate9 = property5.roundCeilingCopy();
//        java.lang.String str10 = property5.getName();
//        org.joda.time.Instant instant12 = new org.joda.time.Instant(1560639118264L);
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.Instant instant14 = instant12.minus(readableDuration13);
//        int int15 = property5.compareTo((org.joda.time.ReadableInstant) instant14);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        long long19 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
//        long long23 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime22);
//        boolean boolean24 = dateTime18.isEqual((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTime.Property property25 = dateTime22.millisOfSecond();
//        org.joda.time.DateTime dateTime27 = property25.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate28 = dateTime27.toLocalDate();
//        org.joda.time.DateTime.Property property29 = dateTime27.centuryOfEra();
//        org.joda.time.DateTime dateTime30 = property29.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime32 = dateTime30.withYearOfEra(3);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendDayOfYear(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder33.appendMillisOfDay((int) (short) 100);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap38 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap38);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder37.appendTimeZoneShortName(strMap38);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatterBuilder40.toFormatter();
//        java.lang.String str42 = dateTime32.toString(dateTimeFormatter41);
//        org.joda.time.Instant instant43 = dateTime32.toInstant();
//        int int44 = property5.getDifference((org.joda.time.ReadableInstant) dateTime32);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "monthOfYear" + "'", str10.equals("monthOfYear"));
//        org.junit.Assert.assertNotNull(instant14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 4681917491563L + "'", long19 == 4681917491563L);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 4681917491564L + "'", long23 == 4681917491564L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(strMap38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000+00:00" + "'", str42.equals("10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000+00:00"));
//        org.junit.Assert.assertNotNull(instant43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 24197 + "'", int44 == 24197);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt(4681917479260L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 4681917479260");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", false);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusHours((-28800000));
        org.joda.time.DateTime dateTime10 = dateTime8.minusMillis((int) (short) 0);
        org.joda.time.Chronology chronology11 = dateTime8.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime2.toMutableDateTimeISO();
//        java.util.Locale locale5 = null;
//        java.util.Calendar calendar6 = dateTime2.toCalendar(locale5);
//        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.fromCalendarFields(calendar6);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendEraText();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.ReadableInstant readableInstant12 = null;
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, readableInstant12);
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology10, dateTimeField14);
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = skipUndoDateTimeField15.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder9.appendFraction(dateTimeFieldType16, 20, 0);
//        org.joda.time.LocalDate localDate21 = localDate7.withField(dateTimeFieldType16, 0);
//        org.joda.time.LocalDate.Property property22 = localDate21.dayOfWeek();
//        try {
//            org.joda.time.LocalDate localDate24 = localDate21.withMonthOfYear((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4681917491964L + "'", long3 == 4681917491964L);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(calendar6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(property22);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField4);
        long long8 = skipUndoDateTimeField5.add((long) (short) 10, (long) (short) 10);
        boolean boolean9 = skipUndoDateTimeField5.isSupported();
        long long12 = skipUndoDateTimeField5.set((long) 10, (int) (short) 10);
        int int14 = skipUndoDateTimeField5.getMinimumValue(1560639114556L);
        int int16 = skipUndoDateTimeField5.get(1560639116927L);
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipUndoDateTimeField5.getAsText(0L, locale18);
        long long22 = skipUndoDateTimeField5.add(1560639147683L, 0L);
        java.lang.String str23 = skipUndoDateTimeField5.getName();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 315532800010L + "'", long8 == 315532800010L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61851772799990L) + "'", long12 == (-61851772799990L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292275054) + "'", int14 == (-292275054));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970" + "'", str19.equals("1970"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560639147683L + "'", long22 == 1560639147683L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "year" + "'", str23.equals("year"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        java.lang.String str4 = dateTimeZone3.toString();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology6 = buddhistChronology5.withUTC();
        try {
            org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((int) (byte) 1, 80, 133, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 80 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear(12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendClockhourOfHalfday(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Pacific Daylight Time", "1969", 3, (int) (byte) 1);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey(3121278300971L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(4681917484466L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test289");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
//        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology3.era();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField19);
//        int int22 = skipUndoDateTimeField20.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField24 = buddhistChronology23.seconds();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        long long28 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime31);
//        boolean boolean33 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime.Property property34 = dateTime31.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, durationField24, dateTimeFieldType35, 2000);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField43);
//        int int46 = skipUndoDateTimeField44.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField48 = buddhistChronology47.seconds();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
//        long long52 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        long long56 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime55);
//        boolean boolean57 = dateTime51.isEqual((org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DateTime.Property property58 = dateTime55.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField44, durationField48, dateTimeFieldType59, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, durationField24, dateTimeFieldType59, 9);
//        long long65 = remainderDateTimeField63.roundFloor(3121278248046166L);
//        int int67 = remainderDateTimeField63.get((-61820237221990L));
//        int int69 = remainderDateTimeField63.getLeapAmount((long) (-3368));
//        int int72 = remainderDateTimeField63.getDifference(4681917483392L, 3121278299570L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = null;
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField74 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField63, dateTimeFieldType73);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 4681917492044L + "'", long28 == 4681917492044L);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4681917492045L + "'", long32 == 4681917492045L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 999 + "'", int46 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 4681917492055L + "'", long52 == 4681917492055L);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 4681917492056L + "'", long56 == 4681917492056L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 3121278192000000L + "'", long65 == 3121278192000000L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 3 + "'", int67 == 3);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 18062 + "'", int72 == 18062);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        int int6 = localDate4.getEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate4.withPeriodAdded(readablePeriod7, (-292275054));
        int int10 = localDate4.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.LocalDate localDate7 = localDate4.withWeekOfWeekyear(10);
        int int8 = localDate4.getWeekyear();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("", false);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        org.joda.time.DateTime dateTime15 = localDate4.toDateTimeAtCurrentTime(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime15.withDayOfWeek(7);
        org.joda.time.DateTime dateTime19 = dateTime15.plusWeeks((int) '4');
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("662", "UTC");
        illegalFieldValueException2.prependMessage("444");
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone6);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate8.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight10 = localDate8.toDateMidnight();
//        boolean boolean11 = julianChronology3.equals((java.lang.Object) localDate8);
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology3.era();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology3.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField19);
//        int int22 = skipUndoDateTimeField20.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField24 = buddhistChronology23.seconds();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        long long28 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime31);
//        boolean boolean33 = dateTime27.isEqual((org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.DateTime.Property property34 = dateTime31.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, durationField24, dateTimeFieldType35, 2000);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, readableInstant39);
//        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField44 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField43);
//        int int46 = skipUndoDateTimeField44.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField48 = buddhistChronology47.seconds();
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone50);
//        long long52 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.DateTimeZone dateTimeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone54);
//        long long56 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime55);
//        boolean boolean57 = dateTime51.isEqual((org.joda.time.ReadableInstant) dateTime55);
//        org.joda.time.DateTime.Property property58 = dateTime55.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField44, durationField48, dateTimeFieldType59, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, durationField24, dateTimeFieldType59, 9);
//        long long65 = remainderDateTimeField63.roundHalfCeiling(1560639137433L);
//        long long67 = remainderDateTimeField63.roundHalfCeiling(3121278303636L);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 999 + "'", int22 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 4681917492257L + "'", long28 == 4681917492257L);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 4681917492258L + "'", long32 == 4681917492258L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 999 + "'", int46 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 4681917492260L + "'", long52 == 4681917492260L);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 4681917492260L + "'", long56 == 4681917492260L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560643200000L + "'", long65 == 1560643200000L);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 3121286400000L + "'", long67 == 3121286400000L);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 74285);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 74285 + "'", int1 == 74285);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField1 = buddhistChronology0.seconds();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField7);
//        int int10 = skipUndoDateTimeField8.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
//        long long16 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
//        long long20 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime19);
//        boolean boolean21 = dateTime15.isEqual((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime.Property property22 = dateTime19.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField25 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, durationField12, dateTimeFieldType23, 2000);
//        boolean boolean26 = buddhistChronology0.equals((java.lang.Object) dateTimeFieldType23);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 14313129056L, (java.lang.Number) 999, (java.lang.Number) 3121278291256L);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 999 + "'", int10 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 4681917492611L + "'", long16 == 4681917492611L);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 4681917492611L + "'", long20 == 4681917492611L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.LocalDate.Property property5 = localDate4.monthOfYear();
        int int6 = localDate4.size();
        org.joda.time.LocalDate localDate8 = localDate4.withYear(51);
        int int9 = localDate8.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.DateMidnight dateMidnight6 = localDate4.toDateMidnight();
        org.joda.time.DateTime dateTime7 = localDate4.toDateTimeAtMidnight();
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime dateTime10 = dateTime7.minusSeconds(15);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths(49073);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        org.joda.time.DateMidnight dateMidnight6 = localDate4.toDateMidnight();
        org.joda.time.DateTime dateTime7 = localDate4.toDateTimeAtMidnight();
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate4);
        org.joda.time.LocalDate.Property property9 = localDate4.weekyear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField2 = buddhistChronology1.weeks();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(1560639114555L, (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology1.weekOfWeekyear();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", false);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfDay((int) (short) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours((-28800000));
        boolean boolean14 = buddhistChronology1.equals((java.lang.Object) dateTime11);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology4.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField5);
//        int int8 = skipUndoDateTimeField6.getMaximumValue(0L);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone11);
//        org.joda.time.LocalDate.Property property14 = localDate13.monthOfYear();
//        boolean boolean15 = property14.isLeap();
//        org.joda.time.LocalDate localDate16 = property14.roundCeilingCopy();
//        int int17 = localDate16.getYear();
//        int int18 = skipUndoDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate16);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone21 = dateTime20.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone21);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone25);
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone25);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray28 = localDate27.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight29 = localDate27.toDateMidnight();
//        boolean boolean30 = julianChronology22.equals((java.lang.Object) localDate27);
//        org.joda.time.DateTimeField dateTimeField31 = julianChronology22.era();
//        org.joda.time.DateTimeField dateTimeField32 = julianChronology22.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.ReadableInstant readableInstant34 = null;
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33, readableInstant34);
//        org.joda.time.DateTimeField dateTimeField36 = gJChronology35.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField38 = buddhistChronology37.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology35, dateTimeField38);
//        int int41 = skipUndoDateTimeField39.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField43 = buddhistChronology42.seconds();
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeUtils.getZone(dateTimeZone44);
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(dateTimeZone45);
//        long long47 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime46);
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeUtils.getZone(dateTimeZone48);
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime(dateTimeZone49);
//        long long51 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime50);
//        boolean boolean52 = dateTime46.isEqual((org.joda.time.ReadableInstant) dateTime50);
//        org.joda.time.DateTime.Property property53 = dateTime50.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property53.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField56 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField39, durationField43, dateTimeFieldType54, 2000);
//        org.joda.time.DateTimeZone dateTimeZone57 = null;
//        org.joda.time.ReadableInstant readableInstant58 = null;
//        org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone57, readableInstant58);
//        org.joda.time.DateTimeField dateTimeField60 = gJChronology59.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology61 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField62 = buddhistChronology61.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField63 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology59, dateTimeField62);
//        int int65 = skipUndoDateTimeField63.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology66 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField67 = buddhistChronology66.seconds();
//        org.joda.time.DateTimeZone dateTimeZone68 = null;
//        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeUtils.getZone(dateTimeZone68);
//        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime(dateTimeZone69);
//        long long71 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime70);
//        org.joda.time.DateTimeZone dateTimeZone72 = null;
//        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeUtils.getZone(dateTimeZone72);
//        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime(dateTimeZone73);
//        long long75 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime74);
//        boolean boolean76 = dateTime70.isEqual((org.joda.time.ReadableInstant) dateTime74);
//        org.joda.time.DateTime.Property property77 = dateTime74.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType78 = property77.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField80 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField63, durationField67, dateTimeFieldType78, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField82 = new org.joda.time.field.RemainderDateTimeField(dateTimeField32, durationField43, dateTimeFieldType78, 9);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField84 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField6, dateTimeFieldType78, 9);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 999 + "'", int8 == 999);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 999 + "'", int18 == 999);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(julianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray28);
//        org.junit.Assert.assertNotNull(dateMidnight29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(buddhistChronology37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 999 + "'", int41 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology42);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 4681917492988L + "'", long47 == 4681917492988L);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 4681917492988L + "'", long51 == 4681917492988L);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertNotNull(gJChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(buddhistChronology61);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 999 + "'", int65 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology66);
//        org.junit.Assert.assertNotNull(durationField67);
//        org.junit.Assert.assertNotNull(dateTimeZone69);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 4681917492991L + "'", long71 == 4681917492991L);
//        org.junit.Assert.assertNotNull(dateTimeZone73);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 4681917492991L + "'", long75 == 4681917492991L);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
//        org.junit.Assert.assertNotNull(property77);
//        org.junit.Assert.assertNotNull(dateTimeFieldType78);
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant4);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.year();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = skipUndoDateTimeField7.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder1.appendFraction(dateTimeFieldType8, 20, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder1.appendSecondOfMinute(57120);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendMonthOfYearText();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
//        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime21);
//        boolean boolean23 = dateTime17.isEqual((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime.Property property24 = dateTime21.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) 1560639129829L, "-1");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder14.appendDecimal(dateTimeFieldType25, 99, 0);
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder14.appendHourOfHalfday((-28800000));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 4681917493920L + "'", long18 == 4681917493920L);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 4681917493920L + "'", long22 == 4681917493920L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField2 = buddhistChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
        org.joda.time.Chronology chronology7 = buddhistChronology1.withZone(dateTimeZone5);
        java.lang.String str8 = dateTimeZone5.getID();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) 100.0f, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Float");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeField[] dateTimeFieldArray5 = localDate4.getFields();
        int int6 = localDate4.getEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.LocalDate localDate9 = localDate4.withPeriodAdded(readablePeriod7, (-292275054));
        org.joda.time.LocalDate.Property property10 = localDate4.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField4);
        long long8 = skipUndoDateTimeField5.add((long) (short) 10, (long) (short) 10);
        boolean boolean9 = skipUndoDateTimeField5.isSupported();
        long long12 = skipUndoDateTimeField5.add(4681917486088L, 0);
        long long14 = skipUndoDateTimeField5.roundHalfFloor(1560639136799L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 315532800010L + "'", long8 == 315532800010L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 4681917486088L + "'", long12 == 4681917486088L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546300800000L + "'", long14 == 1546300800000L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        try {
            org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 12");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 7);
        org.joda.time.DurationField durationField5 = copticChronology4.hours();
        org.joda.time.DurationField durationField6 = copticChronology4.eras();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.year();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField5 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField4);
        long long8 = skipUndoDateTimeField5.add((long) (short) 10, (long) (short) 10);
        boolean boolean9 = skipUndoDateTimeField5.isSupported();
        long long12 = skipUndoDateTimeField5.set((long) 10, (int) (short) 10);
        int int14 = skipUndoDateTimeField5.getMinimumValue(1560639114556L);
        int int16 = skipUndoDateTimeField5.get(1560639116927L);
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipUndoDateTimeField5.getAsText(0L, locale18);
        boolean boolean20 = skipUndoDateTimeField5.isLenient();
        org.joda.time.DurationField durationField21 = skipUndoDateTimeField5.getDurationField();
        int int22 = skipUndoDateTimeField5.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 315532800010L + "'", long8 == 315532800010L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61851772799990L) + "'", long12 == (-61851772799990L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-292275054) + "'", int14 == (-292275054));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970" + "'", str19.equals("1970"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-292269054) + "'", int22 == (-292269054));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = cachedDateTimeZone5.getUncachedZone();
        boolean boolean7 = cachedDateTimeZone5.isFixed();
        java.lang.String str9 = cachedDateTimeZone5.getNameKey((long) 999);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        java.lang.Object obj11 = null;
        boolean boolean12 = copticChronology10.equals(obj11);
        org.joda.time.Chronology chronology13 = copticChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology10.millisOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone2);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray5 = localDate4.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone8);
        org.joda.time.DateTimeField[] dateTimeFieldArray11 = localDate10.getFields();
        int int12 = localDate10.getEra();
        org.joda.time.LocalDate localDate14 = localDate10.withYearOfEra((int) ' ');
        org.joda.time.LocalDate.Property property15 = localDate10.weekOfWeekyear();
        org.joda.time.LocalDate.Property property16 = localDate10.yearOfCentury();
        int int17 = localDate4.compareTo((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.LocalDate localDate19 = localDate4.withWeekOfWeekyear((int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeFieldArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(localDate19);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
//        boolean boolean8 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-1));
//        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
//        org.joda.time.DateTime.Property property13 = dateTime11.centuryOfEra();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.year();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology16);
//        int int19 = dateTime18.getYear();
//        int int20 = property13.getDifference((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime22 = dateTime18.withMillisOfSecond(4);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((-1L));
//        org.joda.time.DateTimeZone dateTimeZone25 = dateTime24.getZone();
//        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone29);
//        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate(1560639109776L, dateTimeZone29);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray32 = localDate31.getFieldTypes();
//        org.joda.time.DateMidnight dateMidnight33 = localDate31.toDateMidnight();
//        boolean boolean34 = julianChronology26.equals((java.lang.Object) localDate31);
//        org.joda.time.DateTimeField dateTimeField35 = julianChronology26.era();
//        org.joda.time.DateTimeField dateTimeField36 = julianChronology26.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.ReadableInstant readableInstant38 = null;
//        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, readableInstant38);
//        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology41.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField43 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology39, dateTimeField42);
//        int int45 = skipUndoDateTimeField43.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField47 = buddhistChronology46.seconds();
//        org.joda.time.DateTimeZone dateTimeZone48 = null;
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeUtils.getZone(dateTimeZone48);
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime(dateTimeZone49);
//        long long51 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime50);
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeUtils.getZone(dateTimeZone52);
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone53);
//        long long55 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime54);
//        boolean boolean56 = dateTime50.isEqual((org.joda.time.ReadableInstant) dateTime54);
//        org.joda.time.DateTime.Property property57 = dateTime54.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = property57.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField60 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField43, durationField47, dateTimeFieldType58, 2000);
//        org.joda.time.DateTimeZone dateTimeZone61 = null;
//        org.joda.time.ReadableInstant readableInstant62 = null;
//        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone61, readableInstant62);
//        org.joda.time.DateTimeField dateTimeField64 = gJChronology63.year();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology65 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField66 = buddhistChronology65.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField67 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology63, dateTimeField66);
//        int int69 = skipUndoDateTimeField67.getMaximumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology70 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField71 = buddhistChronology70.seconds();
//        org.joda.time.DateTimeZone dateTimeZone72 = null;
//        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeUtils.getZone(dateTimeZone72);
//        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime(dateTimeZone73);
//        long long75 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime74);
//        org.joda.time.DateTimeZone dateTimeZone76 = null;
//        org.joda.time.DateTimeZone dateTimeZone77 = org.joda.time.DateTimeUtils.getZone(dateTimeZone76);
//        org.joda.time.DateTime dateTime78 = new org.joda.time.DateTime(dateTimeZone77);
//        long long79 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime78);
//        boolean boolean80 = dateTime74.isEqual((org.joda.time.ReadableInstant) dateTime78);
//        org.joda.time.DateTime.Property property81 = dateTime78.millisOfSecond();
//        org.joda.time.DateTimeFieldType dateTimeFieldType82 = property81.getFieldType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField84 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField67, durationField71, dateTimeFieldType82, 2000);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField86 = new org.joda.time.field.RemainderDateTimeField(dateTimeField36, durationField47, dateTimeFieldType82, 9);
//        org.joda.time.DateTime.Property property87 = dateTime18.property(dateTimeFieldType82);
//        org.joda.time.DateTime dateTime88 = property87.roundHalfEvenCopy();
//        int int89 = dateTime88.getYear();
//        org.joda.time.MutableDateTime mutableDateTime90 = dateTime88.toMutableDateTimeISO();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter91 = org.joda.time.format.ISODateTimeFormat.yearMonth();
//        java.lang.String str92 = mutableDateTime90.toString(dateTimeFormatter91);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4681917494188L + "'", long3 == 4681917494188L);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4681917494188L + "'", long7 == 4681917494188L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2118 + "'", int19 == 2118);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(julianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray32);
//        org.junit.Assert.assertNotNull(dateMidnight33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(gJChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(buddhistChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 999 + "'", int45 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 4681917494200L + "'", long51 == 4681917494200L);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 4681917494201L + "'", long55 == 4681917494201L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertNotNull(gJChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(buddhistChronology65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 999 + "'", int69 == 999);
//        org.junit.Assert.assertNotNull(buddhistChronology70);
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertNotNull(dateTimeZone73);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 4681917494204L + "'", long75 == 4681917494204L);
//        org.junit.Assert.assertNotNull(dateTimeZone77);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 4681917494204L + "'", long79 == 4681917494204L);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
//        org.junit.Assert.assertNotNull(property81);
//        org.junit.Assert.assertNotNull(dateTimeFieldType82);
//        org.junit.Assert.assertNotNull(property87);
//        org.junit.Assert.assertNotNull(dateTime88);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 2118 + "'", int89 == 2118);
//        org.junit.Assert.assertNotNull(mutableDateTime90);
//        org.junit.Assert.assertNotNull(dateTimeFormatter91);
//        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "2118-05" + "'", str92.equals("2118-05"));
//    }
//}

